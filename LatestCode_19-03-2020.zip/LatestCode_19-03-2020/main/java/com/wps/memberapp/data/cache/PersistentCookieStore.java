package com.wps.memberapp.data.cache;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import android.util.Log;

import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.CookieStore;
import java.net.HttpCookie;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import androidx.annotation.NonNull;

/**
 * This class is used for session management via cookies
 */
public class PersistentCookieStore implements CookieStore {

    private static final String LOG_TAG = "PersistentCookieStore";
    private static final String COOKIE_PREFS = "CookiePrefsFile";
    private static final String COOKIE_NAME_PREFIX = "cookie_";
    @NonNull
    private final HashMap<String, ConcurrentHashMap<String, HttpCookie>> mCookies;
    private final SharedPreferences mCookiePrefs;


    /**
     * Construct a persistent cookie store
     *
     * @param context Context to attach cookie store to
     */
    public PersistentCookieStore(Context context) {
        mCookiePrefs = context.getSharedPreferences(COOKIE_PREFS, 0);
        mCookies = new HashMap<>();
    }

    @Override
    public void add(@NonNull URI uri, @NonNull HttpCookie cookie) {
        ConcurrentHashMap<String, HttpCookie> cookieMap = mCookies.get(uri.getHost());
        if (cookieMap == null) {
            return;
        }
        String name = getCookieToken(cookie);
        // Save cookie into local store, or remove if expired
        if (!cookie.hasExpired()) {
            if (!mCookies.containsKey(uri.getHost()))
                mCookies.put(uri.getHost(), new ConcurrentHashMap<>());
            cookieMap.put(name, cookie);
        } else {
            if (mCookies.containsKey(uri.toString()))
                cookieMap.remove(name);
        }

        // Save cookie into persistent store
        SharedPreferences.Editor prefsWriter = mCookiePrefs.edit();
        prefsWriter.putString(uri.getHost(), TextUtils.join(",", cookieMap.keySet()));
        prefsWriter.putString(COOKIE_NAME_PREFIX + name, encodeCookie(new SeriazableHttpCookie(cookie)));
        prefsWriter.apply();

    }

    private String getCookieToken(HttpCookie cookie) {
        return cookie.getName() + cookie.getDomain();
    }

    @NonNull
    @Override
    public List<HttpCookie> get(@NonNull URI uri) {
        ArrayList<HttpCookie> ret = new ArrayList<>();
        ConcurrentHashMap<String, HttpCookie> cookieMap = mCookies.get(uri.getHost());
        if (mCookies.containsKey(uri.getHost()) && cookieMap != null) {
            ret.addAll(cookieMap.values());
        }
        return ret;
    }

    @Override
    public boolean removeAll() {
        SharedPreferences.Editor prefsWriter = mCookiePrefs.edit();
        prefsWriter.clear();
        prefsWriter.apply();
        mCookies.clear();
        return true;
    }

    @Override
    public boolean remove(@NonNull URI uri, @NonNull HttpCookie cookie) {
        ConcurrentHashMap<String, HttpCookie> cookieMap = mCookies.get(uri.getHost());
        if (cookieMap == null) {
            return false;
        }
        String name = getCookieToken(cookie);
        if (mCookies.containsKey(uri.getHost()) && cookieMap.containsKey(name)) {
            cookieMap.remove(name);
            SharedPreferences.Editor prefsWriter = mCookiePrefs.edit();
            if (mCookiePrefs.contains(COOKIE_NAME_PREFIX + name)) {
                prefsWriter.remove(COOKIE_NAME_PREFIX + name);
            }
            prefsWriter.putString(uri.getHost(), TextUtils.join(",", cookieMap.keySet()));
            prefsWriter.apply();
            return true;
        } else {
            return false;
        }
    }

    @NonNull
    @Override
    public List<HttpCookie> getCookies() {
        ArrayList<HttpCookie> ret = new ArrayList<>();
        for (Map.Entry key : mCookies.entrySet()) {
            ConcurrentHashMap<String, HttpCookie> cookieMap = mCookies.get(key.toString());
            if (cookieMap != null) {
                ret.addAll(cookieMap.values());
            }
        }
        return ret;
    }

    @NonNull
    @Override
    public List<URI> getURIs() {
        ArrayList<URI> ret = new ArrayList<>();
        for (String key : mCookies.keySet())
            try {
                ret.add(new URI(key));
            } catch (URISyntaxException e) {
                Logger.d(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
            }
        return ret;
    }

    /**
     * Serializes Cookie object into String
     *
     * @param cookie cookie to be encoded, can be null
     * @return cookie encoded as String
     */

    private String encodeCookie( SeriazableHttpCookie cookie) {
        if (cookie == null)
            return null;
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        try {
            ObjectOutputStream outputStream = new ObjectOutputStream(os);
            outputStream.writeObject(cookie);
        } catch (IOException e) {
            Log.e(LOG_TAG, StringConstants.ERROR);
            return null;
        }

        return byteArrayToHexString(os.toByteArray());
    }

    /**
     * Using some super basic byte array &lt;-&gt; hex conversions so we don't have to rely on any
     * large Base64 libraries. Can be overridden if you like!
     *
     * @param bytes byte array to be converted
     * @return string containing hex values
     */
    private String byteArrayToHexString(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte element : bytes) {
            int v = element & 0xff;
            if (v < 16) {
                sb.append('0');
            }
            sb.append(Integer.toHexString(v));
        }
        return sb.toString().toUpperCase(Locale.US);
    }
}
