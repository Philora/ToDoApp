package com.wps.memberapp.data.cache;

import com.wps.memberapp.data.model.AccountBalance;
import com.wps.memberapp.data.model.AccountBalanceOOP;
import com.wps.memberapp.data.model.AdvanceSearchFilters;
import com.wps.memberapp.data.model.AuthorizationModel;
import com.wps.memberapp.data.model.BenefitUserDetails;
import com.wps.memberapp.data.model.ClaimSummaryModel;
import com.wps.memberapp.data.model.DashboardData;
import com.wps.memberapp.data.model.DemographyData;
import com.wps.memberapp.data.model.GetCityCountry;
import com.wps.memberapp.data.model.GetKnowledgeBase;
import com.wps.memberapp.data.model.GetMemberOOPReponse;
import com.wps.memberapp.data.model.GetProcedureCode;
import com.wps.memberapp.data.model.GetSecureMessagesProvider;
import com.wps.memberapp.data.model.GetTreatmentCost;
import com.wps.memberapp.data.model.Medication;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.model.MemberEligibleInfo;
import com.wps.memberapp.data.model.MemberGroupDetails;
import com.wps.memberapp.data.model.MessageData;
import com.wps.memberapp.data.model.PCPSearchResult;
import com.wps.memberapp.data.model.PlanList;
import com.wps.memberapp.data.model.Portlet;
import com.wps.memberapp.data.model.Provider;
import com.wps.memberapp.data.model.SecureMessage;
import com.wps.memberapp.data.model.UpdatePasswordData;
import com.wps.memberapp.presentation.immunization.fragment.ImmunizationHistoryProvider;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import androidx.annotation.NonNull;


/**
 * This is singleton class to cache profile data and provides helper methods to access the same.
 */

public class ProfileDataCache {

    private static ProfileDataCache sInstance;
    private DashboardData mDashboardData;
    private MemberEligibleInfo mMemberEligibleInfo;
    private List<MemberDetails> mMemberDetails;
    private List<Portlet> mPortletList;
    private List<MemberGroupDetails> mMemberGroupDetails;
    //    private List<BenefitUserDetails> mBenefitUserDetails;
    private BenefitUserDetails mBenefitUserDetails;
    private List<PCPSearchResult> mPcpSearchResult;
    private AccountBalance mAccountBalance;
    private AccountBalanceOOP mAccountBalanceOOP;
    private ClaimSummaryModel mClaimSummary;
    private List<AuthorizationModel> mAuthList;
    private String mBenefitEffectiveDate;
    private String mExternalKey2;
    private String mClaimSearchDays;
    private String mMemberGroupUserDefined;
    private String mClaimNumber;
    private String mEncryptClaimNumber;
    private String mClaimType;
    private String mHashCode;
    private String mAuthNumber;
    private String mMsgID;
    private int mPageID;
    private String param;
    private String mProductCode;
    private String mCoverageEndDate;
    private String mNotificationContent;
    private MessageData mMessageData;
    private String mRequestMessageData;
    private UpdatePasswordData mPasswordData;
    private AdvanceSearchFilters mSearchFilters;
    private List<String> secureMessageSubjectsList;
    private String[] secureMessagesSearchData;
    private DemographyData mDemographyData;
    private List<String> daysList;
    private List<String> medicineList;
    private List<String> noOfTablets;
    private HashMap<String, String> vaccinesList;
    private List<String> idsList;
    private String mMessageBy;
    private String mUserId;
    private String mSearchCity;
    private String mSearchMedicalQuery;
    private String mSearchGroupName;
    private String mSearchSpeciality;
    private String mSearchHospitalAffiliation;
    private int mPageCount;
    private int mRecordCount;
    private int mIdCardPosition;
    private List<String> mLanguageSpokenList;
    private String mSearchCityItemValue;
    private String mTccMedicalItem;
    private String mSearchGroupNameItemValue;
    private String mSearchSpecialityItemValue;
    private String mSearchHospitalAffiliationItemValue;
    private String mProviderType;
    private String mProviderGender;
    private String mProviderLanguage;
    private String mProvMiles;
    private String mTccMiles;
    private String mGeoLat;
    private String mGeoLong;
    private String mFirstName;
    private String mLastName;
    private String mGroupName;
    private String mName;
    private int mProvSearchResults;
    private List<Provider> mPcpProviderList;
    private List<GetProcedureCode> mProcedureCodes;
    private GetMemberOOPReponse mMemberOOPResponse;
    private GetTreatmentCost mTCCResponse;
    // TCC
    private String mDedInNetwork;
    private String mDedOutNetwork;
    private String mOopInNetwork;
    private String mOopOutNetwork;
    private String mProCodeExtraInfo;
    private String mProcCode;
    private String mProviderResults;
    private Boolean mPCPCheck;
    private String mPDFCliamsEOB;
    private String mTypeID;
    private String mSelectedPlan;


    private List<String> mSecMessagesProvider;
    private List<String> mSecMessagesProviderId;
    private List<String> mSecMessagesProviderPCP;
    private List<String> mSecMessagesProviderPCPId;
    private String mProvId;
    private String mFilterResults;
    private int mPersonNumber;
    private Boolean mTCCProcSelected;
    private Boolean mAcceptNewPatients;

    // Change Security Question
    private String mUsername;
    private String mPassword;

    // Change Security Question
    private String questionList;
    private String answerList;

    // Accepting options
    private Boolean mBoardCertification;
    private Boolean mUrgentCareFacility;
    private Boolean mExtendedHours;
    private Boolean mAccredited;
    private Boolean mTelemedicine;
    private Boolean mADAAccessibility;

    // Enhancement 12-02
    private String mSearchClinicItemValue;
    private String mSearchClinic;

    private String mSearchExpertiseItemValue;
    private String mSearchAreaExpertise;


    // Auth&Referral
    private String mPlaceService;
    private String mAuthReferredProvider;
    private String mAuthReferringProvider;

    // Medication Detail Page
    private List<Medication> mMedicationList;
    private int mResPos;

    // Immunization Member List
    private List<String> mImmunizationMemberList;
    private List<ImmunizationHistoryProvider> mProvVaccineList;

    // Secure Message Subject
    private List<String> mMsgSubj;

    // ViewID Card
    private String mSubscriberID;
    private String mGroupId;
    private String mPersonIDNumber;

    // Knowledge Base
    private List<GetKnowledgeBase> mKnowledgeBase;
    private String mKBaseItem;

    // TCC Pharmacy
    private String mStrength;


    /**
     * Factory method to get profile data cache instance
     *
     * @return {@link ProfileDataCache} object
     */
    @NonNull
    public static synchronized ProfileDataCache getInstance() {
        if (sInstance == null) {
            sInstance = new ProfileDataCache();
        }
        return sInstance;
    }

    /**
     * Sets dashboard data object to cache
     *
     * @param dashboardData {@link DashboardData} object
     */

    public void setDashboardData(DashboardData dashboardData) {
        mDashboardData = dashboardData;
    }


    public DashboardData getDashboardData() {
        return mDashboardData;
    }

    /**
     * @return First Name associated with profile else null
     */

    public String getFirstName() {
        if (mDashboardData != null) {
            return mDashboardData.getFirstName();
        }
        return null;
    }

    /**
     * @return Last Name associated with profile else null
     */

    public String getLastName() {
        if (mDashboardData != null) {
            return mDashboardData.getLastName();
        }
        return null;
    }


    public void setmMemberDetails(List<MemberDetails> mMemberDetails) {
        this.mMemberDetails = mMemberDetails;
    }

    public List<MemberDetails> getmMemberDetails() {
        return mMemberDetails;
    }

    /**
     * Clears token cache.
     */
    public void clearCache() {
        mDashboardData = null;
    }

    public MemberEligibleInfo getMemberEligibleInfo() {
        return mMemberEligibleInfo;
    }

    public void setMemberEligibleInfo(MemberEligibleInfo memberEligibleInfo) {
        this.mMemberEligibleInfo = memberEligibleInfo;
    }

    public String getBenefitEffectiveDate() {
        return mBenefitEffectiveDate;
    }

    public void setBenefitEffectiveDate(String mBenefitEffectiveDate) {
        this.mBenefitEffectiveDate = mBenefitEffectiveDate;
    }

    public String getExternalKey2() {
        return mExternalKey2;
    }

    public void setExternalKey2(String mExternalKey2) {
        this.mExternalKey2 = mExternalKey2;
    }

    public String getClaimSearchDays() {
        return mClaimSearchDays;
    }

    public void setClaimSearchDays(String mClaimSearchDays) {
        this.mClaimSearchDays = mClaimSearchDays;
    }

    public String getMemberGroupUserDefined() {
        return mMemberGroupUserDefined;
    }

    public String getHashCode() {
        return mHashCode;
    }

    public void setHashCode(String mHashCode) {
        this.mHashCode = mHashCode;
    }

    public void setMemberGroupUserDefined(String mMemberGroupUserDefined) {
        this.mMemberGroupUserDefined = mMemberGroupUserDefined;
    }

    public List<MemberGroupDetails> getmMemberGroupDetails() {
        return mMemberGroupDetails;
    }

    public void setmMemberGroupDetails(List<MemberGroupDetails> mMemberGroupDetails) {
        this.mMemberGroupDetails = mMemberGroupDetails;
    }


    public int getPageID() {
        return mPageID;
    }

    public void setPageID(int mPageID) {
        this.mPageID = mPageID;
    }

    public String getClaimNumber() {
        return mClaimNumber;
    }

    public void setClaimNumber(String mClaimNumber) {
        this.mClaimNumber = mClaimNumber;
    }

    public String getAuthNumber() {
        return mAuthNumber;
    }

    public void setAuthNumber(String mAuthNumber) {
        this.mAuthNumber = mAuthNumber;
    }

    public AdvanceSearchFilters getSearchFilters() {
        return mSearchFilters;
    }

    public void setSearchFilters(AdvanceSearchFilters mSearchFilters) {
        this.mSearchFilters = mSearchFilters;
    }

    public MessageData getMessageData() {
        return mMessageData;
    }

    public void setMessageData(MessageData mMessageData) {
        this.mMessageData = mMessageData;
    }

    public String getProductCode() {
        return mProductCode;
    }

    public String getCoverageEndDate() {
        return mCoverageEndDate;
    }

    public void setCoverageEndDate(String mCoverageEndDate) {
        this.mCoverageEndDate = mCoverageEndDate;
    }

    public void setProductCode(String mProductCode) {
        this.mProductCode = mProductCode;
    }

    /*public List<BenefitUserDetails> getmBenefitUserDetails() {
        return mBenefitUserDetails;
    }

    public void setmBenefitUserDetails(List<BenefitUserDetails> mBenefitUserDetails) {
        this.mBenefitUserDetails = mBenefitUserDetails;
    }*/

    public BenefitUserDetails getmBenefitUserDetails() {
        return mBenefitUserDetails;
    }

    public void setmBenefitUserDetails(BenefitUserDetails mBenefitUserDetails) {
        this.mBenefitUserDetails = mBenefitUserDetails;
    }

    public void setNotificationContent(String mNotificationContent) {
        this.mNotificationContent = mNotificationContent;
    }

    public String getMsgID() {
        return mMsgID;
    }

    public void setMsgID(String mMsgID) {
        this.mMsgID = mMsgID;
    }

    public String getNotificationContent() {
        return mNotificationContent;
    }

    public String[] getSecureMessagesSearchData() {
        return secureMessagesSearchData;
    }

    public void setSecureMessagesSearchData(String[] secureMessagesSearchData) {
        this.secureMessagesSearchData = secureMessagesSearchData;
    }

    public List<String> getSecureMessageSubjectsList() {
        return secureMessageSubjectsList;
    }

    public void setSecureMessageSubjectsList(List<String> secureMessageSubjectsList) {
        this.secureMessageSubjectsList = secureMessageSubjectsList;
    }

    public UpdatePasswordData getPasswordData() {
        return mPasswordData;
    }

    public void setPasswordData(UpdatePasswordData mPasswordData) {
        this.mPasswordData = mPasswordData;
    }

    public DemographyData getDemographyData() {
        return mDemographyData;
    }

    public void setDemographyData(DemographyData demographyData) {
        this.mDemographyData = demographyData;
    }

    public List<Portlet> getPortletList() {
        return mPortletList;
    }

    public void setPortletList(List<Portlet> mPortletList) {
        this.mPortletList = mPortletList;
    }

    public AccountBalance getAccountBalance() {
        return mAccountBalance;
    }

    public void setAccountBalance(AccountBalance mAccountBalance) {
        this.mAccountBalance = mAccountBalance;
    }

    public AccountBalanceOOP getAccountBalanceOOP() {
        return mAccountBalanceOOP;
    }

    public void setAccountBalanceOOP(AccountBalanceOOP mAccountBalanceOOP) {
        this.mAccountBalanceOOP = mAccountBalanceOOP;
    }

    public ClaimSummaryModel getClaimSummary() {
        return mClaimSummary;
    }

    public void setClaimSummary(ClaimSummaryModel mClaimSummary) {
        this.mClaimSummary = mClaimSummary;
    }

    public String getEncryptClaimNumber() {
        return mEncryptClaimNumber;
    }

    public void setEncryptClaimNumber(String mEncryptClaimNumber) {
        this.mEncryptClaimNumber = mEncryptClaimNumber;
    }

    public String getClaimType() {
        return mClaimType;
    }

    public void setClaimType(String mClaimType) {
        this.mClaimType = mClaimType;
    }

    public String getParam() {
        return param;
    }

    public void setParam(String param) {
        this.param = param;
    }

    public List<String> getDaysList() {
        return daysList;
    }

    public void setDaysList(List<String> daysList) {
        this.daysList = daysList;
    }

    public List<String> getMedicineList() {
        return medicineList;
    }

    public void setMedicineList(List<String> medicineList) {
        this.medicineList = medicineList;
    }

    public List<String> getNoOfTablets() {
        return noOfTablets;
    }

    public void setNoOfTablets(List<String> noOfTablets) {
        this.noOfTablets = noOfTablets;
    }

    public HashMap<String, String> getVaccinesList() {
        return vaccinesList;
    }

    public void setVaccinesList(HashMap<String, String> vaccinesList) {
        this.vaccinesList = vaccinesList;
    }

    public List<String> getIdsList() {
        return idsList;
    }

    public void setIdsList(List<String> idsList) {
        this.idsList = idsList;
    }

    public String getMessageBy() {
        return mMessageBy;
    }

    public void setMessageBy(String mMessageBy) {
        this.mMessageBy = mMessageBy;
    }

    public String getmUserId() {
        return mUserId;
    }

    public void setmUserId(String mUserId) {
        this.mUserId = mUserId;
    }

    public void setSearchCityQueryKeyword(String mSearchCity) {
        this.mSearchCity = mSearchCity;
    }

    public String getSearchCityQueryKeyword() {
        return mSearchCity;
    }

    public int getPageCount() {
        return mPageCount;
    }

    public void setPageCount(int mPageCount) {
        this.mPageCount = mPageCount;
    }

    public int getIdCardPosition() {
        return mIdCardPosition;
    }

    public void setIdCardPosition(int mIdCardPosition) {
        this.mIdCardPosition = mIdCardPosition;
    }

    public List<String> getLanguageSpokenList() {
        return mLanguageSpokenList;
    }

    public void setLanguageSpokenList(List<String> languageSpokenList) {
        this.mLanguageSpokenList = languageSpokenList;
    }

    public String getSearchCityItemValue() {
        return mSearchCityItemValue;
    }

    public void setSearchCityItemValue(String mSearchCityItemValue) {
        this.mSearchCityItemValue = mSearchCityItemValue;
    }

    public String getProviderType() {
        return mProviderType;
    }

    public void setProviderType(String mProviderType) {
        this.mProviderType = mProviderType;
    }

    public String getProviderLanguage() {
        return mProviderLanguage;
    }

    public void setProviderLanguage(String mProviderLanguage) {
        this.mProviderLanguage = mProviderLanguage;
    }

    public String getProvMiles() {
        return mProvMiles;
    }

    public void setProvMiles(String mProvMiles) {
        this.mProvMiles = mProvMiles;
    }

    public String getProviderGender() {
        return mProviderGender;
    }

    public void setProviderGender(String mProviderGender) {
        this.mProviderGender = mProviderGender;
    }

    public List<PCPSearchResult> getPcpSearchResult() {
        return mPcpSearchResult;
    }

    public void setPcpSearchResult(List<PCPSearchResult> mPcpSearchResult) {
        this.mPcpSearchResult = mPcpSearchResult;
    }

    public String getGeoLat() {
        return mGeoLat;
    }

    public void setGeoLat(String mGeoLat) {
        this.mGeoLat = mGeoLat;
    }

    public String getGeoLong() {
        return mGeoLong;
    }

    public void setGeoLong(String mGeoLong) {
        this.mGeoLong = mGeoLong;
    }

    public String getSearchGroupNameItemValue() {
        return mSearchGroupNameItemValue;
    }

    public void setSearchGroupNameItemValue(String mSearchGroupNameItemValue) {
        this.mSearchGroupNameItemValue = mSearchGroupNameItemValue;
    }

    public String getSearchSpecialityItemValue() {
        return mSearchSpecialityItemValue;
    }

    public void setSearchSpecialityItemValue(String mSearchSpecialityItemValue) {
        this.mSearchSpecialityItemValue = mSearchSpecialityItemValue;
    }

    public String getSearchHospitalAffiliationItemValue() {
        return mSearchHospitalAffiliationItemValue;
    }

    public void setSearchHospitalAffiliationItemValue(String mSearchHospitalAffiliationItemValue) {
        this.mSearchHospitalAffiliationItemValue = mSearchHospitalAffiliationItemValue;
    }

    public void setSearchSpecialityQueryKeyword(String searchSpecialityQuery) {
        this.mSearchSpeciality = searchSpecialityQuery;
    }

    public String getSearchSpecialityQueryKeyword() {
        return mSearchSpeciality;
    }

    public void setSearchHospitalAffiliationQueryKeyword(String searchHospitalAffiliationQuery) {
        this.mSearchHospitalAffiliation = searchHospitalAffiliationQuery;
    }

    public String getSearchHospitalAffiliationQueryKeywordKeyword() {
        return mSearchHospitalAffiliation;
    }


    public String getSearchClinicItemValue() {
        return mSearchClinicItemValue;
    }

    public void setSearchClinicItemValue(String mSearchClinicItemValue) {
        this.mSearchClinicItemValue = mSearchClinicItemValue;
    }

    public String getSearchClinicQueryKeyword() {
        return mSearchClinic;
    }

    public void setSearchClinicQueryKeyword(String mSearchClinic) {
        this.mSearchClinic = mSearchClinic;
    }

    public String getSearchExpertiseItemValue() {
        return mSearchExpertiseItemValue;
    }

    public void setSearchExpertiseItemValue(String mSearchExpertiseItemValue) {
        this.mSearchExpertiseItemValue = mSearchExpertiseItemValue;
    }

    public String getSearchAreaExpertiseQueryKeyword() {
        return mSearchAreaExpertise;
    }

    public void setSearchAreaExpertiseQueryKeyword(String mSearchAreaExpertise) {
        this.mSearchAreaExpertise = mSearchAreaExpertise;
    }

    public String getSearchGroupNameQueryKeyword() {
        return mSearchGroupName;
    }

    public void setSearchGroupNameQueryKeyword(String mSearchGroupNameQuery) {
        this.mSearchGroupName = mSearchGroupNameQuery;
    }


    public String getProvFirstName() {
        return mFirstName;
    }

    public void setProvFirstName(String mFirstName) {
        this.mFirstName = mFirstName;
    }

    public String getProvLastName() {
        return mLastName;
    }

    public void setProvLastName(String mLastName) {
        this.mLastName = mLastName;
    }

    public String getProvGroupName() {
        return mGroupName;
    }

    public void setProvGroupName(String mGroupName) {
        this.mGroupName = mGroupName;
    }

    public String getProvName() {
        return mName;
    }

    public void setProvName(String mName) {
        this.mName = mName;
    }

    public int getProvSearchResults() {
        return mProvSearchResults;
    }

    public void setProvSearchResults(int mProvSearchResults) {
        this.mProvSearchResults = mProvSearchResults;
    }

    public List<Provider> getPcpProviderList() {
        return mPcpProviderList;
    }

    public void setPcpProviderList(List<Provider> mPcpProviderList) {
        this.mPcpProviderList = mPcpProviderList;
    }

    public List<GetProcedureCode> getProcedureCodes() {
        return mProcedureCodes;
    }

    public void setProcedureCodes(List<GetProcedureCode> mProcedureCodes) {
        this.mProcedureCodes = mProcedureCodes;
    }

    public GetMemberOOPReponse getMemberOOPReponse() {
        return mMemberOOPResponse;
    }

    public void setMemberOOPReponse(GetMemberOOPReponse mMemberOOPResponse) {
        this.mMemberOOPResponse = mMemberOOPResponse;
    }

    public String getTccMiles() {
        return mTccMiles;
    }

    public void setTccMiles(String mTccMiles) {
        this.mTccMiles = mTccMiles;
    }

    public String getTccMedicalItem() {
        return mTccMedicalItem;
    }

    public void setTccMedicalItem(String mTccMedicalItem) {
        this.mTccMedicalItem = mTccMedicalItem;
    }

    public GetTreatmentCost getTCCResponse() {
        return mTCCResponse;
    }

    public void setTCCResponse(GetTreatmentCost mTCCResponse) {
        this.mTCCResponse = mTCCResponse;
    }

    public String getDedInNetwork() {
        return mDedInNetwork;
    }

    public void setDedInNetwork(String mDedInNetwork) {
        this.mDedInNetwork = mDedInNetwork;
    }

    public String getDedOutNetwork() {
        return mDedOutNetwork;
    }

    public void setDedOutNetwork(String mDedOutNetwork) {
        this.mDedOutNetwork = mDedOutNetwork;
    }

    public String getOopInNetwork() {
        return mOopInNetwork;
    }

    public void setOopInNetwork(String mOopInNetwork) {
        this.mOopInNetwork = mOopInNetwork;
    }

    public String getOopOutNetwork() {
        return mOopOutNetwork;
    }

    public void setOopOutNetwork(String mOopOutNetwork) {
        this.mOopOutNetwork = mOopOutNetwork;
    }

    public String getProcCodeExtraInfo() {
        return mProCodeExtraInfo;
    }

    public void setProcCodeExtraInfo(String mProCodeExtraInfo) {
        this.mProCodeExtraInfo = mProCodeExtraInfo;
    }

    public List<AuthorizationModel> getAuthList() {
        return mAuthList;
    }

    public void setAuthList(List<AuthorizationModel> mAuthList) {
        this.mAuthList = mAuthList;
    }


    public String getProviderResults() {
        return mProviderResults;
    }

    public void setProviderResults(String mProviderResults) {
        this.mProviderResults = mProviderResults;
    }

    public Boolean getPCPCheck() {
        return mPCPCheck;
    }

    public void setPCPCheck(Boolean mPCPCheck) {
        this.mPCPCheck = mPCPCheck;
    }

    public String getPDFCliamsEOB() {
        return mPDFCliamsEOB;
    }

    public void setPDFCliamsEOB(String mPDFCliamsEOB) {
        this.mPDFCliamsEOB = mPDFCliamsEOB;
    }

    public String getTypeID() {
        return mTypeID;
    }

    public void setTypeID(String mTypeID) {
        this.mTypeID = mTypeID;
    }

    public Boolean getAcceptNewPatients() {
        return mAcceptNewPatients;
    }

    public void setAcceptNewPatients(Boolean mAcceptNewPatients) {
        this.mAcceptNewPatients = mAcceptNewPatients;
    }

    public List<String> getSecMessagesProvider() {
        return mSecMessagesProvider;
    }

    public void setSecMessagesProvider(List<String> mSecMessagesProvider) {
        this.mSecMessagesProvider = mSecMessagesProvider;
    }


    public List<String> getSecMessagesProviderPCP() {
        return mSecMessagesProviderPCP;
    }

    public void setSecMessagesProviderPCP(List<String> mSecMessagesProvider) {
        this.mSecMessagesProviderPCP = mSecMessagesProvider;
    }

    public List<String> getSecMessagesProviderId() {
        return mSecMessagesProviderId;
    }

    public void setSecMessagesProviderId(List<String> mSecMessagesProviderId) {
        this.mSecMessagesProviderId = mSecMessagesProviderId;
    }

    public String getProvId() {
        return mProvId;
    }

    public void setProvId(String mProvId) {
        this.mProvId = mProvId;
    }

    public List<String> getSecMessagesProviderPCPId() {
        return mSecMessagesProviderPCPId;
    }

    public void setSecMessagesProviderPCPId(List<String> mSecMessagesProviderPCPId) {
        this.mSecMessagesProviderPCPId = mSecMessagesProviderPCPId;
    }

    public String getFilterResults() {
        return mFilterResults;
    }

    public void setFilterResults(String mFilterResults) {
        this.mFilterResults = mFilterResults;
    }

    public int getPersonNumber() {
        return mPersonNumber;
    }

    public void setPersonNumber(int mPersonNumber) {
        this.mPersonNumber = mPersonNumber;
    }

    public Boolean getTCCProcSelected() {
        return mTCCProcSelected;
    }

    public void setTCCProcSelected(Boolean mTCCProcSelected) {
        this.mTCCProcSelected = mTCCProcSelected;
    }

    public String getSearchMedicalQuery() {
        return mSearchMedicalQuery;
    }

    public void setSearchMedicalQuery(String mSearchMedicalQuery) {
        this.mSearchMedicalQuery = mSearchMedicalQuery;
    }

    public String getSelectedPlan() {
        return mSelectedPlan;
    }

    public void setSelectedPlan(String mSelectedPlan) {
        this.mSelectedPlan = mSelectedPlan;
    }

    public String getProcCode() {
        return mProcCode;
    }

    public void setProcCode(String mProcCode) {
        this.mProcCode = mProcCode;
    }

    public void setConvUsername(String mUsername) {
        this.mUsername = mUsername;
    }

    public String getConvUsername() {
        return mUsername;
    }

    public void setConvPassword(String mCurrentPassword) {
        this.mPassword = mCurrentPassword;
    }

    public String getConvPassword() {
        return mPassword;
    }

    public void setQuestionList(String questionList) {
        this.questionList = questionList;
    }

    public void setAnswerList(String ansList) {
        this.answerList = ansList;
    }

    public String getQuestionList() {
        return questionList;
    }

    public String getAnswerList() {
        return answerList;
    }

    public Boolean getBoardCertification() {
        return mBoardCertification;
    }

    public void setBoardCertification(Boolean mBoardCertification) {
        this.mBoardCertification = mBoardCertification;
    }

    public Boolean getUrgentCareFacility() {
        return mUrgentCareFacility;
    }

    public void setUrgentCareFacility(Boolean mUrgentCareFacility) {
        this.mUrgentCareFacility = mUrgentCareFacility;
    }

    public Boolean getExtendedHours() {
        return mExtendedHours;
    }

    public void setExtendedHours(Boolean mExtendedHours) {
        this.mExtendedHours = mExtendedHours;
    }

    public Boolean getAccredited() {
        return mAccredited;
    }

    public void setAccredited(Boolean mAccredited) {
        this.mAccredited = mAccredited;
    }

    public Boolean getTelemedicine() {
        return mTelemedicine;
    }

    public void setTelemedicine(Boolean mTelemedicine) {
        this.mTelemedicine = mTelemedicine;
    }

    public Boolean getADAAccessibility() {
        return mADAAccessibility;
    }

    public void setADAAccessibility(Boolean mADAAccessibility) {
        this.mADAAccessibility = mADAAccessibility;
    }

    public String getPlaceService() {
        return mPlaceService;
    }

    public void setPlaceService(String mPlaceService) {
        this.mPlaceService = mPlaceService;
    }

    public String getAuthReferringProvider() {
        return mAuthReferringProvider;
    }

    public void setAuthReferringProvider(String mAuthReferringProvider) {
        this.mAuthReferringProvider = mAuthReferringProvider;
    }

    public String getAuthReferredProvider() {
        return mAuthReferredProvider;
    }

    public void setAuthReferredProvider(String mAuthReferredProvider) {
        this.mAuthReferredProvider = mAuthReferredProvider;
    }

    public String getRequestMessageData() {
        return mRequestMessageData;
    }

    public void setRequestMessageData(String mRequestMessageData) {
        this.mRequestMessageData = mRequestMessageData;
    }

    public List<Medication> getMedicationList() {
        return mMedicationList;
    }

    public void setMedicationList(List<Medication> mMedicationList) {
        this.mMedicationList = mMedicationList;
    }

    public void setSecMsgSubject(List<String> mMsgSubj) {
        this.mMsgSubj = mMsgSubj;
    }

    public List<String> getSecMsgSubject() {
        return mMsgSubj;
    }

    public String getSubscriberID() {
        return mSubscriberID;
    }

    public void setSubscriberID(String mSubscriberID) {
        this.mSubscriberID = mSubscriberID;
    }

    public String getGroupId() {
        return mGroupId;
    }

    public void setGroupId(String mGroupId) {
        this.mGroupId = mGroupId;
    }

    public String getPersonIDNumber() {
        return mPersonIDNumber;
    }

    public void setPersonIDNumber(String mPersonIDNumber) {
        this.mPersonIDNumber = mPersonIDNumber;
    }

    public int getSelectedPostion() {
        return mResPos;
    }

    public void setSelectedPostion(int mResPos) {
        this.mResPos = mResPos;
    }

    public List<GetKnowledgeBase> getKnowledgeBase() {
        return mKnowledgeBase;
    }

    public void setKnowledgeBase(List<GetKnowledgeBase> mKnowledgeBase) {
        this.mKnowledgeBase = mKnowledgeBase;
    }

    public String getKBaseItem() {
        return mKBaseItem;
    }

    public void setKBaseItem(String mKBaseItem) {
        this.mKBaseItem = mKBaseItem;
    }

    public String getStrength() {
        return mStrength;
    }

    public void setStrength(String mStrength) {
        this.mStrength = mStrength;
    }
}
