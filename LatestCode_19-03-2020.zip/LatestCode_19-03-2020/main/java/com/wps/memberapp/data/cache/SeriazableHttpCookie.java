package com.wps.memberapp.data.cache;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.HttpCookie;

/**
 * This class is used as a medium for Cookie to store in the cache
 */
public class SeriazableHttpCookie implements Serializable{
    private static final long serialVersionUID = 6374381323722046732L;
    private final transient HttpCookie mCookie;
    private transient HttpCookie mClientCookie;

    SeriazableHttpCookie(HttpCookie mCookie) {
        this.mCookie = mCookie;
    }

    public HttpCookie getCookie() {
        HttpCookie bestCookie = mCookie;
        if (mClientCookie != null) {
            bestCookie = mClientCookie;
        }
        return bestCookie;
    }

    private void writeObject(ObjectOutputStream out) throws IOException {
        out.writeObject(mCookie.getName());
        out.writeObject(mCookie.getValue());
    }

    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        String name = (String) in.readObject();
        String value = (String) in.readObject();
        mClientCookie = new HttpCookie(name, value);
    }
}
