package com.wps.memberapp.data.exception;

public class CipherException extends Exception {
    public CipherException(String s, Exception e){
        super(s);
    }
}
