package com.wps.memberapp.data.exceptions;


import com.wps.memberapp.domain.fitbitauth.authentication.Scope;

import java.util.Collection;
import java.util.Set;


public class MissingScopesException extends FitbitAPIException {

    private Collection<Scope> scopes;

    public MissingScopesException(Set<com.wps.memberapp.domain.fitbitauth.authentication.Scope> scopes) {
        this.scopes = scopes;
    }

    public Collection<Scope> getScopes() {
        return scopes;
    }
}
