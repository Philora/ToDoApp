package com.wps.memberapp.data.exceptions;


public class TokenExpiredException extends FitbitAPIException {
}
