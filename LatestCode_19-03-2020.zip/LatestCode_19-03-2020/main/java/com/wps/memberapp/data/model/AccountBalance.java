package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

import androidx.annotation.NonNull;


public class AccountBalance implements Parcelable {

    
    @SerializedName("BenefitsLimits")
    @Expose
    private final List<BenefitsLimits> mBenefitsLimitList;

    
    @SerializedName("InNetworkIndDeductible")
    @Expose
    private final String mInNetworkIndDeductible;

    
    @SerializedName("InNetworkIndOOP")
    @Expose
    private final String mInNetworkIndOOP;

    
    @SerializedName("InNetworkFamilyDeductible")
    @Expose
    private final String mInNetworkFamilyDeductible;

    
    @SerializedName("InNetworkFamilyOOP")
    @Expose
    private final String mInNetworkFamilyOOP;

    
    @SerializedName("OutNetworkIndDeductible")
    @Expose
    private final String mOutNetworkIndDeductible;

    
    @SerializedName("OutNetworkIndOOP")
    @Expose
    private final String mOutNetworkIndOOP;

    
    @SerializedName("OutNetworkFamilyDeductible")
    @Expose
    private final String mOutNetworkFamilyDeductible;

    
    @SerializedName("OutNetworkFamilyOOP")
    @Expose
    private final String mOutNetworkFamilyOOP;

    
    @SerializedName("InNetworkIndDeductibleSpent")
    @Expose
    private final String mInNetworkIndDeductibleSpent;

    
    @SerializedName("InNetworkIndOOPSpent")
    @Expose
    private final String mInNetworkIndOOPSpent;

    
    @SerializedName("InNetworkFamilyDeductibleSpent")
    @Expose
    private final String mInNetworkFamilyDeductibleSpent;

    
    @SerializedName("InNetworkFamilyOOPSpent")
    @Expose
    private final String mInNetworkFamilyOOPSpent;

    
    @SerializedName("OutNetworkIndDeductibleSpent")
    @Expose
    private final String mOutNetworkIndDeductibleSpent;

    
    @SerializedName("OutNetworkIndOOPSpent")
    @Expose
    private final String mOutNetworkIndOOPSpent;

    
    @SerializedName("OutNetworkFamilyDeductibleSpent")
    @Expose
    private final String mOutNetworkFamilyDeductibleSpent;

    
    @SerializedName("OutNetworkFamilyOOPSpent")
    @Expose
    private final String mOutNetworkFamilyOOPSpent;

    private AccountBalance(Parcel in) {
        mBenefitsLimitList = in.createTypedArrayList(BenefitsLimits.CREATOR);
        mInNetworkIndDeductible = in.readString();
        mInNetworkIndOOP = in.readString();
        mInNetworkFamilyDeductible = in.readString();
        mInNetworkFamilyOOP = in.readString();
        mOutNetworkIndDeductible = in.readString();
        mOutNetworkIndOOP = in.readString();
        mOutNetworkFamilyDeductible = in.readString();
        mOutNetworkFamilyOOP = in.readString();
        mInNetworkIndDeductibleSpent = in.readString();
        mInNetworkIndOOPSpent = in.readString();
        mInNetworkFamilyDeductibleSpent = in.readString();
        mInNetworkFamilyOOPSpent = in.readString();
        mOutNetworkIndDeductibleSpent = in.readString();
        mOutNetworkIndOOPSpent = in.readString();
        mOutNetworkFamilyDeductibleSpent = in.readString();
        mOutNetworkFamilyOOPSpent = in.readString();
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeTypedList(mBenefitsLimitList);
        dest.writeString(mInNetworkIndDeductible);
        dest.writeString(mInNetworkIndOOP);
        dest.writeString(mInNetworkFamilyDeductible);
        dest.writeString(mInNetworkFamilyOOP);
        dest.writeString(mOutNetworkIndDeductible);
        dest.writeString(mOutNetworkIndOOP);
        dest.writeString(mOutNetworkFamilyDeductible);
        dest.writeString(mOutNetworkFamilyOOP);
        dest.writeString(mInNetworkIndDeductibleSpent);
        dest.writeString(mInNetworkIndOOPSpent);
        dest.writeString(mInNetworkFamilyDeductibleSpent);
        dest.writeString(mInNetworkFamilyOOPSpent);
        dest.writeString(mOutNetworkIndDeductibleSpent);
        dest.writeString(mOutNetworkIndOOPSpent);
        dest.writeString(mOutNetworkFamilyDeductibleSpent);
        dest.writeString(mOutNetworkFamilyOOPSpent);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<AccountBalance> CREATOR = new Creator<AccountBalance>() {
        @Override
        public AccountBalance createFromParcel(@NonNull Parcel in) {
            return new AccountBalance(in);
        }

        @Override
        public AccountBalance[] newArray(int size) {
            return new AccountBalance[size];
        }
    };

    
    public String getInNetworkIndDeductible() {
        return mInNetworkIndDeductible;
    }


    
    public String getInNetworkFamilyDeductible() {
        return mInNetworkFamilyDeductible;
    }


    
    public String getOutNetworkIndDeductible() {
        return mOutNetworkIndDeductible;
    }


    
    public String getOutNetworkFamilyDeductible() {
        return mOutNetworkFamilyDeductible;
    }

    
    public String getInNetworkIndDeductibleSpent() {
        return mInNetworkIndDeductibleSpent;
    }


    
    public String getInNetworkFamilyDeductibleSpent() {
        return mInNetworkFamilyDeductibleSpent;
    }


    
    public String getOutNetworkIndDeductibleSpent() {
        return mOutNetworkIndDeductibleSpent;
    }


    
    public String getOutNetworkFamilyDeductibleSpent() {
        return mOutNetworkFamilyDeductibleSpent;
    }

}
