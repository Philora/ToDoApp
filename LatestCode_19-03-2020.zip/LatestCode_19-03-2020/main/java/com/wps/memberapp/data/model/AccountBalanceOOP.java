package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import androidx.annotation.NonNull;


public class AccountBalanceOOP implements Parcelable {

    
    @SerializedName("InNetworkIndOOP")
    @Expose
    private final String mInNetworkIndOOP;

    
    @SerializedName("InNetworkFamilyOOP")
    @Expose
    private final String mInNetworkFamilyOOP;

    
    @SerializedName("OutNetworkIndOOP")
    @Expose
    private final String mOutNetworkIndOOP;

    
    @SerializedName("OutNetworkFamilyOOP")
    @Expose
    private final String mOutNetworkFamilyOOP;

    
    @SerializedName("InNetworkIndOOPSpent")
    @Expose
    private final String mInNetworkIndOOPSpent;

    
    @SerializedName("InNetworkFamilyOOPSpent")
    @Expose
    private final String mInNetworkFamilyOOPSpent;

    
    @SerializedName("OutNetworkIndOOPSpent")
    @Expose
    private final String mOutNetworkIndOOPSpent;

    
    @SerializedName("OutNetworkFamilyOOPSpent")
    @Expose
    private final String mOutNetworkFamilyOOPSpent;

    private AccountBalanceOOP(Parcel in) {
        mInNetworkIndOOP = in.readString();
        mInNetworkFamilyOOP = in.readString();
        mOutNetworkIndOOP = in.readString();
        mOutNetworkFamilyOOP = in.readString();
        mInNetworkIndOOPSpent = in.readString();
        mInNetworkFamilyOOPSpent = in.readString();
        mOutNetworkIndOOPSpent = in.readString();
        mOutNetworkFamilyOOPSpent = in.readString();
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeString(mInNetworkIndOOP);
        dest.writeString(mInNetworkFamilyOOP);
        dest.writeString(mOutNetworkIndOOP);
        dest.writeString(mOutNetworkFamilyOOP);
        dest.writeString(mInNetworkIndOOPSpent);
        dest.writeString(mInNetworkFamilyOOPSpent);
        dest.writeString(mOutNetworkIndOOPSpent);
        dest.writeString(mOutNetworkFamilyOOPSpent);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<AccountBalanceOOP> CREATOR = new Creator<AccountBalanceOOP>() {
        @Override
        public AccountBalanceOOP createFromParcel(@NonNull Parcel in) {
            return new AccountBalanceOOP(in);
        }

        @Override
        public AccountBalanceOOP[] newArray(int size) {
            return new AccountBalanceOOP[size];
        }
    };

    
    public String getInNetworkIndOOP() {
        return mInNetworkIndOOP;
    }

    
    public String getInNetworkFamilyOOP() {
        return mInNetworkFamilyOOP;
    }

    
    public String getOutNetworkIndOOP() {
        return mOutNetworkIndOOP;
    }

    
    public String getOutNetworkFamilyOOP() {
        return mOutNetworkFamilyOOP;
    }

    
    public String getInNetworkIndOOPSpent() {
        return mInNetworkIndOOPSpent;
    }

    
    public String getInNetworkFamilyOOPSpent() {
        return mInNetworkFamilyOOPSpent;
    }

    
    public String getOutNetworkIndOOPSpent() {
        return mOutNetworkIndOOPSpent;
    }

    
    public String getOutNetworkFamilyOOPSpent() {
        return mOutNetworkFamilyOOPSpent;
    }
}
