package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class Address implements Parcelable {

    @SerializedName("Address1")
    @Expose
    private final String mAddress1;

    @SerializedName("Address2")
    @Expose
    private final String mAddress2;

    @SerializedName("AddressType")
    @Expose
    private final String mAddressType;

    @SerializedName("City")
    @Expose
    private final String mCity;

    @SerializedName("State")
    @Expose
    private final String mState;

    @SerializedName("ZipCode")
    @Expose
    private final String mZipCode;

    @SerializedName("County")
    @Expose
    private final String mCounty;

    @SerializedName("PhoneNumber")
    @Expose
    private final String mPhoneNumber;

    @SerializedName("EffectiveDate")
    @Expose
    private final String mEffectiveDate;


    public Address(String mAddress1, String mAddress2, String mAddressType, String mCity, String mState, String mZipCode, String country, String mEffectiveDate, String phoneNumber) {
        super();
        this.mAddress1 = mAddress1;
        this.mAddress2 = mAddress2;
        this.mAddressType = mAddressType;
        this.mCity = mCity;
        this.mState = mState;
        this.mZipCode = mZipCode;
        this.mCounty = country;
        this.mPhoneNumber = phoneNumber;
        this.mEffectiveDate = mEffectiveDate;
    }

    private Address(Parcel in) {
        mAddress1 = in.readString();
        mAddress2 = in.readString();
        mAddressType = in.readString();
        mCity = in.readString();
        mState = in.readString();
        mZipCode = in.readString();
        mCounty = in.readString();
        mPhoneNumber = in.readString();
        mEffectiveDate = in.readString();
    }

    public static final Creator<Address> CREATOR = new Creator<Address>() {
        @Override
        public Address createFromParcel(Parcel in) {
            return new Address(in);
        }

        @Override
        public Address[] newArray(int size) {
            return new Address[size];
        }
    };

    public String getAddress1() {
        return mAddress1;
    }

    public String getAddress2() {
        return mAddress2;
    }

    public String getAddressType() {
        return mAddressType;
    }

    public String getCity() {
        return mCity;
    }

    public String getState() {
        return mState;
    }

    public String getZipCode() {
        return mZipCode;
    }

    public String getCounty() {
        return mCounty;
    }

    public String getPhoneNumber() {
        return mPhoneNumber;
    }

    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(mAddress1);
        parcel.writeString(mAddress2);
        parcel.writeString(mCity);
        parcel.writeString(mState);
        parcel.writeString(mZipCode);
        parcel.writeString(mCounty);
        parcel.writeString(mPhoneNumber);
        parcel.writeString(mEffectiveDate);
    }
}


