package com.wps.memberapp.data.model;

public class AdvanceSearchFilters {
    private String mName;
    private String mStatus;
    private String mNumber;
    private String mStartDate;
    private String mEndDate;
    private String mClaimtype;

    public String getName() {
        return mName;
    }

    public void setName(String mName) {
        this.mName = mName;
    }

    public String getStatus() {
        return mStatus;
    }

    public void setStatus(String mStatus) {
        this.mStatus = mStatus;
    }

    public String getNumber() {
        return mNumber;
    }

    public void setNumber(String mNumber) {
        this.mNumber = mNumber;
    }

    public String getStartDate() {
        return mStartDate;
    }

    public void setStartDate(String mStartDate) {
        this.mStartDate = mStartDate;
    }

    public String getEndDate() {
        return mEndDate;
    }

    public void setEndDate(String mEndDate) {
        this.mEndDate = mEndDate;
    }

    public String getClaimtype() {
        return mClaimtype;
    }

    public void setClaimtype(String mClaimtype) {
        this.mClaimtype = mClaimtype;
    }
}
