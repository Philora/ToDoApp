package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import androidx.annotation.NonNull;

public class AuthDetailMember implements Parcelable {

    @SerializedName("$id")
    @Expose
    private String $id;
    @SerializedName("FirstName")
    @Expose
    private String firstName;
    @SerializedName("LastName")
    @Expose
    private String lastName;
    @SerializedName("CoverageDate")
    @Expose
    private String coverageDate;
    @SerializedName("PlanName")
    @Expose
    private String planName;
    @SerializedName("PaymentDueAmount")
    @Expose
    private Double paymentDueAmount;
    @SerializedName("PremiumAmount")
    @Expose
    private Double premiumAmount;
    @SerializedName("APTCAmount")
    @Expose
    private Double aPTCAmount;
    @SerializedName("DateOfBirth")
    @Expose
    private String dateOfBirth;
    @SerializedName("AGE")
    @Expose
    private Integer aGE;
    @SerializedName("Gender")
    @Expose
    private String gender;
    @SerializedName("IsTobaccoUser")
    @Expose
    private Boolean isTobaccoUser;
    @SerializedName("FMSSeqMemberId")
    @Expose
    private Integer fMSSeqMemberId;
    @SerializedName("DOB")
    @Expose
    private String dOB;
    @SerializedName("Encrypted_PersonNumber")
    @Expose
    private Object encryptedPersonNumber;


    public static final Parcelable.Creator<AuthDetailMember> CREATOR = new Parcelable.Creator<AuthDetailMember>() {
        @Override
        public AuthDetailMember createFromParcel(@NonNull Parcel in) {
            return new AuthDetailMember(in);
        }

        @Override
        public AuthDetailMember[] newArray(int size) {
            return new AuthDetailMember[size];
        }
    };

    public AuthDetailMember(Parcel in) {
    }

    public String get$id() {
        return $id;
    }

    public void set$id(String $id) {
        this.$id = $id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getCoverageDate() {
        return coverageDate;
    }

    public void setCoverageDate(String coverageDate) {
        this.coverageDate = coverageDate;
    }

    public String getPlanName() {
        return planName;
    }

    public void setPlanName(String planName) {
        this.planName = planName;
    }

    public Double getPaymentDueAmount() {
        return paymentDueAmount;
    }

    public void setPaymentDueAmount(Double paymentDueAmount) {
        this.paymentDueAmount = paymentDueAmount;
    }

    public Double getPremiumAmount() {
        return premiumAmount;
    }

    public void setPremiumAmount(Double premiumAmount) {
        this.premiumAmount = premiumAmount;
    }

    public Double getAPTCAmount() {
        return aPTCAmount;
    }

    public void setAPTCAmount(Double aPTCAmount) {
        this.aPTCAmount = aPTCAmount;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public Integer getAGE() {
        return aGE;
    }

    public void setAGE(Integer aGE) {
        this.aGE = aGE;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Boolean getIsTobaccoUser() {
        return isTobaccoUser;
    }

    public void setIsTobaccoUser(Boolean isTobaccoUser) {
        this.isTobaccoUser = isTobaccoUser;
    }

    public Integer getFMSSeqMemberId() {
        return fMSSeqMemberId;
    }

    public void setFMSSeqMemberId(Integer fMSSeqMemberId) {
        this.fMSSeqMemberId = fMSSeqMemberId;
    }

    public String getDOB() {
        return dOB;
    }

    public void setDOB(String dOB) {
        this.dOB = dOB;
    }

    public Object getEncryptedPersonNumber() {
        return encryptedPersonNumber;
    }

    public void setEncryptedPersonNumber(Object encryptedPersonNumber) {
        this.encryptedPersonNumber = encryptedPersonNumber;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(firstName);
        parcel.writeString(lastName);
        parcel.writeString(gender);
        parcel.writeString(dateOfBirth);
        parcel.writeString(planName);
    }

}
