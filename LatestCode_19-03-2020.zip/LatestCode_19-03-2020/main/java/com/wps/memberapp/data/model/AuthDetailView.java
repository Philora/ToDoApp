package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

import androidx.annotation.NonNull;


public class AuthDetailView implements Parcelable {

    
    @SerializedName("ReferProvider")
    @Expose
    private final List<ReferToProviderAddress> mProviderList;

    @SerializedName("Procedure_Services_Details")
    @Expose
    private  List<ProcedureServicesDetails> mProcedureServicesDetails;

    /*@SerializedName("Member")
    @Expose
    private  List<AuthDetailMember> mAuthDetailMember;*/

    @SerializedName("PlaceOfService")
    @Expose
    private PlaceOfService mPlaceOfService;

    @SerializedName("Procedure_Services_Details_InpatientStay")
    @Expose
    private  List<InpatientStay> mInpatientStayDetails;

    
    @SerializedName("Date")
    @Expose
    private final String mDate;

    
    @SerializedName("Type")
    @Expose
    private final String mType;

    
    @SerializedName("HealthPlan")
    @Expose
    private final String mHealthPlan;

    
    @SerializedName("EndDate")
    @Expose
    private final String mEndDate;

    
    @SerializedName("Status")
    @Expose
    private final String mStatus;

    private AuthDetailView(Parcel in) {
        mProviderList = in.createTypedArrayList(ReferToProviderAddress.CREATOR);
        mDate = in.readString();
        mType = in.readString();
        mHealthPlan = in.readString();
        mEndDate = in.readString();
        mStatus = in.readString();
    }

    public static final Creator<AuthDetailView> CREATOR = new Creator<AuthDetailView>() {
        @Override
        public AuthDetailView createFromParcel(@NonNull Parcel in) {
            return new AuthDetailView(in);
        }

        @Override
        public AuthDetailView[] newArray(int size) {
            return new AuthDetailView[size];
        }
    };
    
    public List<ReferToProviderAddress> getProviderList() {
        return mProviderList;
    }

   /* public List<AuthDetailMember> getmAuthDetailMember() {
        return mAuthDetailMember;
    }*/

    public List<ProcedureServicesDetails> getProcedureServicesDetails() {
        return mProcedureServicesDetails;
    }

    public List<InpatientStay> getInpatientStayDetails() {
        return mInpatientStayDetails;
    }

    
    public String getType() {
        return mType;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeTypedList(mProviderList);
//        parcel.writeTypedList(mAuthDetailMember);
        parcel.writeString(mDate);
        parcel.writeString(mType);
        parcel.writeString(mHealthPlan);
        parcel.writeString(mEndDate);
        parcel.writeString(mStatus);
    }

    public PlaceOfService getPlaceOfService() {
        return mPlaceOfService;
    }
}
