package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import androidx.annotation.NonNull;



public class AuthDiagnosis implements Parcelable {

    @SerializedName("Diagnosis_Code")
    @Expose
    private final String mDiagnosisCode;


    @SerializedName("Diagnosis_Description")
    @Expose
    private final String mDiagnosisDescription;


    @SerializedName("Diagnosis_Narrative")
    @Expose
    private final String mDiagnosisNarrative;


    private AuthDiagnosis(Parcel in) {
        mDiagnosisCode = in.readString();
        mDiagnosisDescription = in.readString();
        mDiagnosisNarrative=in.readString();
    }

    public static final Parcelable.Creator<AuthDiagnosis> CREATOR = new Parcelable.Creator<AuthDiagnosis>() {
        @Override
        public AuthDiagnosis createFromParcel(@NonNull Parcel in) {
            return new AuthDiagnosis(in);
        }

        @Override
        public AuthDiagnosis[] newArray(int size) {
            return new AuthDiagnosis[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(mDiagnosisCode);
        parcel.writeString(mDiagnosisDescription);
        parcel.writeString(mDiagnosisNarrative);
    }

    @NonNull
    @Override
    public String toString() {
        return mDiagnosisCode+" "+mDiagnosisDescription+" "+mDiagnosisNarrative;
    }
}
