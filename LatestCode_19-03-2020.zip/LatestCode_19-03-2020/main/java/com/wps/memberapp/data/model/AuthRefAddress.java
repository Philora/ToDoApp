package com.wps.memberapp.data.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AuthRefAddress {

    @SerializedName("Address1")
    @Expose
    private String mAddress1;
    @SerializedName("Address2")
    @Expose
    private String mAddress2;

    @SerializedName("AddressType")
    @Expose
    private String mAddressType;

    @SerializedName("City")
    @Expose
    private String mCity;

    @SerializedName("State")
    @Expose
    private String mState;

    @SerializedName("ZipCode")
    @Expose
    private String mZipCode;

    @SerializedName("County")
    @Expose
    private String mCounty;


    public String getAddress1() {
        return mAddress1;
    }

    public String getAddress2() {
        return mAddress2;
    }

    public String getAddressType() {
        return mAddressType;
    }

    public String getCity() {
        return mCity;
    }

    public String getState() {
        return mState;
    }

    public String getZipCode() {
        return mZipCode;
    }

    public String getCounty() {
        return mCounty;
    }

}
