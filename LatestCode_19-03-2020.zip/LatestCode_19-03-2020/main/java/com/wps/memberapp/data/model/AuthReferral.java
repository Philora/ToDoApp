package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import androidx.annotation.NonNull;


public class AuthReferral implements Parcelable {

    @SerializedName("Member")
    @Expose
    private MemberProfile mMemberFeed;

    @SerializedName("ReferringProvider")
    @Expose
    private ReferringProvider mReferringProvider;

    @SerializedName("ReferedToProvider")
    @Expose
    private RefferedProvider mReferedToProvider;


    @SerializedName("Number")
    @Expose
    private final String mNumber;


    @SerializedName("StartDate")
    @Expose
    private final String mStartDate;


    @SerializedName("EndDate")
    @Expose
    private final String mEndDate;


    @SerializedName("Status")
    @Expose
    private final String mStatus;

    @SerializedName("EncryptAuthNumber")
    @Expose
    private final String mEncryptNumber;

    @SerializedName("HashCode")
    @Expose
    private final String mHashCode;


    private AuthReferral(Parcel in) {
        mNumber = in.readString();
        mStartDate = in.readString();
        mEndDate = in.readString();
        mStatus = in.readString();
        mHashCode = in.readString();
        mEncryptNumber = in.readString();
    }

    public static final Creator<AuthReferral> CREATOR = new Creator<AuthReferral>() {
        @Override
        public AuthReferral createFromParcel(@NonNull Parcel in) {
            return new AuthReferral(in);
        }

        @Override
        public AuthReferral[] newArray(int size) {
            return new AuthReferral[size];
        }
    };

    public MemberProfile getMemberFeed() {
        return mMemberFeed;
    }


    public ReferringProvider getReferringProvider() {
        return mReferringProvider;
    }


    public RefferedProvider getReferedToProvider() {
        return mReferedToProvider;
    }


    public String getNumber() {
        return mNumber;
    }

    public String getEncryptNumber() {
        return mEncryptNumber;
    }


    public String getStartDate() {
        return mStartDate;
    }


    public String getEndDate() {
        return mEndDate;
    }


    public String getStatus() {
        return mStatus;
    }

    public String getHashCode() {
        return mHashCode;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(mNumber);
        parcel.writeString(mEncryptNumber);
        parcel.writeString(mStartDate);
        parcel.writeString(mEndDate);
        parcel.writeString(mStatus);
        parcel.writeString(mHashCode);
    }
}
