package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

import androidx.annotation.NonNull;


public class AuthorizationModel implements Parcelable{

    @SerializedName("AuthList")
    @Expose
    private List<AuthReferral> mAuthList;

    
    @SerializedName("Status")
    @Expose
    private final String mStatus;

    
    @SerializedName("StatusCount")
    @Expose
    private final String mStatusCount;

    @SerializedName("Page_Count")
    @Expose
    private final int mPageCount;

    @SerializedName("Record_Count")
    @Expose
    private final int mRecordCount;

    private final String mPending;
    private final String mApproved;
    private final String mPartiallyApproved;
    private final String mDenied;

    
    public String getStatusCount() {
        return mStatusCount;
    }

    private AuthorizationModel(Parcel in) {
        mStatus = in.readString();
        mPageCount = in.readInt();
        mRecordCount = in.readInt();
        mStatusCount = in.readString();
        mPending = in.readString();
        mApproved = in.readString();
        mPartiallyApproved = in.readString();
        mDenied = in.readString();
    }

    public static final Creator<AuthorizationModel> CREATOR = new Creator<AuthorizationModel>() {
        @Override
        public AuthorizationModel createFromParcel(@NonNull Parcel in) {
            return new AuthorizationModel(in);
        }

        @Override
        public AuthorizationModel[] newArray(int size) {
            return new AuthorizationModel[size];
        }
    };

    public List<AuthReferral> getAuthList() {
        return mAuthList;
    }

    
    public String getStatus() {
        return mStatus;
    }


    public int getPageCount() {
        return mPageCount;
    }

    public int getRecordCount() {
        return mRecordCount;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(mStatus);
        parcel.writeString(mStatusCount);
    }

    public String getmPending() {
        return mPending;
    }

    public String getmApproved() {
        return mApproved;
    }

    public String getmPartiallyApproved() {
        return mPartiallyApproved;
    }

    public String getmDenied() {
        return mDenied;
    }
}

