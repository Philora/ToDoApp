package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import androidx.annotation.NonNull;

public class BenefitUserDetails implements Parcelable{

    @SerializedName("SubscriberID")
    @Expose
    private final String mSubscriberID;


    @SerializedName("PersonNumber")
    @Expose
    private final String mPersonNumber;


    @SerializedName("CoverageStartDate")
    @Expose
    private final String mCoverageStartDate;


    @SerializedName("CoverageEndDate")
    @Expose
    private final String mCoverageEndDate;


    @SerializedName("PlanName")
    @Expose
    private final String mPlanName;


    @SerializedName("GroupId")
    @Expose
    private final String mGroupId;


    @SerializedName("FirstName")
    @Expose
    private final String mFirstName;


    @SerializedName("LastName")
    @Expose
    private final String mLastName;


    @SerializedName("DateOfBirth")
    @Expose
    private final String mDateOfBirth;


    @SerializedName("ProductCode")
    @Expose
    private final String mProductCode;

    private BenefitUserDetails(Parcel in) {
        mSubscriberID = in.readString();
        mPersonNumber = in.readString();
        mCoverageStartDate = in.readString();
        mPlanName = in.readString();
        mGroupId = in.readString();
        mCoverageEndDate = in.readString();
        mFirstName = in.readString();
        mLastName = in.readString();
        mDateOfBirth = in.readString();
        mProductCode = in.readString();
    }

    public String getmGroupId() {
        return mGroupId;
    }

    public static final Parcelable.Creator<BenefitUserDetails> CREATOR = new Parcelable.Creator<BenefitUserDetails>() {
        @Override
        public BenefitUserDetails createFromParcel(@NonNull Parcel in) {
            return new BenefitUserDetails(in);
        }

        @Override
        public BenefitUserDetails[] newArray(int size) {
            return new BenefitUserDetails[size];
        }
    };



    public String getSubscriberID() {
        return mSubscriberID;
    }


    public String getProductCode() {
        return mProductCode;
    }


    public String getPlanName() {
        return mPlanName;
    }


    public String getCoverageDate() {
        return mCoverageStartDate;
    }

    public String getCoverageEndDate() {
        return mCoverageEndDate;
    }


    public String getPersonNumber() {
        return mPersonNumber;
    }


    public String getFirstName() {
        return mFirstName;
    }


    public String getLastName() {
        return mLastName;
    }


    public String getDateOfBirth() {
        return mDateOfBirth;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(mSubscriberID);
        parcel.writeString(mPersonNumber);
        parcel.writeString(mCoverageStartDate);
        parcel.writeString(mPlanName);
        parcel.writeString(mGroupId);
        parcel.writeString(mCoverageEndDate);
        parcel.writeString(mFirstName);
        parcel.writeString(mLastName);
        parcel.writeString(mDateOfBirth);
        parcel.writeString(mProductCode);
    }
}
