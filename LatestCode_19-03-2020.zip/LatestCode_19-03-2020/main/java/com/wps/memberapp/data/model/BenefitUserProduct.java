package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import androidx.annotation.NonNull;

public class BenefitUserProduct implements Parcelable{


    @SerializedName("CopayConInsuranceDescription")
    @Expose
    private final String mDescription;


    @SerializedName("CoPay")
    @Expose
    private final String mCoPay;


    @SerializedName("Deductible")
    @Expose
    private final String mDeductible;


    @SerializedName("Coinsurance")
    @Expose
    private final String mCoinsurance;


    @SerializedName("Limit")
    @Expose
    private final String mLimit;

    private BenefitUserProduct(Parcel in) {
        mDescription = in.readString();
        mCoPay = in.readString();
        mDeductible = in.readString();
        mCoinsurance = in.readString();
        mLimit = in.readString();
    }

    public static final Parcelable.Creator<BenefitUserProduct> CREATOR = new Parcelable.Creator<BenefitUserProduct>() {
        @Override
        public BenefitUserProduct createFromParcel(@NonNull Parcel in) {
            return new BenefitUserProduct(in);
        }

        @Override
        public BenefitUserProduct[] newArray(int size) {
            return new BenefitUserProduct[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(mDescription);
        parcel.writeString(mCoPay);
        parcel.writeString(mDeductible);
        parcel.writeString(mCoinsurance);
        parcel.writeString(mLimit);
    }


    public String getDescription() {
        return mDescription;
    }


    public String getCoPay() {
        return mCoPay;
    }


    public String getDeductible() {
        return mDeductible;
    }


    public String getCoinsurance() {
        return mCoinsurance;
    }


    public String getLimit() {
        return mLimit;
    }
}

