package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import androidx.annotation.NonNull;


public class BenefitsLimits implements Parcelable {

    @SerializedName("BenefitDescription")
    @Expose
    private final String mBenefitDescription;


    @SerializedName("LimitAmount")
    @Expose
    private final String mLimitAmount;


    @SerializedName("AccumulatedAmount")
    @Expose
    private final String mAccumulatedAmount;


    @SerializedName("RemainingAmount")
    @Expose
    private final String mRemainingAmount;


    private BenefitsLimits(Parcel in) {
        mBenefitDescription = in.readString();
        mLimitAmount = in.readString();
        mAccumulatedAmount = in.readString();
        mRemainingAmount = in.readString();
    }

    public static final Creator<BenefitsLimits> CREATOR = new Creator<BenefitsLimits>() {
        @Override
        public BenefitsLimits createFromParcel(@NonNull Parcel in) {
            return new BenefitsLimits(in);
        }

        @Override
        public BenefitsLimits[] newArray(int size) {
            return new BenefitsLimits[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(mBenefitDescription);
        parcel.writeString(mLimitAmount);
        parcel.writeString(mAccumulatedAmount);
        parcel.writeString(mRemainingAmount);
    }
}


