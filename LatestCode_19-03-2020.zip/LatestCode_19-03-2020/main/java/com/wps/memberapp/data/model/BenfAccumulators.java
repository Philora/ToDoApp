
package com.wps.memberapp.data.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class BenfAccumulators {

    @SerializedName("$id")
    @Expose
    private String $id;
    @SerializedName("InNetworkIndDeductible")
    @Expose
    private String inNetworkIndDeductible;
    @SerializedName("InNetworkIndOOP")
    @Expose
    private String inNetworkIndOOP;
    @SerializedName("InNetworkFamilyDeductible")
    @Expose
    private String inNetworkFamilyDeductible;
    @SerializedName("InNetworkFamilyOOP")
    @Expose
    private String inNetworkFamilyOOP;
    @SerializedName("OutNetworkIndDeductible")
    @Expose
    private String outNetworkIndDeductible;
    @SerializedName("OutNetworkIndOOP")
    @Expose
    private String outNetworkIndOOP;
    @SerializedName("OutNetworkFamilyDeductible")
    @Expose
    private String outNetworkFamilyDeductible;
    @SerializedName("OutNetworkFamilyOOP")
    @Expose
    private String outNetworkFamilyOOP;
    @SerializedName("InNetworkIndDeductibleSpent")
    @Expose
    private String inNetworkIndDeductibleSpent;
    @SerializedName("InNetworkIndOOPSpent")
    @Expose
    private String inNetworkIndOOPSpent;
    @SerializedName("InNetworkFamilyDeductibleSpent")
    @Expose
    private String inNetworkFamilyDeductibleSpent;
    @SerializedName("InNetworkFamilyOOPSpent")
    @Expose
    private String inNetworkFamilyOOPSpent;
    @SerializedName("OutNetworkIndDeductibleSpent")
    @Expose
    private String outNetworkIndDeductibleSpent;
    @SerializedName("OutNetworkIndOOPSpent")
    @Expose
    private String outNetworkIndOOPSpent;
    @SerializedName("OutNetworkFamilyDeductibleSpent")
    @Expose
    private String outNetworkFamilyDeductibleSpent;
    @SerializedName("OutNetworkFamilyOOPSpent")
    @Expose
    private String outNetworkFamilyOOPSpent;

    public String get$id() {
        return $id;
    }

    public void set$id(String $id) {
        this.$id = $id;
    }

    public String getInNetworkIndDeductible() {
        return inNetworkIndDeductible;
    }

    public void setInNetworkIndDeductible(String inNetworkIndDeductible) {
        this.inNetworkIndDeductible = inNetworkIndDeductible;
    }

    public String getInNetworkIndOOP() {
        return inNetworkIndOOP;
    }

    public void setInNetworkIndOOP(String inNetworkIndOOP) {
        this.inNetworkIndOOP = inNetworkIndOOP;
    }

    public String getInNetworkFamilyDeductible() {
        return inNetworkFamilyDeductible;
    }

    public void setInNetworkFamilyDeductible(String inNetworkFamilyDeductible) {
        this.inNetworkFamilyDeductible = inNetworkFamilyDeductible;
    }

    public String getInNetworkFamilyOOP() {
        return inNetworkFamilyOOP;
    }

    public void setInNetworkFamilyOOP(String inNetworkFamilyOOP) {
        this.inNetworkFamilyOOP = inNetworkFamilyOOP;
    }

    public String getOutNetworkIndDeductible() {
        return outNetworkIndDeductible;
    }

    public void setOutNetworkIndDeductible(String outNetworkIndDeductible) {
        this.outNetworkIndDeductible = outNetworkIndDeductible;
    }

    public String getOutNetworkIndOOP() {
        return outNetworkIndOOP;
    }

    public void setOutNetworkIndOOP(String outNetworkIndOOP) {
        this.outNetworkIndOOP = outNetworkIndOOP;
    }

    public String getOutNetworkFamilyDeductible() {
        return outNetworkFamilyDeductible;
    }

    public void setOutNetworkFamilyDeductible(String outNetworkFamilyDeductible) {
        this.outNetworkFamilyDeductible = outNetworkFamilyDeductible;
    }

    public String getOutNetworkFamilyOOP() {
        return outNetworkFamilyOOP;
    }

    public void setOutNetworkFamilyOOP(String outNetworkFamilyOOP) {
        this.outNetworkFamilyOOP = outNetworkFamilyOOP;
    }

    public String getInNetworkIndDeductibleSpent() {
        return inNetworkIndDeductibleSpent;
    }

    public void setInNetworkIndDeductibleSpent(String inNetworkIndDeductibleSpent) {
        this.inNetworkIndDeductibleSpent = inNetworkIndDeductibleSpent;
    }

    public String getInNetworkIndOOPSpent() {
        return inNetworkIndOOPSpent;
    }

    public void setInNetworkIndOOPSpent(String inNetworkIndOOPSpent) {
        this.inNetworkIndOOPSpent = inNetworkIndOOPSpent;
    }

    public String getInNetworkFamilyDeductibleSpent() {
        return inNetworkFamilyDeductibleSpent;
    }

    public void setInNetworkFamilyDeductibleSpent(String inNetworkFamilyDeductibleSpent) {
        this.inNetworkFamilyDeductibleSpent = inNetworkFamilyDeductibleSpent;
    }

    public String getInNetworkFamilyOOPSpent() {
        return inNetworkFamilyOOPSpent;
    }

    public void setInNetworkFamilyOOPSpent(String inNetworkFamilyOOPSpent) {
        this.inNetworkFamilyOOPSpent = inNetworkFamilyOOPSpent;
    }

    public String getOutNetworkIndDeductibleSpent() {
        return outNetworkIndDeductibleSpent;
    }

    public void setOutNetworkIndDeductibleSpent(String outNetworkIndDeductibleSpent) {
        this.outNetworkIndDeductibleSpent = outNetworkIndDeductibleSpent;
    }

    public String getOutNetworkIndOOPSpent() {
        return outNetworkIndOOPSpent;
    }

    public void setOutNetworkIndOOPSpent(String outNetworkIndOOPSpent) {
        this.outNetworkIndOOPSpent = outNetworkIndOOPSpent;
    }

    public String getOutNetworkFamilyDeductibleSpent() {
        return outNetworkFamilyDeductibleSpent;
    }

    public void setOutNetworkFamilyDeductibleSpent(String outNetworkFamilyDeductibleSpent) {
        this.outNetworkFamilyDeductibleSpent = outNetworkFamilyDeductibleSpent;
    }

    public String getOutNetworkFamilyOOPSpent() {
        return outNetworkFamilyOOPSpent;
    }

    public void setOutNetworkFamilyOOPSpent(String outNetworkFamilyOOPSpent) {
        this.outNetworkFamilyOOPSpent = outNetworkFamilyOOPSpent;
    }

}
