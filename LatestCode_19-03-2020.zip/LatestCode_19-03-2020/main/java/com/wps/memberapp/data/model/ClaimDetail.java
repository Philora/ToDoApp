package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

import androidx.annotation.NonNull;


public class ClaimDetail implements Parcelable {


    @SerializedName("Provider")
    @Expose
    private final ReferToProviderAddress mProviderList;


    @SerializedName("DiagnosisList")
    @Expose
    private final List<Diagnosis> mDiagnosisList;


    @SerializedName("ClaimDetailsList")
    @Expose
    private final List<ClaimDiagnosis> mDiagnosisDetails;


    @SerializedName("AuthNumber")
    @Expose
    private final String mAuthNumber;


    @SerializedName("Date")
    @Expose
    private final String mDate;

    @SerializedName("FromDateofService")
    @Expose
    private final String mFromDateofService;


    @SerializedName("Status")
    @Expose
    private final String mStatus;

    @SerializedName("Claim_Type")
    @Expose
    private final String mClaimType;

    @SerializedName("PlanPaid")
    @Expose
    private final String mPlanPaid;

    @SerializedName("PlanDiscount")
    @Expose
    private final String mPlanDiscount;


    /*@SerializedName("Allowed_Amount")
    @Expose
    private final String mAllowed_Amount;*/


    @SerializedName("Responsibility")
    @Expose
    private final String mResponsibility;


    @SerializedName("PlanDescription")
    @Expose
    private final String mPlanDescription;

    @SerializedName("GroupDescription")
    @Expose
    private final String mGroupDescription;

    @SerializedName("IPACode")
    @Expose
    private final String mIPACode;

    @SerializedName("ProcedureCodeName")
    @Expose
    private final String mProcedureCodeName;


    private ClaimDetail(Parcel in) {
        mProviderList = in.readParcelable(ReferToProviderAddress.class.getClassLoader());
        mDiagnosisList = in.createTypedArrayList(Diagnosis.CREATOR);
        mDiagnosisDetails = in.createTypedArrayList(ClaimDiagnosis.CREATOR);
        mAuthNumber = in.readString();
        mDate = in.readString();
        mFromDateofService = in.readString();
        mStatus = in.readString();
        mClaimType = in.readString();
        mPlanPaid = in.readString();
//        mAllowed_Amount = in.readString();
        mResponsibility = in.readString();
        mPlanDiscount= in.readString();
        mPlanDescription = in.readString();
        mGroupDescription = in.readString();
        mIPACode = in.readString();
        mProcedureCodeName = in.readString();
    }

    public static final Creator<ClaimDetail> CREATOR = new Creator<ClaimDetail>() {
        @Override
        public ClaimDetail createFromParcel(@NonNull Parcel in) {
            return new ClaimDetail(in);
        }

        @Override
        public ClaimDetail[] newArray(int size) {
            return new ClaimDetail[size];
        }
    };


    public String getAuthNumber() {
        return mAuthNumber;
    }


    public String getDate() {
        return mDate;
    }

    public String getFromDateofService() {
        return mFromDateofService;
    }


    public ReferToProviderAddress getProviderList() {
        return mProviderList;
    }


    public String getPlanPaid() {
        return mPlanPaid;
    }

   /* public String getPlanAllowed_Amount() {
        return mAllowed_Amount;
    }*/

    public String getResponsibility() {
        return mResponsibility;
    }

    public String getPlanDiscount() {
        return mPlanDiscount;
    }

    public String getClaimType() {
        return mClaimType;
    }

    public List<ClaimDiagnosis> getDiagnosisDetails() {
        return mDiagnosisDetails;
    }

    public String getPlanDescription() {
        return mPlanDescription;
    }

    public String getGroupDescription() {
        return mGroupDescription;
    }

    public String getIPACode() {
        return mIPACode;
    }

    public String getProcedureCodeName() {
        return mProcedureCodeName;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeParcelable(mProviderList, i);
        parcel.writeTypedList(mDiagnosisList);
        parcel.writeTypedList(mDiagnosisDetails);
        parcel.writeString(mAuthNumber);
        parcel.writeString(mDate);
        parcel.writeString(mFromDateofService);
        parcel.writeString(mStatus);
        parcel.writeString(mClaimType);
        parcel.writeString(mPlanPaid);
//        parcel.writeString(mAllowed_Amount);
        parcel.writeString(mResponsibility);
        parcel.writeString(mPlanDiscount);
        parcel.writeString(mPlanDescription);
        parcel.writeString(mGroupDescription);
        parcel.writeString(mIPACode);
        parcel.writeString(mProcedureCodeName);
    }
}
