package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import androidx.annotation.NonNull;


public class ClaimDiagnosis implements Parcelable  {


    @SerializedName("Dateofservice")
    @Expose
    private final String mDateofservice;

    @SerializedName("DateFilled")
    @Expose
    private final String mDateFilled;


    @SerializedName("ProcedureCodeName")
    @Expose
    private final String mProcedureCodeName;


    @SerializedName("TypeOfService")
    @Expose
    private TypeOfService typeOfService;

    @SerializedName("BilledAmount")
    @Expose
    private final String mBilledAmount;


    @SerializedName("YourPlanPaid")
    @Expose
    private final String mYourPlanPaid;


    @SerializedName("PlanDiscount")
    @Expose
    private final String mPlanDiscount;


    @SerializedName("YourResponsibility")
    @Expose
    private final String mYourResponsibility;


    @SerializedName("CoPayAmount")
    @Expose
    private final String mCoPayAmount;

    @SerializedName("CoInsurance")
    @Expose
    private CoInsurance mCoInsurance;

    @SerializedName("Deductible")
    @Expose
    private Deductible mDeductible;

    @SerializedName("Status")
    @Expose
    private final String mStatus;

    @SerializedName("DrugNameStrength")
    @Expose
    private final String mDrugNameStrength;

    @SerializedName("Number")
    @Expose
    private final String mNumber;

    @SerializedName("DrugQuantity")
    @Expose
    private final String mDrugQuantity;

    @SerializedName("ORAL_CAVITY")
    @Expose
    private final String mORAL_CAVITY;

    private ClaimDiagnosis(Parcel in) {
        mDateofservice = in.readString();
        mDateFilled = in.readString();
        mProcedureCodeName = in.readString();
        mBilledAmount = in.readString();
        mYourPlanPaid = in.readString();
        mPlanDiscount = in.readString();
        mYourResponsibility = in.readString();
        mCoPayAmount = in.readString();
        mStatus = in.readString();
        mDrugNameStrength = in.readString();
        mNumber= in.readString();
        mDrugQuantity = in.readString();
        mORAL_CAVITY = in.readString();
    }

    public static final Creator<ClaimDiagnosis> CREATOR = new Creator<ClaimDiagnosis>() {
        @Override
        public ClaimDiagnosis createFromParcel(@NonNull Parcel in) {
            return new ClaimDiagnosis(in);
        }

        @Override
        public ClaimDiagnosis[] newArray(int size) {
            return new ClaimDiagnosis[size];
        }
    };


    public String getCoPayAmount() {
        return mCoPayAmount;
    }

    public String getStatus() {
        return mStatus;
    }

    public String getDrugNameStrength() {
        return mDrugNameStrength;
    }

    public String getDrugQuantity() {
        return mDrugQuantity;
    }

    public String getNumber() {
        return mNumber;
    }

    public String getDateofservice() {
        return mDateofservice;
    }

    public String getDateFilled() {
        return mDateFilled;
    }


    public String getProcedureCodeName() {
        return mProcedureCodeName;
    }


    public String getBilledAmount() {
        return mBilledAmount;
    }


    public String getYourPlanPaid() {
        return mYourPlanPaid;
    }

    public TypeOfService getTypeOfService() {
        return typeOfService;
    }

    public String getPlanDiscount() {
        return mPlanDiscount;
    }



    public String getYourResponsibility() {
        return mYourResponsibility;
    }

    public CoInsurance getCoInsurance() {
        return mCoInsurance;
    }

    public Deductible getDeductible() {
        return mDeductible;
    }

    public String getORAL_CAVITY() {
        return mORAL_CAVITY;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(mDateofservice);
        parcel.writeString(mDateFilled);
        parcel.writeString(mProcedureCodeName);
        parcel.writeString(mBilledAmount);
        parcel.writeString(mYourPlanPaid);
        parcel.writeString(mPlanDiscount);
        parcel.writeString(mYourResponsibility);
        parcel.writeString(mCoPayAmount);
        parcel.writeString(mDrugNameStrength);
        parcel.writeString(mDrugQuantity);
        parcel.writeString(mORAL_CAVITY);
    }
}
