package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import androidx.annotation.NonNull;


public class ClaimList implements Parcelable {

    @SerializedName("Member")
    @Expose
    private MemberProfile mMemberFeed;

    @SerializedName("Provider")
    @Expose
    private ReferringProvider mProvider;


    @SerializedName("TotalBilledAmount")
    @Expose
    private final String mTotalBilledAmount;


    @SerializedName("PlanPaid")
    @Expose
    private final String mPlanPaid;


    @SerializedName("PlanDiscount")
    @Expose
    private final String mPlanDiscount;


    @SerializedName("Deductible")
    @Expose
    private final String mDeductible;


    @SerializedName("Responsibility")
    @Expose
    private final String mResponsibility;


    @SerializedName("Status")
    @Expose
    private final String mStatus;

    @SerializedName("HashCode")
    @Expose
    private final String mHashCode;

    @SerializedName("Number")
    @Expose
    private final String mNumber;

    @SerializedName("EncryptClaimNumber")
    @Expose
    private final String mEncryptNumber;

    @SerializedName("Date")
    @Expose
    private final String mDate;


    @SerializedName("Claim_Type")
    @Expose
    private final String mClaimType;

    private ClaimList(Parcel in) {
        mTotalBilledAmount = in.readString();
        mPlanPaid = in.readString();
        mPlanDiscount = in.readString();
        mDeductible = in.readString();
        mResponsibility = in.readString();
        mStatus = in.readString();
        mNumber = in.readString();
        mEncryptNumber = in.readString();
        mHashCode = in.readString();
        mDate = in.readString();
        mClaimType = in.readString();
    }

    public static final Creator<ClaimList> CREATOR = new Creator<ClaimList>() {
        @Override
        public ClaimList createFromParcel(@NonNull Parcel in) {
            return new ClaimList(in);
        }

        @Override
        public ClaimList[] newArray(int size) {
            return new ClaimList[size];
        }
    };


    public String getTotalBilledAmount() {
        return mTotalBilledAmount;
    }


    public String getPlanPaid() {
        return mPlanPaid;
    }


    public String getDeductible() {
        return mDeductible;
    }

    public String getStatus() {
        return mStatus;
    }

    public String getNumber() {
        return mNumber;
    }

    public String getEncryptNumber() {
        return mEncryptNumber;
    }

    public String getDate() {
        return mDate;
    }

    public MemberProfile getMemberFeed() {
        return mMemberFeed;
    }

    public ReferringProvider getProvider() {
        return mProvider;
    }

    public String getHashCode() {
        return mHashCode;
    }

    public String getPlanDiscount() {
        return mPlanDiscount;
    }

    public String getClaimType() {
        return mClaimType;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(mTotalBilledAmount);
        parcel.writeString(mPlanPaid);
        parcel.writeString(mPlanDiscount);
        parcel.writeString(mDeductible);
        parcel.writeString(mResponsibility);
        parcel.writeString(mStatus);
        parcel.writeString(mNumber);
        parcel.writeString(mEncryptNumber);
        parcel.writeString(mHashCode);
        parcel.writeString(mDate);
        parcel.writeString(mClaimType);
    }
}
