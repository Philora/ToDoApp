package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

import androidx.annotation.NonNull;

public class ClaimSearchResults implements Parcelable {

    @SerializedName("ClaimList")
    @Expose
    private List<ClaimList> mClaimList;


    @SerializedName("Date")
    @Expose
    private String mDate;

    @SerializedName("PageCount")
    @Expose
    private int mPageCount;

    @SerializedName("RecordCount")
    @Expose
    private int mRecordCount;

    private ClaimSearchResults(Parcel in) {
        mDate = in.readString();
        mPageCount = in.readInt();
        mRecordCount = in.readInt();
    }

    public static final Creator<ClaimSearchResults> CREATOR = new Creator<ClaimSearchResults>() {
        @Override
        public ClaimSearchResults createFromParcel(@NonNull Parcel in) {
            return new ClaimSearchResults(in);
        }

        @Override
        public ClaimSearchResults[] newArray(int size) {
            return new ClaimSearchResults[size];
        }
    };


    public String getDate() {
        return mDate;
    }

    public int getPageCount() {
        return mPageCount;
    }

    public void setDate(int mPageCount) {
        this.mPageCount = mPageCount;
    }

    public void setDate(String mDate) {
        this.mDate = mDate;
    }

    public List<ClaimList> getClaimList() {
        return mClaimList;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(mDate);
    }

    public int getRecordCount() {
        return mRecordCount;
    }

    public void setRecordCount(int mRecordCount) {
        this.mRecordCount = mRecordCount;
    }
}
