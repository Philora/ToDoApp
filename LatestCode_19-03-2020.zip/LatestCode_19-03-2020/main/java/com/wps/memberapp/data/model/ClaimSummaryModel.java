package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import androidx.annotation.NonNull;


public class ClaimSummaryModel implements Parcelable {


    @SerializedName("USER_ID")
    @Expose
    private final String mUserId;


    @SerializedName("Date")
    @Expose
    private final String mDate;


    @SerializedName("P_LESS15")
    @Expose
    private final String mDays15;


    @SerializedName("P_16TO30")
    @Expose
    private final String mDays30;


    @SerializedName("P_31TO60")
    @Expose
    private final String mDays60;


    @SerializedName("P_61TO90")
    @Expose
    private final String mDays90;


    @SerializedName("P_90PLUS")
    @Expose
    private final String mDays90Plus;

    private ClaimSummaryModel(Parcel in) {
        mUserId = in.readString();
        mDate = in.readString();
        mDays15 = in.readString();
        mDays30 = in.readString();
        mDays60 = in.readString();
        mDays90 = in.readString();
        mDays90Plus = in.readString();
    }

    public static final Creator<ClaimSummaryModel> CREATOR = new Creator<ClaimSummaryModel>() {
        @Override
        public ClaimSummaryModel createFromParcel(@NonNull Parcel in) {
            return new ClaimSummaryModel(in);
        }

        @Override
        public ClaimSummaryModel[] newArray(int size) {
            return new ClaimSummaryModel[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(mUserId);
        parcel.writeString(mDate);
        parcel.writeString(mDays15);
        parcel.writeString(mDays30);
        parcel.writeString(mDays60);
        parcel.writeString(mDays90);
        parcel.writeString(mDays90Plus);
    }


    public String getDate() {
        return mDate;
    }


    public String getDays15() {
        return mDays15;
    }


    public String getDays30() {
        return mDays30;
    }


    public String getDays60() {
        return mDays60;
    }


    public String getDays90() {
        return mDays90;
    }


    public String getDays90Plus() {
        return mDays90Plus;
    }

}


