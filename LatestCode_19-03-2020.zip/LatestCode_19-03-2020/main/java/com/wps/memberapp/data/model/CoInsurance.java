package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import androidx.annotation.NonNull;


public class CoInsurance implements Parcelable {


    @SerializedName("$id")
    @Expose
    private final String mID;


    @SerializedName("Amount")
    @Expose
    private final String mAmount;

    private CoInsurance(Parcel in) {
        mID = in.readString();
        mAmount = in.readString();
    }

    public static final Creator<CoInsurance> CREATOR = new Creator<CoInsurance>() {
        @Override
        public CoInsurance createFromParcel(@NonNull Parcel in) {
            return new CoInsurance(in);
        }

        @Override
        public CoInsurance[] newArray(int size) {
            return new CoInsurance[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(mID);
        parcel.writeString(mAmount);
    }

    public String getId() {
        return mID;
    }


    public String getAmount() {
        return mAmount;
    }
}
