package com.wps.memberapp.data.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class DashboardData implements Serializable {

    @SerializedName("Id")
    @Expose
    private String mProfileID;

    @SerializedName("UserRole")
    @Expose
    private String mUserRole;

    @SerializedName("UserId")
    @Expose
    private String mUserId;

    @SerializedName("FirstName")
    @Expose
    private String mFirstName;

    @SerializedName("LastName")
    @Expose
    private String mLastName;

    public String getUserId() {
        return mUserId;
    }

    public String getProfileId() {
        return mProfileID;
    }

    public String getFirstName() {
        return mFirstName;
    }

    public String getLastName() {
        return mLastName;
    }

    public String getUserRole() {
        return mUserRole;
    }
}

