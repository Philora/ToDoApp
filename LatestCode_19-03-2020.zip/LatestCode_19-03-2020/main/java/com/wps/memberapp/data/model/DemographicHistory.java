package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import androidx.annotation.NonNull;

public class DemographicHistory implements Parcelable {


    @SerializedName("submitDate")
    @Expose
    private final String mSubmitDate;

    @SerializedName("memberInfo")
    @Expose
    private MemberDetails mMemberInfo;

    private DemographicHistory(Parcel in) {
        mSubmitDate = in.readString();
    }

    public static final Creator<DemographicHistory> CREATOR = new Creator<DemographicHistory>() {
        @Override
        public DemographicHistory createFromParcel(@NonNull Parcel in) {
            return new DemographicHistory(in);
        }

        @Override
        public DemographicHistory[] newArray(int size) {
            return new DemographicHistory[size];
        }
    };


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(mSubmitDate);
    }


    public String getSubmitDate() {
        return mSubmitDate;
    }

    public MemberDetails getMemberInfo() {
        return mMemberInfo;
    }
}
