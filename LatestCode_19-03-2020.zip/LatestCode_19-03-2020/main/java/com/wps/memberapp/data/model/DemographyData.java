package com.wps.memberapp.data.model;

public class DemographyData {
    private String mFirstName;
    private String mLastName;
    private String mGender;
    private String mPhone;
    private String mDateOfBirth;
    private String mZipCode;
    private String mAddress1;
    private String mCity;
    private String mState;
    private String mCounty;
    private String mProductCode;

    public String getPhone() {
        return mPhone;
    }

    public void setPhone(String mPhone) {
        this.mPhone = mPhone;
    }

    public String getFirstName() {
        return mFirstName;
    }

    public void setFirstName(String mFirstName) {
        this.mFirstName = mFirstName;
    }

    public String getLastName() {
        return mLastName;
    }

    public void setLastName(String mLastName) {
        this.mLastName = mLastName;
    }

    public String getGender() {
        return mGender;
    }

    public void setGender(String mGender) {
        this.mGender = mGender;
    }

    public String getDateOfBirth() {
        return mDateOfBirth;
    }

    public void setDateOfBirth(String mDateOfBirth) {
        this.mDateOfBirth = mDateOfBirth;
    }

    public String getZipCode() {
        return mZipCode;
    }

    public void setZipCode(String mZipCode) {
        this.mZipCode = mZipCode;
    }

    public String getAddress1() {
        return mAddress1;
    }

    public void setAddress1(String mAddress1) {
        this.mAddress1 = mAddress1;
    }

    public String getCity() {
        return mCity;
    }

    public void setCity(String mCity) {
        this.mCity = mCity;
    }

    public String getState() {
        return mState;
    }

    public void setState(String mState) {
        this.mState = mState;
    }

    public String getCounty() {
        return mCounty;
    }

    public void setCounty(String mCounty) {
        this.mCounty = mCounty;
    }
    public String getProductCode() {
        return mProductCode;
    }

    public void setProductCode(String mProductCode) {
        this.mProductCode = mProductCode;
    }
}
