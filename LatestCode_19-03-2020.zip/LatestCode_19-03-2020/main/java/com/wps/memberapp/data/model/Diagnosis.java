package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import androidx.annotation.NonNull;


public class Diagnosis implements Parcelable {


    @SerializedName("Code")
    @Expose
    private final String mDiagnosisCode;


    @SerializedName("Description")
    @Expose
    private final String mDiagnosisDescription;


    private Diagnosis(Parcel in) {
        mDiagnosisCode = in.readString();
        mDiagnosisDescription = in.readString();
    }

    public static final Creator<Diagnosis> CREATOR = new Creator<Diagnosis>() {
        @Override
        public Diagnosis createFromParcel(@NonNull Parcel in) {
            return new Diagnosis(in);
        }

        @Override
        public Diagnosis[] newArray(int size) {
            return new Diagnosis[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(mDiagnosisCode);
        parcel.writeString(mDiagnosisDescription);
    }
}
