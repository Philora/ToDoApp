package com.wps.memberapp.data.model;

public class ExpandedMenuModel {

  private String mIconName;
  private int mIconImg;

  public String getIconName() {
    return mIconName;
  }

  public void setIconName(String mIconName) {
    this.mIconName = mIconName;
  }

  public int getIconImg() {
    return mIconImg;
  }

  public void setIconImg(int mIconImg) {
    this.mIconImg = mIconImg;
  }

}
