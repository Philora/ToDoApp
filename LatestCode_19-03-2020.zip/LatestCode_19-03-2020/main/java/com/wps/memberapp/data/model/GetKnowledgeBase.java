package com.wps.memberapp.data.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetKnowledgeBase {

    @SerializedName("$id")
    @Expose
    private String $id;

    @SerializedName("DocID")
    @Expose
    private String docID;

    @SerializedName("Title")
    @Expose
    private String title;

    public String getDocID() {
        return docID;
    }

    public String getTitle() {
        return title;
    }
}
