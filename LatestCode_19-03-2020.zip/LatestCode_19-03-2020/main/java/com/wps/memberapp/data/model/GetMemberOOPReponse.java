
package com.wps.memberapp.data.model;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetMemberOOPReponse {

    @SerializedName("$id")
    @Expose
    private String $id;
    @SerializedName("AccumulatorType")
    @Expose
    private String accumulatorType;
    @SerializedName("BenefitPeriod_FromDate")
    @Expose
    private String benefitPeriodFromDate;
    @SerializedName("BenefitPeriod_ToDate")
    @Expose
    private String benefitPeriodToDate;
    @SerializedName("HasPeriodDate")
    @Expose
    private Boolean hasPeriodDate;
    @SerializedName("BenfAccumulators")
    @Expose
    private BenfAccumulators benfAccumulators;
    @SerializedName("Limits")
    @Expose
    private List<Limit> limits = null;

    public String get$id() {
        return $id;
    }

    public void set$id(String $id) {
        this.$id = $id;
    }

    public String getAccumulatorType() {
        return accumulatorType;
    }

    public void setAccumulatorType(String accumulatorType) {
        this.accumulatorType = accumulatorType;
    }

    public String getBenefitPeriodFromDate() {
        return benefitPeriodFromDate;
    }

    public void setBenefitPeriodFromDate(String benefitPeriodFromDate) {
        this.benefitPeriodFromDate = benefitPeriodFromDate;
    }

    public String getBenefitPeriodToDate() {
        return benefitPeriodToDate;
    }

    public void setBenefitPeriodToDate(String benefitPeriodToDate) {
        this.benefitPeriodToDate = benefitPeriodToDate;
    }

    public Boolean getHasPeriodDate() {
        return hasPeriodDate;
    }

    public void setHasPeriodDate(Boolean hasPeriodDate) {
        this.hasPeriodDate = hasPeriodDate;
    }

    public BenfAccumulators getBenfAccumulators() {
        return benfAccumulators;
    }

    public void setBenfAccumulators(BenfAccumulators benfAccumulators) {
        this.benfAccumulators = benfAccumulators;
    }

    public List<Limit> getLimits() {
        return limits;
    }

    public void setLimits(List<Limit> limits) {
        this.limits = limits;
    }

}
