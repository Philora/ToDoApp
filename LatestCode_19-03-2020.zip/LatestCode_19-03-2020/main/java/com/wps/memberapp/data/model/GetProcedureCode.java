package com.wps.memberapp.data.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetProcedureCode {

    @SerializedName("$id")
    @Expose
    private String $id;
    @SerializedName("label")
    @Expose
    private String label;
    @SerializedName("procCode")
    @Expose
    private String procCode;
    @SerializedName("procCodeExtraInfo")
    @Expose
    private String procCodeExtraInfo;

    public String getLabel() {
        return label;
    }

    public String getProcCode() {
        return procCode;
    }

    public String getProcCodeExtraInfo() {
        return procCodeExtraInfo;
    }

}
