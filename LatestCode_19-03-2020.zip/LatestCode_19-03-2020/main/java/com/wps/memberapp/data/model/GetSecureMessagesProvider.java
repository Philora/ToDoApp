package com.wps.memberapp.data.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetSecureMessagesProvider {

    @SerializedName("$id")
    @Expose
    private String $id;
    @SerializedName("SEQ_PROV_ID")
    @Expose
    private String sEQPROVID;
    @SerializedName("PROVIDER_NAME")
    @Expose
    private String pROVIDERNAME;

    public String get$id() {
        return $id;
    }

    public void set$id(String $id) {
        this.$id = $id;
    }

    public String getSEQPROVID() {
        return sEQPROVID;
    }

    public void setSEQPROVID(String sEQPROVID) {
        this.sEQPROVID = sEQPROVID;
    }

    public String getPROVIDERNAME() {
        return pROVIDERNAME;
    }

    public void setPROVIDERNAME(String pROVIDERNAME) {
        this.pROVIDERNAME = pROVIDERNAME;
    }

}
