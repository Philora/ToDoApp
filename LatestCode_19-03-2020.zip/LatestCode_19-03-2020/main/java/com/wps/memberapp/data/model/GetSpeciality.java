
package com.wps.memberapp.data.model;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetSpeciality {

    @SerializedName("$id")
    @Expose
    private String $id;
    @SerializedName("RecordCount")
    @Expose
    private Integer recordCount;
    @SerializedName("PageCount")
    @Expose
    private Integer pageCount;
    @SerializedName("PageSize")
    @Expose
    private Integer pageSize;
    @SerializedName("MaxRecords")
    @Expose
    private Integer maxRecords;
    @SerializedName("CurrentPage")
    @Expose
    private Integer currentPage;
    @SerializedName("PlanList")
    @Expose
    private List<PlanListSpeciality> planList = null;

    public String get$id() {
        return $id;
    }

    public void set$id(String $id) {
        this.$id = $id;
    }

    public Integer getRecordCount() {
        return recordCount;
    }

    public void setRecordCount(Integer recordCount) {
        this.recordCount = recordCount;
    }

    public Integer getPageCount() {
        return pageCount;
    }

    public void setPageCount(Integer pageCount) {
        this.pageCount = pageCount;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getMaxRecords() {
        return maxRecords;
    }

    public void setMaxRecords(Integer maxRecords) {
        this.maxRecords = maxRecords;
    }

    public Integer getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(Integer currentPage) {
        this.currentPage = currentPage;
    }

    public List<PlanListSpeciality> getPlanList() {
        return planList;
    }

    public void setPlanList(List<PlanListSpeciality> planList) {
        this.planList = planList;
    }

}
