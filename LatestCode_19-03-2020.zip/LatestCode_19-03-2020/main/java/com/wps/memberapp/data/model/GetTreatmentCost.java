
package com.wps.memberapp.data.model;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetTreatmentCost {

    @SerializedName("tCCDatas")
    @Expose
    private List<TCCData> tCCDatas = null;
    @SerializedName("totalCount")
    @Expose
    private Integer totalCount;
    @SerializedName("pageNumber")
    @Expose
    private Integer pageNumber;
    @SerializedName("pageSize")
    @Expose
    private Integer pageSize;
    @SerializedName("newRequest")
    @Expose
    private Boolean newRequest;
    @SerializedName("TotalAvgCost")
    @Expose
    private Double totalAvgCost;

    public List<TCCData> getTCCDatas() {
        return tCCDatas;
    }

    public void setTCCDatas(List<TCCData> tCCDatas) {
        this.tCCDatas = tCCDatas;
    }

    public Integer getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(Integer totalCount) {
        this.totalCount = totalCount;
    }

    public Integer getPageNumber() {
        return pageNumber;
    }

    public void setPageNumber(Integer pageNumber) {
        this.pageNumber = pageNumber;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Boolean getNewRequest() {
        return newRequest;
    }

    public void setNewRequest(Boolean newRequest) {
        this.newRequest = newRequest;
    }

    public Double getTotalAvgCost() {
        return totalAvgCost;
    }

    public void setTotalAvgCost(Double totalAvgCost) {
        this.totalAvgCost = totalAvgCost;
    }

}
