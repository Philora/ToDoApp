package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class IDCardBenefits implements Parcelable {

    @SerializedName("$id")
    @Expose
    private final String id;

    @SerializedName("Caption")
    @Expose
    private final String caption;

    @SerializedName("Value")
    @Expose
    private final String value;


    private IDCardBenefits(Parcel in) {
        id = in.readString();
        caption = in.readString();
        value = in.readString();
    }

    public static final Creator<IDCardBenefits> CREATOR = new Creator<IDCardBenefits>() {
        @Override
        public IDCardBenefits createFromParcel(Parcel in) {
            return new IDCardBenefits(in);
        }

        @Override
        public IDCardBenefits[] newArray(int size) {
            return new IDCardBenefits[size];
        }
    };

    public String getCaption() {
        return caption;
    }

    public String getValue() {
        return value;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(id);
        parcel.writeString(caption);
        parcel.writeString(value);
    }
}

