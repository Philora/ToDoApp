package com.wps.memberapp.data.model;


import com.wps.memberapp.presentation.immunization.fragment.ImmunizationHistoryProvider;

import java.util.List;

public class ImmunizationHistory {
    private String medicineName;
    private List<ImmunizationHistoryProvider> providersList;

    public String getMedicineName() {
        return medicineName;
    }

    public void setMedicineName(String medicineName) {
        this.medicineName = medicineName;
    }

    public List<ImmunizationHistoryProvider> getProvidersList() {
        return providersList;
    }

    public void setProvidersList(List<ImmunizationHistoryProvider> providersList) {
        this.providersList = providersList;
    }
}
