package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import androidx.annotation.NonNull;


public class InpatientStay implements Parcelable {


    @SerializedName("$id")
    @Expose
    private final String mID;


    @SerializedName("Quantity")
    @Expose
    private final String mQuantity;


    @SerializedName("FromDate")
    @Expose
    private final String mFromDate;


    @SerializedName("ReceivedDate")
    @Expose
    private final String mReceivedDate;


    @SerializedName("PS_Status")
    @Expose
    private final String mStatus;

    private InpatientStay(Parcel in) {
        mID = in.readString();
        mQuantity = in.readString();
        mFromDate = in.readString();
        mReceivedDate = in.readString();
        mStatus = in.readString();
    }

    public static final Creator<InpatientStay> CREATOR = new Creator<InpatientStay>() {
        @Override
        public InpatientStay createFromParcel(@NonNull Parcel in) {
            return new InpatientStay(in);
        }

        @Override
        public InpatientStay[] newArray(int size) {
            return new InpatientStay[size];
        }
    };


    public String getId() {
        return mID;
    }

    public String getFromDate() {
        return mFromDate;
    }


    public String getStatus() {
        return mStatus;
    }


    public String getReceivedDate() {
        return mReceivedDate;
    }


    public String getQuantity() {
        return mQuantity;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(mID);
        parcel.writeString(mQuantity);
        parcel.writeString(mFromDate);
        parcel.writeString(mReceivedDate);
        parcel.writeString(mStatus);
    }
}




