
package com.wps.memberapp.data.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Limit {

    @SerializedName("$id")
    @Expose
    private String $id;
    @SerializedName("WebDescription")
    @Expose
    private String webDescription;
    @SerializedName("Limit")
    @Expose
    private String limit;
    @SerializedName("LimitLevelDescription")
    @Expose
    private String limitLevelDescription;
    @SerializedName("FamilySatisfiedAmount")
    @Expose
    private String familySatisfiedAmount;
    @SerializedName("MemberSatisfiedAmount")
    @Expose
    private String memberSatisfiedAmount;

    public String get$id() {
        return $id;
    }

    public void set$id(String $id) {
        this.$id = $id;
    }

    public String getWebDescription() {
        return webDescription;
    }

    public void setWebDescription(String webDescription) {
        this.webDescription = webDescription;
    }

    public String getLimit() {
        return limit;
    }

    public void setLimit(String limit) {
        this.limit = limit;
    }

    public String getLimitLevelDescription() {
        return limitLevelDescription;
    }

    public void setLimitLevelDescription(String limitLevelDescription) {
        this.limitLevelDescription = limitLevelDescription;
    }

    public String getFamilySatisfiedAmount() {
        return familySatisfiedAmount;
    }

    public void setFamilySatisfiedAmount(String familySatisfiedAmount) {
        this.familySatisfiedAmount = familySatisfiedAmount;
    }

    public String getMemberSatisfiedAmount() {
        return memberSatisfiedAmount;
    }

    public void setMemberSatisfiedAmount(String memberSatisfiedAmount) {
        this.memberSatisfiedAmount = memberSatisfiedAmount;
    }

}
