package com.wps.memberapp.data.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class MasterData {

    @SerializedName("$id")
    @Expose
    private String $id;
    @SerializedName("MasterDataID")
    @Expose
    private Integer masterDataID;
    @SerializedName("Code")
    @Expose
    private String code;
    @SerializedName("Description")
    @Expose
    private String description;
    @SerializedName("Active")
    @Expose
    private String active;
    @SerializedName("IsDefault")
    @Expose
    private Integer isDefault;
    @SerializedName("ParentID")
    @Expose
    private Integer parentID;
    @SerializedName("SortOrder")
    @Expose
    private Integer sortOrder;

    public String get$id() {
        return $id;
    }

    public void set$id(String $id) {
        this.$id = $id;
    }

    public Integer getMasterDataID() {
        return masterDataID;
    }

    public void setMasterDataID(Integer masterDataID) {
        this.masterDataID = masterDataID;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }

    public Integer getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(Integer isDefault) {
        this.isDefault = isDefault;
    }

    public Integer getParentID() {
        return parentID;
    }

    public void setParentID(Integer parentID) {
        this.parentID = parentID;
    }

    public Integer getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
    }

}
