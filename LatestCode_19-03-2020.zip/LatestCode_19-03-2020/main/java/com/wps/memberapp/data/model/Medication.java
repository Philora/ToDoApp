package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Medication implements Parcelable {

    @SerializedName("MEDICINE_NAME")
    @Expose
    private String Medicine_Name;

    @SerializedName("INTAKE_PLAN")
    @Expose
    private String Intake_Plan;

    @SerializedName("DOSAGE")
    @Expose
    private String Dosage;

    @SerializedName("UNIT")
    @Expose
    private String Unit;

    @SerializedName("IMAGE_PATH")
    @Expose
    private String Image_Path;

    @SerializedName("NUMBER_OF_TABLETS")
    @Expose
    private String Number_Of_Tablets;

    @SerializedName("MEDICINE_DAY_PLAN")
    @Expose
    private String Medicine_Day_Plan;

    private Medication(Parcel in) {
        Medicine_Name = in.readString();
        Intake_Plan = in.readString();
        Dosage = in.readString();
        Unit = in.readString();
        Image_Path = in.readString();
        Number_Of_Tablets = in.readString();
        Medicine_Day_Plan = in.readString();
    }
    public Medication(){}

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(Medicine_Name);
        parcel.writeString(Intake_Plan);
        parcel.writeString(Dosage);
        parcel.writeString(Unit);
        parcel.writeString(Image_Path);
        parcel.writeString(Number_Of_Tablets);
        parcel.writeString(Medicine_Day_Plan);
    }

    public static final Creator<Medication> CREATOR = new Creator<Medication>() {
        @Override
        public Medication createFromParcel(Parcel in) {
            return new Medication(in);
        }

        @Override
        public Medication[] newArray(int size) {
            return new Medication[size];
        }
    };

    public String getMedicine_Name() {
        return Medicine_Name;
    }

    public void setMedicine_Name(String medicine_Name) {
        Medicine_Name = medicine_Name;
    }

    public String getIntake_Plan() {
        return Intake_Plan;
    }

    public void setIntake_Plan(String intake_Plan) {
        Intake_Plan = intake_Plan;
    }

    public String getDosage() {
        return Dosage;
    }

    public void setDosage(String dosage) {
        Dosage = dosage;
    }

    public String getUnit() {
        return Unit;
    }

    public void setUnit(String unit) {
        Unit = unit;
    }

    public String getImage_Path() {
        return Image_Path;
    }

    public void setImage_Path(String image_Path) {
        Image_Path = image_Path;
    }

    public String getNumber_Of_Tablets() {
        return Number_Of_Tablets;
    }

    public void setNumber_Of_Tablets(String number_Of_Tablets) {
        Number_Of_Tablets = number_Of_Tablets;
    }

    public String getMedicine_Day_Plan() {
        return Medicine_Day_Plan;
    }

    public void setMedicine_Day_Plan(String medicine_Day_Plan) {
        Medicine_Day_Plan = medicine_Day_Plan;
    }
}
