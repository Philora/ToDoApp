package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

import androidx.annotation.NonNull;


public class MemberDetails implements Parcelable {


    @SerializedName("SubscriberID")
    @Expose
    private final String mSubscriberID;


    @SerializedName("PersonNumber")
    @Expose
    private final String mPersonNumber;


    @SerializedName("CoverageStartDate")
    @Expose
    private final String mCoverageStartDate;


    @SerializedName("PlanName")
    @Expose
    private final String mPlanName;


    @SerializedName("GroupId")
    @Expose
    private final String mGroupId;


    @SerializedName("GroupName")
    @Expose
    private final String mGroupName;


    @SerializedName("FirstName")
    @Expose
    private final String mFirstName;


    @SerializedName("LastName")
    @Expose
    private final String mLastName;


    @SerializedName("DateOfBirth")
    @Expose
    private final String mDateOfBirth;


    @SerializedName("PhoneNumber")
    @Expose
    private final String mPhoneNumber;

    @SerializedName("FMSSeqMemberId")
    @Expose
    private final String mFMSSeqMemberId;


    @SerializedName("RelationshipCode")
    @Expose
    private final String mRelationshipCode;


    @SerializedName("Addresses")
    @Expose
    private final List<Address> mAddressList;


    @SerializedName("PlanCode")
    @Expose
    private final String mPlanCode;


    @SerializedName("TermDate")
    @Expose
    private final String mTermDate;


    @SerializedName("Gender")
    @Expose
    private final String mGender;

    @SerializedName("ProductCode")
    @Expose
    private final String mProductCode;

    @SerializedName("HashCode")
    @Expose
    private final String mHashCode;

    @SerializedName("PlanType")
    @Expose
    public String mPlanType;

    @SerializedName("EffectiveDate")
    @Expose
    public String mEffectiveDate;

    @SerializedName("PCP_Name")
    @Expose
    public String mPCPName;


    @SerializedName("User_Defined_4")
    @Expose
    public String mUserDefined4;

    @SerializedName("AGE")
    @Expose
    public String mAGE;

    private MemberDetails(Parcel in) {
        mSubscriberID = in.readString();
        mPersonNumber = in.readString();
        mCoverageStartDate = in.readString();
        mPlanName = in.readString();
        mGroupId = in.readString();
        mGroupName = in.readString();
        mFirstName = in.readString();
        mLastName = in.readString();
        mDateOfBirth = in.readString();
        mFMSSeqMemberId = in.readString();
        mRelationshipCode = in.readString();
        mPhoneNumber = in.readString();
        mPlanCode = in.readString();
        mTermDate = in.readString();
        mGender = in.readString();
        mProductCode = in.readString();
        mHashCode = in.readString();
        mAddressList = in.createTypedArrayList(Address.CREATOR);
        mPlanType = in.readString();
        mEffectiveDate = in.readString();
        mPCPName = in.readString();
        mAGE= in.readString();
        mUserDefined4 = in.readString();
    }

    public static final Creator<MemberDetails> CREATOR = new Creator<MemberDetails>() {
        @Override
        public MemberDetails createFromParcel(@NonNull Parcel in) {
            return new MemberDetails(in);
        }

        @Override
        public MemberDetails[] newArray(int size) {
            return new MemberDetails[size];
        }
    };

    public String getGroupName() {
        return mGroupName;
    }


    public String getSubscriberID() {
        return mSubscriberID;
    }


    public String getPlanName() {
        return mPlanName;
    }


    public String getGroupId() {
        return mGroupId;
    }


    public String getGender() {
        return mGender;
    }


    public String getCoverageDate() {
        return mCoverageStartDate;
    }

    public String getPersonNumber() {
        return mPersonNumber;
    }


    public String getFirstName() {
        return mFirstName;
    }

    public String getProductCode() {
        return mProductCode;
    }

    public String getLastName() {
        return mLastName;
    }


    public String getDateOfBirth() {
        return mDateOfBirth;
    }


    public String getPhoneNumber() {
        return mPhoneNumber;
    }


    public List<Address> getAddressList() {
        return mAddressList;
    }


    public String getfMSSeqMemberId() {
        return mFMSSeqMemberId;
    }


    public String getRelationshipCode() {
        return mRelationshipCode;
    }

    public String getUserDefined4() {
        return mUserDefined4;
    }


    public String getPlanCode() {
        return mPlanCode;
    }

    public String getHashCode() {
        return mHashCode;
    }

    public String getTermDate() {
        return mTermDate;
    }


    public String getPlanType() {
        return mPlanType;
    }

    public String getEffectiveDate() {
        return mEffectiveDate;
    }

    public String getPCPName() {
        return mPCPName;
    }

    public String getAGE() {
        return mAGE;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(mSubscriberID);
        parcel.writeString(mPersonNumber);
        parcel.writeString(mCoverageStartDate);
        parcel.writeString(mPlanName);
        parcel.writeString(mGroupId);
        parcel.writeString(mGroupName);
        parcel.writeString(mFirstName);
        parcel.writeString(mLastName);
        parcel.writeString(mDateOfBirth);
        parcel.writeString(mFMSSeqMemberId);
        parcel.writeString(mRelationshipCode);
        parcel.writeString(mPhoneNumber);
        parcel.writeString(mPlanCode);
        parcel.writeString(mTermDate);
        parcel.writeString(mGender);
        parcel.writeString(mProductCode);
        parcel.writeString(mHashCode);
        parcel.writeTypedList(mAddressList);
        parcel.writeString(mPlanType);
        parcel.writeString(mEffectiveDate);
        parcel.writeString(mPCPName);
        parcel.writeString(mAGE);
        parcel.writeString(mUserDefined4);
    }
}
