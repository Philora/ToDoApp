package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

import androidx.annotation.NonNull;

public class MemberEligibleInfo implements Parcelable {

    
    @SerializedName("LineOfBusiness")
    private final String mLineOfBusiness;

    
    @SerializedName("CurrentRelEntityID")
    private final String mCurrentRelEntityID;

    
    @SerializedName("GroupID")
    private final String mGroupID;

    
    @SerializedName("SubscriberId")
    private final String mSubscriberID;

    
    @SerializedName("PersonNumber")
    private final String mPersonNumber;

    private MemberEligibleInfo(Parcel in) {
        mSubscriberID = in.readString();
        mPersonNumber = in.readString();
        mCurrentRelEntityID = in.readString();
        mLineOfBusiness = in.readString();
        mGroupID = in.readString();
    }


    public static final Creator<MemberEligibleInfo> CREATOR = new Creator<MemberEligibleInfo>() {
        @Override
        public MemberEligibleInfo createFromParcel(@NonNull Parcel in) {
            return new MemberEligibleInfo(in);
        }

        @Override
        public MemberEligibleInfo[] newArray(int size) {
            return new MemberEligibleInfo[size];
        }
    };


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(mSubscriberID);
        parcel.writeString(mPersonNumber);
        parcel.writeString(mCurrentRelEntityID);
        parcel.writeString(mLineOfBusiness);
        parcel.writeString(mGroupID);
    }

    
    public String getLineOfBusiness() {
        return mLineOfBusiness;
    }

    
    public String getCurrentRelEntityID() {
        return mCurrentRelEntityID;
    }

    
    public String getSubscriberID() {
        return mSubscriberID;
    }

    
    public String getPersonNumber() {
        return mPersonNumber;
    }
}

