package com.wps.memberapp.data.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class MemberFeed {

    public static final int TEXT=1;
    public static final int IMAGE=2;
    public static final int VIDEO=3;

    @SerializedName("viewType")
    @Expose
    private int viewType;

    @SerializedName("value")
    @Expose
    private String value;

    public int getViewType() {
        return viewType;
    }

    public void setViewType(int viewType) {
        this.viewType = viewType;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}

