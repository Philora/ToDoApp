package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import androidx.annotation.NonNull;


public class MemberGroupDetails implements Parcelable {


    @SerializedName("SubscriberID")
    @Expose
    private final String mSubscriberID;


    @SerializedName("TermDate")
    @Expose
    private final String mTermDate;


    @SerializedName("IsActive")
    @Expose
    private final String mIsActive;


    @SerializedName("GroupName")
    @Expose

    private final String mGroupName;


    @SerializedName("USER_DEFINED_2")
    @Expose
    private final String mUserDefined;


    private MemberGroupDetails(Parcel in) {
        mSubscriberID = in.readString();
        mTermDate = in.readString();
        mIsActive = in.readString();
        mGroupName = in.readString();
        mUserDefined = in.readString();
    }


    public static final Creator<MemberGroupDetails> CREATOR = new Creator<MemberGroupDetails>() {
        @Override
        public MemberGroupDetails createFromParcel(@NonNull Parcel in) {
            return new MemberGroupDetails(in);
        }

        @Override
        public MemberGroupDetails[] newArray(int size) {
            return new MemberGroupDetails[size];
        }
    };



    public String getGroupName() {
        return mGroupName;
    }


    public String getSubscriberID() {
        return mSubscriberID;
    }


    public String getCoverageDate() {
        return mTermDate;
    }


    public String getUserDefined() {
        return mUserDefined;
    }


    public String getIsActive() {
        return mIsActive;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(mSubscriberID);
        parcel.writeString(mTermDate);
        parcel.writeString(mIsActive);
        parcel.writeString(mGroupName);
        parcel.writeString(mUserDefined);
    }
}
