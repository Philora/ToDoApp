package com.wps.memberapp.data.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class MemberProfile {
    @SerializedName("mValue")
    @Expose
    private String mValue;

    @SerializedName("FirstName")
    @Expose
    private String mFirstName;

    @SerializedName("LastName")
    @Expose
    private String mLastName;

    @SerializedName("DateOfBirth")
    @Expose
    private String mDateOfBirth;

    @SerializedName("Gender")
    @Expose
    private String mGender;

    public String getValue() {
        return mValue;
    }


    public String getFirstName() {
        return mFirstName;
    }

    public String getLastName() {
        return mLastName;
    }

    public String getDateOfBirth() {
        return mDateOfBirth;
    }

    public String getGender() {
        return mGender;
    }
}
