package com.wps.memberapp.data.model;

import android.text.SpannableString;
import android.text.Spanned;

import java.io.Serializable;

public class Message implements Serializable {
    private int id;
    private Spanned message;
    private String userType;
    private String CreatedAt;
    private String url;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Message() {
    }

    public Message(int id, SpannableString message, String createdAt) {
        this.id = id;
        this.message = message;


    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Spanned getMessage() {
        return message;
    }

    public void setMessage(Spanned message) {
        this.message = message;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getCreatedAt() {
        return CreatedAt;
    }

    public void setCreatedAt(String createdAt) {
        CreatedAt = createdAt;
    }
}

