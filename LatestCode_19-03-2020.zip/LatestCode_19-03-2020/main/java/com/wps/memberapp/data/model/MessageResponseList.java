package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import androidx.annotation.NonNull;

public class MessageResponseList implements Parcelable {


    @SerializedName("ResponseDate")
    @Expose
    private final String responseDate;

    @SerializedName("SEQ")
    @Expose
    private final String mSEQ;


    @SerializedName("ResponseText")
    @Expose
    private final String responseText;

    @SerializedName("ResponseUser")
    @Expose
    private ResponseUser responseUser;

    private MessageResponseList(Parcel in) {
        responseDate = in.readString();
        responseText = in.readString();
        mSEQ = in.readString();
    }

    public static final Creator<MessageResponseList> CREATOR = new Creator<MessageResponseList>() {
        @Override
        public MessageResponseList createFromParcel(@NonNull Parcel in) {
            return new MessageResponseList(in);
        }

        @Override
        public MessageResponseList[] newArray(int size) {
            return new MessageResponseList[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(responseDate);
        parcel.writeString(responseDate);
        parcel.writeString(mSEQ);
    }

    public ResponseUser getResponseUser() {
        return responseUser;
    }

    public String getResponseDate() {
        return responseDate;
    }

    public String getSEQ() {
        return mSEQ;
    }

    public String getResponseText() {
        return responseText;
    }
}
