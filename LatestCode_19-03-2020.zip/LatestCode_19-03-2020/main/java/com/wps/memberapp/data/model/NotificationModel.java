package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import androidx.annotation.NonNull;

public class NotificationModel implements Parcelable {

    
    @SerializedName("Topic")
    @Expose
    private final String mTitle;

    
    @SerializedName("Message")
    @Expose
    private final String mContent;

    
    @SerializedName("StartDate")
    @Expose

    private final String mStartDate;

    
    @SerializedName("EndDate")
    @Expose
    private final String mEndDate;

    private NotificationModel(Parcel in) {
        mTitle = in.readString();
        mContent = in.readString();
        mStartDate = in.readString();
        mEndDate = in.readString();
    }

    public static final Creator<NotificationModel> CREATOR = new Creator<NotificationModel>() {
        @Override
        public NotificationModel createFromParcel(@NonNull Parcel in) {
            return new NotificationModel(in);
        }

        @Override
        public NotificationModel[] newArray(int size) {
            return new NotificationModel[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(mTitle);
        parcel.writeString(mContent);
        parcel.writeString(mStartDate);
        parcel.writeString(mEndDate);
    }

    
    public String getTitle() {
        return mTitle;
    }

    
    public String getContent() {
        return mContent;
    }

    
    public String getStartDate() {
        return mStartDate;
    }

    
    public String getEndDate() {
        return mEndDate;
    }
}
