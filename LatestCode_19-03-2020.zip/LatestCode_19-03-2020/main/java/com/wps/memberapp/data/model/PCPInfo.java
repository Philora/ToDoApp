package com.wps.memberapp.data.model;


import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PCPInfo implements Parcelable {

    @SerializedName("FirstName")
    @Expose
    private String FirstName;

    @SerializedName("LastName")
    @Expose
    private String LastName;

    @SerializedName("PhoneNumber")
    @Expose
    private String PhoneNumber;


    public PCPInfo(String firstName, String lastName, String phoneNumber) {
        super();
        this.FirstName = firstName;
        this.LastName= lastName;
        this.PhoneNumber=phoneNumber;
    }

    PCPInfo(Parcel in) {
        FirstName = in.readString();
        LastName = in.readString();
        PhoneNumber = in.readString();
    }

    public static final Creator<PCPInfo> CREATOR = new Creator<PCPInfo>() {
        @Override
        public PCPInfo createFromParcel(Parcel in) {
            return new PCPInfo(in);
        }

        @Override
        public PCPInfo[] newArray(int size) {
            return new PCPInfo[size];
        }
    };

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        PhoneNumber = phoneNumber;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(FirstName);
        parcel.writeString(LastName);
        parcel.writeString(PhoneNumber);
    }
}


