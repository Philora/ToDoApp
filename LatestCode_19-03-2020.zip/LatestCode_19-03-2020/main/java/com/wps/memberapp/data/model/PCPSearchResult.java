
package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PCPSearchResult implements Parcelable {

    @SerializedName("Distance")
    @Expose
    private String distance;
    @SerializedName("Providers")
    @Expose
    private List<Provider> providers = null;
    @SerializedName("RecordCount")
    @Expose
    private Integer recordCount;
    @SerializedName("ADAAccessibility")
    @Expose
    private String aDAAccessibility;
    @SerializedName("Address1")
    @Expose
    private String address1;
    @SerializedName("Address2")
    @Expose
    private String address2;
    @SerializedName("City")
    @Expose
    private String city;
    @SerializedName("ClinicName")
    @Expose
    private String clinicName;
    @SerializedName("ClinicWebsite")
    @Expose
    private String clinicWebsite;
    @SerializedName("County")
    @Expose
    private String county;
    @SerializedName("FACILITYNAME")
    @Expose
    private Object fACILITYNAME;
    @SerializedName("ISCHC")
    @Expose
    private String iSCHC;
    @SerializedName("ISPCMH")
    @Expose
    private String iSPCMH;
    @SerializedName("Latitude")
    @Expose
    private String latitude;
    @SerializedName("Longitude")
    @Expose
    private String longitude;
    @SerializedName("PhoneNumber")
    @Expose
    private String phoneNumber;
    @SerializedName("DISTANCE")
    @Expose
    private String dISTANCE;
    @SerializedName("State")
    @Expose
    private String state;
    @SerializedName("Telemedicine")
    @Expose
    private String telemedicine;
    @SerializedName("ZipCode")
    @Expose
    private String zipCode;

    protected PCPSearchResult(Parcel in) {
        distance = in.readString();
        if (in.readByte() == 0) {
            recordCount = null;
        } else {
            recordCount = in.readInt();
        }
        aDAAccessibility = in.readString();
        address1 = in.readString();
        address2 = in.readString();
        city = in.readString();
        clinicName = in.readString();
        clinicWebsite = in.readString();
        county = in.readString();
        iSCHC = in.readString();
        iSPCMH = in.readString();
        latitude = in.readString();
        longitude = in.readString();
        phoneNumber = in.readString();
        dISTANCE = in.readString();
        state = in.readString();
        telemedicine = in.readString();
        zipCode = in.readString();
    }

    public static final Creator<PCPSearchResult> CREATOR = new Creator<PCPSearchResult>() {
        @Override
        public PCPSearchResult createFromParcel(Parcel in) {
            return new PCPSearchResult(in);
        }

        @Override
        public PCPSearchResult[] newArray(int size) {
            return new PCPSearchResult[size];
        }
    };

    public String getDistance() {
        return distance;
    }

    public List<Provider> getProviders() {
        return providers;
    }

    public Integer getRecordCount() {
        return recordCount;
    }

    public String getADAAccessibility() {
        return aDAAccessibility;
    }

    public String getAddress1() {
        return address1;
    }

    public String getAddress2() {
        return address2;
    }

    public String getCity() {
        return city;
    }

    public String getClinicName() {
        return clinicName;
    }

    public String getClinicWebsite() {
        return clinicWebsite;
    }

    public String getCounty() {
        return county;
    }

    public Object getFACILITYNAME() {
        return fACILITYNAME;
    }

    public String getISCHC() {
        return iSCHC;
    }

    public String getISPCMH() {
        return iSPCMH;
    }

    public String getLatitude() {
        return latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getDISTANCE() {
        return dISTANCE;
    }

    public String getState() {
        return state;
    }

    public String getTelemedicine() {
        return telemedicine;
    }

    public String getZipCode() {
        return zipCode;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(clinicName);
        parcel.writeString(address1);
        parcel.writeString(city);
        parcel.writeString(state);
        parcel.writeString(zipCode);
        parcel.writeString(clinicWebsite);
        parcel.writeString(latitude);
        parcel.writeString(longitude);
    }
}
