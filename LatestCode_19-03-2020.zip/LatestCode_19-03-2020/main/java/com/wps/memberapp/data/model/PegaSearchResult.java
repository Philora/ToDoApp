package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by 133580 on 12/20/2017.
 */

public class PegaSearchResult implements Parcelable {

    @SerializedName("Title")
    @Expose
    private String Title;

    @SerializedName("Message")
    @Expose
    private String Message;

    @SerializedName("URL")
    @Expose
    private String URL;

    public PegaSearchResult(){}

    private PegaSearchResult(Parcel in) {
        Title = in.readString();
        Message = in.readString();
        URL = in.readString();
    }

    public static final Creator<PegaSearchResult> CREATOR = new Creator<PegaSearchResult>() {
        @Override
        public PegaSearchResult createFromParcel(Parcel in) {
            return new PegaSearchResult(in);
        }

        @Override
        public PegaSearchResult[] newArray(int size) {
            return new PegaSearchResult[size];
        }
    };


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(Title);
        parcel.writeString(Message);
        parcel.writeString(URL);
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getMessage() {
        return Message;
    }

    public void setMessage(String message) {
        Message = message;
    }

    public String getURL() {
        return URL;
    }

    public void setURL(String URL) {
        this.URL = URL;
    }
}

