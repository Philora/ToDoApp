package com.wps.memberapp.data.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PlaceOfService {

    @SerializedName("$id")
    @Expose
    private String mId;

    @SerializedName("Code")
    @Expose
    private String mCode;

    @SerializedName("Description")
    @Expose
    private String mDescription;

    public String getId() {
        return mId;
    }

    public String getCode() {
        return mCode;
    }

    public String getDescription() {
        return mDescription;
    }
}
