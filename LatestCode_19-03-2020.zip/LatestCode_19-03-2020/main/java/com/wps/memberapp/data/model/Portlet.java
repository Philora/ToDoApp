package com.wps.memberapp.data.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class Portlet {

    public static final int MEMBER_FEED = 1;
    public static final int NOTIFICATION = 2;
    public static final int MY_COVERAGE = 3;
    public static final int ACCOUNT_BALANCE = 4;
//    public static final int AUTHORIZATION_REFERAL = -1;
    public static final int AUTHORIZATION_REFERAL = 7;
    public static final int MYCLAIM = 5;
    public static final int ACCOUNT_BALANCE_OOP = 16;
    public static final int CARE_ASSESSMENT = 19;


    @SerializedName("Widget_ID")
    @Expose
    private int viewType;

    @SerializedName("Widget_Description")
    @Expose
    private String heading;

    public int getViewType() {
        return viewType;
    }

    public void setViewType(int viewType) {
        this.viewType = viewType;
    }

    public void setHeading(String heading) {
        this.heading = heading;
    }

    public String getHeading() {
        return heading;
    }
}
