package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import androidx.annotation.NonNull;


public class ProcedureServicesDetails implements Parcelable {


    @SerializedName("$id")
    @Expose
    private String mID;


    @SerializedName("PS_ID")
    @Expose
    private final String mPSID;


    @SerializedName("PS_Description")
    @Expose
    private final String mPSDescription;


    @SerializedName("ReceivedDate")
    @Expose
    private final String mReceivedDate;


    @SerializedName("FromDate")
    @Expose
    private final String mFromDate;


    @SerializedName("ToDate")
    @Expose
    private final String mToDate;


    @SerializedName("PS_Status")
    @Expose
    private final String mStatus;

    private ProcedureServicesDetails(Parcel in) {
        mID = in.readString();
        mPSID = in.readString();
        mPSDescription = in.readString();
        mReceivedDate = in.readString();
        mFromDate = in.readString();
        mToDate = in.readString();
        mStatus = in.readString();
    }

    public static final Creator<ProcedureServicesDetails> CREATOR = new Creator<ProcedureServicesDetails>() {
        @Override
        public ProcedureServicesDetails createFromParcel(@NonNull Parcel in) {
            return new ProcedureServicesDetails(in);
        }

        @Override
        public ProcedureServicesDetails[] newArray(int size) {
            return new ProcedureServicesDetails[size];
        }
    };


    public String getId() {
        return mID;
    }

    public void setId(String mID) {
        this.mID = mID;
    }


    public String getPS_IDe() {
        return mPSID;
    }



    public String getPS_Description() {
        return mPSDescription;
    }


    public String getReceivedDate() {
        return mReceivedDate;
    }


    public String getFromDate() {
        return mFromDate;
    }


    public String getStatus() {
        return mStatus;
    }


    public String getToDate() {
        return mToDate;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(mID);
        parcel.writeString(mPSID);
        parcel.writeString(mPSDescription);
        parcel.writeString(mReceivedDate);
        parcel.writeString(mFromDate);
        parcel.writeString(mToDate);
        parcel.writeString(mStatus);
    }
}




