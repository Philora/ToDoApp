
package com.wps.memberapp.data.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Provider {

    @SerializedName("AcceptingPatients")
    @Expose
    private String acceptingPatients;
    @SerializedName("Accessibility")
    @Expose
    private String accessibility;
    @SerializedName("Accreditation")
    @Expose
    private String accreditation;
    @SerializedName("AccreditationLink")
    @Expose
    private String accreditationLink;
    @SerializedName("AreasOfExpertise")
    @Expose
    private String areasOfExpertise;
    @SerializedName("BoardCertifications")
    @Expose
    private String boardCertifications;
    @SerializedName("ClinicalStafLanguage")
    @Expose
    private String clinicalStafLanguage;
    @SerializedName("CulturalCompetence")
    @Expose
    private String culturalCompetence;
    @SerializedName("CulturalExperiance")
    @Expose
    private String culturalExperiance;
    @SerializedName("EthenicRace")
    @Expose
    private String ethenicRace;
    @SerializedName("EXAM_ROOM_ACCESS")
    @Expose
    private String eXAMROOMACCESS;
    @SerializedName("EXAM_TABLE_SCALE_ACCESS")
    @Expose
    private String eXAMTABLESCALEACCESS;
    @SerializedName("EXTENDED_HOUR")
    @Expose
    private String eXTENDEDHOUR;
    @SerializedName("EXTERIOR_BUILDING_ACCESS")
    @Expose
    private String eXTERIORBUILDINGACCESS;
    @SerializedName("FirstName")
    @Expose
    private String firstName;
    @SerializedName("FRIDAY_HOURS")
    @Expose
    private String fRIDAYHOURS;
    @SerializedName("Gender")
    @Expose
    private String gender;
    @SerializedName("HospAffiliationName")
    @Expose
    private String hospAffiliationName;
    @SerializedName("HospitalQualityLink")
    @Expose
    private String hospitalQualityLink;
    @SerializedName("INTERIOR_BUILDING_ACCESS")
    @Expose
    private String iNTERIORBUILDINGACCESS;
    @SerializedName("InterpretationServices")
    @Expose
    private String interpretationServices;
    @SerializedName("IsER_Physician")
    @Expose
    private String isERPhysician;
    @SerializedName("IsUrgentcare")
    @Expose
    private String isUrgentcare;
    @SerializedName("Languages")
    @Expose
    private String languages;
    @SerializedName("LastName")
    @Expose
    private String lastName;
    @SerializedName("LICENSE")
    @Expose
    private String lICENSE;
    @SerializedName("LIMITATIONS")
    @Expose
    private String lIMITATIONS;
    @SerializedName("MiddleName")
    @Expose
    private String middleName;
    @SerializedName("MONDAY_HOURS")
    @Expose
    private String mONDAYHOURS;
    @SerializedName("MoreInfo")
    @Expose
    private Object moreInfo;
    @SerializedName("PARKING_ACCESS")
    @Expose
    private String pARKINGACCESS;
    @SerializedName("PCPFlag")
    @Expose
    private Boolean pCPFlag;
    @SerializedName("Physician")
    @Expose
    private String physician;
    @SerializedName("PracticeGroup")
    @Expose
    private String practiceGroup;
    @SerializedName("ProviderId")
    @Expose
    private String providerId;
    @SerializedName("ProviderType")
    @Expose
    private String providerType;
    @SerializedName("RESTROOM_ACCESS")
    @Expose
    private String rESTROOMACCESS;
    @SerializedName("SATURDAY_HOURS")
    @Expose
    private String sATURDAYHOURS;
    @SerializedName("Specialties")
    @Expose
    private Object specialties;
    @SerializedName("Specialty")
    @Expose
    private String specialty;
    @SerializedName("SUNDAY_HOURS")
    @Expose
    private String sUNDAYHOURS;
    @SerializedName("THURSDAY_HOURS")
    @Expose
    private String tHURSDAYHOURS;
    @SerializedName("TUESDAY_HOURS")
    @Expose
    private String tUESDAYHOURS;
    @SerializedName("WEDNESDAY_HOURS")
    @Expose
    private String wEDNESDAYHOURS;
    @SerializedName("RecordCount")
    @Expose
    private Integer recordCount;
    @SerializedName("ADAAccessibility")
    @Expose
    private String aDAAccessibility;
    @SerializedName("Address1")
    @Expose
    private String address1;
    @SerializedName("Address2")
    @Expose
    private String address2;
    @SerializedName("City")
    @Expose
    private String city;
    @SerializedName("ClinicName")
    @Expose
    private String clinicName;
    @SerializedName("ClinicWebsite")
    @Expose
    private String clinicWebsite;
    @SerializedName("County")
    @Expose
    private String county;
    @SerializedName("FACILITYNAME")
    @Expose
    private String fACILITYNAME;
    @SerializedName("ISCHC")
    @Expose
    private String iSCHC;
    @SerializedName("ISPCMH")
    @Expose
    private String iSPCMH;
    @SerializedName("Latitude")
    @Expose
    private String latitude;
    @SerializedName("Longitude")
    @Expose
    private String longitude;
    @SerializedName("PhoneNumber")
    @Expose
    private String phoneNumber;
    @SerializedName("DISTANCE")
    @Expose
    private String dISTANCE;
    @SerializedName("State")
    @Expose
    private String state;
    @SerializedName("Telemedicine")
    @Expose
    private String telemedicine;
    @SerializedName("ZipCode")
    @Expose
    private String zipCode;

    public String getAcceptingPatients() {
        return acceptingPatients;
    }

    public void setAcceptingPatients(String acceptingPatients) {
        this.acceptingPatients = acceptingPatients;
    }

    public String getAccessibility() {
        return accessibility;
    }

    public void setAccessibility(String accessibility) {
        this.accessibility = accessibility;
    }

    public String getAccreditation() {
        return accreditation;
    }

    public void setAccreditation(String accreditation) {
        this.accreditation = accreditation;
    }

    public String getAccreditationLink() {
        return accreditationLink;
    }

    public void setAccreditationLink(String accreditationLink) {
        this.accreditationLink = accreditationLink;
    }

    public String getAreasOfExpertise() {
        return areasOfExpertise;
    }

    public void setAreasOfExpertise(String areasOfExpertise) {
        this.areasOfExpertise = areasOfExpertise;
    }

    public String getBoardCertifications() {
        return boardCertifications;
    }

    public void setBoardCertifications(String boardCertifications) {
        this.boardCertifications = boardCertifications;
    }

    public String getClinicalStafLanguage() {
        return clinicalStafLanguage;
    }

    public void setClinicalStafLanguage(String clinicalStafLanguage) {
        this.clinicalStafLanguage = clinicalStafLanguage;
    }

    public String getCulturalCompetence() {
        return culturalCompetence;
    }

    public void setCulturalCompetence(String culturalCompetence) {
        this.culturalCompetence = culturalCompetence;
    }

    public String getCulturalExperiance() {
        return culturalExperiance;
    }

    public void setCulturalExperiance(String culturalExperiance) {
        this.culturalExperiance = culturalExperiance;
    }

    public String getEthenicRace() {
        return ethenicRace;
    }

    public void setEthenicRace(String ethenicRace) {
        this.ethenicRace = ethenicRace;
    }

    public String getEXAMROOMACCESS() {
        return eXAMROOMACCESS;
    }

    public void setEXAMROOMACCESS(String eXAMROOMACCESS) {
        this.eXAMROOMACCESS = eXAMROOMACCESS;
    }

    public String getEXAMTABLESCALEACCESS() {
        return eXAMTABLESCALEACCESS;
    }

    public void setEXAMTABLESCALEACCESS(String eXAMTABLESCALEACCESS) {
        this.eXAMTABLESCALEACCESS = eXAMTABLESCALEACCESS;
    }

    public String getEXTENDEDHOUR() {
        return eXTENDEDHOUR;
    }

    public void setEXTENDEDHOUR(String eXTENDEDHOUR) {
        this.eXTENDEDHOUR = eXTENDEDHOUR;
    }

    public String getEXTERIORBUILDINGACCESS() {
        return eXTERIORBUILDINGACCESS;
    }

    public void setEXTERIORBUILDINGACCESS(String eXTERIORBUILDINGACCESS) {
        this.eXTERIORBUILDINGACCESS = eXTERIORBUILDINGACCESS;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getFRIDAYHOURS() {
        return fRIDAYHOURS;
    }

    public void setFRIDAYHOURS(String fRIDAYHOURS) {
        this.fRIDAYHOURS = fRIDAYHOURS;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getHospAffiliationName() {
        return hospAffiliationName;
    }

    public void setHospAffiliationName(String hospAffiliationName) {
        this.hospAffiliationName = hospAffiliationName;
    }

    public String getHospitalQualityLink() {
        return hospitalQualityLink;
    }

    public void setHospitalQualityLink(String hospitalQualityLink) {
        this.hospitalQualityLink = hospitalQualityLink;
    }

    public String getINTERIORBUILDINGACCESS() {
        return iNTERIORBUILDINGACCESS;
    }

    public void setINTERIORBUILDINGACCESS(String iNTERIORBUILDINGACCESS) {
        this.iNTERIORBUILDINGACCESS = iNTERIORBUILDINGACCESS;
    }

    public String getInterpretationServices() {
        return interpretationServices;
    }

    public void setInterpretationServices(String interpretationServices) {
        this.interpretationServices = interpretationServices;
    }

    public String getIsERPhysician() {
        return isERPhysician;
    }

    public void setIsERPhysician(String isERPhysician) {
        this.isERPhysician = isERPhysician;
    }

    public String getIsUrgentcare() {
        return isUrgentcare;
    }

    public void setIsUrgentcare(String isUrgentcare) {
        this.isUrgentcare = isUrgentcare;
    }

    public String getLanguages() {
        return languages;
    }

    public void setLanguages(String languages) {
        this.languages = languages;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getLICENSE() {
        return lICENSE;
    }

    public void setLICENSE(String lICENSE) {
        this.lICENSE = lICENSE;
    }

    public String getLIMITATIONS() {
        return lIMITATIONS;
    }

    public void setLIMITATIONS(String lIMITATIONS) {
        this.lIMITATIONS = lIMITATIONS;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getMONDAYHOURS() {
        return mONDAYHOURS;
    }

    public void setMONDAYHOURS(String mONDAYHOURS) {
        this.mONDAYHOURS = mONDAYHOURS;
    }

    public Object getMoreInfo() {
        return moreInfo;
    }

    public void setMoreInfo(Object moreInfo) {
        this.moreInfo = moreInfo;
    }

    public String getPARKINGACCESS() {
        return pARKINGACCESS;
    }

    public void setPARKINGACCESS(String pARKINGACCESS) {
        this.pARKINGACCESS = pARKINGACCESS;
    }

    public Boolean getPCPFlag() {
        return pCPFlag;
    }

    public void setPCPFlag(Boolean pCPFlag) {
        this.pCPFlag = pCPFlag;
    }

    public String getPhysician() {
        return physician;
    }

    public void setPhysician(String physician) {
        this.physician = physician;
    }

    public String getPracticeGroup() {
        return practiceGroup;
    }

    public void setPracticeGroup(String practiceGroup) {
        this.practiceGroup = practiceGroup;
    }

    public String getProviderId() {
        return providerId;
    }

    public void setProviderId(String providerId) {
        this.providerId = providerId;
    }

    public String getProviderType() {
        return providerType;
    }

    public void setProviderType(String providerType) {
        this.providerType = providerType;
    }

    public String getRESTROOMACCESS() {
        return rESTROOMACCESS;
    }

    public void setRESTROOMACCESS(String rESTROOMACCESS) {
        this.rESTROOMACCESS = rESTROOMACCESS;
    }

    public String getSATURDAYHOURS() {
        return sATURDAYHOURS;
    }

    public void setSATURDAYHOURS(String sATURDAYHOURS) {
        this.sATURDAYHOURS = sATURDAYHOURS;
    }

    public Object getSpecialties() {
        return specialties;
    }

    public void setSpecialties(Object specialties) {
        this.specialties = specialties;
    }

    public String getSpecialty() {
        return specialty;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }

    public String getSUNDAYHOURS() {
        return sUNDAYHOURS;
    }

    public void setSUNDAYHOURS(String sUNDAYHOURS) {
        this.sUNDAYHOURS = sUNDAYHOURS;
    }

    public String getTHURSDAYHOURS() {
        return tHURSDAYHOURS;
    }

    public void setTHURSDAYHOURS(String tHURSDAYHOURS) {
        this.tHURSDAYHOURS = tHURSDAYHOURS;
    }

    public String getTUESDAYHOURS() {
        return tUESDAYHOURS;
    }

    public void setTUESDAYHOURS(String tUESDAYHOURS) {
        this.tUESDAYHOURS = tUESDAYHOURS;
    }

    public String getWEDNESDAYHOURS() {
        return wEDNESDAYHOURS;
    }

    public void setWEDNESDAYHOURS(String wEDNESDAYHOURS) {
        this.wEDNESDAYHOURS = wEDNESDAYHOURS;
    }

    public Integer getRecordCount() {
        return recordCount;
    }

    public void setRecordCount(Integer recordCount) {
        this.recordCount = recordCount;
    }

    public String getADAAccessibility() {
        return aDAAccessibility;
    }

    public void setADAAccessibility(String aDAAccessibility) {
        this.aDAAccessibility = aDAAccessibility;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getClinicName() {
        return clinicName;
    }

    public void setClinicName(String clinicName) {
        this.clinicName = clinicName;
    }

    public String getClinicWebsite() {
        return clinicWebsite;
    }

    public void setClinicWebsite(String clinicWebsite) {
        this.clinicWebsite = clinicWebsite;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getFACILITYNAME() {
        return fACILITYNAME;
    }

    public void setFACILITYNAME(String fACILITYNAME) {
        this.fACILITYNAME = fACILITYNAME;
    }

    public String getISCHC() {
        return iSCHC;
    }

    public void setISCHC(String iSCHC) {
        this.iSCHC = iSCHC;
    }

    public String getISPCMH() {
        return iSPCMH;
    }

    public void setISPCMH(String iSPCMH) {
        this.iSPCMH = iSPCMH;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getDISTANCE() {
        return dISTANCE;
    }

    public void setDISTANCE(String dISTANCE) {
        this.dISTANCE = dISTANCE;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getTelemedicine() {
        return telemedicine;
    }

    public void setTelemedicine(String telemedicine) {
        this.telemedicine = telemedicine;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

}
