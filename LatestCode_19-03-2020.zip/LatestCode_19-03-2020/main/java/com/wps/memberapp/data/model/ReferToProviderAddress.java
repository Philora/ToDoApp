package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import androidx.annotation.NonNull;


public class ReferToProviderAddress implements Parcelable {

    
    @SerializedName("FirstName")
    @Expose
    private final String mFirstName;

    
    @SerializedName("Address")
    @Expose
    private final Address mAddress;

    
    @SerializedName("MiddleName")
    @Expose
    private final String mMiddleName;

    @SerializedName("LastName")
    @Expose
    private final String mLastName;

    
    @SerializedName("Group")
    @Expose
    private final String mGroup;

    
    @SerializedName("ProviderId")
    @Expose
    private final String mProvider;

    @SerializedName("Gender")
    @Expose
    private final String mGender;

    @SerializedName("ProviderType")
    @Expose
    private final String mProviderType;

    @SerializedName("NPI")
    @Expose
    private final String mNPI;


    private ReferToProviderAddress(Parcel in) {
        mFirstName = in.readString();
        mLastName = in.readString();
        mMiddleName = in.readString();
        mAddress = in.readParcelable(Address.class.getClassLoader());
        mGroup = in.readString();
        mProvider = in.readString();
        mGender = in.readString();
        mNPI = in.readString();
        mProviderType = in.readString();
    }

    public static final Creator<ReferToProviderAddress> CREATOR = new Creator<ReferToProviderAddress>() {
        @Override
        public ReferToProviderAddress createFromParcel(@NonNull Parcel in) {
            return new ReferToProviderAddress(in);
        }

        @Override
        public ReferToProviderAddress[] newArray(int size) {
            return new ReferToProviderAddress[size];
        }
    };

    public String getFirstName() {
        return mFirstName;
    }

    public Address getAddress() {
        return mAddress;
    }

    public String getLastName() {
        return mLastName;
    }

    public String getMiddleName() {
        return mMiddleName;
    }
    
    public String getGroup() {
        return mGroup;
    }

    public String getProvider() {
        return mProvider;
    }

    public String getmGender() {
        return mGender;
    }

    public String getmNPI() {
        return mNPI;
    }

    public String getProviderType() {
        return mProviderType;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(mFirstName);
        parcel.writeString(mMiddleName);
        parcel.writeString(mLastName);
        parcel.writeParcelable(mAddress, i);
        parcel.writeString(mGroup);
        parcel.writeString(mProvider);
        parcel.writeString(mGender);
        parcel.writeString(mNPI);
        parcel.writeString(mProviderType);
    }
}
