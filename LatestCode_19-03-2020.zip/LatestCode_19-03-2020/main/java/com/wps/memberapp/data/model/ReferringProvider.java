package com.wps.memberapp.data.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ReferringProvider {

    @SerializedName("FirstName")
    @Expose
    private final String mFirstName;

    @SerializedName("LastName")
    @Expose
    private final String mLastName;

    public ReferringProvider(String mFirstName, String mLastName) {
        super();
        this.mFirstName = mFirstName;
        this.mLastName = mLastName;
    }

    public String getFirstName() {
        return mFirstName;
    }

    public String getLastName() {
        return mLastName;
    }
}
