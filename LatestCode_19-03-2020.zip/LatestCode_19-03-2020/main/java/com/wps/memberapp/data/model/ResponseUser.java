package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ResponseUser implements Parcelable {


    @SerializedName("FNAME")
    @Expose
    private String fNAME;
    @SerializedName("LNAME")
    @Expose
    private String lNAME;

    protected ResponseUser(Parcel in) {
        fNAME = in.readString();
        lNAME = in.readString();
    }

    public static final Creator<ResponseUser> CREATOR = new Creator<ResponseUser>() {
        @Override
        public ResponseUser createFromParcel(Parcel in) {
            return new ResponseUser(in);
        }

        @Override
        public ResponseUser[] newArray(int size) {
            return new ResponseUser[size];
        }
    };

    public String getFNAME() {
        return fNAME;
    }

    public String getLNAME() {
        return lNAME;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(fNAME);
        parcel.writeString(lNAME);
    }
}
