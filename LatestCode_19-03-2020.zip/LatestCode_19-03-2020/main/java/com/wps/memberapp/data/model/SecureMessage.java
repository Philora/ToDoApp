package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

import androidx.annotation.NonNull;

public class SecureMessage implements Parcelable {

    @SerializedName("MessageResponseList")
    @Expose
    private List<MessageResponseList> messageResponseList;

    @SerializedName("SubscriberId")
    @Expose
    private String subscriberId;


    @SerializedName("MessageID")
    @Expose
    private final String messageID;


    @SerializedName("SenderFirstName")
    @Expose
    private final String senderFirstName;


    @SerializedName("SenderLastName")
    @Expose
    private final String senderLastName;


    @SerializedName("SentReceiveDate")
    @Expose
    private final String sentReceiveDate;


    @SerializedName("Subject")
    @Expose
    private final String subject;


    @SerializedName("Status")
    @Expose
    private final String status;


    @SerializedName("MsgType")
    @Expose
    private final String msgType;


    @SerializedName("ReceiveDate")
    @Expose
    private final String receiveDate;


    @SerializedName("LastActivityDate")
    @Expose
    private final String lastActivityDate;


    @SerializedName("MessageBody")
    @Expose
    private final String messageBody;

    @SerializedName("EncryptMsgId")
    @Expose
    private final String mEncryptMsgId;

    @SerializedName("HashCode")
    @Expose
    private final String mHashCode;

    @SerializedName("GeneratedfileName")
    @Expose
    private final String mGeneratedfileName;

    private SecureMessage(Parcel in) {
        messageID = in.readString();
        mEncryptMsgId = in.readString();
        senderFirstName = in.readString();
        senderLastName = in.readString();
        sentReceiveDate = in.readString();
        subject = in.readString();
        status = in.readString();
        msgType = in.readString();
        receiveDate = in.readString();
        lastActivityDate = in.readString();
        messageBody = in.readString();
        mHashCode = in.readString();
        mGeneratedfileName = in.readString();
    }

    public static final Creator<SecureMessage> CREATOR = new Creator<SecureMessage>() {
        @Override
        public SecureMessage createFromParcel(@NonNull Parcel in) {
            return new SecureMessage(in);
        }

        @Override
        public SecureMessage[] newArray(int size) {
            return new SecureMessage[size];
        }
    };


    public String getMessageID() {
        return messageID;
    }

    public String getEncryptMsgId() {
        return mEncryptMsgId;
    }

    public String getSenderFirstName() {
        return senderFirstName;
    }


    public String getSenderLastName() {
        return senderLastName;
    }


    public String getSent_ReceiveDate() {
        return sentReceiveDate;
    }


    public String getSubject() {
        return subject;
    }

    public String getHashCode() {
        return mHashCode;
    }

    public String getGeneratedfileName() {
        return mGeneratedfileName;
    }

    public String getStatus() {
        return status;
    }

    public String getMsgType() {
        return msgType;
    }

    public String getLastActivityDate() {
        return lastActivityDate;
    }

    public String getSubscriberId() {
        return subscriberId;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeTypedList(messageResponseList);
        parcel.writeString(subscriberId);
        parcel.writeString(messageID);
        parcel.writeString(mEncryptMsgId);
        parcel.writeString(senderFirstName);
        parcel.writeString(senderLastName);
        parcel.writeString(sentReceiveDate);
        parcel.writeString(subject);
        parcel.writeString(status);
        parcel.writeString(msgType);
        parcel.writeString(receiveDate);
        parcel.writeString(lastActivityDate);
        parcel.writeString(messageBody);
        parcel.writeString(mHashCode);
        parcel.writeString(mGeneratedfileName);
    }
}
