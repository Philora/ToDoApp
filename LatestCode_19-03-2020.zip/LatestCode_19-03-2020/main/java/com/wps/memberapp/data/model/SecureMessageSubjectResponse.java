package com.wps.memberapp.data.model;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SecureMessageSubjectResponse {

    @SerializedName("$id")
    @Expose
    private String $id;
    @SerializedName("CategoryID")
    @Expose
    private Integer categoryID;
    @SerializedName("MasterDataCategoryName")
    @Expose
    private String masterDataCategoryName;
    @SerializedName("Description")
    @Expose
    private String description;
    @SerializedName("CodeMaxLength")
    @Expose
    private Integer codeMaxLength;
    @SerializedName("DescriptionMaxLength")
    @Expose
    private Integer descriptionMaxLength;
    @SerializedName("MasterData")
    @Expose
    private List<MasterData> masterData = null;

    public String get$id() {
        return $id;
    }

    public void set$id(String $id) {
        this.$id = $id;
    }

    public Integer getCategoryID() {
        return categoryID;
    }

    public void setCategoryID(Integer categoryID) {
        this.categoryID = categoryID;
    }

    public String getMasterDataCategoryName() {
        return masterDataCategoryName;
    }

    public void setMasterDataCategoryName(String masterDataCategoryName) {
        this.masterDataCategoryName = masterDataCategoryName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getCodeMaxLength() {
        return codeMaxLength;
    }

    public void setCodeMaxLength(Integer codeMaxLength) {
        this.codeMaxLength = codeMaxLength;
    }

    public Integer getDescriptionMaxLength() {
        return descriptionMaxLength;
    }

    public void setDescriptionMaxLength(Integer descriptionMaxLength) {
        this.descriptionMaxLength = descriptionMaxLength;
    }

    public List<MasterData> getMasterData() {
        return masterData;
    }

    public void setMasterData(List<MasterData> masterData) {
        this.masterData = masterData;
    }

}
