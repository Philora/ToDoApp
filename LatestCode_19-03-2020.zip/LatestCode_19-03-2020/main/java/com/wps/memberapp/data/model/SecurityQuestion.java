package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import androidx.annotation.NonNull;


public class SecurityQuestion implements Parcelable {

    @SerializedName("Question_ID")
    @Expose
    private final String mQuestionID;

    @SerializedName("Question")
    @Expose
    private final String mQuestion;

    @SerializedName("Answer_Hash")
    @Expose
    private final String mAnswerHash;

    private SecurityQuestion(Parcel in) {
        mQuestionID = in.readString();
        mQuestion = in.readString();
        mAnswerHash = in.readString();
    }

    public static final Creator<SecurityQuestion> CREATOR = new Creator<SecurityQuestion>() {
        @Override
        public SecurityQuestion createFromParcel(@NonNull Parcel in) {
            return new SecurityQuestion(in);
        }

        @Override
        public SecurityQuestion[] newArray(int size) {
            return new SecurityQuestion[size];
        }
    };


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(mQuestionID);
        parcel.writeString(mQuestion);
        parcel.writeString(mAnswerHash);
    }

    public String getQuestionID() {
        return mQuestionID;
    }

    public String getQuestion() {
        return mQuestion;
    }

}


