
package com.wps.memberapp.data.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class TCCData {

    @SerializedName("FirstName")
    @Expose
    private String firstName;
    @SerializedName("LastName")
    @Expose
    private String lastName;
    @SerializedName("MiddleName")
    @Expose
    private Object middleName;
    @SerializedName("Gender")
    @Expose
    private Object gender;
    @SerializedName("PhoneNumber")
    @Expose
    private Object phoneNumber;
    @SerializedName("Organization")
    @Expose
    private Object organization;
    @SerializedName("AcceptingPatients")
    @Expose
    private Object acceptingPatients;
    @SerializedName("Address")
    @Expose
    private TccProvAddress TccProvAddress;
    @SerializedName("ProviderId")
    @Expose
    private String providerId;
    @SerializedName("Physician")
    @Expose
    private Object physician;
    @SerializedName("Location")
    @Expose
    private Object location;
    @SerializedName("Procedure")
    @Expose
    private String procedure;
    @SerializedName("AvgAmount")
    @Expose
    private Integer avgAmount;
    @SerializedName("GeoDistance")
    @Expose
    private Double geoDistance;
    @SerializedName("Latitude")
    @Expose
    private String latitude;
    @SerializedName("Longitude")
    @Expose
    private String longitude;
    @SerializedName("zipCode")
    @Expose
    private String zipCode;

    @SerializedName("DrugName")
    @Expose
    private String drugName;
    @SerializedName("Strength")
    @Expose
    private String strength;
    @SerializedName("Quantity")
    @Expose
    private String quantity;


    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Object getMiddleName() {
        return middleName;
    }

    public void setMiddleName(Object middleName) {
        this.middleName = middleName;
    }

    public Object getGender() {
        return gender;
    }

    public void setGender(Object gender) {
        this.gender = gender;
    }

    public Object getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(Object phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Object getOrganization() {
        return organization;
    }

    public void setOrganization(Object organization) {
        this.organization = organization;
    }

    public Object getAcceptingPatients() {
        return acceptingPatients;
    }

    public void setAcceptingPatients(Object acceptingPatients) {
        this.acceptingPatients = acceptingPatients;
    }

    public TccProvAddress getTccProvAddress() {
        return TccProvAddress;
    }

    public void setTccProvAddress(TccProvAddress TccProvAddress) {
        this.TccProvAddress = TccProvAddress;
    }

    public String getProviderId() {
        return providerId;
    }

    public void setProviderId(String providerId) {
        this.providerId = providerId;
    }

    public Object getPhysician() {
        return physician;
    }

    public void setPhysician(Object physician) {
        this.physician = physician;
    }

    public Object getLocation() {
        return location;
    }

    public void setLocation(Object location) {
        this.location = location;
    }

    public String getProcedure() {
        return procedure;
    }

    public void setProcedure(String procedure) {
        this.procedure = procedure;
    }

    public Integer getAvgAmount() {
        return avgAmount;
    }

    public void setAvgAmount(Integer avgAmount) {
        this.avgAmount = avgAmount;
    }

    public Double getGeoDistance() {
        return geoDistance;
    }

    public void setGeoDistance(Double geoDistance) {
        this.geoDistance = geoDistance;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getQuantity() {
        return quantity;
    }

    public String getStrength() {
        return strength;
    }

    public String getDrugName() {
        return drugName;
    }
}
