
package com.wps.memberapp.data.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class TccProvAddress {

    @SerializedName("Address1")
    @Expose
    private String address1;
    @SerializedName("Address2")
    @Expose
    private Object address2;
    @SerializedName("City")
    @Expose
    private Object city;
    @SerializedName("State")
    @Expose
    private String state;
    @SerializedName("ZipCode")
    @Expose
    private String zipCode;
    @SerializedName("PhoneNumber")
    @Expose
    private Object phoneNumber;
    @SerializedName("County")
    @Expose
    private Object county;
    @SerializedName("AddressType")
    @Expose
    private Object addressType;
    @SerializedName("Email")
    @Expose
    private Object email;
    @SerializedName("ContactNumber")
    @Expose
    private Object contactNumber;
    @SerializedName("Phone")
    @Expose
    private Object phone;
    @SerializedName("EffectiveDate")
    @Expose
    private Object effectiveDate;
    @SerializedName("TermDate")
    @Expose
    private Object termDate;
    @SerializedName("HomePhone")
    @Expose
    private Object homePhone;
    @SerializedName("BussinessPhone")
    @Expose
    private Object bussinessPhone;
    @SerializedName("Fax")
    @Expose
    private Object fax;
    @SerializedName("StateCode")
    @Expose
    private Object stateCode;

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public Object getAddress2() {
        return address2;
    }

    public void setAddress2(Object address2) {
        this.address2 = address2;
    }

    public Object getCity() {
        return city;
    }

    public void setCity(Object city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public Object getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(Object phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Object getCounty() {
        return county;
    }

    public void setCounty(Object county) {
        this.county = county;
    }

    public Object getAddressType() {
        return addressType;
    }

    public void setAddressType(Object addressType) {
        this.addressType = addressType;
    }

    public Object getEmail() {
        return email;
    }

    public void setEmail(Object email) {
        this.email = email;
    }

    public Object getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(Object contactNumber) {
        this.contactNumber = contactNumber;
    }

    public Object getPhone() {
        return phone;
    }

    public void setPhone(Object phone) {
        this.phone = phone;
    }

    public Object getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(Object effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public Object getTermDate() {
        return termDate;
    }

    public void setTermDate(Object termDate) {
        this.termDate = termDate;
    }

    public Object getHomePhone() {
        return homePhone;
    }

    public void setHomePhone(Object homePhone) {
        this.homePhone = homePhone;
    }

    public Object getBussinessPhone() {
        return bussinessPhone;
    }

    public void setBussinessPhone(Object bussinessPhone) {
        this.bussinessPhone = bussinessPhone;
    }

    public Object getFax() {
        return fax;
    }

    public void setFax(Object fax) {
        this.fax = fax;
    }

    public Object getStateCode() {
        return stateCode;
    }

    public void setStateCode(Object stateCode) {
        this.stateCode = stateCode;
    }

}
