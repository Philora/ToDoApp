package com.wps.memberapp.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class TypeOfService implements Parcelable {

    @SerializedName("$id")
    @Expose
    private String $id;
    @SerializedName("Code")
    @Expose
    private String code;
    @SerializedName("Description")
    @Expose
    private String description;

    protected TypeOfService(Parcel in) {
        $id = in.readString();
        code = in.readString();
        description = in.readString();
    }

    public static final Creator<TypeOfService> CREATOR = new Creator<TypeOfService>() {
        @Override
        public TypeOfService createFromParcel(Parcel in) {
            return new TypeOfService(in);
        }

        @Override
        public TypeOfService[] newArray(int size) {
            return new TypeOfService[size];
        }
    };

    public String get$id() {
        return $id;
    }

    public void set$id(String $id) {
        this.$id = $id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString($id);
        parcel.writeString(code);
        parcel.writeString(description);
    }
}
