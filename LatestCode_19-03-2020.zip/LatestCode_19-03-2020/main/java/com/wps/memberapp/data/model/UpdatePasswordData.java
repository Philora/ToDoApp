package com.wps.memberapp.data.model;

public class UpdatePasswordData {
    private String mOldPwd;
    private String mNewPwd;

    public String getOldPwd() {
        return mOldPwd;
    }

    public void setOldPwd(String mOldPwd) {
        this.mOldPwd = mOldPwd;
    }

    public String getNewPwd() {
        return mNewPwd;
    }

    public void setNewPwd(String mNewPwd) {
        this.mNewPwd = mNewPwd;
    }
}
