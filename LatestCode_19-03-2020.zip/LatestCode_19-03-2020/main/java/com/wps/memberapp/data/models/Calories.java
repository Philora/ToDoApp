package com.wps.memberapp.data.models;

/**
 * Created by 133580 on 2/25/2018.
 */

public class Calories {

}
