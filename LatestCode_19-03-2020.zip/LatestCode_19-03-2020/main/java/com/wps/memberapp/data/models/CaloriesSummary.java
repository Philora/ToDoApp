package com.wps.memberapp.data.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 133580 on 2/25/2018.
 */

public class CaloriesSummary {

    @SerializedName("activities-calories")
    @Expose
    private List<FitbitActivityValues> activities = new ArrayList<FitbitActivityValues>();

    public List<FitbitActivityValues> getActivities() {
        return activities;
    }

    public void setActivities(List<FitbitActivityValues> activities) {
        this.activities = activities;
    }
}
