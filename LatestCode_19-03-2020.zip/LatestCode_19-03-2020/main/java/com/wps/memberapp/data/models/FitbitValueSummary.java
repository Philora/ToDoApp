package com.wps.memberapp.data.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by 133580 on 2/25/2018.
 */

public class FitbitValueSummary implements Serializable {

    private Integer heart_rate;
    private String calories;
    private String steps;
    private String floors;
    private Double distance;
    private Double duration;
    private Integer Sleep;
    private Double goals;
    private String min;
    private String max;
    private String name;
    private String cardioMin;
    private String cardioMax;
    private String cardioName;
    private String peakMin;
    private String peakMax;
    private String peakName;
    private String resttLessCount;
    private String AwakeCount;


    public Integer getHeart_rate() {
        return heart_rate;
    }

    public void setHeart_rate(Integer heart_rate) {
        this.heart_rate = heart_rate;
    }

    public String getCalories() {
        return calories;
    }

    public void setCalories(String calories) {
        this.calories = calories;
    }

    public String getSteps() {
        return steps;
    }

    public void setSteps(String steps) {
        this.steps = steps;
    }

    public String getFloors() {
        return floors;
    }

    public void setFloors(String floors) {
        this.floors = floors;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }

    public Double getDuration() {
        return duration;
    }

    public void setDuration(Double duration) {
        this.duration = duration;
    }

    public Integer getSleep() {
        return Sleep;
    }

    public void setSleep(Integer sleep) {
        Sleep = sleep;
    }

    public Double getGoals() {
        return goals;
    }

    public void setGoals(Double goals) {
        this.goals = goals;
    }

    public String getMin() {
        return min;
    }

    public void setMin(String min) {
        this.min = min;
    };


    public String getMax() {
        return max;
    }

    public void setMax(String max) {
        this.max = max;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCardioMin() {
        return cardioMin;
    }

    public void setCardioMin(String cardioMin) {
        this.cardioMin = cardioMin;
    }

    public String getCardioMax() {
        return cardioMax;
    }

    public void setCardioMax(String cardioMax) {
        this.cardioMax = cardioMax;
    }

    public String getCardioName() {
        return cardioName;
    }

    public void setCardioName(String cardioName) {
        this.cardioName = cardioName;
    }

    public String getPeakMin() {
        return peakMin;
    }

    public void setPeakMin(String peakMin) {
        this.peakMin = peakMin;
    }

    public String getPeakMax() {
        return peakMax;
    }

    public void setPeakMax(String peakMax) {
        this.peakMax = peakMax;
    }

    public String getPeakName() {
        return peakName;
    }

    public void setPeakName(String peakName) {
        this.peakName = peakName;
    }

    public String getResttLessCount() {
        return resttLessCount;
    }

    public void setResttLessCount(String resttLessCount) {
        this.resttLessCount = resttLessCount;
    }

    public String getAwakeCount() {
        return AwakeCount;
    }

    public void setAwakeCount(String awakeCount) {
        AwakeCount = awakeCount;
    }
}
