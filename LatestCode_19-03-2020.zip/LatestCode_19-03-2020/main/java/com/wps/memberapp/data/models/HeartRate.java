package com.wps.memberapp.data.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by 133580 on 2/25/2018.
 */

public class HeartRate {
    @SerializedName("dateTime")
    @Expose
    private String date;

    @SerializedName("value")
    @Expose
    private RestingHeartRate value;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public RestingHeartRate getValue() {
        return value;
    }

    public void setValue(RestingHeartRate value) {
        this.value = value;
    }

}
