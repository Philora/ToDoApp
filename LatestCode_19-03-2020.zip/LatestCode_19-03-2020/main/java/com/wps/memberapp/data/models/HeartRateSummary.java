package com.wps.memberapp.data.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 133580 on 2/22/2018.
 */

public class HeartRateSummary {

    @SerializedName("activities-heart")
    @Expose
    private List<HeartRate> activities = new ArrayList<HeartRate>();

    public List<HeartRate> getActivities() {
        return activities;
    }

    public void setActivities(List<HeartRate> activities) {
        this.activities = activities;
    }


}
