package com.wps.memberapp.data.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by 133580 on 3/3/2018.
 */

public class HeartRateZone {

    @SerializedName("max")
    @Expose
    private String max;

    @SerializedName("min")
    @Expose
    private String min;

    @SerializedName("name")
    @Expose
    private String name;

    public String getMax() {
        return max;
    }

    public void setMax(String max) {
        this.max = max;
    }

    public String getMin() {
        return min;
    }

    public void setMin(String min) {
        this.min = min;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
