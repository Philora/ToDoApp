package com.wps.memberapp.data.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 133580 on 2/22/2018.
 */

public class RestingHeartRate {

    @SerializedName("restingHeartRate")
    @Expose
    private String restingHeartRate;

    @SerializedName("heartRateZones")
    @Expose
    private List<HeartRateZone> activities = new ArrayList<HeartRateZone>();

    public String getRestingHeartRate() {
        return restingHeartRate;
    }

    public void setRestingHeartRate(String restingHeartRate) {
        this.restingHeartRate = restingHeartRate;
    }

    public List<HeartRateZone> getActivities() {
        return activities;
    }

    public void setActivities(List<HeartRateZone> activities) {
        this.activities = activities;
    }
}
