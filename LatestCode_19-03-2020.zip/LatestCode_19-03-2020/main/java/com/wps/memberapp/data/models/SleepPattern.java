package com.wps.memberapp.data.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by 133580 on 2/27/2018.
 */

public class SleepPattern {

    @SerializedName("minutesAsleep")
    @Expose
    private String totalSleepRecords;

    @SerializedName("awakeningsCount")
    @Expose
    private String awakeningsCount;

    @SerializedName("restlessCount")
    @Expose
    private String restlessCount;

    @SerializedName("dateOfSleep")
    @Expose
    private String dateOfSleep;

    public String getTotalSleepRecords() {
        return totalSleepRecords;
    }

    public void setTotalSleepRecords(String totalSleepRecords) {
        this.totalSleepRecords = totalSleepRecords;
    }

    public String getDateOfSleep() {
        return dateOfSleep;
    }

    public void setDateOfSleep(String dateOfSleep) {
        this.dateOfSleep = dateOfSleep;
    }

    public String getAwakeningsCount() {
        return awakeningsCount;
    }

    public void setAwakeningsCount(String awakeningsCount) {
        this.awakeningsCount = awakeningsCount;
    }

    public String getRestlessCount() {
        return restlessCount;
    }

    public void setRestlessCount(String restlessCount) {
        this.restlessCount = restlessCount;
    }
}
