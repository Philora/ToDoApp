package com.wps.memberapp.data.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 133580 on 2/27/2018.
 */

public class SleepSummary {

    @SerializedName("sleep")
    @Expose
    private List<SleepPattern> sleepPattern;

    public List<SleepPattern> getSleepPattern() {
        return sleepPattern;
    }

    public void setSleepPattern(List<SleepPattern> sleepPattern) {
        this.sleepPattern = sleepPattern;
    }
}
