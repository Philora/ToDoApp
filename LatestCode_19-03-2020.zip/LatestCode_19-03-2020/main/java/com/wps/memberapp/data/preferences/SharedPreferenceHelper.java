package com.wps.memberapp.data.preferences;

import android.content.Context;
import android.content.SharedPreferences;

import com.wps.memberapp.utility.AppConstants;

import androidx.annotation.NonNull;


/**
 * This class is used to store persistent application data with shared preference.
 */
public class SharedPreferenceHelper {

    private static SharedPreferenceHelper mInstance;
    private SharedPreferences mPreferences;

    public static synchronized SharedPreferenceHelper getInstance() {
        if (mInstance == null) {
            mInstance = new SharedPreferenceHelper();
        }
        return mInstance;
    }

    private SharedPreferenceHelper() {

    }

    public void setPreference(@NonNull Context context, String key, String value) {
        mPreferences = context.getSharedPreferences(AppConstants.PREFS_FILE_NAME, 0);
        SharedPreferences.Editor editor = mPreferences.edit();
        editor.putString(key, value);
        editor.apply();
    }


    public String getPreference(@NonNull Context context, String key) {
        mPreferences = context.getSharedPreferences(AppConstants.PREFS_FILE_NAME, 0);
        return mPreferences.getString(key, null);
    }

    public void setPrefBoolean(@NonNull Context context, String key, boolean value) {
        mPreferences = context.getSharedPreferences(AppConstants.PREFS_FILE_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = mPreferences.edit();
        editor.putBoolean(key, value);
        editor.apply();
    }

    public boolean getPrefBoolean(@NonNull Context context, String key, boolean value) {
        mPreferences = context.getSharedPreferences(AppConstants.PREFS_FILE_NAME, Context.MODE_PRIVATE);
        return mPreferences.getBoolean(key, value);
    }

    public void clearPreference(@NonNull Context context, String key) {
        mPreferences = context.getSharedPreferences(AppConstants.PREFS_FILE_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = mPreferences.edit();
        editor.remove(key);
        editor.apply();
    }

    public static boolean isFirst(Context context) {
        final SharedPreferences reader = context.getSharedPreferences(AppConstants.PREFS_FILE_NAME, Context.MODE_PRIVATE);
        final boolean first = reader.getBoolean("is_first", true);
        if (first) {
            final SharedPreferences.Editor editor = reader.edit();
            editor.putBoolean("is_first", false);
            editor.apply();
        }
        return first;
    }
}
