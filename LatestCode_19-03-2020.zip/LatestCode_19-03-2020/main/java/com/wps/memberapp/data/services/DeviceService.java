package com.wps.memberapp.data.services;


import android.app.Activity;
import android.content.Loader;

import com.wps.memberapp.data.exceptions.MissingScopesException;
import com.wps.memberapp.data.exceptions.TokenExpiredException;
import com.wps.memberapp.data.loaders.ResourceLoaderFactory;
import com.wps.memberapp.data.loaders.ResourceLoaderResult;
import com.wps.memberapp.data.models.Device;
import com.wps.memberapp.domain.fitbitauth.authentication.Scope;

/**
 * Created by Shraddha
 */
public class DeviceService {

    private final static String DEVICE_URL = "https://api.fitbit.com/1/user/-/devices.json";
    private static final ResourceLoaderFactory<Device[]> USER_DEVICES_LOADER_FACTORY = new ResourceLoaderFactory<>(DEVICE_URL, Device[].class);

    public static Loader<ResourceLoaderResult<Device[]>> getUserDevicesLoader(Activity activityContext) throws MissingScopesException, TokenExpiredException {
        return USER_DEVICES_LOADER_FACTORY.newResourceLoader(activityContext, new Scope[]{Scope.settings});
    }

}
