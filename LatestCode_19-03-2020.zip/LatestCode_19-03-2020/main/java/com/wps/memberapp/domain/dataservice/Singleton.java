package com.wps.memberapp.domain.dataservice;

import android.content.Context;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;

import androidx.annotation.NonNull;

/**
 * This class provides global point of access to the created instance and
 * enforces that there can only ever be (at most) a single instance of a particular class (Singleton design pattern)
 */

public class Singleton {
    private static Singleton mInstance;
    private RequestQueue mRequestQueue;

    /**
     * No outer class can initialize this class's object
     */

    private Singleton(Context context) {
        mRequestQueue = getRequestQueue(context);
    }

    /**
     * if no instance is initialized yet then create new instance else return stored instance
     */

    public static synchronized Singleton getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new Singleton(context);
        }
        return mInstance;
    }

    private RequestQueue getRequestQueue(Context mCtx) {
        if (mRequestQueue == null) {
            mRequestQueue = Volley.newRequestQueue(mCtx);
        }
        return mRequestQueue;
    }

    <T> void addToRequestQueue(@NonNull Request<T> req) {
        mRequestQueue.add(req);
    }
}
