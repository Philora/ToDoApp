package com.wps.memberapp.domain.dataservice;

import com.android.volley.VolleyError;

/**
 * A Generic Volley Listener which get
 * result from class and give it to CallingActivity using Interface Callback
 */

public interface VolleyByteResponseListener {

  void onResponse(byte[] response);

  void onError(VolleyError error);
}

