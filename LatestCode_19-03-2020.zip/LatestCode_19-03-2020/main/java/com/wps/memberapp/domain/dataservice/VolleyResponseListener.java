package com.wps.memberapp.domain.dataservice;

/**
 * A Generic Volley Listener which get
 * result from class and give it to CallingActivity using Interface Callback
 */

public interface VolleyResponseListener {

  void onResponse(String message);

  void onError(String error);
}

