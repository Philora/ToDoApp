package com.wps.memberapp.domain.dataservice;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Header;
import com.android.volley.NetworkError;
import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.wps.memberapp.R;
import com.wps.memberapp.data.model.GetKnowledgeBase;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.domain.network.AddAppointmentRequest;
import com.wps.memberapp.domain.network.AddMedicationRequest;
import com.wps.memberapp.domain.network.AddVaccineRequest;
import com.wps.memberapp.domain.network.AuthRefSendInquiryRequest;
import com.wps.memberapp.domain.network.ChangePasswordRequest;
import com.wps.memberapp.domain.network.ClaimsSendInquiryRequest;
import com.wps.memberapp.domain.network.ComposeMessageRequest;
import com.wps.memberapp.domain.network.GetAccessTokenRequest;
import com.wps.memberapp.domain.network.GetAccountBalanceOOPRequest;
import com.wps.memberapp.domain.network.GetAccountBalanceOOPSummary;
import com.wps.memberapp.domain.network.GetAccountBalanceRequest;
import com.wps.memberapp.domain.network.GetAccountbalanceSummary;
import com.wps.memberapp.domain.network.GetAdvanceClaimSearch;
import com.wps.memberapp.domain.network.GetAdvanceSearchRequest;
import com.wps.memberapp.domain.network.GetApplicantsLocation;
import com.wps.memberapp.domain.network.GetAreaExpertise;
import com.wps.memberapp.domain.network.GetAuthDetailViewDataRequest;
import com.wps.memberapp.domain.network.GetAuthReferralRequest;
import com.wps.memberapp.domain.network.GetBenefitProductDetailsRequest;
import com.wps.memberapp.domain.network.GetBenefitUserDetailsRequest;
import com.wps.memberapp.domain.network.GetBenefitUserRequest;
import com.wps.memberapp.domain.network.GetCityCountryData;
import com.wps.memberapp.domain.network.GetClaimDetailViewRequest;
import com.wps.memberapp.domain.network.GetClaimDocumentRequest;
import com.wps.memberapp.domain.network.GetClaimSummaryRequest;
import com.wps.memberapp.domain.network.GetClaimsSearchRequest;
import com.wps.memberapp.domain.network.GetClinicNameData;
import com.wps.memberapp.domain.network.GetCountriesRequest;
import com.wps.memberapp.domain.network.GetDashboardPortletDetails;
import com.wps.memberapp.domain.network.GetDemographicHistoryRequest;
import com.wps.memberapp.domain.network.GetExpertPDFRequest;
import com.wps.memberapp.domain.network.GetExportProviderPDFRequest;
import com.wps.memberapp.domain.network.GetGroupNameData;
import com.wps.memberapp.domain.network.GetHRAPDFRequest;
import com.wps.memberapp.domain.network.GetHospitalAffiliationData;
import com.wps.memberapp.domain.network.GetIDCardPDFRequest;
import com.wps.memberapp.domain.network.GetImmunizationByMemberIDRequest;
import com.wps.memberapp.domain.network.GetImmunizationHistoryByMemberIDRequest;
import com.wps.memberapp.domain.network.GetImmunizationHistoryPDFRequest;
import com.wps.memberapp.domain.network.GetKnowledgeBaseRequest;
import com.wps.memberapp.domain.network.GetLanguageSpoken;
import com.wps.memberapp.domain.network.GetMedicationsByMemberIDRequest;
import com.wps.memberapp.domain.network.GetMemberDeductible;
import com.wps.memberapp.domain.network.GetMemberDetailRequest;
import com.wps.memberapp.domain.network.GetMemberEligInfoRequest;
import com.wps.memberapp.domain.network.GetMemberGroupListRequest;
import com.wps.memberapp.domain.network.GetMemberOOPRequest;
import com.wps.memberapp.domain.network.GetMembermedRequest;
import com.wps.memberapp.domain.network.GetNotificationsContentRequest;
import com.wps.memberapp.domain.network.GetNotificationsRequest;
import com.wps.memberapp.domain.network.GetPCPSearch;
import com.wps.memberapp.domain.network.GetProcedureCodes;
import com.wps.memberapp.domain.network.GetProfileRequest;
import com.wps.memberapp.domain.network.GetProvAuthDashboardRequest;
import com.wps.memberapp.domain.network.GetRescheduleMemRequest;
import com.wps.memberapp.domain.network.GetSecureMessageAttachment;
import com.wps.memberapp.domain.network.GetSecureMessageDetailViewRequest;
import com.wps.memberapp.domain.network.GetSecureMessageProvPCPRequest;
import com.wps.memberapp.domain.network.GetSecureMessageProvRequest;
import com.wps.memberapp.domain.network.GetSecureMessageRequest;
import com.wps.memberapp.domain.network.GetSecureMessageSearchRequest;
import com.wps.memberapp.domain.network.GetSecureMessageSubjectsRequest;
import com.wps.memberapp.domain.network.GetSecurityQuestionsRequest;
import com.wps.memberapp.domain.network.GetSpecialityData;
import com.wps.memberapp.domain.network.GetTreatmentCostParams;
import com.wps.memberapp.domain.network.GetUpdateDemographicsMemberRequest;
import com.wps.memberapp.domain.network.GetUserProfileRequest;
import com.wps.memberapp.domain.network.GetUserSecurityQuestionsRequest;
import com.wps.memberapp.domain.network.GetVaccineListRequest;
import com.wps.memberapp.domain.network.ImmunizationRegistrationRequest;
import com.wps.memberapp.domain.network.LogInRequest;
import com.wps.memberapp.domain.network.MemberFeedRequest;
import com.wps.memberapp.domain.network.NewCardByEmailRequest;
import com.wps.memberapp.domain.network.RegisterDeviceRequest;
import com.wps.memberapp.domain.network.SaveJsonResult;
import com.wps.memberapp.domain.network.SendReplyRequest;
import com.wps.memberapp.domain.network.TokenRequest;
import com.wps.memberapp.domain.network.UpdateDemographyRequest;
import com.wps.memberapp.domain.network.UpdateMemberGroupRequest;
import com.wps.memberapp.domain.network.UpdateSecurityQuestionsRequest;
import com.wps.memberapp.domain.network.ValidateIDCardRequest;
import com.wps.memberapp.domain.network.VerifyPwdRequest;
//import com.wps.memberapp.presentation.login.activity.DetectionActivity;
import com.wps.memberapp.utility.AlertDialogFragment;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.SessionManagementDialog;
import com.wps.memberapp.utility.StringConstants;

import org.apache.http.HttpStatus;

import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import static com.wps.memberapp.domain.dataservice.Singleton.getInstance;

/**
 * * An Interface class to executes the web service and handle callback using the volley.
 * Supported Methods: GET and POST.By default it will be executed on POST method.
 */

public class VolleyService {
    private static final String EXCEPTION = "exception";
    private static final String TIMEOUT_ERROR = "TIMEOUT_ERROR";
    private static final String NETWORK_ERROR = "NETWORK_ERROR";
    private static final String SET_COOKIE = "Set-Cookie";

    private VolleyService() {
    }

    /**
     * Request String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */
    public static void issueSTCToken(@NonNull final Context context,
                                     String url, @NonNull final VolleyResponseListener listener) {
        final AppCompatActivity activity = (AppCompatActivity) context;
        try {
    /*
    Initialize a new TokenRequest
    */
            TokenRequest stringRequest = new TokenRequest(url, response -> {
                listener.onResponse(response);
                Log.d("Token_Success_Response", response);
            }, error -> {
                try {
                    listener.onError(error.toString());
                    Log.d("Error_Response_FED", error.toString());
                    try {
                        listener.onError(error.toString());
                        NetworkResponse networkResponse = error.networkResponse;
                        if (networkResponse != null && networkResponse.statusCode == HttpURLConnection.HTTP_UNAUTHORIZED) {
                            showWrongCreds(activity.getString(R.string.wrong_credentials), activity);
                        } else {
                            showErrorDialog(error, activity);
                        }
                    } catch (Exception e) {
                        Logger.e(EXCEPTION, e);
                    }
                } catch (Exception e) {
                    Logger.e(EXCEPTION, e);
                }
            }, context) {
                @NonNull
                @Override
                protected Response<String> parseNetworkResponse(NetworkResponse response) {
                    try {
                        String type = response.headers.get("content-type");
                        if (type != null) {
                            response.headers.put(StringConstants.CONTENT_TYPE, type);
                        }
                        String responseString = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                        SharedPreferenceHelper.getInstance().setPreference
                                (context, AppConstants.AUTHORIZATION_TOKEN, responseString);
                        return Response.success(responseString,
                                HttpHeaderParser.parseCacheHeaders(response));
                    } catch (UnsupportedEncodingException e) {
                        return Response.error(new ParseError(e));
                    }
                }
            };

/*
Access the RequestQueue through singleton class
*/
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * Request String response from the Web API.
     *
     * @param context context of the activity.
     * @param url     the String refers the web service URL.
     */
    public static void issueSAMLFedAuth(@NonNull final Context context,
                                        String url, @NonNull final VolleyResponseListener listener) {
        final AppCompatActivity activity = (AppCompatActivity) context;
        try {
    /*
    Initialize a new FedAuthRequest
    */
            LogInRequest stringRequest =
                    new LogInRequest(url, context, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                listener.onResponse(response);
                                Log.d("cookie_Response_FED", response);
                            } catch (Exception e) {
                                e.getLocalizedMessage();
                            }
                        }
                    }, error -> {
                        listener.onError(error.toString());
                        Log.d("Error_Response_FED", error.toString());
                        showErrorDialog(error, activity);
                    }) {
                        @Override
                        protected Response<String> parseNetworkResponse(NetworkResponse response) {
                            handleCookies(response, context);
                    /*        CookieManager cmrCookieMan = new CookieManager    // Changing after Volley version from 1.0.0
                                    (new PersistentCookieStore(context), CookiePolicy.ACCEPT_ALL);
                            CookieHandler.setDefault(cmrCookieMan);
                            for (Map.Entry<String, String> entry : response.headers.entrySet()) {
                                Log.i(entry.getKey(), " <=> " + entry.getValue());
                            }
                            for (int i = 0; i < response.headers.size(); i++) {
                                String cookie = response.headers.get(SET_COOKIE);
                                if (cookie != null && cookie.length() > 0) {
                                    SharedPreferenceHelper.getInstance().setPreference(context, "sessionid", cookie);
                                }
                            }*/
                            return Response.success(response.allHeaders.toString(),
                                    HttpHeaderParser.parseCacheHeaders(response));
                        }
                    };
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the RequestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

  /*  // Faceprint Authentication UserToken
    public static void issueUserToken(Context mContext, LoginCallback callback) {
        final AppCompatActivity activity = (AppCompatActivity) mContext;
        new IssueUserTokenRequest(activity, new LoginCallback() {
            @Override
            public void onResponse(String response) {
                callback.onResponse(response);
            }

            @Override
            public void onError(int code, String message) {
                if (code == HttpsURLConnection.HTTP_UNAUTHORIZED) {
                    if (message.equalsIgnoreCase("10022")) {
                        showAccountLockMessage(activity);
                    } else {
                        showWrongCreds(activity.getString(R.string.wrong_credentials), activity);
                    }
                } else {
                    GeneralUtils.showAlertDialog(activity, "Something went wrong,please try again.");
                }
                callback.onError(code, message);
            }
        }).execute();
    }
*/

    /**
     * Get String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void getProfileData
    (final Context context, String url, @NonNull final VolleyResponseListener listener) {

        final AppCompatActivity activity = (AppCompatActivity) context;
        try {

    /*
    Initialize a new StringRequest
    */
            GetProfileRequest stringRequest =
                    new GetProfileRequest(Request.Method.GET, url,
                            context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.i("Profile_Success", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("Error_Response", error.toString());
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });

            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * Get String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void getUserProfileData
    (final Context context, String url, @NonNull final VolleyResponseListener listener) {

        final AppCompatActivity activity = (AppCompatActivity) context;
        try {

    /*
    Initialize a new StringRequest
    */
            GetUserProfileRequest stringRequest =
                    new GetUserProfileRequest(Request.Method.GET, url,
                            context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.i("User_Profile_Success", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("Error_Response", error.toString());
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });

            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void getDashboardPortletDetails
    (final Context context, String url, @NonNull final VolleyResponseListener listener) {

        final AppCompatActivity activity = (AppCompatActivity) context;
        try {
            GetDashboardPortletDetails stringRequest = new GetDashboardPortletDetails
                    (Request.Method.POST, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("Dashboard_Success", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("Error_Dashlets", error.toString());
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });

            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }


    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */
    public static void getMemberDetails
    (final Context context, String url, @NonNull final VolleyResponseListener listener) {
        final AppCompatActivity activity = (AppCompatActivity) context;
        try {
            GetMemberDetailRequest stringRequest = new GetMemberDetailRequest
                    (Request.Method.POST, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("Success_MemberInfo", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("Error_MemberInfo", error.toString());
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0, 0));
    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void getClaimSummaryData
    (final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            final AppCompatActivity activity = (AppCompatActivity) context;
            GetClaimSummaryRequest stringRequest = new GetClaimSummaryRequest(Request.Method.POST, url,
                    context, response -> {
                try {
                    listener.onResponse(response);
                    Log.d("Success_ClaimReferal", response);
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
            },
                    error -> {
                        try {
                            listener.onError(error.toString());
                            Log.d("Error_ClaimReferal", error.toString());
                            showErrorDialog(error, activity);
                        } catch (Exception e) {
                            Logger.e(EXCEPTION, e);
                        }
                    });

            stringRequest.setRetryPolicy(
                    new DefaultRetryPolicy(
                            60 * 1000,
                            0,
                            0
                    )
            );
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void getAccountBalanceData
    (final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetAccountbalanceSummary stringRequest = new GetAccountbalanceSummary
                    (Request.Method.POST, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("balance", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                listener.onError(error.toString());
                                Log.d("balance", error.toString());
                                final AppCompatActivity activity = (AppCompatActivity) context;
                                showErrorDialog(error, activity);
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void getAccountBalanceOOP
    (final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetAccountBalanceOOPSummary stringRequest = new GetAccountBalanceOOPSummary
                    (Request.Method.POST, url, context, response -> {
                        try {
                            Log.d("balance_oop", response);
                            listener.onResponse(response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                listener.onError(error.toString());
                                Log.d("balance_oop", error.toString());
                                final AppCompatActivity activity = (AppCompatActivity) context;
                                showErrorDialog(error, activity);
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void getAccountBalanceBenefitData
    (final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetAccountBalanceRequest stringRequest = new GetAccountBalanceRequest
                    (Request.Method.POST, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("balance", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                listener.onError(error.toString());
                                Log.d("balance", error.toString());
                                final AppCompatActivity activity = (AppCompatActivity) context;
                                showErrorDialog(error, activity);
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void getAccountBalanceBenefitOOP
    (final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetAccountBalanceOOPRequest stringRequest = new GetAccountBalanceOOPRequest
                    (Request.Method.POST, url, context, response -> {
                        try {
                            Log.d("balance_oop", response);
                            listener.onResponse(response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                listener.onError(error.toString());
                                Log.d("balance_oop", error.toString());
                                final AppCompatActivity activity = (AppCompatActivity) context;
                                showErrorDialog(error, activity);
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }


    /**
     * GET String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void getMemberFeedData
    (final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            MemberFeedRequest stringRequest = new MemberFeedRequest
                    (Request.Method.GET, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("Success_Member_Feed", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("Error_MemberFeed", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void getAuthorizationReferralData
    (final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetAuthReferralRequest stringRequest = new GetAuthReferralRequest
                    (Request.Method.POST, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("Success_AuthReferral", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("Error_AuthReferralData", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void getAdvanceSearchData
    (final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetAdvanceSearchRequest stringRequest = new GetAdvanceSearchRequest
                    (Request.Method.POST, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("Success_Advance_Searc", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("Error_Advance_Searc", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }


    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void getAdvanceSearchClaimData
    (final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetAdvanceClaimSearch stringRequest = new GetAdvanceClaimSearch
                    (Request.Method.POST, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("Success_Advance_Search", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("Error_Advance_Search", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void getAuthorizationDetailViewData
    (final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetAuthDetailViewDataRequest stringRequest = new GetAuthDetailViewDataRequest
                    (Request.Method.POST, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("Success_AuthDetailView", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    public static void getClaimDetailViewData
            (final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetClaimDetailViewRequest stringRequest = new GetClaimDetailViewRequest
                    (Request.Method.POST, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("Success_AuthDetailView", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("Error_AuthDataView", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param listener listener callback reference.
     */

    private static void claimsSendInquiryData(final Context context, @NonNull final VolleyResponseListener listener) {
        try {
            ClaimsSendInquiryRequest stringRequest = new ClaimsSendInquiryRequest
                    (Request.Method.POST, AppConstants.COMPOSE_MESSAGE, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("secure_message", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("secure_message", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    private static void authRefSendInquiryData(final Context context, @NonNull final VolleyResponseListener listener) {
        try {
            AuthRefSendInquiryRequest stringRequest = new AuthRefSendInquiryRequest
                    (Request.Method.POST, AppConstants.COMPOSE_MESSAGE, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("secure_message", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("secure_message", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    private static void composeMessageData
            (final Context context, @NonNull final VolleyResponseListener listener) {
        try {
            ComposeMessageRequest stringRequest = new ComposeMessageRequest
                    (Request.Method.POST, AppConstants.COMPOSE_MESSAGE, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("secure_message", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("secure_message", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void sendMessageData
    (@NonNull final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            SendReplyRequest stringRequest = new SendReplyRequest
                    (Request.Method.POST, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("Success_reply_message", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("Error_reply_message", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void getSecureMessageDetail(@NonNull final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetSecureMessageDetailViewRequest stringRequest = new GetSecureMessageDetailViewRequest
                    (Request.Method.POST, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("Success_secure", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("Error_secure", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void getSecureMessages(@NonNull final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetSecureMessageRequest stringRequest = new GetSecureMessageRequest
                    (Request.Method.POST, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("Success_secure_message", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("Error_secure_message", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * GET String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */
    public static void getSecureMessageSubjects
    (final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetSecureMessageSubjectsRequest stringRequest = new GetSecureMessageSubjectsRequest
                    (Request.Method.POST, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("Success_Secure_Su", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("Error_Secure_Su", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * GET String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */
    public static void getNotificationsContent(Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetNotificationsContentRequest stringRequest = new GetNotificationsContentRequest
                    (Request.Method.GET, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("Success_Notifications", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("Error_Notifications", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * GET String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */
    public static void getNotifications(Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetNotificationsRequest stringRequest = new GetNotificationsRequest
                    (Request.Method.POST, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("Success_Notifications", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("Error_Notifications", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * GET String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */
    public static void getMemberEligInfo
    (final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            final AppCompatActivity activity = (AppCompatActivity) context;
            GetMemberEligInfoRequest stringRequest = new GetMemberEligInfoRequest
                    (Request.Method.GET, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("Meliginfo", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("Meliginfo", error.toString());
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void getClaimSearchResult
    (final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetClaimsSearchRequest stringRequest = new GetClaimsSearchRequest(Request.Method.POST, url,
                    context, response -> {
                try {
                    listener.onResponse(response);
                    Log.d("Success_ClaimReferal", response);
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
            },
                    error -> {
                        try {
                            listener.onError(error.toString());
                            Log.d("Error_ClaimReferal", error.toString());
                            final AppCompatActivity activity = (AppCompatActivity) context;
                            showErrorDialog(error, activity);
                        } catch (Exception e) {
                            Logger.e(EXCEPTION, e);
                        }
                    });

            stringRequest.setRetryPolicy(
                    new DefaultRetryPolicy(
                            60 * 1000,
                            0,
                            0
                    )
            );
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */
    public static void getIDCardAsPDF(final Context context, String url, @NonNull final VolleyByteResponseListener listener) {
        try {
            GetIDCardPDFRequest idCardPDFRequest = new GetIDCardPDFRequest
                    (Request.Method.GET, url, context, new Response.Listener<byte[]>() {
                        @Override
                        public void onResponse(byte[] response) {
                            listener.onResponse(response);
                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            listener.onError(error);
                            final AppCompatActivity activity = (AppCompatActivity) context;
                            showErrorDialog(error, activity);
                        }
                    });
            idCardPDFRequest.setShouldCache(false);
            idCardPDFRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));

//          Access the requestQueue through singleton class
            Singleton.getInstance(context).addToRequestQueue(idCardPDFRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */
    public static void getClaimDocument(final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetClaimDocumentRequest stringRequest = new GetClaimDocumentRequest
                    (Request.Method.POST, url, context, listener::onResponse, error -> {
                        listener.onError(error.toString());
                        final AppCompatActivity activity = (AppCompatActivity) context;
                        showErrorDialog(error, activity);
                    });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * GET String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */
    public static void getBenefitUserDetailsReq
    (final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetBenefitUserDetailsRequest stringRequest = new GetBenefitUserDetailsRequest
                    (Request.Method.POST, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("benifit_details", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("benifit_details", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * GET String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */
    public static void getBenefitUser
    (final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetUpdateDemographicsMemberRequest stringRequest = new GetUpdateDemographicsMemberRequest
                    (Request.Method.POST, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("benifit_user", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("benifit_user", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * GET String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */
    public static void getBenefitProductDetailsReq(final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetBenefitProductDetailsRequest stringRequest = new GetBenefitProductDetailsRequest
                    (Request.Method.POST, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("Success_product", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("Error_product", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * GET String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */
    public static void validateIDCardRequest
    (final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            ValidateIDCardRequest stringRequest = new ValidateIDCardRequest
                    (Request.Method.POST, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("id card", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("id card", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * GET String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */
    public static void newIDCardByEmail
    (final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            NewCardByEmailRequest stringRequest = new NewCardByEmailRequest
                    (Request.Method.POST, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("new id card", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("new id card", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * Get String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void getMemberGroupList
    (final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetMemberGroupListRequest stringRequest =
                    new GetMemberGroupListRequest(Request.Method.GET, url,
                            context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.i("Group_Success", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.i("Group_Failed", error.toString());
                                    AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });

            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * Get String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void updateMemberGroupPreference
    (final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            UpdateMemberGroupRequest stringRequest =
                    new UpdateMemberGroupRequest(Request.Method.POST, url,
                            context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.i("UpdateGroup_Success", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.i("UpdateGroup_Failed", error.toString());
                                    AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });

            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, EXCEPTION);
        }
    }

    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void getAuthorizationReferalData
    (final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetProvAuthDashboardRequest stringRequest = new GetProvAuthDashboardRequest(Request.Method.POST, url,
                    context, response -> {
                try {
                    listener.onResponse(response);
                    Log.d("Success_AuthReferal", response);
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
            }, error -> {
                try {
                    listener.onError(error.toString());
                    Log.d("Error_AuthReferal", error.toString());
                    final AppCompatActivity activity = (AppCompatActivity) context;
                    showErrorDialog(error, activity);
                } catch (Exception e) {
                    Logger.e(EXCEPTION, e);
                }
            });

            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, EXCEPTION);
        }
    }


    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void updatePassword(final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            ChangePasswordRequest stringRequest = new ChangePasswordRequest(Request.Method.POST, url,
                    context, response -> {
                try {
                    listener.onResponse(response);
                    Log.d("change pwd", response);
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
            }, error -> {
                try {
                    listener.onError(error.toString());
                    Log.d("change pwd", error.toString());
                    final AppCompatActivity activity = (AppCompatActivity) context;
                    showErrorDialog(error, activity);
                } catch (Exception e) {
                    Logger.e(EXCEPTION, e);
                }
            });

            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, EXCEPTION);
        }
    }

    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void getAdvanceSearchSecureMessages
    (@NonNull final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetSecureMessageSearchRequest stringRequest = new GetSecureMessageSearchRequest
                    (Request.Method.POST, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("Success_Advance_Search", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("Error_Advance_Search", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e("Exc2", e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }


    /**
     * GET String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */
    public static void getDemographicHistory
    (final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetDemographicHistoryRequest stringRequest = new GetDemographicHistoryRequest
                    (Request.Method.GET, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("demographic history", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("demographic history", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }


    /**
     * GET String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */
    public static void verifyPwd(final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            VerifyPwdRequest stringRequest = new VerifyPwdRequest
                    (Request.Method.POST, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("verifyPwd", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("verifyPwd", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * GET String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */
    public static void getSecurityQuestions(final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetSecurityQuestionsRequest stringRequest = new GetSecurityQuestionsRequest
                    (Request.Method.GET, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("SecurityQuestions", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("SecurityQuestions", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * GET String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */
    public static void getUserSecurityQuestions(final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetUserSecurityQuestionsRequest stringRequest = new GetUserSecurityQuestionsRequest
                    (Request.Method.POST, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("userQuestions", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("userQuestions", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * GET String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */
    public static void updateSecurityQuestions(final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            UpdateSecurityQuestionsRequest stringRequest = new UpdateSecurityQuestionsRequest
                    (Request.Method.POST, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("updateQuestions", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("updateQuestions", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * GET String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */
    public static void getCountries(final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetCountriesRequest stringRequest = new GetCountriesRequest
                    (Request.Method.POST, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("getCountries", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("getCountries", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * GET String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */
    public static void updateDemography(final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            UpdateDemographyRequest stringRequest = new UpdateDemographyRequest
                    (Request.Method.POST, url, context, response -> {
                        listener.onResponse(response);
                        Log.d("updateDemography", response);
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("updateDemography", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }


    /**
     * Used to call web service for claimSummary and get response as JSON
     * using post method and to plot the horizontal bar chart
     */

    // Claims Send Inquiry
    public static void claimsSendInquiry(@NonNull final AppCompatActivity activity, final boolean isFromSecureMessage) {
        //Displaying the progress dialog
        GeneralUtils.showProgress(activity);
        //Sending API request to send msg
        VolleyService.claimsSendInquiryData(activity, new VolleyResponseListener() {
            @Override
            public void onError(String error) {
                GeneralUtils.hideProgress();
                Log.i("Error_Secure_Message", error);
            }

            @TargetApi(Build.VERSION_CODES.KITKAT)
            @Override
            public void onResponse(String response) {
                try {
                    Log.i("Success_Secure_message", response);
                    GeneralUtils.hideProgress();
                    //Displaying successful msg based on the response
                    final AlertDialog.Builder alertDialog = new AlertDialog.Builder(activity);
                    alertDialog.setTitle(R.string.message_sent);
                    alertDialog.setMessage(activity.getString(R.string.reference_id_colon) + response);
                    // Setting Positive "Yes" Button
                    alertDialog.setPositiveButton(R.string.ok, (dialogInterface, i) -> {
                        alertDialog.create().dismiss();
                        if (isFromSecureMessage) {
                            activity.getSupportFragmentManager().popBackStack();
                        }
                    });
                    // Showing Alert Message
                    alertDialog.show();
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
            }
        });
    }

    public static void authRefSendInquiry(@NonNull final AppCompatActivity activity, final boolean isFromSecureMessage) {
        //Displaying the progress dialog
        GeneralUtils.showProgress(activity);
        //Sending API request to send msg
        VolleyService.authRefSendInquiryData(activity, new VolleyResponseListener() {
            @Override
            public void onError(String error) {
                GeneralUtils.hideProgress();
                Log.i("Error_Secure_Message", error);
            }

            @TargetApi(Build.VERSION_CODES.KITKAT)
            @Override
            public void onResponse(String response) {
                try {
                    Log.i("Success_Secure_message", response);
                    GeneralUtils.hideProgress();
                    //Displaying successful msg based on the response
                    final AlertDialog.Builder alertDialog = new AlertDialog.Builder(activity);
                    alertDialog.setTitle(R.string.message_sent);
                    alertDialog.setMessage(activity.getString(R.string.reference_id_colon) + response);
                    // Setting Positive "Yes" Button
                    alertDialog.setPositiveButton(R.string.ok, (dialogInterface, i) -> {
                        alertDialog.create().dismiss();
                        if (isFromSecureMessage) {
                            activity.getSupportFragmentManager().popBackStack();
                        }
                    });
                    // Showing Alert Message
                    alertDialog.show();
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
            }
        });
    }

    public static void composeMessage(@NonNull final AppCompatActivity activity, final boolean isFromSecureMessage) {
        //Displaying the progress dialog
        GeneralUtils.showProgress(activity);
        //Sending API request to send msg
        VolleyService.composeMessageData(activity, new VolleyResponseListener() {
            @Override
            public void onError(String error) {
                GeneralUtils.hideProgress();
                Log.i("Error_Secure_Message", error);
            }

            @TargetApi(Build.VERSION_CODES.KITKAT)
            @Override
            public void onResponse(String response) {
                try {
                    Log.i("Success_Secure_message", response);
                    GeneralUtils.hideProgress();
                    //Displaying successful msg based on the response
                    final AlertDialog.Builder alertDialog = new AlertDialog.Builder(activity);
                    alertDialog.setTitle(R.string.message_sent);
                    alertDialog.setMessage(activity.getString(R.string.reference_id_colon) + response);
                    // Setting Positive "Yes" Button
                    alertDialog.setPositiveButton(R.string.ok, (dialogInterface, i) -> {
                        alertDialog.create().dismiss();
                        if (isFromSecureMessage) {
                            activity.getSupportFragmentManager().popBackStack();
                        }
                    });
                    // Showing Alert Message
                    alertDialog.show();
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
            }
        });
    }

    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    // Found New Implementation after Security defects fixed
    public static void registerDevice
    (Context context, String url, final VolleyResponseListener listener) {
        try {
            RegisterDeviceRequest stringRequest = new RegisterDeviceRequest
                    (Request.Method.POST, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("registerDevice_message", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    listener.onError(error.toString());
                                    Log.d("registerDevice_message", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    // Found New Implementation after Security defects fixed
    public static void reminderApiRequest
    (Context context, String url, final VolleyResponseListener listener) {
        try {
            GetMembermedRequest stringRequest = new GetMembermedRequest
                    (Request.Method.POST, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("GetMembermed_message", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    listener.onError(error.toString());
                                    Log.d("GetMembermed_message", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    public static void rescheduleReminderApiRequest(Context context, String url, final VolleyResponseListener listener) {
        try {
            GetRescheduleMemRequest stringRequest = new GetRescheduleMemRequest
                    (Request.Method.POST, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("reschRemind_message", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    listener.onError(error.toString());
                                    Log.d("reschRemind_message", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void addMedicationData
    (final Context context, String url, final VolleyResponseListener listener) {
        final AppCompatActivity activity = (AppCompatActivity) context;
        try {
            AddMedicationRequest stringRequest = new AddMedicationRequest
                    (Request.Method.POST, url, context, response -> {
                        listener.onResponse(response);
                        Log.d("Success_reply_message", response);
                    },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    try {
                                        listener.onError(error.toString());
                                        Log.d("Error_reply_message", error.toString());
                                        showErrorDialog(error, activity);
                                    } catch (Exception e) {
                                        Logger.e(EXCEPTION, e);
                                    }
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void getMedicationsByMemberID(final Context context, String url, VolleyResponseListener listener) {
        try {
            GeneralUtils.showProgress(context);
            GetMedicationsByMemberIDRequest stringRequest = new GetMedicationsByMemberIDRequest
                    (Request.Method.POST, url, context, response -> {
                        listener.onResponse(response);
                        Log.d("Success_reply_message", response);
                        GeneralUtils.hideProgress();
                    },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    try {
                                        GeneralUtils.hideProgress();
                                        final AppCompatActivity activity = (AppCompatActivity) context;
                                        listener.onError(error.toString());
                                        Log.d("Error_reply_message", error.toString());
                                        showErrorDialog(error, activity);
                                    } catch (Exception e) {
                                        Logger.e(EXCEPTION, e);
                                    }
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void getImmunizationHistoryByMemberID
    (final Context context, String url, final VolleyResponseListener listener) {
        final AppCompatActivity activity = (AppCompatActivity) context;
        try {
            GetImmunizationHistoryByMemberIDRequest stringRequest = new GetImmunizationHistoryByMemberIDRequest
                    (Request.Method.POST, url, context, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            listener.onResponse(response);
                            Log.d("Success_reply_message", response);
                        }
                    },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    try {
                                        listener.onError(error.toString());
                                        Log.d("Error_reply_message", error.toString());
                                        showErrorDialog(error, activity);
                                    } catch (Exception e) {
                                        Logger.e(EXCEPTION, e);
                                    }
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void getImmunizationByMemberID
    (final Context context, String url, final VolleyResponseListener listener) {
        final AppCompatActivity activity = (AppCompatActivity) context;
        try {
            GetImmunizationByMemberIDRequest stringRequest = new GetImmunizationByMemberIDRequest
                    (Request.Method.POST, url, context, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            listener.onResponse(response);
                            Log.d("Success_reply_message", response);
                        }
                    },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    try {
                                        listener.onError(error.toString());
                                        Log.d("Error_reply_message", error.toString());
                                        showErrorDialog(error, activity);
                                    } catch (Exception e) {
                                        Logger.e(EXCEPTION, e);
                                    }
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void addAppointment(final Context context, String url, final VolleyResponseListener listener) {
        final AppCompatActivity activity = (AppCompatActivity) context;
        try {
            AddAppointmentRequest stringRequest = new AddAppointmentRequest
                    (Request.Method.POST, url, context, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            listener.onResponse(response);
                            Log.d("Success_reply_message", response);
                        }
                    },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    try {
                                        listener.onError(error.toString());
                                        Log.d("Error_reply_message", error.toString());
                                        showErrorDialog(error, activity);
                                    } catch (Exception e) {
                                        Logger.e(EXCEPTION, e);
                                    }
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void addVaccine(final Context context, String url, final VolleyResponseListener listener) {
        final AppCompatActivity activity = (AppCompatActivity) context;
        try {
            AddVaccineRequest stringRequest = new AddVaccineRequest
                    (Request.Method.POST, url, context, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            listener.onResponse(response);
                            Log.d("Success_reply_message", response);
                        }
                    },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    try {
                                        listener.onError(error.toString());
                                        Log.d("Error_reply_message", error.toString());
                                        showErrorDialog(error, activity);
                                    } catch (Exception e) {
                                        Logger.e(EXCEPTION, e);
                                    }
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    public static void getCityCountry(final Context context, String url, VolleyResponseListener listener) {
        try {
            GetCityCountryData stringRequest = new GetCityCountryData
                    (Request.Method.POST, url, context, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            listener.onResponse(response);
                            Log.d("Success_reply_message", response);
                        }
                    },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    try {
                                        listener.onError(error.toString());
                                        Log.d("Error_reply_message", error.toString());
                                        final AppCompatActivity activity = (AppCompatActivity) context;
                                        showErrorDialog(error, activity);
                                    } catch (Exception e) {
                                        Logger.e(EXCEPTION, e);
                                    }
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    public static void getGroupName(final Context context, String url, VolleyResponseListener listener) {
        try {
            GetGroupNameData stringRequest = new GetGroupNameData
                    (Request.Method.POST, url, context, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            listener.onResponse(response);
                            Log.d("Success_reply_message", response);
                        }
                    },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    try {
                                        listener.onError(error.toString());
                                        Log.d("Error_reply_message", error.toString());
                                        final AppCompatActivity activity = (AppCompatActivity) context;
                                        showErrorDialog(error, activity);
                                    } catch (Exception e) {
                                        Logger.e(EXCEPTION, e);
                                    }
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    public static void getSpeciality(final Context context, String url, VolleyResponseListener listener) {
        try {
            GetSpecialityData stringRequest = new GetSpecialityData
                    (Request.Method.POST, url, context, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            listener.onResponse(response);
                            Log.d("Success_reply_message", response);
                        }
                    },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    try {
                                        listener.onError(error.toString());
                                        Log.d("Error_reply_message", error.toString());
                                        final AppCompatActivity activity = (AppCompatActivity) context;
                                        showErrorDialog(error, activity);
                                    } catch (Exception e) {
                                        Logger.e(EXCEPTION, e);
                                    }
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    public static void getHospitalAffiliation(final Context context, String url, VolleyResponseListener listener) {
        try {
            GetHospitalAffiliationData stringRequest = new GetHospitalAffiliationData
                    (Request.Method.POST, url, context, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            listener.onResponse(response);
                            Log.d("Success_reply_message", response);
                        }
                    },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    try {
                                        listener.onError(error.toString());
                                        Log.d("Error_reply_message", error.toString());
                                        final AppCompatActivity activity = (AppCompatActivity) context;
                                        showErrorDialog(error, activity);
                                    } catch (Exception e) {
                                        Logger.e(EXCEPTION, e);
                                    }
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    public static void getClinicName(final Context context, String url, VolleyResponseListener listener) {
        try {
            GetClinicNameData stringRequest = new GetClinicNameData
                    (Request.Method.POST, url, context, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            listener.onResponse(response);
                            Log.d("Success_reply_message", response);
                        }
                    },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    try {
                                        listener.onError(error.toString());
                                        Log.d("Error_reply_message", error.toString());
                                        final AppCompatActivity activity = (AppCompatActivity) context;
                                        showErrorDialog(error, activity);
                                    } catch (Exception e) {
                                        Logger.e(EXCEPTION, e);
                                    }
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    public static void getAreaExpertise(final Context context, String url, VolleyResponseListener listener) {
        try {
            GetAreaExpertise stringRequest = new GetAreaExpertise
                    (Request.Method.POST, url, context, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            listener.onResponse(response);
                            Log.d("Success_reply_message", response);
                        }
                    },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    try {
                                        listener.onError(error.toString());
                                        Log.d("Error_reply_message", error.toString());
                                        final AppCompatActivity activity = (AppCompatActivity) context;
                                        showErrorDialog(error, activity);
                                    } catch (Exception e) {
                                        Logger.e(EXCEPTION, e);
                                    }
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    public static void getLanguageSpoken(final Context context, String url, VolleyResponseListener listener) {
        try {
            GetLanguageSpoken stringRequest = new GetLanguageSpoken
                    (Request.Method.POST, url, context, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            listener.onResponse(response);
                            Log.d("Success_reply_message", response);
                        }
                    },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    try {
                                        listener.onError(error.toString());
                                        Log.d("Error_reply_message", error.toString());
                                        final AppCompatActivity activity = (AppCompatActivity) context;
                                        showErrorDialog(error, activity);
                                    } catch (Exception e) {
                                        Logger.e(EXCEPTION, e);
                                    }
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    public static void getApplicantsLocation(final Context context, String url, VolleyResponseListener listener) {
        try {
            GetApplicantsLocation stringRequest = new GetApplicantsLocation
                    (Request.Method.POST, url, context, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            listener.onResponse(response);
                            Log.d("Success_reply_message", response);
                        }
                    },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    try {
                                        listener.onError(error.toString());
                                        Log.d("Error_reply_message", error.toString());
                                        final AppCompatActivity activity = (AppCompatActivity) context;
                                        showErrorDialog(error, activity);
                                    } catch (Exception e) {
                                        Logger.e(EXCEPTION, e);
                                    }
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    public static void saveJsonResultRequest(final Context context, String url, VolleyResponseListener listener) {
        try {
            SaveJsonResult stringRequest = new SaveJsonResult
                    (Request.Method.POST, url, context, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            listener.onResponse(response);
                            Log.d("Success_reply_message", response);
                        }
                    },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    try {
                                        listener.onError(error.toString());
                                        Log.d("Error_reply_message", error.toString());
                                        final AppCompatActivity activity = (AppCompatActivity) context;
                                        showErrorDialog(error, activity);
                                    } catch (Exception e) {
                                        Logger.e(EXCEPTION, e);
                                    }
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    public static void getPCPSearch(final Context context, String url, VolleyResponseListener listener) {
        try {
            GetPCPSearch stringRequest = new GetPCPSearch
                    (Request.Method.POST, url, context, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            listener.onResponse(response);
                            Log.d("Success_reply_message", response);
                        }
                    },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    try {
                                        listener.onError(error.toString());
                                        Log.d("Error_reply_message", error.toString());
                                        final AppCompatActivity activity = (AppCompatActivity) context;
                                        showErrorDialog(error, activity);
                                    } catch (Exception e) {
                                        Logger.e(EXCEPTION, e);
                                    }
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    public static void getExpertPDFRequest(final Context context, String url, VolleyResponseListener listener) {
        try {

            GetExpertPDFRequest stringRequest = new GetExpertPDFRequest
                    (Request.Method.POST, url, context, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            listener.onResponse(response);
                            Log.d("Success_reply_message", response);
                        }
                    },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    try {
                                        listener.onError(error.toString());
                                        Log.d("Error_reply_message", error.toString());
                                        final AppCompatActivity activity = (AppCompatActivity) context;
                                        showErrorDialog(error, activity);
                                    } catch (Exception e) {
                                        Logger.e(EXCEPTION, e);
                                    }
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    public static void getProcedureCodes(final Context context, String url, VolleyResponseListener listener) {
        try {

            GetProcedureCodes stringRequest = new GetProcedureCodes
                    (Request.Method.POST, url, context, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            listener.onResponse(response);
                            Log.d("Success_reply_message", response);
                        }
                    },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    try {
                                        listener.onError(error.toString());
                                        Log.d("Error_reply_message", error.toString());
                                        final AppCompatActivity activity = (AppCompatActivity) context;
                                        showErrorDialog(error, activity);
                                    } catch (Exception e) {
                                        Logger.e(EXCEPTION, e);
                                    }
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    public static void getMemberDeductible(final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetMemberDeductible stringRequest = new GetMemberDeductible
                    (Request.Method.POST, url, context, response -> {
                        listener.onResponse(response);
                        Log.d("balance", response);
                    },
                            error -> {
                                listener.onError(error.toString());
                                Log.d("balance", error.toString());
                                final AppCompatActivity activity = (AppCompatActivity) context;
                                showErrorDialog(error, activity);
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    public static void getTCCOOP(final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetMemberOOPRequest stringRequest = new GetMemberOOPRequest
                    (Request.Method.POST, url, context, response -> {
                        Log.d("balance_oop", response);
                        listener.onResponse(response);
                    },
                            error -> {
                                listener.onError(error.toString());
                                Log.d("balance_oop", error.toString());
                                final AppCompatActivity activity = (AppCompatActivity) context;
                                showErrorDialog(error, activity);
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    public static void getTreatmentCostRequest(final Context context, String url, @NonNull final VolleyResponseListener listener) {

        try {
            GetTreatmentCostParams stringRequest = new GetTreatmentCostParams
                    (Request.Method.POST, url, context, response -> {
                        listener.onResponse(response);
                        Log.d("balance", response);
                    },
                            error -> {
                                listener.onError(error.toString());
                                Log.d("balance", error.toString());
                                final AppCompatActivity activity = (AppCompatActivity) context;
                                showErrorDialog(error, activity);
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void getImmunizationHistoyAsPDF(final Context context, String url, final VolleyByteResponseListener listener) {
        try {
            GetImmunizationHistoryPDFRequest stringRequest = new GetImmunizationHistoryPDFRequest
                    (Request.Method.GET, url, context, new Response.Listener<byte[]>() {
                        @Override
                        public void onResponse(byte[] response) {
                            listener.onResponse(response);
                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            listener.onError(error);
                            final AppCompatActivity activity = (AppCompatActivity) context;
                            showErrorDialog(error, activity);
                        }
                    });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            /* Access the requestQueue through singleton class */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    public static void getHRAAsPDF(final Context context, String url, final VolleyByteResponseListener listener) {
        try {
            GetHRAPDFRequest stringRequest = new GetHRAPDFRequest
                    (Request.Method.GET, url, context, new Response.Listener<byte[]>() {
                        @Override
                        public void onResponse(byte[] response) {
                            listener.onResponse(response);
                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            listener.onError(error);
                            final AppCompatActivity activity = (AppCompatActivity) context;
                            showErrorDialog(error, activity);
                        }
                    });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    public static void getVaccineList
            (final Context context, String url, final VolleyResponseListener listener) {
        try {
            GetVaccineListRequest stringRequest = new GetVaccineListRequest
                    (Request.Method.GET, url, context, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            listener.onResponse(response);
                            Log.d("Success_vaccine", response);
                        }
                    },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    listener.onError(error.toString());
                                    Log.d("Error_vaccine", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * Get String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */
    public static void registerImmunization
    (final Context context, String url, final VolleyResponseListener listener) {
        try {
            ImmunizationRegistrationRequest stringRequest = new ImmunizationRegistrationRequest
                    (Request.Method.POST, url, context, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            listener.onResponse(response);
                            Log.d("Success_Immunization", response);
                        }
                    },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    listener.onError(error.toString());
                                    Log.d("Error_Immunization", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                }
                            });

            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0,
                    0));

        /*
        Access the requestQueue through singleton class
        */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /*private static void showErrorDialog(VolleyError error, @NonNull AppCompatActivity activity) {
        try {
            NetworkResponse networkResponse = error.networkResponse;
            if (networkResponse != null) {
                if (networkResponse.statusCode == HttpURLConnection.HTTP_FORBIDDEN) {
                    AlertDialogFragment alertDialogFragment = AlertDialogFragment.newInstance(R.string.alert,
                            activity.getString(R.string.page_access_restricted));
                    alertDialogFragment.show(activity.getSupportFragmentManager(), NETWORK_ERROR);
                } else if (error instanceof TimeoutError || error instanceof NoConnectionError || error instanceof NetworkError || error instanceof ServerError) {
                    AlertDialogFragment alertDialogFragment = AlertDialogFragment.newInstance(R.string.timeout_error_title,
                            activity.getString(R.string.timeout_error_dialog_body));
                    alertDialogFragment.show(activity.getSupportFragmentManager(), TIMEOUT_ERROR);
                } else {
                    AlertDialogFragment alertDialogFragment = AlertDialogFragment.newInstance(R.string.timeout_error_title,
                            activity.getString(R.string.timeout_error_dialog_body));
                    alertDialogFragment.show(activity.getSupportFragmentManager(), TIMEOUT_ERROR);
                }
            }
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }*/
    private static void showErrorDialog(VolleyError error, @NonNull AppCompatActivity activity) {
        if (error instanceof TimeoutError || error instanceof AuthFailureError || error instanceof ServerError) {
            SessionManagementDialog alertDialogFragment = SessionManagementDialog.newInstance(R.string.timeout_error_title,
                    activity.getString(R.string.timeout_error_dialog_body));
            alertDialogFragment.show(activity.getSupportFragmentManager(), TIMEOUT_ERROR);
        } else if (error instanceof NoConnectionError || error instanceof NetworkError) {
            AlertDialogFragment alertDialogFragment = AlertDialogFragment.newInstance(R.string.network_error_title,
                    activity.getString(R.string.network_error_dialog_body));
            alertDialogFragment.show(activity.getSupportFragmentManager(), NETWORK_ERROR);
        }
    }

   /* private static void showAccountLockMessage(Activity activity) {
        View view = activity.getLayoutInflater().inflate(R.layout.layout_account_lock, null);
        TextView contact = view.findViewById(R.id.contactUs);
        *//*contact.setPaintFlags(contact.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        contact.setOnClickListener(view1 -> {
            activity.startActivity(new Intent(activity, ContactUsActivity.class));
        });*//*
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setView(view);
        builder.setCancelable(false)
                .setPositiveButton(activity.getString(R.string.ok), null).create().show();
    }*/

    private static void showWrongCreds(String message, Activity activity) {
        View view = activity.getLayoutInflater().inflate(R.layout.link_textview, null);
        TextView textView = view.findViewById(R.id.linkText);
        textView.setText(message);
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setView(view);
        builder.setCancelable(false)
                .setPositiveButton(activity.getString(R.string.ok), null).create().show();
    }


    private static void handleCookies(NetworkResponse response, Context ctx) {
        String cookies = null;
        for (Header header : response.allHeaders) {
            if (header.getName().equals(SET_COOKIE) && header.getValue().startsWith("FedAuth=")) {
                cookies = header.getValue();
                SharedPreferenceHelper.getInstance().setPreference(ctx, "sessionid", cookies);
            }
        }
    }

    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void getFitbitAccessToken
    (final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetAccessTokenRequest stringRequest = new GetAccessTokenRequest
                    (Request.Method.POST, url, context, response -> {
                        listener.onResponse(response);
                        Log.d("Success_AuthReferral", response);
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("Error_AuthReferralData", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    /**
     * POST String response from the Web API.
     *
     * @param context  context of the activity.
     * @param url      the String refers the web service URL.
     * @param listener listener callback reference.
     */

    public static void getFitbitGoals
    (final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetAccessTokenRequest stringRequest = new GetAccessTokenRequest
                    (Request.Method.POST, url, context, response -> {
                        listener.onResponse(response);
                        Log.d("Success_AuthReferral", response);
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("Error_AuthReferralData", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    public static void getExportAsPDF(final Context context, String url, @NonNull final VolleyByteResponseListener listener) {
        try {
            GetExportProviderPDFRequest getExportproPDFRequest = new GetExportProviderPDFRequest(Request.Method.GET, url, context, new Response.Listener<byte[]>() {
                @Override
                public void onResponse(byte[] response) {
                    try {
                        listener.onResponse(response);
                    } catch (Exception e) {
                        e.getLocalizedMessage();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    listener.onError(error);
                    final AppCompatActivity activity = (AppCompatActivity) context;
                    showErrorDialog(error, activity);
                }
            });
            getExportproPDFRequest.setShouldCache(false);
            getExportproPDFRequest.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));

//          Access the requestQueue through singleton class
            Singleton.getInstance(context).addToRequestQueue(getExportproPDFRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }

    }

    public static void getSecureMessageProvider(final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetSecureMessageProvRequest stringRequest = new GetSecureMessageProvRequest
                    (Request.Method.POST, url, context, response -> {
                        listener.onResponse(response);
                        Log.d("Success_SecMsgProvider", response);
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("Error_SecMsgProvider", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }

    public static void getSecureMessageProviderPCP(final Context context, String url, @NonNull final VolleyResponseListener listener) {
        try {
            GetSecureMessageProvPCPRequest stringRequest = new GetSecureMessageProvPCPRequest
                    (Request.Method.POST, url, context, response -> {
                        listener.onResponse(response);
                        Log.d("Success_SecMsgProvPCP", response);
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("Error_SecMsgProvPCP", error.toString());
                                    final AppCompatActivity activity = (AppCompatActivity) context;
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000, 0, 0));
            /*
            Access the requestQueue through singleton class
            */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }


    public static void getSecureMessageAttachment(final Context context, String url, @NonNull final VolleyByteResponseListener listener) {
        try {
            GetSecureMessageAttachment secureMessageAttachment = new GetSecureMessageAttachment
                    (Request.Method.GET, url, context, new Response.Listener<byte[]>() {
                        @Override
                        public void onResponse(byte[] response) {
                            listener.onResponse(response);
                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            listener.onError(error);
                            final AppCompatActivity activity = (AppCompatActivity) context;
                            showErrorDialog(error, activity);
                        }
                    });
            secureMessageAttachment.setShouldCache(false);
            secureMessageAttachment.setRetryPolicy(new DefaultRetryPolicy(90 * 1000, 0, 0));

//          Access the requestQueue through singleton class
            Singleton.getInstance(context).addToRequestQueue(secureMessageAttachment);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }


    public static void getKnowledgeBase
            (final Context context, String url, @NonNull final VolleyResponseListener listener) {
        final AppCompatActivity activity = (AppCompatActivity) context;
        try {
            GetKnowledgeBaseRequest stringRequest = new GetKnowledgeBaseRequest
                    (Request.Method.POST, url, context, response -> {
                        try {
                            listener.onResponse(response);
                            Log.d("Success_MemberInfo", response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    },
                            error -> {
                                try {
                                    listener.onError(error.toString());
                                    Log.d("Error_MemberInfo", error.toString());
                                    showErrorDialog(error, activity);
                                } catch (Exception e) {
                                    Logger.e(EXCEPTION, e);
                                }
                            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                    0, 0));
    /*
    Access the requestQueue through singleton class
    */
            getInstance(context).addToRequestQueue(stringRequest);
        } catch (Exception e) {
            Logger.e(EXCEPTION, e);
        }
    }
}

