package com.wps.memberapp.domain.fitbitauth.authentication;

/**
 * Created by Shraddha.
 */
public interface AuthenticationHandler {

    void onAuthFinished(AuthenticationResult result);

}
