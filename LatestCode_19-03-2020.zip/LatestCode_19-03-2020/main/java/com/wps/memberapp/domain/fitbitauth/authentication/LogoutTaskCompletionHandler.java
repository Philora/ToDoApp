package com.wps.memberapp.domain.fitbitauth.authentication;

/**
 * Created by Shraddha
 */
public interface LogoutTaskCompletionHandler {
    void logoutSuccess();

    void logoutError(String message);
}
