package com.wps.memberapp.domain.fitbitauth.authentication;

import com.wps.memberapp.domain.fitbitnetwork.BasicHttpRequestBuilder;

/**
 * Created by Shraddha
 */

public interface RequestSigner {

    void signRequest(BasicHttpRequestBuilder builder);

}
