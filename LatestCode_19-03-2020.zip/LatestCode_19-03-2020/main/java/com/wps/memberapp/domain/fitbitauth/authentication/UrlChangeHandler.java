package com.wps.memberapp.domain.fitbitauth.authentication;

/**
 * Created by Shraddha
 */
public interface UrlChangeHandler {
    void onUrlChanged(String newUrl);
    void onLoadError(int errorCode, CharSequence description);
}
