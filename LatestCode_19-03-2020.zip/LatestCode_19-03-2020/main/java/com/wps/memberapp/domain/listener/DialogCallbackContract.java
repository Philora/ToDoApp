package com.wps.memberapp.domain.listener;

/*
This class is used to manage the callbacks for custom alert dialogs.
 */


public interface DialogCallbackContract {

}
