package com.wps.memberapp.domain.listener;

public interface LoginCallback {
    void onResponse(String response);

    void onError(int code, String message);
}
