
package com.wps.memberapp.domain.listener;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;

import com.salesforce.android.chat.core.ChatConfiguration;
import com.salesforce.android.chat.core.SessionStateListener;
import com.salesforce.android.chat.core.model.ChatEndReason;
import com.salesforce.android.chat.core.model.ChatSessionState;
import com.wps.memberapp.R;
import com.wps.memberapp.utility.AppConstants;


public class MyChatListener implements SessionStateListener

{
    private final Context mContext;
    private final ChatConfiguration mChatConfiguration;


    private boolean mSessionEnded = false;

    public MyChatListener(ChatConfiguration chatConfiguration, Context context) {
        mChatConfiguration = chatConfiguration;
        mContext = context;
    }

    @Override
    public void onSessionStateChange(ChatSessionState state) {
        if (state == ChatSessionState.Disconnected) {
            // TODO: Handle the disconnected state change
        }
    }

    @Override
    public void onSessionEnded(ChatEndReason endReason) {

        // Test whether onSessionEnded has already been called
        if (mSessionEnded) {
            return;
        }
        mSessionEnded = true;

        // Launch the alert dialog asking if the user wants to complete a survey
        AlertDialog.Builder surveyPrompt = new AlertDialog.Builder(mContext, R.style.AlertDialog);
        surveyPrompt.setTitle(R.string.survey_prompt_title);
        surveyPrompt.setMessage(R.string.survey_prompt_question);
        surveyPrompt.setPositiveButton(R.string.survey_prompt_positive, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(AppConstants.SFDC_COMMUNITY_URL));
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        intent.putExtra("visitor_name", mChatConfiguration.getVisitorName());
                        intent.putExtra("button_id", mChatConfiguration.getButtonId());
                        intent.putExtra("live_agent_pod", mChatConfiguration.getLiveAgentPod());
                        mContext.startActivity(intent);

                       /* Intent intent = new Intent(mContext, WebViewSFDCCommmunityActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        intent.putExtra("visitor_name", mChatConfiguration.getVisitorName());
                        intent.putExtra("button_id", mChatConfiguration.getButtonId());
                        intent.putExtra("live_agent_pod", mChatConfiguration.getLiveAgentPod());
                        mContext.startActivity(intent);*/
                    }
                }
        );
        surveyPrompt.setNegativeButton(R.string.survey_prompt_negative, null);
        surveyPrompt.show();
    }
}