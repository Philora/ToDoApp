package com.wps.memberapp.domain.network;

import android.content.Context;
import android.util.Log;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.Logger;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class AddAppointmentRequest extends StringRequest {
    private final Context context;
    private String mRequestBody;

    public AddAppointmentRequest(int method, String url, final Context context, Response.Listener<String> listener, Response.ErrorListener errorListener) {
        super(method, url, listener, errorListener);
        this.context = context;
    }

    @Override
    public Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<>();
        if (SharedPreferenceHelper.getInstance() != null && SharedPreferenceHelper.getInstance().getPreference(context, "sessionid") != null) {
            String sessionId = SharedPreferenceHelper.getInstance().getPreference(context, "sessionid");
            if (sessionId != null) {
                headers.put("Cookie", sessionId);
            }
        }
        return headers;
    }

    @Override
    public String getBodyContentType() {
        return "application/json";
    }

    @Override
    public byte[] getBody() {
        if (SharedPreferenceHelper.getInstance() != null) {
            String id = SharedPreferenceHelper.getInstance().getPreference(context, "MEMBER_ID");
            String vaccine = SharedPreferenceHelper.getInstance().getPreference(context, "VACCINE_GROUP_ID");
            String dos = SharedPreferenceHelper.getInstance().getPreference(context, "DATE_OF_SERVICE");
            String providerName = SharedPreferenceHelper.getInstance().getPreference(context, "PROVIDER_NAME");
            String fName = SharedPreferenceHelper.getInstance().getPreference(context, "MEMBER_FNAME");
            String lName = SharedPreferenceHelper.getInstance().getPreference(context, "MEMBER_LNAME");
            String dob = SharedPreferenceHelper.getInstance().getPreference(context, "MEMBER_DOB");
            MemberDetails details = ProfileDataCache.getInstance().getmMemberDetails().get(0);
            try {
                JSONObject jsonObj = new JSONObject();
                jsonObj.put("MemberId", id);
                if (details != null) {
                    jsonObj.put("SubscriberID", details.getSubscriberID());
                    jsonObj.put("SubscriberFName", details.getFirstName());
                    jsonObj.put("SubscriberLName", details.getLastName());
                }
                jsonObj.put("MemberFName", fName);
                jsonObj.put("MemberLName", lName);
                jsonObj.put("MemberDOB", dob);
                jsonObj.put("VaccineId", vaccine);
                jsonObj.put("DOS", "");
                jsonObj.put("DOA", dos);
                jsonObj.put("ProviderName", providerName);
                JSONObject obj = new JSONObject();
                obj.put("ImmunizationRequest", jsonObj);
                mRequestBody = obj.toString();
                Log.i("Request is ", mRequestBody);
            } catch (JSONException e) {
                Logger.e("Ex", e);
            }
        }
        return mRequestBody.getBytes();
    }
}