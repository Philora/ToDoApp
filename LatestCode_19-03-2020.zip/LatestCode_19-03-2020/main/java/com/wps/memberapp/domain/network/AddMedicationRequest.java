package com.wps.memberapp.domain.network;

import android.content.Context;
import android.util.Log;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.Logger;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;


public class AddMedicationRequest extends StringRequest {
    private final Context context;
    private String mRequestBody;


    public AddMedicationRequest(int method, String url, final Context context,
                                Response.Listener<String> listener, Response.ErrorListener errorListener) {
        super(method, url, listener, errorListener);
        this.context = context;
    }

    @Override
    public Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<>();

        if (SharedPreferenceHelper.getInstance() != null && SharedPreferenceHelper.getInstance().getPreference(context, "sessionid") != null) {
            String sessionId = SharedPreferenceHelper.getInstance().getPreference(context, "sessionid");
            if (sessionId != null) {
                headers.put("Cookie", sessionId);
            }
        }
        return headers;
    }

    @Override
    public String getBodyContentType() {
        return "application/json";
    }

    @Override
    public byte[] getBody() {

        ArrayList<String> medicineList;
        ArrayList<String> daysList;
        List<String> noOfTablets;
        String formattedNewStartDate = null;
        String formattedNewEndDate = null;

        if (SharedPreferenceHelper.getInstance() != null) {
            String intakePlanSelectedValue = SharedPreferenceHelper.getInstance().getPreference(context, "intakePlanValue");
            String doseValue = SharedPreferenceHelper.getInstance().getPreference(context, "doseValueSelectedItem");
            String doseUnitValue = SharedPreferenceHelper.getInstance().getPreference(context, "doseUnitValueSelectedItem");
            String medicineName = SharedPreferenceHelper.getInstance().getPreference(context, "medicine_name");
            String startDate = SharedPreferenceHelper.getInstance().getPreference(context, "startDate");
            String endDate = SharedPreferenceHelper.getInstance().getPreference(context, "endDate");
            String reminderTime = SharedPreferenceHelper.getInstance().getPreference(context, "reminder_time");
            String desiredString = "";
            if (reminderTime.length() > 2) {
                desiredString = reminderTime.substring(0, 2);
            }
            daysList = (ArrayList<String>) ProfileDataCache.getInstance().getDaysList();
            medicineList = (ArrayList<String>) ProfileDataCache.getInstance().getMedicineList();
            noOfTablets = ProfileDataCache.getInstance().getNoOfTablets();

            SimpleDateFormat originalFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
            SimpleDateFormat newFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);

            Date date;
            if (SharedPreferenceHelper.getInstance().getPreference(context, "startDate") != null) {
                try {
                    date = originalFormat.parse(startDate);
                    formattedNewStartDate = newFormat.format(date);
                } catch (ParseException e) {
                    Logger.e("Exc", e);
                }

            }
            if (SharedPreferenceHelper.getInstance().getPreference(context, "endDate") != null) {
                Date date2;
                try {
                    date2 = originalFormat.parse(endDate);
                    formattedNewEndDate = newFormat.format(date2);
                } catch (ParseException e) {
                    Logger.e("Exc1", e);
                }
            }

            JSONArray daysValue = new JSONArray();
            JSONArray medicineTimeValue = new JSONArray();

            if (daysList != null && !daysList.isEmpty()) {
                for (int i = 0; i < daysList.size(); i++) {
                    daysValue.put(daysList.get(i));
                }
            }
            if (medicineList != null && !medicineList.isEmpty() && noOfTablets != null && medicineList.size() == noOfTablets.size()) {
                for (int j = 0; j < medicineList.size(); j++) {
                    try {
                        JSONObject obj = new JSONObject();
                        obj.put("id", medicineList.get(j));
                        obj.put("time", medicineList.get(j));
                        obj.put("quantity", noOfTablets.get(j));
                        medicineTimeValue.put(obj);
                    } catch (Exception r) {
                        Logger.e("Ex", r);
                    }
                }
            }
            try {
                MemberDetails details = ProfileDataCache.getInstance().getmMemberDetails().get(0);
                JSONObject jsonObject = new JSONObject();
                if (details != null) {
                    jsonObject.put("MemberId", details.getfMSSeqMemberId());
                }
                jsonObject.put("MedicationName", medicineName);
                jsonObject.put("IntakePlan", intakePlanSelectedValue);
                jsonObject.put("Dose", doseValue);
                jsonObject.put("Unit", doseUnitValue);
                jsonObject.put("StartDate", formattedNewStartDate);
                jsonObject.put("EndDate", formattedNewEndDate);
                jsonObject.put("setReminder", "true");
                jsonObject.put("reminderBefore", desiredString);
                jsonObject.put("SelectedDays", daysValue);
                jsonObject.put("SelectedTimes", medicineTimeValue);
                jsonObject.put("Image", "");

                JSONObject object = new JSONObject();
                object.put("MedicationRequest", jsonObject);

                mRequestBody = object.toString();
                Log.i("Request is ", mRequestBody);
            } catch (JSONException e) {
                Logger.e("Exc2", e);
            }
        }
        return mRequestBody.getBytes();
    }
}