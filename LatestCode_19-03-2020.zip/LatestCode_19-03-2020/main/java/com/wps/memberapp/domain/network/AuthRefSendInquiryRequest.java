package com.wps.memberapp.domain.network;

import android.content.Context;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MemberEligibleInfo;
import com.wps.memberapp.data.model.MessageData;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.NetworkConfig;
import com.wps.memberapp.utility.NetworkConfigValues;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;

/*
This class is used to send a network request for new message and return the response
 */
public class AuthRefSendInquiryRequest extends StringRequest {

    private final Context mContext;

    public AuthRefSendInquiryRequest(int method, String url, final Context mContext,
                                     Response.Listener<String> listener, Response.ErrorListener errorListener) {
        super(method, url, listener, errorListener);
        this.mContext = mContext;
    }

    @Override
    public byte[] getBody() {
        String str = "";
        if (SharedPreferenceHelper.getInstance() != null) {
            MessageData data = ProfileDataCache.getInstance().getMessageData();
            MemberEligibleInfo info = ProfileDataCache.getInstance().getMemberEligibleInfo();
            String mData = ProfileDataCache.getInstance().getRequestMessageData();

            Map<String, String> params = new HashMap<>();
            params.put(NetworkConfig.REQUEST_TYPE, NetworkConfigValues.MESSAGES);
            params.put(NetworkConfig.REQUEST_SUB_TYPE, NetworkConfigValues.CREATE);
            params.put(NetworkConfig.UPDATE_PARAMETERS_0_PARAM_NAME, NetworkConfigValues.TYPE_ID);
            params.put(NetworkConfig.UPDATE_PARAMETERS_0_PARAM_VALUE, NetworkConfigValues.ONE);
            params.put(NetworkConfig.UPDATE_PARAMETERS_1_PARAM_NAME, NetworkConfigValues.HEADER);
            params.put(NetworkConfig.UPDATE_PARAMETERS_1_PARAM_VALUE, NetworkConfigValues.CDATA);
            params.put(NetworkConfig.UPDATE_PARAMETERS_2_PARAM_NAME, NetworkConfigValues.MSG_TEXT);
            if (mData != null) {
                params.put(NetworkConfig.UPDATE_PARAMETERS_2_PARAM_VALUE, mData);
            }
            params.put(NetworkConfig.UPDATE_PARAMETERS_3_PARAM_NAME, NetworkConfigValues.PRIOR);
            params.put(NetworkConfig.UPDATE_PARAMETERS_3_PARAM_VALUE, NetworkConfigValues.ZERO);
            params.put(NetworkConfig.UPDATE_PARAMETERS_4_PARAM_NAME, NetworkConfigValues.MSG_SUB);
            if (data != null) {
                params.put(NetworkConfig.UPDATE_PARAMETERS_4_PARAM_VALUE, data.getSubject());
            }
            params.put(NetworkConfig.UPDATE_PARAMETERS_5_PARAM_NAME, NetworkConfigValues.MSG_WF_STATUS);
            params.put(NetworkConfig.UPDATE_PARAMETERS_5_PARAM_VALUE, NetworkConfigValues.ONE);
            params.put(NetworkConfig.UPDATE_PARAMETERS_6_PARAM_NAME, NetworkConfigValues.UPLOADED_FILE_NAME);
            params.put(NetworkConfig.UPDATE_PARAMETERS_6_PARAM_VALUE, "");
            params.put(NetworkConfig.UPDATE_PARAMETERS_7_PARAM_NAME, NetworkConfigValues.GENERATED_FILE_NAME);
            params.put(NetworkConfig.UPDATE_PARAMETERS_7_PARAM_VALUE, "");
            params.put(NetworkConfig.UPDATE_PARAMETERS_8_PARAM_NAME, NetworkConfigValues.CURRENT_REL_ENTY_ID);
            if (info != null) {
                params.put(NetworkConfig.UPDATE_PARAMETERS_8_PARAM_VALUE, info.getCurrentRelEntityID());
            }

            str = GeneralUtils.convertToBody(params);
        }
        return str.getBytes();


    }

    @NonNull
    @Override
    public Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<>();

        if (SharedPreferenceHelper.getInstance() != null && SharedPreferenceHelper.getInstance().getPreference(mContext, "sessionid") != null) {
            String sessionId = SharedPreferenceHelper.getInstance().getPreference(mContext, "sessionid");
            if (sessionId != null) {
                headers.put(NetworkConfig.COOKIE, sessionId);
            }
            headers.put(NetworkConfig.REFERER, NetworkConfigValues.REFERER_VALUE);
            headers.put(NetworkConfig.USER_AGENT, NetworkConfigValues.USER_AGENT_VALUE);
        }
        return headers;
    }
}
