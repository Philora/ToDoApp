package com.wps.memberapp.domain.network;

import android.content.Context;
import android.util.Log;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class GetAccessTokenRequest extends StringRequest {
    private final Context context;
    private String mRequestBody;

    public GetAccessTokenRequest(int method, String url, final Context context, Response.Listener<String> listener, Response.ErrorListener errorListener) {
        super(method, url, listener, errorListener);
        this.context = context;
    }

    @Override
    public Map<String, String> getHeaders(){
        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", "Basic MjJCOUw5OjVmOTY2YjJhMzFlZGNiZTI3ZDQyNTQ3YTEzN2FkMjdh");
        return headers;
    }

    @Override
    public String getBodyContentType() {
        return "application/json";
    }

    @Override
    public byte[] getBody() {

        JSONObject jsonObj = new JSONObject();
        try {
            jsonObj.put("grant_type", "refresh_token");
            //this refresh token should be stored in shared preference and will be updated everytime you get new access token
            jsonObj.put("refresh_token", "61118f0760862bfa6f161ae20e725f645d7bc31299d9123704ab972bd5d3f4b0");
        } catch (JSONException e) {
            e.printStackTrace();
        }
            mRequestBody = jsonObj.toString();
            Log.i("Request is ", mRequestBody);

        return mRequestBody.getBytes();
    }
}