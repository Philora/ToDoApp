package com.wps.memberapp.domain.network;

import android.content.Context;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.BenefitUserDetails;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.NetworkConfig;
import com.wps.memberapp.utility.NetworkConfigValues;
import com.wps.memberapp.utility.StringConstants;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import androidx.annotation.NonNull;

/*
This class is used to send a network request to get the account balance details of the user to display
in the dashboard.
 */
public class GetAccountBalanceRequest extends StringRequest {

    private final Context mContext;

    public GetAccountBalanceRequest(int method, String url, Context mContext, Response.Listener<String> listener,
                                    Response.ErrorListener errorListener) {
        super(method, url, listener, errorListener);
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<>();

        if (SharedPreferenceHelper.getInstance() != null && SharedPreferenceHelper.getInstance().getPreference(mContext, "sessionid") != null) {
            String sessionId = SharedPreferenceHelper.getInstance().getPreference(mContext, "sessionid");
            if (sessionId != null) {
                headers.put(NetworkConfig.COOKIE, sessionId);
                headers.put(NetworkConfig.CONTENT_TYPE, NetworkConfig.CONTENT_TYPE_FORM_URLENCODED);
            }
        }
        headers.put(NetworkConfig.REFERER, NetworkConfigValues.REFERER_VALUE);
        headers.put(NetworkConfig.USER_AGENT, NetworkConfigValues.USER_AGENT_VALUE);
        return headers;
    }

    @Override
    public Map<String, String> getParams() {
        Map<String, String> params = new HashMap<>();
        if (ProfileDataCache.getInstance().getmMemberDetails() != null) {
            int position = ProfileDataCache.getInstance().getPersonNumber();
            MemberDetails mMemberDetails = ProfileDataCache.getInstance().getmMemberDetails().get(position);
            if (mMemberDetails != null) {
                params.put(NetworkConfig.SUBSCRIBER_ID, mMemberDetails.getSubscriberID());
                params.put(NetworkConfig.PERSON_NUMBER, mMemberDetails.getPersonNumber());
                params.put(NetworkConfig.GROUP_ID, mMemberDetails.getGroupId());
                params.put(NetworkConfig.DATE, GeneralUtils.getTodayDate());

                // Code changes - During My Benefits Part
                String date = mMemberDetails.getTermDate();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                Date testDate = null;
                try {
                    testDate = sdf.parse(date);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault());
                String newFormat = formatter.format(testDate);

                params.put(NetworkConfig.TERM_DATE, newFormat);
                params.put(NetworkConfig.PLANTYPE,mMemberDetails.getUserDefined4());
            }
        }
        return params;
    }
}
