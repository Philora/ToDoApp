package com.wps.memberapp.domain.network;

import android.content.Context;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.NetworkConfig;
import com.wps.memberapp.utility.NetworkConfigValues;

import java.io.StringReader;
import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;

public class GetAccountbalanceSummary extends StringRequest {
    private final Context mContext;

    public GetAccountbalanceSummary(int method, String url, Context mContext, Response.Listener<String> listener,
                               Response.ErrorListener errorListener) {
        super(method, url, listener, errorListener);
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<>();

        if (SharedPreferenceHelper.getInstance() != null && SharedPreferenceHelper.getInstance().getPreference(mContext, "sessionid") != null) {
            String sessionId = SharedPreferenceHelper.getInstance().getPreference(mContext, "sessionid");
            if (sessionId != null) {
                headers.put(NetworkConfig.COOKIE, sessionId);
                headers.put(NetworkConfig.CONTENT_TYPE, NetworkConfig.CONTENT_TYPE_FORM_URLENCODED);
            }
        }
        headers.put(NetworkConfig.REFERER, NetworkConfigValues.REFERER_VALUE);
        headers.put(NetworkConfig.USER_AGENT, NetworkConfigValues.USER_AGENT_VALUE);
        return headers;
    }

    @Override
    public Map<String, String> getParams() {
        Map<String, String> params = new HashMap<>();
        if (ProfileDataCache.getInstance().getmMemberDetails() != null) {
            MemberDetails mMemberDetails = ProfileDataCache.getInstance().getmMemberDetails().get(0);
            if (mMemberDetails != null) {
                params.put(NetworkConfig.SUBSCRIBER_ID, mMemberDetails.getSubscriberID());
                params.put(NetworkConfig.PERSON_NUMBER, mMemberDetails.getPersonNumber());
                params.put(NetworkConfig.GROUP_ID, mMemberDetails.getGroupId());
                params.put(NetworkConfig.DATE, GeneralUtils.getTodayDate());

            }
        }
        return params;
    }
}
