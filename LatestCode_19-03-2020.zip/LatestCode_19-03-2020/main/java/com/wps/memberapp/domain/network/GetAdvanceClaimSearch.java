package com.wps.memberapp.domain.network;

import android.content.Context;
import android.util.Log;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.NetworkConfig;
import com.wps.memberapp.utility.NetworkConfigValues;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;

/*
This class is used to send a network request to get list of claims based on the
advanced search filters.
 */
public class GetAdvanceClaimSearch extends StringRequest {
    private final Context mContext;

    public GetAdvanceClaimSearch(int method, String url, final Context mContext, Response.Listener<String> listener,
                                 Response.ErrorListener errorListener) {
        super(method, url, listener, errorListener);
        this.mContext = mContext;
    }

    @Override
    public byte[] getBody() {
        String str = "";
        if (ProfileDataCache.getInstance().getSearchFilters() != null) {
            String startDate = ProfileDataCache.getInstance().getSearchFilters().getStartDate();
            String endDate = ProfileDataCache.getInstance().getSearchFilters().getEndDate();
            String memberName = ProfileDataCache.getInstance().getSearchFilters().getName();
            String status = ProfileDataCache.getInstance().getSearchFilters().getStatus();
            String mClaimTypeOp = "";
            String type = ProfileDataCache.getInstance().getSearchFilters().getClaimtype();

            String firstName = "";
            String lastName = "";
            String personNo = "";
            if (memberName != null) {
                personNo = GeneralUtils.getPersonNumber(memberName);
                String[] arr = memberName.toUpperCase().split(" ", 2);
                firstName = arr[0];
                if (arr.length > 1) {
                    lastName = arr[1];
                }
            }
        /*if (status != null && status.length() > 1) {
            status = status.toUpperCase().substring(0, 1);
        }*/
            if (startDate == null) {
                startDate = "";
            }
            if (endDate == null) {
                endDate = "";
            }
            if (status == null) {
                status = "";
            }
            // Change the request value based on spinner selection(Claim type)
            if (type != null && type.equalsIgnoreCase("Dental")) {
                type = "D";
                mClaimTypeOp = NetworkConfigValues.EQ;
            } else if (type != null && type.equalsIgnoreCase("Medical")) {
                type = "\'I\'" + "," + "\'P\'";
                mClaimTypeOp = NetworkConfigValues.IN;
            } else if (type != null && type.equalsIgnoreCase("Pharmacy")) {
                type = "M";
                mClaimTypeOp = NetworkConfigValues.EQ;
            }
            Map<String, String> params = new HashMap<>();
            params.put(NetworkConfig.REQUEST_TYPE, NetworkConfigValues.CLAIMS);
            params.put(NetworkConfig.REQUEST_SUB_TYPE, GeneralUtils.getClaimRequestSubType());
            params.put(NetworkConfig.PAGE_ID, NetworkConfigValues.ONE);
            params.put(NetworkConfig.PAGE_SIZE, "" + 50); // Changed the value from TWENTY to TWENTY FIVE(Sparsh raised this issue)
            params.put(NetworkConfig.REQUEST_PARAMETERS_0_PARAM_NAME, NetworkConfigValues.STATUS);
            params.put(NetworkConfig.REQUEST_PARAMETERS_0_PARAM_VALUES, status);
            params.put(NetworkConfig.REQUEST_PARAMETERS_0_OPERATOR, NetworkConfigValues.EQ);
            params.put(NetworkConfig.REQUEST_PARAMETERS_1_PARAM_NAME, NetworkConfigValues.FROM_DATE);
            params.put(NetworkConfig.REQUEST_PARAMETERS_1_PARAM_VALUES, startDate);
            params.put(NetworkConfig.REQUEST_PARAMETERS_1_OPERATOR, NetworkConfigValues.GE);
            params.put(NetworkConfig.REQUEST_PARAMETERS_2_PARAM_NAME, NetworkConfigValues.TO_DATE);
            params.put(NetworkConfig.REQUEST_PARAMETERS_2_PARAM_VALUES, endDate);
            params.put(NetworkConfig.REQUEST_PARAMETERS_2_OPERATOR, NetworkConfigValues.LE);

            if (type != null && !type.equalsIgnoreCase("")) {
                params.put(NetworkConfig.REQUEST_PARAMETERS_3_PARAM_NAME, NetworkConfigValues.CLAIM_TYPE);
                params.put(NetworkConfig.REQUEST_PARAMETERS_3_PARAM_VALUES, type);
                params.put(NetworkConfig.REQUEST_PARAMETERS_3_OPERATOR, mClaimTypeOp);
            }
            if (personNo != null && !firstName.equalsIgnoreCase("") && !lastName.equalsIgnoreCase("")) {
                params.put(NetworkConfig.REQUEST_PARAMETERS_3_PARAM_NAME, NetworkConfigValues.MEMBER_FNAME);
                params.put(NetworkConfig.REQUEST_PARAMETERS_3_PARAM_VALUES, firstName);
                params.put(NetworkConfig.REQUEST_PARAMETERS_3_OPERATOR, NetworkConfigValues.EQ);
                params.put(NetworkConfig.REQUEST_PARAMETERS_4_PARAM_NAME, NetworkConfigValues.PERSON_NO);
                params.put(NetworkConfig.REQUEST_PARAMETERS_4_PARAM_VALUES, personNo);
                params.put(NetworkConfig.REQUEST_PARAMETERS_4_OPERATOR, NetworkConfigValues.EQ);
                params.put(NetworkConfig.REQUEST_PARAMETERS_5_PARAM_NAME, NetworkConfigValues.MEMBER_LNAME);
                params.put(NetworkConfig.REQUEST_PARAMETERS_5_PARAM_VALUES, lastName);
                params.put(NetworkConfig.REQUEST_PARAMETERS_5_OPERATOR, NetworkConfigValues.EQ);
            }
            if (type != null && personNo != null && !firstName.equalsIgnoreCase("") && !lastName.equalsIgnoreCase("") && !type.equalsIgnoreCase("")) {
                params.put(NetworkConfig.REQUEST_PARAMETERS_3_PARAM_NAME, NetworkConfigValues.MEMBER_FNAME);
                params.put(NetworkConfig.REQUEST_PARAMETERS_3_PARAM_VALUES, firstName);
                params.put(NetworkConfig.REQUEST_PARAMETERS_3_OPERATOR, NetworkConfigValues.EQ);
                params.put(NetworkConfig.REQUEST_PARAMETERS_4_PARAM_NAME, NetworkConfigValues.PERSON_NO);
                params.put(NetworkConfig.REQUEST_PARAMETERS_4_PARAM_VALUES, personNo);
                params.put(NetworkConfig.REQUEST_PARAMETERS_4_OPERATOR, NetworkConfigValues.EQ);
                params.put(NetworkConfig.REQUEST_PARAMETERS_5_PARAM_NAME, NetworkConfigValues.MEMBER_LNAME);
                params.put(NetworkConfig.REQUEST_PARAMETERS_5_PARAM_VALUES, lastName);
                params.put(NetworkConfig.REQUEST_PARAMETERS_5_OPERATOR, NetworkConfigValues.EQ);
                params.put(NetworkConfig.REQUEST_PARAMETERS_6_PARAM_NAME, NetworkConfigValues.CLAIM_TYPE);
                params.put(NetworkConfig.REQUEST_PARAMETERS_6_PARAM_VALUES, type);
                params.put(NetworkConfig.REQUEST_PARAMETERS_6_OPERATOR, mClaimTypeOp);
            }
            str = GeneralUtils.convertToBody(params);
            Log.i("Request", str);
        }
        return str.getBytes();
    }

    @NonNull
    @Override
    public Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<>();

        if (SharedPreferenceHelper.getInstance() != null && SharedPreferenceHelper.getInstance().getPreference(mContext, "sessionid") != null) {
            String sessionId = SharedPreferenceHelper.getInstance().getPreference(mContext, "sessionid");
            if (sessionId != null) {
                headers.put(NetworkConfig.COOKIE, sessionId);
            }
            headers.put(NetworkConfig.REFERER, NetworkConfigValues.REFERER_VALUE);
            headers.put(NetworkConfig.USER_AGENT, NetworkConfigValues.USER_AGENT_VALUE);
        }
        return headers;
    }
}


