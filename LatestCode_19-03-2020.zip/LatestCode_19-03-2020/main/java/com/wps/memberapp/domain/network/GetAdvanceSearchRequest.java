package com.wps.memberapp.domain.network;

import android.content.Context;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.NetworkConfig;
import com.wps.memberapp.utility.NetworkConfigValues;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;

/**
 * This class is used to send a network request to get list of authorizations based on the
 * advanced search filters.
 */
public class GetAdvanceSearchRequest extends StringRequest {

    private final Context mContext;

    public GetAdvanceSearchRequest(int method, String url, final Context mContext, Response.Listener<String> listener,
                                   Response.ErrorListener errorListener) {
        super(method, url, listener, errorListener);
        this.mContext = mContext;
    }

    @Override
    public byte[] getBody() {
        String str = "";
        if (ProfileDataCache.getInstance().getSearchFilters() != null) {
            String startDate = ProfileDataCache.getInstance().getSearchFilters().getStartDate();
            String endDate = ProfileDataCache.getInstance().getSearchFilters().getEndDate();
            String memberName = ProfileDataCache.getInstance().getSearchFilters().getName();
            String authNo = ProfileDataCache.getInstance().getSearchFilters().getNumber();
            String status = ProfileDataCache.getInstance().getSearchFilters().getStatus();
            String firstName = "";
            String lastName = "";
            if (memberName != null) {
                String[] arr = memberName.toUpperCase().split(" ", 2);
                firstName = arr[0];
                if (arr.length > 1) {
                    lastName = arr[1];
                }
            }
            if (startDate == null) {
                startDate = "";
            }
            if (endDate == null) {
                endDate = "";
            }
            if (status == null) {
                status = "";
            }

            Map<String, String> params = new HashMap<>();
            params.put(NetworkConfig.PAGE_ID, NetworkConfigValues.ONE);
            params.put(NetworkConfig.PAGE_SIZE, NetworkConfigValues.THIRTY);
            params.put(NetworkConfig.REQUEST_TYPE, NetworkConfigValues.AUTHS);
            params.put(NetworkConfig.REQUEST_SUB_TYPE, GeneralUtils.getAuthRequestSubType());
            params.put(NetworkConfig.REQUEST_PARAMETERS_0_PARAM_NAME, NetworkConfigValues.STATUS);
            params.put(NetworkConfig.REQUEST_PARAMETERS_0_PARAM_VALUES, status);
            params.put(NetworkConfig.REQUEST_PARAMETERS_0_OPERATOR, NetworkConfigValues.EQ);
            params.put(NetworkConfig.REQUEST_PARAMETERS_1_PARAM_NAME, NetworkConfigValues.FROM_DATE);
            params.put(NetworkConfig.REQUEST_PARAMETERS_1_PARAM_VALUES, startDate);
            params.put(NetworkConfig.REQUEST_PARAMETERS_1_OPERATOR, NetworkConfigValues.GE);
            params.put(NetworkConfig.REQUEST_PARAMETERS_2_PARAM_NAME, NetworkConfigValues.TO_DATE);
            params.put(NetworkConfig.REQUEST_PARAMETERS_2_PARAM_VALUES, endDate);
            params.put(NetworkConfig.REQUEST_PARAMETERS_2_OPERATOR, NetworkConfigValues.LE);

            // params will change based on selection(with auth number / member name)
            params.put(NetworkConfig.REQUEST_PARAMETERS_3_PARAM_NAME, NetworkConfigValues.AUTH_NUMBER);
            params.put(NetworkConfig.REQUEST_PARAMETERS_3_PARAM_VALUES, authNo);
            params.put(NetworkConfig.REQUEST_PARAMETERS_3_OPERATOR, NetworkConfigValues.EQ);

            if (!firstName.equalsIgnoreCase("") && !lastName.equalsIgnoreCase("")) {
                params.put(NetworkConfig.REQUEST_PARAMETERS_3_PARAM_NAME, NetworkConfigValues.FIRST_NAME);
                params.put(NetworkConfig.REQUEST_PARAMETERS_3_PARAM_VALUES, firstName);
                params.put(NetworkConfig.REQUEST_PARAMETERS_3_OPERATOR, NetworkConfigValues.EQ);
                params.put(NetworkConfig.REQUEST_PARAMETERS_4_PARAM_NAME, NetworkConfigValues.LAST_NAME);
                params.put(NetworkConfig.REQUEST_PARAMETERS_4_PARAM_VALUES, lastName);
                params.put(NetworkConfig.REQUEST_PARAMETERS_4_OPERATOR, NetworkConfigValues.EQ);
                params.put(NetworkConfig.REQUEST_PARAMETERS_5_PARAM_NAME, NetworkConfigValues.AUTH_NUMBER);
                params.put(NetworkConfig.REQUEST_PARAMETERS_5_PARAM_VALUES, authNo);
                params.put(NetworkConfig.REQUEST_PARAMETERS_5_OPERATOR, NetworkConfigValues.EQ);
            }
            if (!firstName.equalsIgnoreCase("") && !lastName.equalsIgnoreCase("") && !authNo.equalsIgnoreCase("")) {
                params.put(NetworkConfig.REQUEST_PARAMETERS_3_PARAM_NAME, NetworkConfigValues.FIRST_NAME);
                params.put(NetworkConfig.REQUEST_PARAMETERS_3_PARAM_VALUES, firstName);
                params.put(NetworkConfig.REQUEST_PARAMETERS_3_OPERATOR, NetworkConfigValues.EQ);
                params.put(NetworkConfig.REQUEST_PARAMETERS_4_PARAM_NAME, NetworkConfigValues.LAST_NAME);
                params.put(NetworkConfig.REQUEST_PARAMETERS_4_PARAM_VALUES, lastName);
                params.put(NetworkConfig.REQUEST_PARAMETERS_4_OPERATOR, NetworkConfigValues.EQ);
                params.put(NetworkConfig.REQUEST_PARAMETERS_5_PARAM_NAME, NetworkConfigValues.AUTH_NUMBER);
                params.put(NetworkConfig.REQUEST_PARAMETERS_5_PARAM_VALUES, authNo);
                params.put(NetworkConfig.REQUEST_PARAMETERS_5_OPERATOR, NetworkConfigValues.EQ);
            }

            str = GeneralUtils.convertToBody(params);
        }
        return str.getBytes();
    }

    @NonNull
    @Override
    public Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<>();

        if (SharedPreferenceHelper.getInstance() != null && SharedPreferenceHelper.getInstance().getPreference(mContext, "sessionid") != null) {
            String sessionId = SharedPreferenceHelper.getInstance().getPreference(mContext, "sessionid");
            if (sessionId != null) {
                headers.put(NetworkConfig.COOKIE, sessionId);
            }
            headers.put(NetworkConfig.REFERER, NetworkConfigValues.REFERER_VALUE);
            headers.put(NetworkConfig.USER_AGENT, NetworkConfigValues.USER_AGENT_VALUE);
        }

        return headers;
    }
}
