package com.wps.memberapp.domain.network;

import android.content.Context;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.BenefitUserDetails;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.NetworkConfig;
import com.wps.memberapp.utility.NetworkConfigValues;
import com.wps.memberapp.utility.StringConstants;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import androidx.annotation.NonNull;

/**
 * This class is used to send network a request to get benefit product details
 * based on the product ID.
 */
public class GetBenefitProductDetailsRequest extends StringRequest {

    private final Context mContext;

    public GetBenefitProductDetailsRequest(int method, String url, final Context mContext,
                                           Response.Listener<String> listener, Response.ErrorListener errorListener) {
        super(method, url, listener, errorListener);
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<>();
        try {
            if (SharedPreferenceHelper.getInstance() != null && SharedPreferenceHelper.getInstance().getPreference(mContext, "sessionid") != null) {
                String sessionId = SharedPreferenceHelper.getInstance().getPreference(mContext, "sessionid");
                if (sessionId != null) {
                    headers.put(NetworkConfig.COOKIE, sessionId);
                }
                headers.put(NetworkConfig.REFERER, NetworkConfigValues.REFERER_VALUE);
                headers.put(NetworkConfig.USER_AGENT, NetworkConfigValues.USER_AGENT_VALUE);
            }
        } catch (Exception e) {
            Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
        }
        return headers;
    }

    @NonNull
    @Override
    protected Map<String, String> getParams() {
        Map<String, String> params = new HashMap<>();
        int position = ProfileDataCache.getInstance().getPersonNumber();
       /// String productCode = ProfileDataCache.getInstance().getProductCode();
        MemberDetails mMemberDetails = ProfileDataCache.getInstance().getmMemberDetails().get(position);
       /* if (productCode != null) {
            params.put(NetworkConfig.PRODUCT_DETAILS_ID, productCode);
        }*/
        if (mMemberDetails != null) {
            params.put(NetworkConfig.DATE, GeneralUtils.getTodayDate());

            // Code changes - During My Benefits Part
            String date = mMemberDetails.getTermDate();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            Date testDate = null;
            try {
                testDate = sdf.parse(date);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault());
            String newFormat = formatter.format(testDate);

            params.put(NetworkConfig.TERM_DATE, newFormat);
        }
        return params;
    }
}
