package com.wps.memberapp.domain.network;

import android.content.Context;
import android.util.Log;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.NetworkConfig;
import com.wps.memberapp.utility.NetworkConfigValues;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;

/**
 * This class is used to send a network request to get claim details
 * based on the claim number.
 */
public class GetClaimDetailViewRequest extends StringRequest {

    private final Context mContext;

    public GetClaimDetailViewRequest(int method, String url, final Context mContext,
                                     Response.Listener<String> listener, Response.ErrorListener errorListener) {
        super(method, url, listener, errorListener);
        this.mContext = mContext;
    }

    @Override
    public byte[] getBody() {
        String claimNumber = ProfileDataCache.getInstance().getEncryptClaimNumber();
        String claimType = ProfileDataCache.getInstance().getClaimType();
        String sID = ProfileDataCache.getInstance().getHashCode();
        Map<String, String> params = new HashMap<>();
        params.put(NetworkConfig.REQUEST_TYPE, NetworkConfigValues.CLAIMS);
        if (claimType != null) { // Checking Null
            params.put(NetworkConfig.REQUEST_SUB_TYPE, claimType);
        }
        params.put(NetworkConfig.REQUEST_PARAMETERS_0_PARAM_NAME, NetworkConfigValues.CLAIM_NUMBER);
        if (claimNumber != null) {
            params.put(NetworkConfig.REQUEST_PARAMETERS_0_PARAM_VALUES, claimNumber);
        }
        params.put(NetworkConfig.REQUEST_PARAMETERS_1_PARAM_NAME, NetworkConfigValues.SID);
        if (sID != null) {
            params.put(NetworkConfig.REQUEST_PARAMETERS_1_PARAM_VALUES, sID);
        }
        String str = GeneralUtils.convertToBody(params);
        Log.i("Claims request", str);
        return str.getBytes();
    }

    @NonNull
    @Override
    public Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<>();
        if (SharedPreferenceHelper.getInstance() != null && SharedPreferenceHelper.getInstance().getPreference(mContext, "sessionid") != null) {
            String sessionId = SharedPreferenceHelper.getInstance().getPreference(mContext, "sessionid");
            if (sessionId != null) {
                headers.put(NetworkConfig.COOKIE, sessionId);
            }
            headers.put(NetworkConfig.REFERER, NetworkConfigValues.REFERER_VALUE);
            headers.put(NetworkConfig.USER_AGENT, NetworkConfigValues.USER_AGENT_VALUE);
        }
        return headers;
    }
}
