package com.wps.memberapp.domain.network;

import android.content.Context;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.NetworkConfig;
import com.wps.memberapp.utility.NetworkConfigValues;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;

/*
This class is used to send a network request to get claim summary used to
display in the dashboard.
 */
public class GetClaimSummaryRequest extends StringRequest {

    private final Context mContext;

    public GetClaimSummaryRequest(int method, String url, final Context mContext, Response.Listener<String> listener, Response.ErrorListener errorListener) {
        super(method, url, listener, errorListener);
        this.mContext = mContext;
    }

    @Override
    public byte[] getBody() {
        String str = "";
        if (ProfileDataCache.getInstance().getmMemberDetails() != null) {
            MemberDetails details = ProfileDataCache.getInstance().getmMemberDetails().get(0);
            if (details != null) {
                Map<String, String> params = new HashMap<>();
                params.put(NetworkConfig.REQUEST_TYPE, NetworkConfigValues.CLAIMS);
                if (details.getPersonNumber() != null && details.getPersonNumber().equalsIgnoreCase("01")) {
                    params.put(NetworkConfig.REQUEST_SUB_TYPE, NetworkConfigValues.MEMBCLAIMSUMMARY_FOR_SUBSCRIBER);
                } else {
                    params.put(NetworkConfig.REQUEST_SUB_TYPE, NetworkConfigValues.MEMBCLAIMSUMMARY);
                }
                str = GeneralUtils.convertToBody(params);
            }
        }
        return str.getBytes();
    }

    @NonNull
    @Override
    public Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<>();

        if (SharedPreferenceHelper.getInstance() != null && SharedPreferenceHelper.getInstance().getPreference(mContext, "sessionid") != null) {
            String sessionId = SharedPreferenceHelper.getInstance().getPreference(mContext, "sessionid");
            if (sessionId != null) {
                headers.put(NetworkConfig.COOKIE, sessionId);
                headers.put(NetworkConfig.CONTENT_TYPE, NetworkConfig.CONTENT_TYPE_FORM_URLENCODED);
            }
            headers.put(NetworkConfig.REFERER, NetworkConfigValues.REFERER_VALUE);
            headers.put(NetworkConfig.USER_AGENT, NetworkConfigValues.USER_AGENT_VALUE);
        }

        return headers;
    }
}
