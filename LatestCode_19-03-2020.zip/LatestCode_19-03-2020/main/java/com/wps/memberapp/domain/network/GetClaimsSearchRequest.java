package com.wps.memberapp.domain.network;

import android.content.Context;
import android.util.Log;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.NetworkConfig;
import com.wps.memberapp.utility.NetworkConfigValues;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;

/*
This class is used to send a network request to get list of claims
based on the duration and other filters.
 */
public class GetClaimsSearchRequest extends StringRequest {

    private final Context mContext;

    public GetClaimsSearchRequest(int method, String url, final Context mContext, Response.Listener<String> listener, Response.ErrorListener errorListener) {
        super(method, url, listener, errorListener);
        this.mContext = mContext;
    }

    @Override
    public byte[] getBody() {
        String days = ProfileDataCache.getInstance().getClaimSearchDays();
        int pageID = ProfileDataCache.getInstance().getPageID();
        Map<String, String> params = new HashMap<>();
        params.put(NetworkConfig.REQUEST_TYPE, NetworkConfigValues.CLAIMS);
        params.put(NetworkConfig.REQUEST_SUB_TYPE, GeneralUtils.getClaimRequestSubType());
        params.put(NetworkConfig.PAGE_ID, "" + pageID);
        params.put(NetworkConfig.PAGE_SIZE, String.valueOf(60)); // Changes NetworkConfigValues.TEN
        params.put(NetworkConfig.REQUEST_PARAMETERS_0_PARAM_NAME, NetworkConfigValues.FROM_DATE);
        params.put(NetworkConfig.REQUEST_PARAMETERS_0_PARAM_VALUES, days);
        if (days.length() == 4) {
            params.put(NetworkConfig.REQUEST_PARAMETERS_0_OPERATOR, NetworkConfigValues.CY);
        } else {
            params.put(NetworkConfig.REQUEST_PARAMETERS_0_OPERATOR, NetworkConfigValues.BT);
        }
        if (ProfileDataCache.getInstance().getSearchFilters() != null) {
            String memberName = ProfileDataCache.getInstance().getSearchFilters().getName();
            String firstName = "";
            String lastName = "";
            String personNo = "";
            if (memberName != null) {
                personNo = GeneralUtils.getPersonNumber(memberName);
                String[] arr = memberName.toUpperCase().split(" ", 2);
                firstName = arr[0];
                if (arr.length > 1) {
                    lastName = arr[1];
                }
            }
            if (personNo != null && !firstName.equalsIgnoreCase("") && !lastName.equalsIgnoreCase("")) {
                params.put(NetworkConfig.REQUEST_PARAMETERS_1_PARAM_NAME, NetworkConfigValues.MEMBER_FNAME);
                params.put(NetworkConfig.REQUEST_PARAMETERS_1_PARAM_VALUES, firstName);
                params.put(NetworkConfig.REQUEST_PARAMETERS_1_OPERATOR, NetworkConfigValues.EQ);
                params.put(NetworkConfig.REQUEST_PARAMETERS_2_PARAM_NAME, NetworkConfigValues.PERSON_NO);
                params.put(NetworkConfig.REQUEST_PARAMETERS_2_PARAM_VALUES, personNo);
                params.put(NetworkConfig.REQUEST_PARAMETERS_2_OPERATOR, NetworkConfigValues.EQ);
                params.put(NetworkConfig.REQUEST_PARAMETERS_3_PARAM_NAME, NetworkConfigValues.MEMBER_LNAME);
                params.put(NetworkConfig.REQUEST_PARAMETERS_3_PARAM_VALUES, lastName);
                params.put(NetworkConfig.REQUEST_PARAMETERS_3_OPERATOR, NetworkConfigValues.EQ);
            }
        }
        String str = GeneralUtils.convertToBody(params);
        Log.i("Claims Request", str);
        return str.getBytes();
    }

    @NonNull
    @Override
    public Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<>();

        if (SharedPreferenceHelper.getInstance() != null && SharedPreferenceHelper.getInstance().getPreference(mContext, "sessionid") != null) {
            String sessionId = SharedPreferenceHelper.getInstance().getPreference(mContext, "sessionid");
            if (sessionId != null) {
                headers.put(NetworkConfig.COOKIE, sessionId);
                headers.put(NetworkConfig.CONTENT_TYPE, NetworkConfig.CONTENT_TYPE_FORM_URLENCODED);
            }
            headers.put(NetworkConfig.REFERER, NetworkConfigValues.REFERER_VALUE);
            headers.put(NetworkConfig.USER_AGENT, NetworkConfigValues.USER_AGENT_VALUE);
        }

        return headers;
    }
}
