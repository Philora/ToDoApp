package com.wps.memberapp.domain.network;


import android.content.Context;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.NetworkConfig;
import com.wps.memberapp.utility.NetworkConfigValues;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;

public class GetGroupNameData extends StringRequest {
    private final Context context;

    public GetGroupNameData(int method, String url, final Context context,
                            Response.Listener<String> listener, Response.ErrorListener errorListener) {
        super(method, url, listener, errorListener);
        this.context = context;
    }

    @NonNull
    @Override
    public Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<>();

        if (SharedPreferenceHelper.getInstance() != null && SharedPreferenceHelper.getInstance().getPreference(context, "sessionid") != null) {
            String sessionId = SharedPreferenceHelper.getInstance().getPreference(context, "sessionid");
            if (sessionId != null) {
                headers.put(NetworkConfig.COOKIE, sessionId);
            }
            headers.put(NetworkConfig.REFERER, NetworkConfigValues.REFERER_VALUE);
            headers.put(NetworkConfig.USER_AGENT, NetworkConfigValues.USER_AGENT_VALUE);
        }
        return headers;
    }

    @Override
    public byte[] getBody() {
        String searchGroupName = ProfileDataCache.getInstance().getSearchGroupNameQueryKeyword();
        Map<String, String> params = new HashMap<>();
        if (searchGroupName != null) {
            String mParamValue = "<![CDATA[" + searchGroupName + "]]>";
            params.put(NetworkConfig.REQUEST_TYPE, NetworkConfigValues.REPORTS);
            params.put(NetworkConfig.REQUEST_SUB_TYPE, NetworkConfigValues.PRACTICEGROUP);
            params.put(NetworkConfig.PAGE_ID, "1");
            params.put(NetworkConfig.REQUEST_PARAMETERS_0_PARAM_NAME, NetworkConfigValues.PRACTICEGROUP);
            params.put(NetworkConfig.REQUEST_PARAMETERS_0_PARAM_VALUES, mParamValue);
            params.put(NetworkConfig.REQUEST_PARAMETERS_0_OPERATOR, "CN");
        }
        String str = GeneralUtils.convertToBody(params);
        return str.getBytes();
    }
}
