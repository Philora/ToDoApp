package com.wps.memberapp.domain.network;

import android.content.Context;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * This class is used to check whether user is exist or not in the immunization for particular user
 */

public class GetImmunizationByMemberIDRequest extends StringRequest {
    private final Context context;
    private String mRequestBody;

    public GetImmunizationByMemberIDRequest(int method, String url, final Context context,
                                 Response.Listener<String> listener, Response.ErrorListener errorListener)
    {
        super(method, url, listener, errorListener);
        this.context = context;
    }

    @Override
    public Map<String, String> getHeaders()
    {
        Map<String, String> headers = new HashMap<>();
        String sessionId = SharedPreferenceHelper.getInstance().getPreference(context,"sessionid");
        headers.put("Cookie",sessionId);
        headers.put("Content_Type","application/x-www-form-urlencoded");
        return headers;
    }

    @Override
    public String getBodyContentType()
    {
        return "application/json";
    }

    @Override
    public byte[] getBody()
    {
        try {
            String id= GeneralUtils.getCurrentMemberID();
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("MEMBER_ID", id);
            mRequestBody = jsonObject.toString();

        } catch (JSONException e) {
            Logger.e("Exc",e);
        }
        return mRequestBody.getBytes();
    }

}