package com.wps.memberapp.domain.network;

import android.content.Context;
import android.util.Log;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.NetworkConfig;
import com.wps.memberapp.utility.NetworkConfigValues;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;

/**
 * This class is used to check whether user is exist or not in the immunization for particular user
 */

public class GetImmunizationHistoryByMemberIDRequest extends StringRequest {
    private final Context context;

    public GetImmunizationHistoryByMemberIDRequest(int method, String url, final Context context,
                                                   Response.Listener<String> listener, Response.ErrorListener errorListener) {
        super(method, url, listener, errorListener);
        this.context = context;
    }

    @Override
    public Map<String, String> getHeaders() {
        /*Map<String, String> headers = new HashMap<>();
        String sessionId = SharedPreferenceHelper.getInstance().getPreference(context, "sessionid");
        headers.put("Cookie", sessionId);
        return headers;*/
        Map<String, String> headers = new HashMap<>();
        if (SharedPreferenceHelper.getInstance() != null && SharedPreferenceHelper.getInstance().getPreference(context, "sessionid") != null) {
            String sessionId = SharedPreferenceHelper.getInstance().getPreference(context, "sessionid");
            if (sessionId != null) {
                headers.put(NetworkConfig.COOKIE, sessionId);
            }
            headers.put(NetworkConfig.REFERER, NetworkConfigValues.REFERER_VALUE);
            headers.put(NetworkConfig.USER_AGENT, NetworkConfigValues.USER_AGENT_VALUE);
        }
        return headers;
    }

    @Override
    public String getBodyContentType() {
        return "application/json";
    }

    @Override
    public byte[] getBody() {
        String mRequestBody = "";
        MemberDetails details = ProfileDataCache.getInstance().getmMemberDetails().get(0);
        try {
            if (details!=null) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("SubscriberID", details.getSubscriberID());
                Log.i("id ", details.getSubscriberID());
                mRequestBody = jsonObject.toString();
                Log.i("body is ", mRequestBody);
            }
        } catch (JSONException e) {
            Logger.e("Ex", e);
        }
        return mRequestBody.getBytes();
    }
}