package com.wps.memberapp.domain.network;


import android.content.Context;
import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MemberEligibleInfo;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.NetworkConfig;
import com.wps.memberapp.utility.NetworkConfigValues;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/*
This class is used to send a network request to get member details
based on the subscriber ID.
 */
public class GetKnowledgeBaseRequest extends StringRequest {

    private final Context mContext;

    public GetKnowledgeBaseRequest(int method, String url, final Context mContext, Response.Listener<String> listener, Response.ErrorListener errorListener) {
        super(method, url, listener, errorListener);
        this.mContext = mContext;
    }

    @Override
    public Map<String, String> getHeaders() throws AuthFailureError {
        Map<String, String> headers = super.getHeaders();
        if (headers == null || headers.equals(Collections.emptyMap())) {
            headers = new HashMap<>();
        }

        if (SharedPreferenceHelper.getInstance() != null && SharedPreferenceHelper.getInstance().getPreference(mContext, "sessionid") != null) {
            String sessionId = SharedPreferenceHelper.getInstance().getPreference(mContext, "sessionid");
            if (sessionId != null) {
                headers.put(NetworkConfig.COOKIE, sessionId);
                headers.put(NetworkConfig.CONTENT_TYPE, NetworkConfig.CONTENT_TYPE_FORM_URLENCODED);
            }
            headers.put(NetworkConfig.REFERER, NetworkConfigValues.REFERER_VALUE);
            headers.put(NetworkConfig.USER_AGENT, NetworkConfigValues.USER_AGENT_VALUE);
        }
        return headers;
    }
}

