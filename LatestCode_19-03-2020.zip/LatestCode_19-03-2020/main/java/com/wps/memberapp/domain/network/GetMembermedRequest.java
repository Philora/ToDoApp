package com.wps.memberapp.domain.network;

import android.content.Context;
import android.util.Log;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;

public class GetMembermedRequest extends StringRequest {
    private final Context context;
    private String mRequestBody;

    public GetMembermedRequest(int method, String url, final Context context, Response.Listener<String> listener, Response.ErrorListener errorListener) {
        super(method, url, listener, errorListener);
        this.context = context;
    }

    @Override
    public Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<>();
        String sessionId = SharedPreferenceHelper.getInstance().getPreference(context, "sessionid");
        headers.put("Cookie", sessionId);
        return headers;
    }

    @Override
    public String getBodyContentType() {
        return "application/json";
    }

    @Override
    public byte[] getBody() {
        try {
            JSONObject jsonObject = new JSONObject();
            JSONObject object = new JSONObject();
            if (ProfileDataCache.getInstance().getmMemberDetails() != null) {
                MemberDetails details = ProfileDataCache.getInstance().getmMemberDetails().get(0);
               if (details != null) {
                    jsonObject.put("MemberId", details.getfMSSeqMemberId());
                }
                object.put("getMedicationdetails", jsonObject);
            }
            mRequestBody = object.toString();
            Log.d("GetMedicationRequest", "getBodyRequest: " + mRequestBody);
        } catch (JSONException e) {
            Logger.e("exc", e);
        }
        return mRequestBody.getBytes();
    }

}
