package com.wps.memberapp.domain.network;

import android.content.Context;
import android.util.Log;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.NetworkConfig;
import com.wps.memberapp.utility.NetworkConfigValues;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import androidx.annotation.NonNull;

public class GetPCPSearch extends StringRequest {
    private final Context context;

    public GetPCPSearch(int method, String url, final Context context,
                        Response.Listener<String> listener, Response.ErrorListener errorListener) {
        super(method, url, listener, errorListener);
        this.context = context;
    }

    @NonNull
    @Override
    public Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<>();

        if (SharedPreferenceHelper.getInstance() != null && SharedPreferenceHelper.getInstance().getPreference(context, "sessionid") != null) {
            String sessionId = SharedPreferenceHelper.getInstance().getPreference(context, "sessionid");
            if (sessionId != null) {
                headers.put(NetworkConfig.COOKIE, sessionId);
            }
            headers.put(NetworkConfig.REFERER, NetworkConfigValues.REFERER_VALUE);
            headers.put(NetworkConfig.USER_AGENT, NetworkConfigValues.USER_AGENT_VALUE);
        }
        return headers;
    }

    @Override
    public Map<String, String> getParams() {
        Map<String, String> params = new HashMap<>();
        if (ProfileDataCache.getInstance() != null) {
            int pageID = ProfileDataCache.getInstance().getPageID();
            String mLatValue = ProfileDataCache.getInstance().getGeoLat();
            String mLongValue = ProfileDataCache.getInstance().getGeoLong();
            String mSearchCityValue = ProfileDataCache.getInstance().getSearchCityItemValue();
            String mProviderType = ProfileDataCache.getInstance().getProviderType();
            String mProviderGender = ProfileDataCache.getInstance().getProviderGender();
            String mProviderLanguage = ProfileDataCache.getInstance().getProviderLanguage();
            String mProviderMiles = ProfileDataCache.getInstance().getProvMiles();
            String mSearchGroupNameValue = ProfileDataCache.getInstance().getSearchGroupNameItemValue();
            String mSearchSpecialityValue = ProfileDataCache.getInstance().getSearchSpecialityItemValue();
            String mSearchHospitalAffiliationValue = ProfileDataCache.getInstance().getSearchHospitalAffiliationItemValue();

            String mSearchClinicItemValue = ProfileDataCache.getInstance().getSearchClinicItemValue();
            String mSearchExpertiseItemValue = ProfileDataCache.getInstance().getSearchExpertiseItemValue();


            String mProvFirstName = ProfileDataCache.getInstance().getProvFirstName();
            String mProvLastName = ProfileDataCache.getInstance().getProvLastName();
//        String mProvGroupName = ProfileDataCache.getInstance().getProvGroupName();
            String mProvName = ProfileDataCache.getInstance().getProvName();
            if (mSearchCityValue == null) {
                mSearchCityValue = "";
            }
            if (mProviderType == null) {
                mProviderType = "";
            }
            if (mProviderGender == null) {
                mProviderGender = "";
            }
            if (mProviderLanguage == null) {
                mProviderLanguage = "";
            }
            if (mProviderMiles == null) {
                mProviderMiles = "";
            }
            if (mSearchGroupNameValue == null) {
                mSearchGroupNameValue = "";
            }
            if (mSearchSpecialityValue == null) {
                mSearchSpecialityValue = "";
            }
            if (mSearchHospitalAffiliationValue == null) {
                mSearchHospitalAffiliationValue = "";
            }
            if (mSearchClinicItemValue == null) {
                mSearchClinicItemValue = "";
            }
            if (mSearchExpertiseItemValue == null) {
                mSearchExpertiseItemValue = "";
            }
            if (mProvFirstName == null) {
                mProvFirstName = "";
            }
            if (mProvLastName == null) {
                mProvLastName = "";
            }
            if (mProvName == null) {
                mProvName = "";
            }
        /*if (mProvGroupName == null) {
            mProvGroupName = "";
        }*/

            boolean isCheckedPCP = ProfileDataCache.getInstance().getPCPCheck();
            boolean isCheckedAcceptingNewPatients = ProfileDataCache.getInstance().getAcceptNewPatients();

            // Enhancement 16-01-2020
            boolean isCheckedBoardCertification = ProfileDataCache.getInstance().getBoardCertification();
            boolean isCheckedUrgentCareFacility = ProfileDataCache.getInstance().getUrgentCareFacility();
            boolean isCheckedExtendedHours = ProfileDataCache.getInstance().getExtendedHours();
            boolean isCheckedAccredited = ProfileDataCache.getInstance().getAccredited();
            boolean isCheckedTelemedicine = ProfileDataCache.getInstance().getTelemedicine();
            boolean isCheckedADAAccessibility = ProfileDataCache.getInstance().getADAAccessibility();

            String mUpdateDate = "07/20/2019 ,Provider Directory,It is the patients' responsibility to verify each provider's participation in Community Health Plan of Washington plan prior to seeking care. Healthcare professionals are participating providers only at the locations specified. Out-of-Network Specialist or Tertiary Care (usually a teaching facility/academic medical center) requires a pre-service authorization from your Primary Care Physician. The authorization must be approved by Community Health Plan of Washington plan prior to services being rendered. Please contact Member Services:1-800-440-1561 or CustomerCare@HealthGen.org.,Disclaimer,Working Hours,Updated on,Specialty,Gender,Provider Type,First Name,Last Name,Phone No,Location,Language,Hospital/Medical Affiliations,Monday Hours,Tuesday Hours,Wednesday Hours,Thursday Hours,Friday Hours,Providers self-report their information to HealthGen on the application to join our network and is verified every three years thereafter. Additional updates are made at the providers request.,Hospitals and other healthcare facilities self-report their information when the facility is contracted be HealthGen. HealthGen reviews this information during initial application before the facility is admitted to the network. It is verified at least tri-annually thereafter. Additional updates are made at the facilities request.,Doctors/Medical Professionals,Facility,Behavioral Health,Hospital,Durable Medical Equipment";


            params.put(NetworkConfig.GET_PCP_REQUEST_ZIPCODE, mSearchCityValue);
            params.put(NetworkConfig.GET_PCP_REQUEST_PROVIDER_TYPE, mProviderType);
            params.put(NetworkConfig.GET_PCP_REQUEST_PLAN, "");
            params.put(NetworkConfig.GET_PCP_REQUEST_IS_PRIMARY_CARE, String.valueOf(isCheckedPCP));
            params.put(NetworkConfig.GET_PCP_REQUEST_FIRST_NAME, mProvFirstName);
            params.put(NetworkConfig.GET_PCP_REQUEST_LAST_NAME, mProvLastName);
            params.put(NetworkConfig.GET_PCP_REQUEST_CLINIC_NAME, mSearchClinicItemValue);
            params.put(NetworkConfig.GET_PCP_REQUEST_ORGANIZATION_NAME, mSearchGroupNameValue);
            params.put(NetworkConfig.GET_PCP_REQUEST_GENDER, mProviderGender);
            params.put(NetworkConfig.GET_PCP_REQUEST_SPECIALITY, mSearchSpecialityValue);
            params.put(NetworkConfig.GET_PCP_REQUEST_AREA_OF_EXPERTISE, mSearchExpertiseItemValue);
            params.put(NetworkConfig.GET_PCP_REQUEST_HOSPITAL_AFFILIATION, mSearchHospitalAffiliationValue);
            params.put(NetworkConfig.GET_PCP_REQUEST_LANGUAGE_SPOKEN, mProviderLanguage);
            params.put(NetworkConfig.GET_PCP_REQUEST_DISTANCE, mProviderMiles);
            params.put(NetworkConfig.GET_PCP_REQUEST_ACCEPTING_NEW_PATIENTS, String.valueOf(isCheckedAcceptingNewPatients));

            // Enhancement 12-02-2020
            params.put(NetworkConfig.GET_PCP_REQUEST_IS_BOARDING_CERTIFICATE, String.valueOf(isCheckedBoardCertification));
            params.put(NetworkConfig.GET_PCP_REQUEST_IS_ADA_ACCESSIBILITY, String.valueOf(isCheckedADAAccessibility));
            params.put(NetworkConfig.GET_PCP_REQUEST_IS_TELEMEDICINE, String.valueOf(isCheckedTelemedicine));
            params.put(NetworkConfig.GET_PCP_REQUEST_IS_URGENT_CARE_FACILITY, String.valueOf(isCheckedUrgentCareFacility));
            params.put(NetworkConfig.GET_PCP_REQUEST_IS_EXTENDED_HOURS, String.valueOf(isCheckedExtendedHours));
            params.put(NetworkConfig.GET_PCP_REQUEST_IS_ACCREDITATION, String.valueOf(isCheckedAccredited));


            params.put(NetworkConfig.GET_PCP_REQUEST_FACILITY_NAME, mProvName);
            params.put(NetworkConfig.GET_PCP_REQUEST_CLINICAL_STAFF_LANGUAGE, "");
            params.put(NetworkConfig.GET_PCP_REQUEST_IS_INTERPRETATION_SERVICES, "false");
            params.put(NetworkConfig.GET_PCP_REQUEST_UPDATED_DATE, mUpdateDate);
            params.put(NetworkConfig.GET_PCP_REQUEST_LANGUAGE_KEY, "");
            params.put(NetworkConfig.GET_PCP_REQUEST_BLANK_SEARCH, "true");
            params.put(NetworkConfig.GET_PCP_REQUEST_PAGE_ID, String.valueOf(pageID));
            params.put(NetworkConfig.GET_PCP_REQUEST_PAGE_SIZE, "10");

            if (mSearchCityValue.equalsIgnoreCase("")) {
                params.put(NetworkConfig.GET_PCP_REQUEST_LATITUDE, mLatValue);
                params.put(NetworkConfig.GET_PCP_REQUEST_LONGITUDE, mLongValue);
            } else {
                params.put(NetworkConfig.GET_PCP_REQUEST_LATITUDE, "");
                params.put(NetworkConfig.GET_PCP_REQUEST_LONGITUDE, "");
            }
        }
        return params;
    }
}
