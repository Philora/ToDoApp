package com.wps.memberapp.domain.network;

import android.content.Context;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.NetworkConfig;
import com.wps.memberapp.utility.NetworkConfigValues;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;


public class GetSecureMessageDetailViewRequest extends StringRequest {
    private final Context context;

    public GetSecureMessageDetailViewRequest(int method, String url, final Context context,
                                             Response.Listener<String> listener, Response.ErrorListener errorListener) {
        super(method, url, listener, errorListener);
        this.context = context;
    }

    @Override
    public byte[] getBody() {
        String messageId = ProfileDataCache.getInstance().getMsgID();
        String hashCode = ProfileDataCache.getInstance().getHashCode();
        Map<String, String> params = new HashMap<>();
        params.put(NetworkConfig.REQUEST_TYPE, NetworkConfigValues.MESSAGES);
        params.put(NetworkConfig.REQUEST_SUB_TYPE, NetworkConfigValues.DETAILS);
        params.put(NetworkConfig.EXNTERNAL_ID, "");
        params.put(NetworkConfig.USER_ID, "");
        params.put(NetworkConfig.MPARAM, "");
        params.put(NetworkConfig.USER_TYPE, "");
        params.put(NetworkConfig.PAGE_ID, "");
        params.put(NetworkConfig.REQUEST_PARAMETERS_0_PARAM_NAME, NetworkConfigValues.MESSAGE_ID);
        if(messageId!=null) {
            params.put(NetworkConfig.REQUEST_PARAMETERS_0_PARAM_VALUES, messageId);
        }
        if(hashCode!=null) {
            params.put(NetworkConfig.REQUEST_PARAMETERS_1_PARAM_VALUES, hashCode);
        }
        params.put(NetworkConfig.REQUEST_PARAMETERS_1_PARAM_NAME, NetworkConfigValues.HASH_CODE);
        String str = GeneralUtils.convertToBody(params);
        return str.getBytes();
    }

    @NonNull
    @Override
    public Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<>();

        if (SharedPreferenceHelper.getInstance() != null && SharedPreferenceHelper.getInstance().getPreference(context, "sessionid") != null) {
            String sessionId = SharedPreferenceHelper.getInstance().getPreference(context, "sessionid");
            if (sessionId != null) {
                headers.put(NetworkConfig.COOKIE, sessionId);
            }
            headers.put(NetworkConfig.REFERER, NetworkConfigValues.REFERER_VALUE);
            headers.put(NetworkConfig.USER_AGENT, NetworkConfigValues.USER_AGENT_VALUE);
        }

        return headers;
    }
}
