package com.wps.memberapp.domain.network;

import android.content.Context;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.model.MemberEligibleInfo;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.NetworkConfig;
import com.wps.memberapp.utility.NetworkConfigValues;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;


public class GetSecureMessageProvRequest extends StringRequest {

    private final Context context;

    public GetSecureMessageProvRequest(int method, String url, final Context context,
                                       Response.Listener<String> listener, Response.ErrorListener errorListener) {
        super(method, url, listener, errorListener);
        this.context = context;
    }

    @Override
    public byte[] getBody() {
        String str = "";
        if (ProfileDataCache.getInstance().getMemberEligibleInfo() != null && ProfileDataCache.getInstance().getmMemberDetails().get(0) != null) {
            MemberEligibleInfo info = ProfileDataCache.getInstance().getMemberEligibleInfo();
            MemberDetails details = ProfileDataCache.getInstance().getmMemberDetails().get(0);
            Map<String, String> params = new HashMap<>();
            params.put(NetworkConfig.REQUEST_LOB, info.getLineOfBusiness());
            params.put(NetworkConfig.REQUEST_BUSINESS_UNIT, info.getCurrentRelEntityID());
            params.put(NetworkConfig.REQUEST_TYPE_ACTION, "A");
            if (details != null) {
                params.put(NetworkConfig.REQUEST_SUBSCRIBER_ID, details.getSubscriberID());
                params.put(NetworkConfig.REQUEST_PERSON_NUMBER, details.getPersonNumber());
            }
            str = GeneralUtils.convertToBody(params);
        }
        return str.getBytes();
    }


    @NonNull
    @Override
    public Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<>();

        if (SharedPreferenceHelper.getInstance() != null && SharedPreferenceHelper.getInstance().getPreference(context, "sessionid") != null) {
            String sessionId = SharedPreferenceHelper.getInstance().getPreference(context, "sessionid");
            if (sessionId != null) {
                headers.put(NetworkConfig.COOKIE, sessionId);
            }
            headers.put(NetworkConfig.REFERER, NetworkConfigValues.REFERER_VALUE);
            headers.put(NetworkConfig.USER_AGENT, NetworkConfigValues.USER_AGENT_VALUE);
        }
        return headers;
    }
}
