package com.wps.memberapp.domain.network;

import android.content.Context;
import android.util.Log;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.NetworkConfig;
import com.wps.memberapp.utility.NetworkConfigValues;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;


public class GetSecureMessageSearchRequest extends StringRequest {

    private final Context context;

    public GetSecureMessageSearchRequest(int method, String url, final Context context,
                                         Response.Listener<String> listener, Response.ErrorListener errorListener) {
        super(method, url, listener, errorListener);
        this.context = context;
    }

    @Override
    public byte[] getBody() {
        Map<String, String> params = new HashMap<>();
        if (ProfileDataCache.getInstance().getSecureMessagesSearchData()!=null) {
            String[] data = ProfileDataCache.getInstance().getSecureMessagesSearchData();

            params.put(NetworkConfig.REQUEST_TYPE, NetworkConfigValues.MESSAGES);
            params.put(NetworkConfig.REQUEST_SUB_TYPE, NetworkConfigValues.LIST);
            params.put(NetworkConfig.EXNTERNAL_ID, "");
            params.put(NetworkConfig.USER_ID, "");
            params.put(NetworkConfig.MPARAM, "");
            params.put(NetworkConfig.USER_TYPE, "");
            params.put(NetworkConfig.PAGE_ID, "");
            params.put(NetworkConfig.REQUEST_PARAMETERS_0_PARAM_NAME, NetworkConfigValues.REF_NUMBER);
            params.put(NetworkConfig.REQUEST_PARAMETERS_0_PARAM_VALUES, data[2] != null ? data[2] : "");
            params.put(NetworkConfig.REQUEST_PARAMETERS_1_PARAM_NAME, NetworkConfigValues.SUBJECT);
            params.put(NetworkConfig.REQUEST_PARAMETERS_1_PARAM_VALUES, data[0] != null ? data[0] : "");
            params.put(NetworkConfig.REQUEST_PARAMETERS_2_PARAM_NAME, NetworkConfigValues.AS_OF);
            params.put(NetworkConfig.REQUEST_PARAMETERS_2_PARAM_VALUES, data[3] != null ? data[3] : "");
            params.put(NetworkConfig.REQUEST_PARAMETERS_3_PARAM_NAME, NetworkConfigValues.STATUS);
            params.put(NetworkConfig.REQUEST_PARAMETERS_3_PARAM_VALUES, data[1] != null ? data[1] : "");
            // Added Message type after PCP/TCC
            params.put(NetworkConfig.REQUEST_PARAMETERS_4_PARAM_NAME, NetworkConfigValues.TYPE);
            params.put(NetworkConfig.REQUEST_PARAMETERS_4_PARAM_VALUES, data[4] != null ? data[4] : "");
        }

        String str = GeneralUtils.convertToBody(params);
        Log.i("Request",str);
        return str.getBytes();
    }

    @NonNull
    @Override
    public Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<>();

        if (SharedPreferenceHelper.getInstance() != null && SharedPreferenceHelper.getInstance().getPreference(context, "sessionid") != null) {
            String sessionId = SharedPreferenceHelper.getInstance().getPreference(context, "sessionid");
            if (sessionId != null) {
                headers.put(NetworkConfig.COOKIE, sessionId);
            }
            headers.put(NetworkConfig.REFERER, NetworkConfigValues.REFERER_VALUE);
            headers.put(NetworkConfig.USER_AGENT, NetworkConfigValues.USER_AGENT_VALUE);
        }
        return headers;
    }
}
