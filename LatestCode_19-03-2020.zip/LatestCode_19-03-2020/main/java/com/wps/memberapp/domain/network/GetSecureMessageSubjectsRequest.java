package com.wps.memberapp.domain.network;

import android.content.Context;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MemberEligibleInfo;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.NetworkConfig;
import com.wps.memberapp.utility.NetworkConfigValues;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;


public class GetSecureMessageSubjectsRequest extends StringRequest {

    private final Context context;

    public GetSecureMessageSubjectsRequest(int method, String url, final Context context, Response.Listener<String> listener,
                                           Response.ErrorListener errorListener) {
        super(method, url, listener, errorListener);
        this.context = context;
    }

    @NonNull
    @Override
    public Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<>();

        if (SharedPreferenceHelper.getInstance() != null && SharedPreferenceHelper.getInstance().getPreference(context, "sessionid") != null) {
            String sessionId = SharedPreferenceHelper.getInstance().getPreference(context, "sessionid");
            if (sessionId != null) {
                headers.put(NetworkConfig.COOKIE, sessionId);
            }
            headers.put(NetworkConfig.REFERER, NetworkConfigValues.REFERER_VALUE);
            headers.put(NetworkConfig.USER_AGENT, NetworkConfigValues.USER_AGENT_VALUE);
        }
        return headers;
    }

    @NonNull
    @Override
    protected Map<String, String> getParams() {
        MemberEligibleInfo info = ProfileDataCache.getInstance().getMemberEligibleInfo();
        Map<String, String> params = new HashMap<>();
        if (info != null) {
            params.put(NetworkConfig.REQUEST_LOB, info.getLineOfBusiness());
            params.put(NetworkConfig.REQUEST_BUSINESS_UNIT, info.getCurrentRelEntityID());
        }
        return params;
    }
}
