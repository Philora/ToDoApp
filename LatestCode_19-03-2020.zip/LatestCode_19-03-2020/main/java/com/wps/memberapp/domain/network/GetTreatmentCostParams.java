package com.wps.memberapp.domain.network;

import android.content.Context;
import android.util.Log;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.GetProcedureCode;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.NetworkConfig;
import com.wps.memberapp.utility.NetworkConfigValues;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;

public class GetTreatmentCostParams extends StringRequest {
    private final Context context;

    public GetTreatmentCostParams(int method, String url, final Context context,
                                  Response.Listener<String> listener, Response.ErrorListener errorListener) {
        super(method, url, listener, errorListener);
        this.context = context;
    }

    @NonNull
    @Override
    public Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<>();

        if (SharedPreferenceHelper.getInstance() != null && SharedPreferenceHelper.getInstance().getPreference(context, "sessionid") != null) {
            String sessionId = SharedPreferenceHelper.getInstance().getPreference(context, "sessionid");
            if (sessionId != null) {
                headers.put(NetworkConfig.COOKIE, sessionId);
            }
            headers.put(NetworkConfig.REFERER, NetworkConfigValues.REFERER_VALUE);
            headers.put(NetworkConfig.USER_AGENT, NetworkConfigValues.USER_AGENT_VALUE);
        }
        return headers;
    }

    @Override
    public byte[] getBody() {
        String mProcCode = ProfileDataCache.getInstance().getProcCode();
        String mStrength = ProfileDataCache.getInstance().getStrength();
        String mLatValue = ProfileDataCache.getInstance().getGeoLat();
        String mLongValue = ProfileDataCache.getInstance().getGeoLong();
        String mTccMiles = ProfileDataCache.getInstance().getTccMiles();
        String mSelectedPlan = ProfileDataCache.getInstance().getSelectedPlan();
        String str = "";
        Map<String, String> params = new HashMap<>();


        if (ProfileDataCache.getInstance().getmMemberDetails() != null) {
            if (mSelectedPlan.equalsIgnoreCase("Pharmacy")) {
                if (mProcCode!=null) {
                    mProcCode=mProcCode.toLowerCase();
                    params.put("getTCCRequest[ProcedureCode]", mProcCode);
                    params.put("getTCCRequest[Strength]", mStrength);
                    params.put("getTCCRequest[SelectedPlan]", mSelectedPlan);
                    params.put("getTCCRequest[newRequest]", "true");
                    params.put("getTCCRequest[PageNumber]", "1");
                    params.put("getTCCRequest[PageSize]", "10");
                    params.put("getTCCRequest[columnSelectedForSort]", "Distance");
                    params.put("getTCCRequest[ascendingFlag]", "true");
                }
            }
            if (mSelectedPlan.equalsIgnoreCase("Medical") || mSelectedPlan.equalsIgnoreCase("Dental")) {
                if (mProcCode!=null) {
                    params.put("getTCCRequest[ProcedureCode]", mProcCode);
                }
                MemberDetails details = ProfileDataCache.getInstance().getmMemberDetails().get(0);
                params.put("getTCCRequest[Address]", "");
                params.put("getTCCRequest[City]", "");
                params.put("getTCCRequest[PhoneNumber]", "");
                if (details != null) {
                    for (int i = 0; i < details.getAddressList().size(); i++) {
                        if (details.getAddressList().get(i).getAddressType().equalsIgnoreCase("R1")) {
                            params.put("getTCCRequest[ZipCode]", details.getAddressList().get(i).getZipCode());
                        }
                    }
                    params.put("getTCCRequest[Age]", details.getAGE());
                    params.put("getTCCRequest[Gender]", details.getGender());
                }
                params.put("getTCCRequest[Latitude]", mLatValue);
                params.put("getTCCRequest[Longitude]", mLongValue);
                params.put("getTCCRequest[Distance]", mTccMiles);
                params.put("getTCCRequest[PageNumber]", "1");
                params.put("getTCCRequest[PageSize]", "10");
                params.put("getTCCRequest[newRequest]", "true");
                params.put("getTCCRequest[columnSelectedForSort]", "Distance");
                params.put("getTCCRequest[ascendingFlag]", "true");

            }
            str = GeneralUtils.convertToBody(params);
            Log.i("Secure Message body", str);
        }
        return str.getBytes();
    }
}
