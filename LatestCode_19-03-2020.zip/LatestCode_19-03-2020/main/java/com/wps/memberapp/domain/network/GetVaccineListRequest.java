package com.wps.memberapp.domain.network;

import android.content.Context;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;

import java.util.HashMap;
import java.util.Map;


public class GetVaccineListRequest extends StringRequest {

    private final Context context;
    public GetVaccineListRequest(int method, String url, Context context, Response.Listener<String> listener,
                                 Response.ErrorListener errorListener) {
        super(method, url, listener, errorListener);
        this.context = context;
    }

    @Override
    public Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<>();

            if(SharedPreferenceHelper.getInstance()!=null && SharedPreferenceHelper.getInstance().getPreference(context,"sessionid")!= null)
            {
                String sessionId = SharedPreferenceHelper.getInstance().getPreference(context,"sessionid");
                if(sessionId!=null){
                    headers.put("Cookie",sessionId);
                }
            }

        return headers;
    }
}
