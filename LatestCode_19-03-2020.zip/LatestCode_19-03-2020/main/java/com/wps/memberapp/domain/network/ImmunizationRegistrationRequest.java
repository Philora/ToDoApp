package com.wps.memberapp.domain.network;

import android.content.Context;
import android.util.Log;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This class is used to register the immunization for particular user
 */

public class ImmunizationRegistrationRequest extends StringRequest {
    private final Context context;
    private String mRequestBody;

    public ImmunizationRegistrationRequest(int method, String url, final Context context,
                                           Response.Listener<String> listener, Response.ErrorListener errorListener) {
        super(method, url, listener, errorListener);
        this.context = context;
    }

    @Override
    public Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<>();

        if (SharedPreferenceHelper.getInstance() != null && SharedPreferenceHelper.getInstance().getPreference(context, "sessionid") != null) {
            String sessionId = SharedPreferenceHelper.getInstance().getPreference(context, "sessionid");
            if (sessionId != null) {
                headers.put("Cookie", sessionId);
            }
        }

        return headers;
    }

    @Override
    public String getBodyContentType() {
        return "application/json";
    }

    @Override
    public byte[] getBody() {
        JSONArray memberIDValue = new JSONArray();
        JSONArray firstNameValue = new JSONArray();
        JSONArray lastNameValue = new JSONArray();
        List<String> idsList = ProfileDataCache.getInstance().getIdsList();
        List<MemberDetails> details = ProfileDataCache.getInstance().getmMemberDetails();
        String id = GeneralUtils.getCurrentMemberID();
        for (int i = 0; i < idsList.size(); i++) {
            memberIDValue.put(id + idsList.get(i));
        }
        if (details != null) {
            for (int i = 0; i < details.size(); i++) {
                MemberDetails data = details.get(i);
                for (int j = 0; j < idsList.size(); j++) {
                    if (data.getPersonNumber().equalsIgnoreCase(idsList.get(j))) {
                        firstNameValue.put(data.getFirstName());
                        lastNameValue.put(data.getLastName());
                    }
                }
            }
            boolean appointFlag = SharedPreferenceHelper.getInstance().getPrefBoolean(context, "APPOINTMENT_FLAG", false);
            boolean remindFlag = SharedPreferenceHelper.getInstance().getPrefBoolean(context, "REMINDER_FLAG", false);
            try {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("MEMBER_ID", details.get(0).getfMSSeqMemberId());
                jsonObject.put("DEVICE_ID", GeneralUtils.getDeviceId(context));
                jsonObject.put("MEMBER_FIRST_NAME", firstNameValue);
                jsonObject.put("MEMBER_LAST_NAME", lastNameValue);
                jsonObject.put("DEPENDEND_MEMBER_ID", memberIDValue);
                jsonObject.put("NOTIFICATION_FLAG", true);
                jsonObject.put("REMINDER_FLAG", remindFlag);
                jsonObject.put("APPOINTMENT_FLAG", appointFlag);
                mRequestBody = jsonObject.toString();
                Log.e("Request is ", mRequestBody);
            } catch (JSONException e) {
                Logger.e("ex", e);
            }
        }
        return mRequestBody.getBytes();
    }
}