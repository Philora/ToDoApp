package com.wps.memberapp.domain.network;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;

import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.domain.listener.LoginCallback;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.StringConstants;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.lang.ref.WeakReference;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

import androidx.appcompat.app.AppCompatActivity;

class FetchGoalsRequest extends AsyncTask<Void, Void, String[]> {

    private final WeakReference<Activity> weakActivity;
    private LoginCallback callback;

    public FetchGoalsRequest(AppCompatActivity myActivity, LoginCallback callback) {
        this.weakActivity = new WeakReference<>(myActivity);
        this.callback = callback;
    }

    @Override
    protected String[] doInBackground(Void... voids) {
        String[] result = new String[2];
        try {
            Activity activity = weakActivity.get();
            HttpsURLConnection httpClient = (HttpsURLConnection) new URL(AppConstants.LOGIN_STC_TOKEN).openConnection();
            httpClient.setRequestMethod("POST");
            String urlParameters = GeneralUtils.getRealmString(StringConstants.DOMAIN_NAME, activity.getApplicationContext());
            httpClient.setDoOutput(true);
            try (DataOutputStream wr = new DataOutputStream(httpClient.getOutputStream())) {
                wr.writeBytes(urlParameters);
                wr.flush();
            }
            int responseCode = httpClient.getResponseCode();
            String responseMessage = httpClient.getResponseMessage();
            result[0] = "" + responseCode;
            result[1] = responseMessage;
            if (responseCode == HttpsURLConnection.HTTP_OK) {
                StringBuilder response;
                try (BufferedReader in = new BufferedReader(
                        new InputStreamReader(httpClient.getInputStream()))) {
                    String line;
                    response = new StringBuilder();
                    while ((line = in.readLine()) != null) {
                        response.append(line);
                    }
                    //print result
                    System.out.println(response.toString());
                }
                SharedPreferenceHelper.getInstance().setPreference
                        (activity.getApplicationContext(), AppConstants.AUTHORIZATION_TOKEN, response.toString());
                result[1] = response.toString();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    protected void onPostExecute(String[] result) {
        int responseCode = Integer.parseInt(result[0]);
        if (responseCode == HttpsURLConnection.HTTP_OK) {
            callback.onResponse(result[1]);
        } else {
            callback.onError(responseCode, result[1]);
        }
    }
}
