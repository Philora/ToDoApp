package com.wps.memberapp.domain.network;

import android.content.Context;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.NetworkConfig;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;

/*
This class is used to send a network request for login.
 */
public class LogInRequest extends StringRequest {

    private final Context mContext;

    protected LogInRequest(String url, final Context mContext, Response.Listener<String> listener, Response.ErrorListener errorListener) {
        super(Request.Method.POST, url, listener, errorListener);
        this.mContext = mContext;
    }

    @Override
    public String getBodyContentType() {
        return NetworkConfig.CONTENT_TYPE_FORM_URLENCODED_UTF;
    }

    @Override
    public Map<String, String> getHeaders() throws AuthFailureError {

        Map<String, String> headers = super.getHeaders();
        if (headers == null || headers.equals(Collections.emptyMap())) {
            headers = new HashMap<>();
        }
        headers.put(NetworkConfig.REFERRER, AppConstants.FED_AUTH_REFERRER);
        return headers;

    }

    @NonNull
    @Override
    protected Map<String, String> getParams() {
        Map<String, String> params = new HashMap<>();
        if (SharedPreferenceHelper.getInstance() != null) {
            String mPrefAuthorizationToken = SharedPreferenceHelper.getInstance().getPreference
                    (mContext, AppConstants.AUTHORIZATION_TOKEN);
            if(mPrefAuthorizationToken!=null) {
                params.put(NetworkConfig.WRESULT, mPrefAuthorizationToken);
            }
        }
        params.put(NetworkConfig.WA, "wsignin1.0");
        return params;
    }
}
