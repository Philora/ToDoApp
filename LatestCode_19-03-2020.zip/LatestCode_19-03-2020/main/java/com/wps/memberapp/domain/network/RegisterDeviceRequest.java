package com.wps.memberapp.domain.network;

import android.content.Context;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


public class RegisterDeviceRequest extends StringRequest {
    private final Context context;
    private String mRequestBody;

    public RegisterDeviceRequest(int method, String url, final Context context,
                                 Response.Listener<String> listener, Response.ErrorListener errorListener)
    {
        super(method, url, listener, errorListener);
        this.context = context;
    }

    @Override
    public Map<String, String> getHeaders()
    {
        Map<String, String> headers = new HashMap<>();
        String sessionId = SharedPreferenceHelper.getInstance().getPreference(context,"sessionid");
        headers.put("Cookie",sessionId);
        headers.put("Content_Type","application/x-www-form-urlencoded");
        return headers;
    }

    @Override
    public String getBodyContentType()
    {
        return "application/json";
    }

    @Override
    public byte[] getBody()
    {
        try {
            String memberID=GeneralUtils.getCurrentMemberID();
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("MEMBER_ID", memberID);
            jsonObject.put("DEVICE_ID", GeneralUtils.getDeviceId(context));
            jsonObject.put("FIRST_NAME", ProfileDataCache.getInstance().getFirstName());
            jsonObject.put("LAST_NAME",ProfileDataCache.getInstance().getLastName());
            mRequestBody = jsonObject.toString();

        } catch (JSONException e) {
            Logger.e("Ex",e);
        }
        return mRequestBody.getBytes();
    }

}
