package com.wps.memberapp.domain.network;

import android.content.Context;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MemberEligibleInfo;
import com.wps.memberapp.data.model.MessageData;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.NetworkConfig;
import com.wps.memberapp.utility.NetworkConfigValues;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;

public class SendReplyRequest extends StringRequest {
    private final Context context;

    public SendReplyRequest(int method, String url, final Context context,
                            Response.Listener<String> listener, Response.ErrorListener errorListener) {
        super(method, url, listener, errorListener);
        this.context = context;
    }

    @Override
    public byte[] getBody() {
        MessageData data = ProfileDataCache.getInstance().getMessageData();
        MemberEligibleInfo info = ProfileDataCache.getInstance().getMemberEligibleInfo();

        Map<String, String> params = new HashMap<>();
        params.put(NetworkConfig.REQUEST_TYPE, NetworkConfigValues.MESSAGES);
        params.put(NetworkConfig.REQUEST_SUB_TYPE, NetworkConfigValues.REPLY);
        if (data != null) {
            params.put(NetworkConfig.UPDATE_PARAMETERS_0_PARAM_NAME, NetworkConfigValues.MESSID);
            params.put(NetworkConfig.UPDATE_PARAMETERS_0_PARAM_VALUE, data.getSubject());
            params.put(NetworkConfig.UPDATE_PARAMETERS_1_PARAM_NAME, NetworkConfigValues.REPLY_TEXT);
            params.put(NetworkConfig.UPDATE_PARAMETERS_1_PARAM_VALUE, data.getMessage());
        }
        params.put(NetworkConfig.UPDATE_PARAMETERS_2_PARAM_NAME, NetworkConfigValues.UPLOADED_FILE_NAME);
        params.put(NetworkConfig.UPDATE_PARAMETERS_2_PARAM_VALUE, "");
        params.put(NetworkConfig.UPDATE_PARAMETERS_3_PARAM_NAME, NetworkConfigValues.GENERATED_FILE_NAME);
        params.put(NetworkConfig.UPDATE_PARAMETERS_3_PARAM_VALUE, "");
        params.put(NetworkConfig.UPDATE_PARAMETERS_4_PARAM_NAME, NetworkConfigValues.CURRENT_REL_ENTY_ID);
        if (info != null) {
            params.put(NetworkConfig.UPDATE_PARAMETERS_4_PARAM_VALUE, info.getCurrentRelEntityID());
        }

        // Optional only
        params.put(NetworkConfig.UPDATE_PARAMETERS_5_PARAM_NAME, NetworkConfigValues.STATUS);
        params.put(NetworkConfig.UPDATE_PARAMETERS_5_PARAM_VALUE, NetworkConfigValues.ONE); // Pradeep said if you opening / replying the message - The Status should be "1"
        String str = GeneralUtils.convertToBody(params);
        return str.getBytes();
    }

    @NonNull
    @Override
    public Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<>();
        String sessionId = SharedPreferenceHelper.getInstance().getPreference(context, "sessionid");
        if (sessionId != null) {
            headers.put(NetworkConfig.COOKIE, sessionId);
        }
        headers.put(NetworkConfig.REFERER, NetworkConfigValues.REFERER_VALUE);
        headers.put(NetworkConfig.USER_AGENT, NetworkConfigValues.USER_AGENT_VALUE);
        return headers;
    }
}
