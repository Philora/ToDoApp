package com.wps.memberapp.domain.network;

import android.content.Context;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.NetworkConfig;
import com.wps.memberapp.utility.StringConstants;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;

/*
This class is used to send a network request to get the token.
 */
public class TokenRequest extends StringRequest {

    private final Context context;

    /**
     * Creates a new request with the given method.
     *
     * @param url           URL to fetch the string at
     * @param listener      Listener to receive the String response
     * @param errorListener Error listener, or null to ignore errors
     */
    protected TokenRequest( String url, Response.Listener<String> listener, Response.ErrorListener errorListener, Context context) {
        super(Request.Method.POST, url, listener, errorListener);
        this.context = context;
    }

    @NonNull
    @Override
    public Map<String, String> getHeaders() {
        return new HashMap<>();
    }

    @Override
    public byte[] getBody() {
        String str = GeneralUtils.getRealmString(StringConstants.DOMAIN_NAME, context);
        return str.getBytes();
    }

    @Override
    public String getBodyContentType() {
        return NetworkConfig.CONTENT_TYPE_FORM_URLENCODED_UTF;
    }

}