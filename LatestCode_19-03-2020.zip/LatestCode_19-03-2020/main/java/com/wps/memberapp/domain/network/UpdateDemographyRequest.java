package com.wps.memberapp.domain.network;

import android.content.Context;
import android.util.Log;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.DemographyData;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.NetworkConfig;
import com.wps.memberapp.utility.NetworkConfigValues;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import androidx.annotation.NonNull;

/*
This class is used to send a network request to get member details
based on the subscriber ID.
 */
public class UpdateDemographyRequest extends StringRequest {

    private final Context mContext;

    public UpdateDemographyRequest(int method, String url, final Context mContext, Response.Listener<String> listener, Response.ErrorListener errorListener) {
        super(method, url, listener, errorListener);
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<>();
        if (SharedPreferenceHelper.getInstance() != null && SharedPreferenceHelper.getInstance().getPreference(mContext, "sessionid") != null) {
            String sessionId = SharedPreferenceHelper.getInstance().getPreference(mContext, "sessionid");
            if (sessionId != null) {
                headers.put(NetworkConfig.COOKIE, sessionId);
                headers.put(NetworkConfig.CONTENT_TYPE, NetworkConfig.CONTENT_TYPE_FORM_URLENCODED);
            }
            headers.put(NetworkConfig.REFERER, NetworkConfigValues.REFERER_VALUE);
            headers.put(NetworkConfig.USER_AGENT, NetworkConfigValues.USER_AGENT_VALUE);
        }
        return headers;
    }

    @NonNull
    @Override
    protected Map<String, String> getParams() {
        Map<String, String> params = new HashMap<>();
        if (ProfileDataCache.getInstance().getmMemberDetails() != null) {
            MemberDetails details = ProfileDataCache.getInstance().getmMemberDetails().get(0);
            DemographyData data = ProfileDataCache.getInstance().getDemographyData();
            if (data != null && details != null) {
                Log.i("Phone", details.getPhoneNumber() + data.getFirstName() + data.getLastName());
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_FIRSTNAME, data.getFirstName());
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_MIDDLENAME, "");
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_LASTNAME, data.getLastName());
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_DOB, data.getDateOfBirth());
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_GENDER, data.getGender());
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_PHONE, data.getPhone());
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_ADDRESSES_0_ADDRESS1, data.getAddress1());
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_ADDRESSES_0_ADDRESS2, "");
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_ADDRESSES_0_CITY, data.getCity());
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_ADDRESSES_0_STATE, data.getState());
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_ADDRESSES_0_COUNTY, data.getCounty());
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_ADDRESSES_0_ZIPCODE, data.getZipCode());
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_ADDRESSES_0_HOMEPHONE, details.getPhoneNumber());
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_ADDRESSES_0_ADRESSTYPE, "R1");
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_ADDRESSES_1_ADDRESS1, data.getAddress1());
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_ADDRESSES_1_ADDRESS2, "");
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_ADDRESSES_1_CITY, data.getCity());
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_ADDRESSES_1_STATE, data.getState());
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_ADDRESSES_1_COUNTY, data.getCounty());
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_ADDRESSES_1_ZIPCODE, data.getZipCode());
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_ADDRESSES_1_HOMEPHONE, details.getPhoneNumber());
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_ADDRESSES_1_ADRESSTYPE, "M");
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_SUBID, details.getSubscriberID());
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_GROUPID, details.getGroupId());
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_PERSONNO, details.getPersonNumber());
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_PLANTYPE, "");
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_PRODUCT_CODE, data.getProductCode());
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_RELATIONSHIP_CODE, details.getRelationshipCode());
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_PLANNAME, details.getPlanName());
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_EXTERNAL_KEY3, "");
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_COVERAGE_STARTDATE, details.getCoverageDate());
                // Code changes - During My Benefits Part
                String date = details.getTermDate();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                Date testDate = null;
                try {
                    testDate = sdf.parse(date);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault());
                String newFormat = formatter.format(testDate);
                params.put(NetworkConfig.UPDATED_MEMBER_INFO_COVERAGE_ENDDATE, newFormat);
            }
        }
        return params;
    }
}
