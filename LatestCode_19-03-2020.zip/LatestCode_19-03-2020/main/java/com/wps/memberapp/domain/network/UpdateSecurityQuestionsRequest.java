package com.wps.memberapp.domain.network;

import android.content.Context;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.NetworkConfig;
import com.wps.memberapp.utility.NetworkConfigValues;
import com.wps.memberapp.utility.StringConstants;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;

/*
This class is used to send a network request to get profile details.
 */
public class UpdateSecurityQuestionsRequest extends StringRequest {
    private final Context mContext;

    public UpdateSecurityQuestionsRequest(int method, String url, final Context mContext, Response.Listener<String> listener, Response.ErrorListener errorListener) {
        super(method, url, listener, errorListener);
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<>();
        if (SharedPreferenceHelper.getInstance() != null && SharedPreferenceHelper.getInstance().getPreference(mContext, "sessionid") != null) {
            String sessionId = SharedPreferenceHelper.getInstance().getPreference(mContext, "sessionid");
            if (sessionId != null) {
                headers.put(NetworkConfig.COOKIE, sessionId);
            }
            headers.put(NetworkConfig.REFERER, NetworkConfigValues.REFERER_VALUE);
            headers.put(NetworkConfig.USER_AGENT, NetworkConfigValues.USER_AGENT_VALUE);
        }
        return headers;
    }

    @NonNull
    @Override
    protected Map<String, String> getParams() {
        String param2 = SharedPreferenceHelper.getInstance().getPreference(mContext, StringConstants.PARAM2);
        String questionList = ProfileDataCache.getInstance().getQuestionList();
        String ansList = ProfileDataCache.getInstance().getAnswerList();

        Map<String, String> params = new HashMap<>();
        if (param2 != null) {
            params.put(NetworkConfig.EMAIL_ID, param2);
        }
        if (questionList != null) {
            params.put(NetworkConfig.QUESTION_LIST, questionList);
        }
        if (ansList != null) {
            params.put(NetworkConfig.ANSWER_LIST, ansList);
        }

        return params;
    }
}
