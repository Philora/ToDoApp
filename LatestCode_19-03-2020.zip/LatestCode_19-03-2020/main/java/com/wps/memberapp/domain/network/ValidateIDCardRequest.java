package com.wps.memberapp.domain.network;

import android.content.Context;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.NetworkConfig;
import com.wps.memberapp.utility.NetworkConfigValues;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;

/*
This class is used to send a network request to validate
new ID card request.
 */
public class ValidateIDCardRequest extends StringRequest {
    private final Context mContext;

    public ValidateIDCardRequest(int method, String url, final Context mContext, Response.Listener<String> listener,
                                 Response.ErrorListener errorListener) {
        super(method, url, listener, errorListener);
        this.mContext = mContext;
    }

    @Override
    public byte[] getBody() {
        /*int idCardPosition = ProfileDataCache.getInstance().getIdCardPosition();
        MemberDetails details = ProfileDataCache.getInstance().getmMemberDetails().get(idCardPosition);
        Map<String, String> params = new HashMap<>();
        params.put(NetworkConfig.SUBSCRIBER_ID, GeneralUtils.getBase64String(details.getSubscriberID()));
        params.put(NetworkConfig.PERSON_NUMBER, GeneralUtils.getBase64String(details.getPersonNumber()));
        params.put(NetworkConfig.GROUP_ID, GeneralUtils.getBase64String(details.getGroupId()));
        params.put(NetworkConfig.SID, details.getHashCode());
        String str = GeneralUtils.convertToBody(params);
        return str.getBytes();*/
        Map<String, String> params = new HashMap<>();
        int idCardPosition = ProfileDataCache.getInstance().getIdCardPosition();
        if (ProfileDataCache.getInstance().getmMemberDetails() != null) {
            MemberDetails details = ProfileDataCache.getInstance().getmMemberDetails().get(idCardPosition);
            if (details != null) {
                String SubscriberID = GeneralUtils.getBase64String(details.getSubscriberID());
                String PersonNumber = GeneralUtils.getBase64String(details.getPersonNumber());
                String GroupId = GeneralUtils.getBase64String(details.getGroupId());
                SubscriberID = SubscriberID.replace("\n", "");
                PersonNumber = PersonNumber.replace("\n", "");
                GroupId = GroupId.replace("\n", "");
                params.put(NetworkConfig.SUBSCRIBER_ID, SubscriberID);
                params.put(NetworkConfig.PERSON_NUMBER, PersonNumber);
                params.put(NetworkConfig.GROUP_ID, GroupId);
                params.put(NetworkConfig.SID, details.getHashCode());
            }
        }
        String str = GeneralUtils.convertToBody(params);
        return str.getBytes();
    }

    @NonNull
    @Override
    public Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<>();

        if (SharedPreferenceHelper.getInstance() != null && SharedPreferenceHelper.getInstance().getPreference(mContext, "sessionid") != null) {
            String sessionId = SharedPreferenceHelper.getInstance().getPreference(mContext, "sessionid");
            if (sessionId != null) {
                headers.put(NetworkConfig.COOKIE, sessionId);
            }
            headers.put(NetworkConfig.REFERER, NetworkConfigValues.REFERER_VALUE);
            headers.put(NetworkConfig.USER_AGENT, NetworkConfigValues.USER_AGENT_VALUE);
        }
        return headers;
    }
}


