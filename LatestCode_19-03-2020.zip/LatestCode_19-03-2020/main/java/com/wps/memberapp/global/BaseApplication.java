package com.wps.memberapp.global;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Bundle;

import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.domain.fitbitauth.authentication.AuthenticationConfiguration;
import com.wps.memberapp.domain.fitbitauth.authentication.AuthenticationConfigurationBuilder;
import com.wps.memberapp.domain.fitbitauth.authentication.AuthenticationManager;
import com.wps.memberapp.domain.fitbitauth.authentication.ClientCredentials;
import com.wps.memberapp.domain.fitbitauth.authentication.Scope;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.LocaleHelper;
import androidx.multidex.MultiDex;
import androidx.multidex.MultiDexApplication;

/*
This class is a custom Application class with multi dex support.
 */
public class BaseApplication extends MultiDexApplication {
	

	/**
     * These client credentials come from creating an app on https://dev.fitbit.com.
     * <p>
     * To use with your own app, register as a developer at https://dev.fitbit.com, create an application,
     * set the "OAuth 2.0 Application Type" to "Client", enter a word for the redirect url as a url
     * (like `https://finished` or `https://done` or `https://completed`, etc.), and save.
     * <p>
     */

    //!! THIS SHOULD BE IN AN ANDROID KEYSTORE!! See https://developer.android.com/training/articles/keystore.html
    private static final String CLIENT_SECRET = "390992650657893fd74f76fa59467b12";

    /**
     * This key was generated using the SecureKeyGenerator [java] class. Run as a Java application (not Android)
     * This key is used to encrypt the authentication token in Android user preferences. If someone decompiles
     * your application they'll have access to this key, and access to your user's authentication token
     */
    //!! THIS SHOULD BE IN AN ANDROID KEYSTORE!! See https://developer.android.com/training/articles/keystore.html
    private static final String SECURE_KEY = "CVPdQNAT6fBI4rrPLEn9x0+UV84DoqLFiNHpKOPLRW0=";

    /**
     * This method sets up the authentication config needed for
     * successfully connecting to the Fitbit API. Here we include our client credentials,
     * requested scopes, and  where to return after login
     */
	  public static AuthenticationConfiguration generateAuthenticationConfiguration(Context context, Class<? extends Activity> mainActivityClass) {

        try {
            ApplicationInfo ai = context.getPackageManager().getApplicationInfo(context.getPackageName(), PackageManager.GET_META_DATA);
            Bundle bundle = ai.metaData;

            // Load clientId and redirectUrl from application manifest
            String clientId = bundle.getString("com.wps.memberapp.CLIENT_ID");
            String redirectUrl = bundle.getString("com.wps.app.REDIRECT_URL");

            ClientCredentials CLIENT_CREDENTIALS = new ClientCredentials(clientId, CLIENT_SECRET, redirectUrl);

            return new AuthenticationConfigurationBuilder()

                    .setClientCredentials(CLIENT_CREDENTIALS)
                    .setEncryptionKey(SECURE_KEY)
                    .setTokenExpiresIn(31536000L) // 1 days
                    .setBeforeLoginActivity(new Intent(context, mainActivityClass))
                    .addRequiredScopes(Scope.profile, Scope.settings)
                    .addOptionalScopes(Scope.activity, Scope.weight)
                    .addOptionalScopes(Scope.heartrate, Scope.sleep)
                    .setLogoutOnAuthFailure(true)

                    .build();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void attachBaseContext(Context base) {
        String lang = SharedPreferenceHelper.getInstance().getPreference(base, "Language");
//        super.attachBaseContext(LocaleHelper.onAttach(base, lang));
//        super.attachBaseContext(LocaleHelper.onAttach(base, "en"));
        if("es".equalsIgnoreCase(lang)){
            base = LocaleHelper.setLocale(base, "es");
            super.attachBaseContext(base);
        } else {
            base = LocaleHelper.setLocale(base, "en");
            super.attachBaseContext(base);
        }
        MultiDex.install(this);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        AuthenticationManager.configure(this, generateAuthenticationConfiguration(this, RootActivity.class));
        MultiDex.install(this);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        GeneralUtils.setLanguage(this);
    }
}
