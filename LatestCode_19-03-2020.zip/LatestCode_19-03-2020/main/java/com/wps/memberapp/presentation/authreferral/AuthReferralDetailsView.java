package com.wps.memberapp.presentation.authreferral;

import com.wps.memberapp.data.model.AuthDetailView;
import com.wps.memberapp.presentation.base.MvpView;

/**
 * This interface contain UI functions of AuthReferralDetailsScreen
 */
public interface AuthReferralDetailsView extends MvpView {
    void onDetailsLoadingCompleted(AuthDetailView authViewModel);
}
