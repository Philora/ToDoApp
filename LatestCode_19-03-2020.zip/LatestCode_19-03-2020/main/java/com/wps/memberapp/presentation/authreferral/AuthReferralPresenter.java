package com.wps.memberapp.presentation.authreferral;


import com.wps.memberapp.presentation.base.MvpPresenter;

/**
 * This interface contain all the AuthReferral functionality declarations.
 */
public interface AuthReferralPresenter extends MvpPresenter {
    void getAuthReferralDetails();
    void getAuthReferralDetailView();
}
