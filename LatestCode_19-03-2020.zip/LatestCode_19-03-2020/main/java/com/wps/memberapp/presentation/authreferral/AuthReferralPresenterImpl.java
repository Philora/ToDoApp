package com.wps.memberapp.presentation.authreferral;

import android.util.Log;

import com.google.gson.Gson;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.AuthDetailView;
import com.wps.memberapp.data.model.AuthReferral;
import com.wps.memberapp.data.model.AuthorizationModel;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.base.MvpView;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.StringConstants;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used to implement all the AuthReferral functions which
 * are declared in AuthReferralPresenter.
 */
public class AuthReferralPresenterImpl implements AuthReferralPresenter {
    private MvpView mView;

    /*
    This method is used to getting authorization referral list of the user
     */
    @Override
    public void getAuthReferralDetails() {
        final List<AuthReferral> authViewList = new ArrayList<>();
        VolleyService.getAuthorizationReferralData(mView.getAppContext(), AppConstants.GET_AUTH_SEARCH, new VolleyResponseListener() {
            @Override
            public void onError(String error) {
                Log.i("Error_Auth_Referral", StringConstants.ERROR);
            }

            @Override
            public void onResponse(String response) {
                try {
                    Log.i("Success_Auth_Referral", StringConstants.RESPONSE);
                    if (response != null && response.length() > 0) {
                        AuthorizationModel jsonParseResult = new Gson().fromJson(response, AuthorizationModel.class);
                        ProfileDataCache.getInstance().setPageCount(jsonParseResult.getPageCount());
                        if (jsonParseResult != null && jsonParseResult.getAuthList() != null) {
                            authViewList.addAll(jsonParseResult.getAuthList());
                        }
                        if (authViewList != null) {
                            ((AuthReferralView) mView).onAuthReferralLoadingCompleted(authViewList);
                        }
                    }
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
            }
        });
    }

    /*
 This method is used to getting authorization referral details of the selected item
  */
    @Override
    public void getAuthReferralDetailView() {
        mView.showProgress();
        VolleyService.getAuthorizationDetailViewData(mView.getAppContext(), AppConstants.GET_AUTH_DETAILS, new VolleyResponseListener() {
            @Override
            public void onError(String error) {
                mView.hideProgress();
                Log.i("Error_Auth_Referral", StringConstants.ERROR);
            }

            @Override
            public void onResponse(String response) {
                Log.i("Success_Detailed_View", StringConstants.RESPONSE);
                mView.hideProgress();
                if (response != null) {
                    //Processing the response and setting to mViews
                    AuthDetailView authViewModel = new Gson().fromJson(response, AuthDetailView.class);



                    String placeService = authViewModel.getPlaceOfService().getDescription();
                    ProfileDataCache.getInstance().setPlaceService(placeService);
                    String authReferringProvider = "";
                    String authReferredProvider = "";
                    for (int i = 0; i < authViewModel.getProviderList().size(); i++) {
                        if (authViewModel.getProviderList().get(i).getProviderType().equalsIgnoreCase("RF")) {
                            authReferredProvider = authViewModel.getProviderList().get(i).getFirstName() + authViewModel.getProviderList().get(i).getLastName() + "\n" +
                                    authViewModel.getProviderList().get(i).getAddress().getAddress1() +
                                    authViewModel.getProviderList().get(i).getAddress().getCity() + " ," +
                                    authViewModel.getProviderList().get(i).getAddress().getState() +
                                    authViewModel.getProviderList().get(i).getAddress().getZipCode();
                        }
                        if (authViewModel.getProviderList().get(i).getProviderType().equalsIgnoreCase("RP")) {
                            authReferringProvider = authViewModel.getProviderList().get(i).getFirstName() + authViewModel.getProviderList().get(i).getLastName() + "\n" +
                                    authViewModel.getProviderList().get(i).getAddress().getAddress1() +
                                    authViewModel.getProviderList().get(i).getAddress().getCity() + " ," +
                                    authViewModel.getProviderList().get(i).getAddress().getState() +
                                    authViewModel.getProviderList().get(i).getAddress().getZipCode();
                        }
                        ProfileDataCache.getInstance().setAuthReferringProvider(authReferringProvider);
                        ProfileDataCache.getInstance().setAuthReferredProvider(authReferredProvider);
                    }
                    ((AuthReferralDetailsView) mView).onDetailsLoadingCompleted(authViewModel);
                }
            }
        });
    }

    @Override
    public void onAttach(MvpView mView) {
        this.mView = mView;
    }

    @Override
    public void onDetach() {
        mView = null;
    }
}
