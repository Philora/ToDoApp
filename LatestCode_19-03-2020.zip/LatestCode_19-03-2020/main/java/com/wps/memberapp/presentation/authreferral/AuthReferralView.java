package com.wps.memberapp.presentation.authreferral;

import com.wps.memberapp.data.model.AuthReferral;
import com.wps.memberapp.presentation.base.MvpView;

import java.util.List;

/**
 * This interface contain UI functions of AuthReferral Screen.
 */
public interface AuthReferralView extends MvpView {
    void onAuthReferralLoadingCompleted(List<AuthReferral> authViewList);
}
