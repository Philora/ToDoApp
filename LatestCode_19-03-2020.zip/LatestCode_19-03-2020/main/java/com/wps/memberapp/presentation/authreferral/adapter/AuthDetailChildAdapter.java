package com.wps.memberapp.presentation.authreferral.adapter;

import android.app.Activity;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.model.ProcedureServicesDetails;

import java.util.List;

/**
 * This adapter is used to display auth detail information to the user.
 */
public class AuthDetailChildAdapter extends RecyclerView.Adapter<AuthDetailChildAdapter.ProductViewHolder> {

    //This context will be used to inflate the layout

    private final Context mCtx;
    //We are storing all the product in a list
    private final List<ProcedureServicesDetails> mProcedureServicesList;

    //getting the context and product list with constructor
    public AuthDetailChildAdapter(Activity mCtx, List<ProcedureServicesDetails> mProcedureServicesList) {
        this.mCtx = mCtx;
        this.mProcedureServicesList = mProcedureServicesList;
    }

    /*
   Creating ViewHolder based on the layout to bind the data to adapter.
    */
    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.row_auth_details, parent, false);
        return new ProductViewHolder(view);
    }

    /*
  Binding data to ViewHolder class object based on the position.
  */
    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, final int position) {
        if (mProcedureServicesList != null && !mProcedureServicesList.isEmpty()) {
            ProcedureServicesDetails details = mProcedureServicesList.get(position);
            if (details != null) {
                //Binding the data with the viewHolder views
                holder.tvProcedure.setText(details.getPS_IDe());
                holder.tvDescription.setText(details.getPS_Description());
                holder.tvReceivedDate.setText(details.getReceivedDate());
                holder.tvFromDate.setText(details.getFromDate());
                holder.tvToDate.setText(details.getToDate());
                holder.tvStatusDetail.setText(details.getStatus());
            }
        }
    }

    /*
    This method is used to get the items size in array list
   */
    @Override
    public int getItemCount() {
        if (mProcedureServicesList != null) {
            return mProcedureServicesList.size();
        } else {
            return 0;
        }
    }


    /*
    View Holder class to bind the data to views and will improve the performance.
   */
    class ProductViewHolder extends RecyclerView.ViewHolder {

        final TextView tvProcedure;
        final TextView tvDescription;
        final TextView tvReceivedDate;
        final TextView tvFromDate;
        final TextView tvToDate;
        final TextView tvStatusDetail;

        private ProductViewHolder(@NonNull View itemView) {
            super(itemView);
            tvProcedure = itemView.findViewById(R.id.procedureValue);
            tvDescription = itemView.findViewById(R.id.descriptionValue);
            tvReceivedDate = itemView.findViewById(R.id.receivedDateValue);
            tvFromDate = itemView.findViewById(R.id.fromDateValue);
            tvToDate = itemView.findViewById(R.id.toDateValue);
            tvStatusDetail = itemView.findViewById(R.id.statusDetailTextViewAuth);
        }

    }
}
