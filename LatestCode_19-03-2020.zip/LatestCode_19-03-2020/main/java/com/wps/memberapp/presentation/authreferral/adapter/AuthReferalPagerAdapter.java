package com.wps.memberapp.presentation.authreferral.adapter;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.AuthReferral;
import com.wps.memberapp.domain.listener.DialogCallbackContract;
import com.wps.memberapp.presentation.authreferral.fragment.AuthDetailViewFragment;
import com.wps.memberapp.utility.StringConstants;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

/**
 * This adapter is used to display the list of auths and refs of the user
 * as a list view.
 */
public class AuthReferalPagerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>
        implements DialogCallbackContract {

    //this context  will be used to inflate the layout
    private final Context mCtx;
    private static final int BODY = 0;
    private static final int FOOTER = 1;
    private final AppCompatActivity mActivity;
    //We are storing all the product in a list
    private final List<AuthReferral> mProductList;

    //getting the context and product list with constructor
    public AuthReferalPagerAdapter(Context mCtx, AppCompatActivity mActivity, List<AuthReferral> mProductList) {
        this.mCtx = mCtx;
        this.mProductList = mProductList;
        this.mActivity = mActivity;
    }

    /*
   Creating ViewHolder based on the layout to bind the data to adapter.
    */
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //inflating and returning our view holder
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.row_fragment_auth_referal, parent, false);
        return new ProductViewHolder(view);
    }

    /*
  Binding data to ViewHolder class object based on the position.
  */
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
        if (mProductList != null && !mProductList.isEmpty() && holder instanceof ProductViewHolder) {
            //getting the product of the specified position
            final AuthReferral authDetails = mProductList.get(position);
            //Binding the data  with the viewHolder views
            if (authDetails.getMemberFeed() != null) {
                if (authDetails.getMemberFeed().getFirstName() != null
                        && authDetails.getMemberFeed().getLastName() != null) {
                    String name = authDetails.getMemberFeed().getFirstName() + StringConstants.SPACE_SINGLE + authDetails.getMemberFeed().getLastName();
                    ((ProductViewHolder) holder).tvTitle.setText(name);
                }
                if (authDetails.getMemberFeed().getDateOfBirth() != null && !authDetails.getMemberFeed().getDateOfBirth().equals("null")) {
                    ((ProductViewHolder) holder).tvDobValue.setText(String.valueOf(authDetails.getMemberFeed().getDateOfBirth()));
                }
            }

            if (authDetails.getNumber() != null && !authDetails.getNumber().equals("null")) {
                ((ProductViewHolder) holder).tvAuthorizationNumber.setText(authDetails.getNumber());
            }
            if (authDetails.getReferedToProvider() != null &&
                    authDetails.getReferedToProvider().getFirstName() != null && !authDetails.getReferedToProvider().getFirstName().equals("null")
                    && authDetails.getReferedToProvider().getLastName() != null && !authDetails.getReferedToProvider().getLastName().equals("null")) {
                ((ProductViewHolder) holder).tvReferralName.setText(String.valueOf(
                        authDetails.getReferedToProvider().getFirstName() + StringConstants.SPACE_SINGLE + authDetails.getReferedToProvider().getLastName()));
            } else {
                ((ProductViewHolder) holder).tvReferralName.setText("N/A");
            }

            if (authDetails.getReferringProvider() != null &&
                    authDetails.getReferringProvider().getFirstName() != null && !authDetails.getReferringProvider().getFirstName().equals("null") &&
                    authDetails.getReferringProvider().getLastName() != null && !authDetails.getReferringProvider().getLastName().equals("null")) {
                ((ProductViewHolder) holder).tvReferringName.setText(String.valueOf(
                        authDetails.getReferringProvider().getFirstName() + StringConstants.SPACE_SINGLE + authDetails.getReferringProvider().getLastName()));
            } else {
                ((ProductViewHolder) holder).tvReferringName.setText("N/A");
            }
            updateOtherDetails(authDetails, ((ProductViewHolder) holder));
            ((ProductViewHolder) holder).cardView.setOnClickListener(view -> openDetailsFragment(authDetails));
        }
    }

    /*
    Binding authorization details data to views in the adapter
     */
    private void updateOtherDetails(AuthReferral authDetails, @NonNull ProductViewHolder holder) {
        if (authDetails.getStatus() != null && !authDetails.getStatus().equals("null")) {
            holder.tvStatus.setText(String.valueOf(authDetails.getStatus()));
        }
        if (authDetails.getStartDate() != null && !authDetails.getStartDate().equals("null")) {
            holder.tvStartDate.setText(String.valueOf(authDetails.getStartDate()));
        }
        if (authDetails.getEndDate() != null && !authDetails.getEndDate().equals("null")) {
            holder.tvEndDate.setText(String.valueOf(authDetails.getEndDate()));
        }
    }

    /*
    This method is used to open the Authorization details in separate fragment
     */
    private void openDetailsFragment(AuthReferral authDetails) {
        AuthDetailViewFragment authDetailView = new AuthDetailViewFragment();
        ProfileDataCache.getInstance().setHashCode(authDetails.getHashCode());
        Bundle args = new Bundle();
        if (authDetails.getNumber() != null && !authDetails.getNumber().equals("null")) {
            args.putString("authNumber", authDetails.getNumber());
            ProfileDataCache.getInstance().setAuthNumber(authDetails.getEncryptNumber());
        }
        if (authDetails.getMemberFeed().getDateOfBirth() != null && !authDetails.getMemberFeed().getDateOfBirth().equals("null")) {
            args.putString("dob", authDetails.getMemberFeed().getDateOfBirth());
        }

        if (authDetails.getStatus() != null && !authDetails.getStatus().equals("null")) {
            args.putString("status", authDetails.getStatus());
        }
        if (authDetails.getMemberFeed() != null && authDetails.getMemberFeed().getFirstName() != null
                && authDetails.getMemberFeed().getLastName() != null) {
            args.putString("name", authDetails.getMemberFeed().getFirstName() + StringConstants.SPACE_SINGLE + authDetails.getMemberFeed().getLastName());
        }
        if (authDetails.getMemberFeed() != null && authDetails.getMemberFeed().getGender() != null) {
            args.putString("gender", authDetails.getMemberFeed().getGender());
        }
        authDetailView.setArguments(args);
        mActivity.getSupportFragmentManager().beginTransaction().
                replace(R.id.frame_container, authDetailView).addToBackStack(null).commit();
    }

    /*
   This method is used to get the items size in array list
  */
    @Override
    public int getItemCount() {
        if (mProductList != null) {
            return mProductList.size();
        } else {
            return 0;
        }
    }

    /*
  Getting item view type based on the position
   */
    @Override
    public int getItemViewType(int position) {
        return mProductList.size();
    }

    /**
     * This class is used to bind the authorization and referral data in Auth Referral adapter
     */
    class ProductViewHolder extends RecyclerView.ViewHolder {

        //Member variables
        final TextView tvTitle;
        final TextView tvAuthorizationNumber;
        final TextView tvDobValue;
        final TextView tvStatus;
        final TextView tvReferringName;
        final TextView tvReferralName;
        final TextView tvStartDate;
        final TextView tvEndDate;
        private final CardView cardView;

        private ProductViewHolder(@NonNull View itemView) {
            super(itemView);

            //Initializing views
            cardView = itemView.findViewById(R.id.authReferalCardView);
            tvTitle = itemView.findViewById(R.id.authHeadingTxt);
            tvAuthorizationNumber = itemView.findViewById(R.id.authNumberValue);
            tvDobValue = itemView.findViewById(R.id.dobValue);
            tvStatus = itemView.findViewById(R.id.statusTextView);
            tvReferringName = itemView.findViewById(R.id.referringNameDetailTextView);
            tvReferralName = itemView.findViewById(R.id.referralNameDetailTextView);
            tvStartDate = itemView.findViewById(R.id.startDateDetailTextView);
            tvEndDate = itemView.findViewById(R.id.endDateTextView);
        }
    }

    /* *//**
     * This class is used to display spinner at the end of the list
     *//*
    private class ProgressViewHolder extends RecyclerView.ViewHolder {

        private ProgressViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }*/
}
