package com.wps.memberapp.presentation.authreferral.adapter;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.github.mikephil.charting.charts.PieChart;
import com.wps.memberapp.R;

/**
 * This class is used to bind the authorization and referral summary data in dashboard adapter
 */
public class AuthorizationViewHolder extends RecyclerView.ViewHolder {

    //Member variables
    public final TextView tvHeader;
    public final PieChart mChart;
    public final Button btnDetailAuthView;

    public AuthorizationViewHolder(@NonNull View authorizationItemView) {
        super(authorizationItemView);

        //Initializing views
        tvHeader = authorizationItemView.findViewById(R.id.headingTxt);
        CardView authorizationCardView = authorizationItemView.findViewById(R.id.authorizationCardView);
        btnDetailAuthView = authorizationCardView.findViewById(R.id.btnDetailAuthView);
        mChart = authorizationItemView.findViewById(R.id.pieChart);

    }
}
