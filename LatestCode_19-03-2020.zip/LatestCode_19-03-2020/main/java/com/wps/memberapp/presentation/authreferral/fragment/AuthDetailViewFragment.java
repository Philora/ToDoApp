package com.wps.memberapp.presentation.authreferral.fragment;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.AuthDetailView;
import com.wps.memberapp.data.model.InpatientStay;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.model.MessageData;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.authreferral.AuthReferralDetailsView;
import com.wps.memberapp.presentation.authreferral.AuthReferralPresenter;
import com.wps.memberapp.presentation.authreferral.AuthReferralPresenterImpl;
import com.wps.memberapp.presentation.authreferral.adapter.AuthDetailChildAdapter;
import com.wps.memberapp.presentation.base.BaseFragment;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.StringConstants;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * This class is used to display Authorization details along with provider and diagnostic information
 */

public class AuthDetailViewFragment extends BaseFragment implements AuthReferralDetailsView {

    //Declaring the member variables
    @BindView(R.id.txt_ReferredProvider)
    TextView txtReferredProvider;

    @BindView(R.id.healthPlanValue)
    TextView tvHealthValue;

    @BindView(R.id.authDetailNumberValue)
    TextView tvAuthNumber;

    @BindView(R.id.dobValue)
    TextView tvDobValue;

    @BindView(R.id.authDetailHeadingTxt)
    TextView tvTxtName;

    @BindView(R.id.typeDetailTextViewAuth)
    TextView tvAuthType;

    @BindView(R.id.typeOfServices)
    TextView tvServiceType;

    @BindView(R.id.btnSendEnquiry)
    Button btnSendEnquiry;

    @BindView(R.id.procedureRecylerView)
    RecyclerView recyclerView;

    @BindView(R.id.inPatientStayLayout)
    LinearLayout llInpatientStayLayout;

    @BindView(R.id.fromDateValue)
    TextView tvFromDate;

    @BindView(R.id.receivedDateValue)
    TextView tvRecievedDate;

    @BindView(R.id.daysDetailTextViewAuth)
    TextView tvNoOfDays;

    @BindView(R.id.statusDetailTextViewAuth)
    TextView tvStatus;

    @BindView(R.id.txt_Gender)
    TextView txtGender;

    @BindView(R.id.txt_PlaceService)
    TextView txtPlaceService;

    @BindView(R.id.txt_ReferringProvider)
    TextView txtReferringProvider;

    private AlertDialog mAlert = null;
    private Unbinder mUnbinder;
    String authValue;

    /*
     * This override method is used to inflate the layout for AuthDetailViewFragment fragment
     */
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        View rootView = inflater.inflate(R.layout.fragment_auth_detail_view, container, false);
        mUnbinder = ButterKnife.bind(this, rootView);
        if (getActivity() != null) {
            View view = getActivity().findViewById(R.id.imageViewSearch);
            view.setVisibility(View.GONE);
            view.setClickable(false);
            TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
            fragmentTitle.setText(R.string.auth_referral_title);
        }
        recyclerView.setHasFixedSize(true);
        final LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        //Getting the details from the previous screen to display
        if (getArguments() != null) {
            authValue = getArguments().getString("authNumber");
            String dob = getArguments().getString("dob");
            tvDobValue.setText(dob);
            tvAuthNumber.setText(authValue);
            String name = getArguments().getString("name");
            tvTxtName.setText(name);
        }
        btnSendEnquiry.setOnClickListener(v -> showNewMessageDialog());
        AuthReferralPresenter referralPresenter = new AuthReferralPresenterImpl();
        referralPresenter.onAttach(this);
        if (getActivity() != null) {
            if (GeneralUtils.isOnline(getActivity())) {
                referralPresenter.getAuthReferralDetailView();
            } else {
                GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.login_no_internet));
            }
        }
        return rootView;
    }

    /*
    Call back to handle the response of getting authorization details of the selected item in the list
     */
    @Override
    public void onDetailsLoadingCompleted(AuthDetailView authViewModel) {
        if (authViewModel != null) {
            MemberDetails details = ProfileDataCache.getInstance().getmMemberDetails().get(0);
            if (details != null) {
                tvHealthValue.setText(details.getPlanName());
            }
            tvAuthType.setText(authViewModel.getType());
            List<InpatientStay> inpatientStayList = authViewModel.getInpatientStayDetails();
            if (inpatientStayList != null && !inpatientStayList.isEmpty()) {
                llInpatientStayLayout.setVisibility(View.VISIBLE);
                InpatientStay stay = inpatientStayList.get(0);
                if (stay != null) {
                    tvFromDate.setText(stay.getFromDate());
                    tvRecievedDate.setText(stay.getReceivedDate());
                    tvNoOfDays.setText(stay.getQuantity());
                    tvStatus.setText(stay.getStatus());
                }
            }
            /*if (authViewModel.getType() != null && authViewModel.getType().equalsIgnoreCase("INP")) {
                tvServiceType.setText(R.string.inpatient_services);
            } else {
                tvServiceType.setText(R.string.outpatient_services);
            }*/


            // Auth - Refer - Provider
            String authPlaceService = ProfileDataCache.getInstance().getPlaceService();
            if (authPlaceService != null && !authPlaceService.equalsIgnoreCase("") && !authPlaceService.isEmpty()) {
                txtPlaceService.setText(authPlaceService);
            } else {
                txtPlaceService.setText("N/A");
            }

            String authReferringProvider = ProfileDataCache.getInstance().getAuthReferringProvider();
            if (authReferringProvider != null && !authReferringProvider.equalsIgnoreCase("") && !authReferringProvider.isEmpty()) {
                txtReferringProvider.setText(authReferringProvider);
            } else {
                txtReferringProvider.setText("N/A");
            }

            String authReferredProvider = ProfileDataCache.getInstance().getAuthReferredProvider();
            if (authReferredProvider != null && !authReferredProvider.equalsIgnoreCase("") && !authReferredProvider.isEmpty()) {
                txtReferredProvider.setText(authReferredProvider);
            } else {
                txtReferredProvider.setText("N/A");
            }

            if (details != null && details.getGender().equalsIgnoreCase("M")) {
                txtGender.setText(R.string.txt_male);
            } else {
                txtGender.setText(R.string.txt_female);
            }

            //Binding adapter to recycle view to display data
            if (authViewModel.getProcedureServicesDetails() != null && !authViewModel.getProcedureServicesDetails().isEmpty()) {
                tvServiceType.setVisibility(View.VISIBLE);
                AuthDetailChildAdapter adapter = new AuthDetailChildAdapter(getActivity(), authViewModel.getProcedureServicesDetails());
                recyclerView.setItemAnimator(new DefaultItemAnimator());
                recyclerView.setAdapter(adapter);
                adapter.notifyDataSetChanged();
            } else {
                tvServiceType.setVisibility(View.GONE);
            }
        }
    }

    /*
    This method is used to show new message dialog to send enquiry to CSR
     */
    private void showNewMessageDialog() {
        if (getActivity() == null) {
            return;
        }
        View view = View.inflate(getActivity(), R.layout.dialog_auth_send_enquiry, null);
        TextView authTv = view.findViewById(R.id.authNo);
        final EditText msgEt = view.findViewById(R.id.msg);
        MemberDetails details = ProfileDataCache.getInstance().getmMemberDetails().get(0);
        if (details != null) {
            TextView memId = view.findViewById(R.id.memId);
            TextView provTv = view.findViewById(R.id.provNo);
            String memIdText = getString(R.string.member_id_colon) + StringConstants.SPACE_SINGLE + details.getSubscriberID() + "-" + details.getPersonNumber();
            String provIdText = getString(R.string.providerno_colon) + StringConstants.SPACE_SINGLE + details.getSubscriberID();
            memId.setText(memIdText);
            provTv.setText(provIdText);
        }
        String authText = getString(R.string.authorization_no) + StringConstants.SPACE_SINGLE + tvAuthNumber.getText().toString();
        authTv.setText(authText);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(R.string.send_nquiry)
                .setCancelable(false)
                .setView(view)
                .setPositiveButton(R.string.submit, null)
                .setNegativeButton(R.string.cancel, null);
        mAlert = builder.create();
        mAlert.show();
        mAlert.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            MessageData data = new MessageData();
            data.setSubject(getString(R.string.authorizations));
            String msg = msgEt.getText().toString().trim();
            if (msg.length() != 0) {
                data.setMessage(msg);
                ProfileDataCache.getInstance().setMessageData(data);

                String mDetSubscriberID = details.getSubscriberID();
                String strMessage = msgEt.getText().toString();
                ProfileDataCache.getInstance().setRequestMessageData(StringConstants.Ref_Member_ID_Colon + mDetSubscriberID + StringConstants.Authorization_Number_Colon + authValue + StringConstants.Dot_Space + strMessage);

                VolleyService.authRefSendInquiry((AppCompatActivity) getActivity(), false);
                mAlert.dismiss();
            } else {
                GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.please_enter_message));
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUnbinder.unbind();
    }

}

