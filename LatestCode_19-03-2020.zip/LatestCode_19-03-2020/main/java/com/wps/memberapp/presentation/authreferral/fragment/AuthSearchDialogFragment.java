package com.wps.memberapp.presentation.authreferral.fragment;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.AdvanceSearchFilters;
import com.wps.memberapp.data.model.AuthReferral;
import com.wps.memberapp.data.model.AuthorizationModel;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.claims.adapter.NothingSelectedSpinnerAdapter;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.DatePickerFragment;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * A Dialog which will display auth and referral related search fields
 */

public class AuthSearchDialogFragment extends DialogFragment {

    //Member variables declaration

    @BindView(R.id.memberName)
    Spinner spnMemberName;

    @BindView(R.id.authorizationStatus)
    Spinner spnAuthorizationStatus;

    @BindView(R.id.imgCalendar)
    ImageView ivCalendarView1;

    @BindView(R.id.imgCalendar2)
    ImageView ivCalendarView2;

    @BindView(R.id.txtStartDateAuth)
    TextView tvStartDate;

    @BindView(R.id.txtEndDateAuth)
    TextView tvEndDate;

    @BindView(R.id.btnAuthSearch)
    Button btnSearch;

    @BindView(R.id.btnAuthCancel)
    Button btnCancel;

    @BindView(R.id.authNumEt)
    EditText etAuthNum;

    @BindView(R.id.close)
    ImageView ivClose;
    @NonNull
    private String mMemberName = "";
    @NonNull
    private String mStartDate = "";
    @NonNull
    private String mEndDate = "";
    private AuthDialogContract mListener;
    private Unbinder mUnbinder;
    private List<AuthReferral> authList;
    @NonNull
    private String mStatus = "";
    private AdvanceSearchFilters mSearchFilters;

    public void setListener(AuthorizationReferalFragment listener) {
        mListener = listener;
    }

    public interface AuthDialogContract {
        void authData(List<AuthReferral> authList);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NORMAL, R.style.DialogFragmentTheme);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.frag_auth_search, container, false);
        mSearchFilters = new AdvanceSearchFilters();
        mUnbinder = ButterKnife.bind(this, rootView);
        ivClose.setOnClickListener(view -> dismiss());
        //Adding data to spinner
        addItemsOnSpinner2();
        addItemsOnSpinner1();
        return rootView;
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ivCalendarView1.setOnClickListener(v -> showDatePickerforCalendar());
        ivCalendarView2.setOnClickListener(v -> showDatePickerforCalendarNew());
        btnSearch.setOnClickListener(view1 -> {
            if (getActivity() != null) {
                if (GeneralUtils.isOnline(getActivity())) {
                    getAdvanceSearchDetails();
                } else {
                    GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.login_no_internet));
                }
            }
        });
        btnCancel.setOnClickListener(view12 -> dismiss());
    }


    /*
    Adding authorization status to spinner by creating adapter
     */
    private void addItemsOnSpinner2() {

        //creating spinnner adapter with authorization status values and setting to spinner
        if (getActivity() == null) {
            return;
        }
        List<String> list = Arrays.asList(getActivity().getResources().getStringArray(R.array.authorization_status));
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(getActivity(),
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnAuthorizationStatus.setAdapter(new NothingSelectedSpinnerAdapter(
                dataAdapter,
                R.layout.authorization_auth_status_spinner_hint,
                getActivity()));

        //setting selected listener to get the selected item from spinner
        spnAuthorizationStatus.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                try {
                    if (spnAuthorizationStatus.getSelectedItem() != null) {
                        switch (i) {
                            case 1:
                                mStatus = "PN";
                                break;
                            case 2:
                                mStatus = "A";
                                break;
                            case 3:
                                mStatus = "PA";
                                break;
                            case 4:
                                mStatus = "DN";
                                break;
                            default:
                        }
                        mSearchFilters.setStatus(mStatus);
                    }
                } catch (Exception e) {
                    Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //Do something
            }
        });

    }

    /*
    Adding member names to spinner by creating adapter with member details
     */
    private void addItemsOnSpinner1() {
        if (getActivity() == null) {
            return;
        }
        //creating spinnner adapter with member name values and setting to spinner
        List<String> list = new ArrayList<>();
        List<MemberDetails> memberDetailsList = ProfileDataCache.getInstance().getmMemberDetails();
        for (MemberDetails details : memberDetailsList) {
            list.add(details.getFirstName() + StringConstants.SPACE_SINGLE + details.getLastName());
        }
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnMemberName.setAdapter(new NothingSelectedSpinnerAdapter(
                dataAdapter,
                R.layout.authorization_member_name_spinner_hint,
                // R.layout.contact_spinner_nothing_selected_dropdown, // Optional
                getActivity()));

        //setting selected listener to get the selected item from spinner
        spnMemberName.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                try {
                    if (spnMemberName.getSelectedItem() != null) {
                        mMemberName = spnMemberName.getSelectedItem().toString();
                        mSearchFilters.setName(mMemberName);
                    }
                } catch (Exception e) {
                    Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //Do something
            }
        });
    }

    /*
  Used to show date picker dialog to user
   */
    private void showDatePickerforCalendar() {
        DatePickerFragment date = new DatePickerFragment();
        // Set up Current Date into dialog
        Calendar calender = Calendar.getInstance();
        Bundle args = new Bundle();
        args.putInt("year", calender.get(Calendar.YEAR));
        args.putInt("month", calender.get(Calendar.MONTH));
        args.putInt("day", calender.get(Calendar.DAY_OF_MONTH));
        args.putString("CustomDatePicker", "AuthDatePicker");
        date.setArguments(args);
        //Set Call back to capture selected date
        date.setCallBack(ondate);
        if (getFragmentManager() != null) {
            date.show(getFragmentManager(), "Date Picker");
        }
    }

    /*
    Used to show date picker dialog to user
     */
    private void showDatePickerforCalendarNew() {
        DatePickerFragment date = new DatePickerFragment();

        // Set Up current Date into dialog

        Calendar calender = Calendar.getInstance();
        Bundle args = new Bundle();
        args.putInt("year", calender.get(Calendar.YEAR));
        args.putInt("month", calender.get(Calendar.MONTH));
        args.putInt("day", calender.get(Calendar.DAY_OF_MONTH));
        args.putString("CustomDatePicker", "AuthDatePicker");
        date.setArguments(args);
        // Set Call Back to capture selected date
        date.setCallBack(ondateSecond);
        if (getFragmentManager() != null) {
            date.show(getFragmentManager(), "Date PickerNew");
        }
    }

    //Used to display the date picker to select the start date and will store in shared preferences
    private final DatePickerDialog.OnDateSetListener ondate = new DatePickerDialog.OnDateSetListener() {

        public void onDateSet(DatePicker view, int year, int monthOfYear,
                              int dayOfMonth) {
            mStartDate = String.valueOf(monthOfYear + 1) + "/" + dayOfMonth
                    + "/" + year;
            tvStartDate.setText(mStartDate);
            tvStartDate.setError(null);
            mSearchFilters.setStartDate(mStartDate);
        }
    };

    //Used to display the date picker to select the end date and will store in shared preferences
    private final DatePickerDialog.OnDateSetListener ondateSecond = new DatePickerDialog.OnDateSetListener() {

        public void onDateSet(DatePicker view, int year, int monthOfYear,
                              int dayOfMonth) {
            mEndDate = String.valueOf(monthOfYear + 1) + "/" + dayOfMonth + "/" + year;
            tvEndDate.setError(null);
            tvEndDate.setText(mEndDate);
            mSearchFilters.setEndDate(mEndDate);
        }
    };

    /*
      This method is used to fetch the advanced search authorization referral data
     */

    private void getAdvanceSearchDetails() {
        String authNumber = etAuthNum.getText().toString();
        //Validating the search related data

        // Checked in portal after discussing with Shraddha, 13/01/2020
       /* if (mMemberName.length() == 0 && mStartDate.length() == 0 && mEndDate.length() == 0
                && authNumber.length() == 0 && mStatus.length() == 0) {
            Toast.makeText(getActivity(), getString(R.string.select_atleast_one_field), Toast.LENGTH_LONG).show();
            return;
        }*/
        mSearchFilters.setNumber(authNumber);
        ProfileDataCache.getInstance().setSearchFilters(mSearchFilters);
        dismiss();
        //display the progress dialog
        if (getActivity() != null) {
            GeneralUtils.showProgress(getActivity());
        }
        //Intiating the API request to get the search related data
        VolleyService.getAdvanceSearchData(getActivity(), AppConstants.GET_AUTH_SEARCH, new VolleyResponseListener() {
            @Override
            public void onError(String error) {
                GeneralUtils.hideProgress();
                Log.i("Error_Auth_Referral", StringConstants.ERROR);
            }

            @Override
            public void onResponse(String response) {

                //Processing the response
                Log.i("Success_Auth_Referral", StringConstants.RESPONSE);
                if (response != null) {  // Checking Null
                    GeneralUtils.hideProgress();
                    AuthorizationModel jsonParseResult = new Gson().fromJson(response, AuthorizationModel.class);
                    if (jsonParseResult != null && jsonParseResult.getAuthList() != null) {
                        authList = new ArrayList<>();
                        authList.addAll(jsonParseResult.getAuthList());
                        if (getDialog() != null) {
                            getDialog().cancel();
                        }
                    }
                    if (mListener != null) {
                        mListener.authData(authList);
                    }
                }
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUnbinder.unbind();
    }
}
