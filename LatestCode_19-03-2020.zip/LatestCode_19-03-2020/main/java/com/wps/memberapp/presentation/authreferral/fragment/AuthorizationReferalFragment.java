package com.wps.memberapp.presentation.authreferral.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.AuthReferral;
import com.wps.memberapp.presentation.authreferral.AuthReferralPresenter;
import com.wps.memberapp.presentation.authreferral.AuthReferralPresenterImpl;
import com.wps.memberapp.presentation.authreferral.AuthReferralView;
import com.wps.memberapp.presentation.authreferral.adapter.AuthReferalPagerAdapter;
import com.wps.memberapp.presentation.base.BaseFragment;
import com.wps.memberapp.utility.GeneralUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;


/**
 * Used to display list of Authorization Referral data of the user.
 */

public class AuthorizationReferalFragment extends BaseFragment implements View.OnClickListener, AuthReferralView, AuthSearchDialogFragment.AuthDialogContract {

    //Member variables declaration

    @BindView(R.id.recyclerAuthreferalView)
    RecyclerView recycleView;

    @BindView(R.id.nodata)
    TextView tvNoData;

    @BindView(R.id.claimHeader)
    TextView tvAuthHeader;

    private Unbinder mUnbinder;
    private AuthReferralPresenter mAuthReferralPresenter;
    private boolean isLoading;
    private int pageID = 1;
    private int scrollPosition = 0;
    private ProgressBar mProgressBar;
    private List<AuthReferral> authList;

    /**
     * This override method is used to inflate the layout for Authorization fragment
     *
     * @return rootView
     */
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        if (container != null) {
            container.removeAllViews();
            container.clearDisappearingChildren();
        }
        View rootView = inflater.inflate(R.layout.fragment_authorization, container, false);
        if (getActivity() != null) {
            TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
            fragmentTitle.setText(R.string.authorization_and_referral);
            View view = getActivity().findViewById(R.id.imageViewSearch);
            view.setVisibility(View.VISIBLE);
            TextView txtDownloadPDF = getActivity().findViewById(R.id.txt_Call);
            txtDownloadPDF.setVisibility(View.GONE);
            view.setClickable(true);
            view.setOnClickListener(this);
        }
        mUnbinder = ButterKnife.bind(this, rootView);
        mAuthReferralPresenter = new AuthReferralPresenterImpl();
        mAuthReferralPresenter.onAttach(this);
        recycleView.setHasFixedSize(true);
        mProgressBar = rootView.findViewById(R.id.progressBar);
        final LinearLayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        mLayoutManager.setOrientation(RecyclerView.VERTICAL);
        recycleView.setLayoutManager(mLayoutManager);
        authList = new ArrayList<>();
        Spinner daysSpinner = rootView.findViewById(R.id.daysSpinner);
        List<String> list = Arrays.asList(getActivity().getResources().getStringArray(R.array.auth_days));
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        daysSpinner.setAdapter(dataAdapter);

        //Added OnItemSelectedListener to handle the user selections in the spinner
        daysSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if (i > -1) {
                    pageID = 1;
                    String days = getDays(i);
                    authList.clear();
                    scrollPosition = 0;
                    ProfileDataCache.getInstance().setClaimSearchDays(days);
                    ProfileDataCache.getInstance().setPageID(pageID);
                    if (getActivity() != null) {
                        if (GeneralUtils.isOnline(getActivity())) {
                            mProgressBar.setVisibility(View.VISIBLE);
                            mAuthReferralPresenter.getAuthReferralDetails();
                        } else {
                            GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.login_no_internet));
                        }
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //need to implement
            }
        });

        /*//Added ScrollListener to implement the pagination for earch 10 records
        recycleView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                if (authList.size() > 9) {
                    int visibleItemCount = mLayoutManager.getChildCount();
                    int totalItemCount = mLayoutManager.getItemCount();
                    int pastVisibleItems = mLayoutManager.findFirstVisibleItemPosition();
                    if (pastVisibleItems + visibleItemCount >= totalItemCount && !isLoading) {
                        isLoading = true;
                        pageID = pageID + 1;
                        scrollPosition = scrollPosition + 10;
                        ProfileDataCache.getInstance().setPageID(pageID);
                        if (getActivity() != null) {
                            if (GeneralUtils.isOnline(getActivity())) {
                                mAuthReferralPresenter.getAuthReferralDetails();
                            } else {
                                GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.login_no_internet));
                            }
                        }
                    }
                }
            }
        });*/

        return rootView;
    }

    @Override
    public void onClick(@NonNull View view) {
        if (view.getId() == R.id.imageViewSearch) {
            showDialog();
        }
    }

    /*
    Used to show the advance search dialog
     */
    private void showDialog() {
        if (getActivity() != null) {
            FragmentManager fm = getActivity().getSupportFragmentManager();
            AuthSearchDialogFragment addDialog = new AuthSearchDialogFragment();
            addDialog.setTargetFragment(this, 0);
            addDialog.setListener(this);
            addDialog.show(fm, "dialog");
        }
    }

    /*
    Getting No of days based on the user input
     */
    private String getDays(int i) {
        String days = "";
        switch (i) {
            case 1:
                days = "7";
                break;
            case 2:
                days = "15";
                break;
            case 3:
                days = "30";
                break;
            case 4:
                days = "60";
                break;
            case 5:
                days = "90";
                break;
            default:
                break;
        }
        return days;
    }

    /*
    Call back to handle the response of the getting authorization and referrals API
     */
    @Override
    public void onAuthReferralLoadingCompleted(List<AuthReferral> authViewList) {
        if (authViewList != null) {
            authList.remove(null);
            authList.addAll(authViewList);
//            if (authList.size() > 9) {
//                authList.add(null);
//            }
            updateList(authList);
        }
    }

    /*
    Call back to handle the response of the advance search for auth & referrals
     */
    @Override
    public void authData(List<AuthReferral> authViewList) {
        String startDate = ProfileDataCache.getInstance().getSearchFilters().getStartDate();
        String endDate = ProfileDataCache.getInstance().getSearchFilters().getEndDate();
        if (startDate != null && endDate != null) {
            String text = getString(R.string.showing_results_between) + " " + startDate + " " + "&" + " " + endDate;
            tvAuthHeader.setText(text);
        }
        if (authViewList != null) {
            authList.clear();
            authList.addAll(authViewList);
            updateList(authList);
        } else {
            tvNoData.setVisibility(View.VISIBLE);
        }
    }

    /*
    This method is used to create the adapter with list of auth&referrals and attach it to recycle view
     */
    private void updateList(@NonNull List<AuthReferral> authViewList) {
        AuthReferalPagerAdapter adapter = new AuthReferalPagerAdapter(getActivity(), (AppCompatActivity) getActivity(), authViewList);
        recycleView.setItemAnimator(new DefaultItemAnimator());
        recycleView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        mProgressBar.setVisibility(View.GONE);
        if (scrollPosition > 0) {
            recycleView.scrollToPosition(scrollPosition - 3);
        }
        isLoading = false;

        //Displaying no records found label when search  results are empty
        if (authViewList.isEmpty()) {
            tvNoData.setVisibility(View.VISIBLE);
        } else {
            tvNoData.setVisibility(View.GONE);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mAuthReferralPresenter.onDetach();
        recycleView = null;
        mUnbinder.unbind();
    }

}