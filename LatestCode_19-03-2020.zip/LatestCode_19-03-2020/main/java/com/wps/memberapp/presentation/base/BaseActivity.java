package com.wps.memberapp.presentation.base;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.view.MenuItem;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.utility.GeneralUtils;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import butterknife.BindView;
import io.github.yavski.fabspeeddial.FabSpeedDial;

/**
 * This Activity contains all the common utility functions of the
 * Dashboard Activity in this module.
 */
public class BaseActivity extends AppCompatActivity implements MvpView {


    @BindView(R.id.toolbar)
    Toolbar toolbar;

    @BindView(R.id.drawer_layout)
    DrawerLayout drawerLayout;

    @BindView(R.id.fabBtn)
    public FabSpeedDial fabBtn;

    @BindView(R.id.textView2)
    TextView textView;

    @BindView(R.id.textViewTitle)
    TextView tvTitle;

    private ActionBarDrawerToggle mNavDrawerToggle;


    /*
     Method is used to get toolbar control
     */


    protected Toolbar getToolbar() {
        return toolbar;
    }

    /*
      This method is used by other classes to set Navigation Drawer
     */
    protected void setNavDrawer() {
        GeneralUtils.setLanguage(this);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            Drawable drawable = getResources().getDrawable(R.drawable.ic_menu);
            Bitmap bitmap = ((BitmapDrawable) drawable).getBitmap();
            Drawable newdrawable = new BitmapDrawable(getResources(), Bitmap.createScaledBitmap(bitmap, 80, 80, true));
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(newdrawable);

        }
        if (drawerLayout != null) {
            mNavDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
            drawerLayout.addDrawerListener(mNavDrawerToggle);
            mNavDrawerToggle.setDrawerIndicatorEnabled(false);
            //toolbar.setNavigationIcon(R.drawable.ic_menu);
            mNavDrawerToggle.syncState();
            toolbar.setNavigationOnClickListener(v -> {
                if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    drawerLayout.closeDrawer(GravityCompat.START);
                } else {
                    drawerLayout.openDrawer(GravityCompat.START); // ToDo dismiss keyboard while clicking on drawer menu
                }
            });
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (drawerLayout != null) {
            drawerLayout.removeAllViews();
            drawerLayout.removeAllViewsInLayout();
            drawerLayout.removeAllViewsInLayout();
            drawerLayout = null;
        }
        if (toolbar != null) {
            toolbar.removeAllViews();
            toolbar = null;
        }
        if (mNavDrawerToggle != null) {
            mNavDrawerToggle = null;
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int i = item.getItemId();
        if (i == android.R.id.home) {
            drawerLayout.openDrawer(GravityCompat.START);  // OPEN DRAWER
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void showProgress() {
        //Need to implement
    }

    @Override
    public void hideProgress() {
        //Need to implement
    }

    @Override
    public void showLog(String msg) {
        //Need to implement
    }

    @Override
    public boolean isNetworkConnected() {
        return false;
    }

    @Override
    public void showNetworkError(String msg) {
        //Need to implement
    }

    @NonNull
    @Override
    public Activity getAppContext() {
        return this;
    }
}
