package com.wps.memberapp.presentation.base;

import android.app.Activity;
import android.app.AlertDialog;
import android.util.Log;

import com.wps.memberapp.utility.GeneralUtils;

import androidx.fragment.app.Fragment;

/**
 * This fragment contains all the common utility functions of the
 * other fragments in this module.
 */
public class BaseFragment extends Fragment implements MvpView {


    /*
    This method used to show progress
     */
    @Override
    public void showProgress() {
        if (getActivity() != null) {
            GeneralUtils.showProgress(getActivity());
        }
    }

    /*
 This method used to hide progress
  */
    @Override
    public void hideProgress() {
        GeneralUtils.hideProgress();
    }

    /*
 This method used to show the log messages
  */
    @Override
    public void showLog(String msg) {
        Log.i("info", msg);
    }

    /*
 This method used to check whether internet is connected or not
  */
    @Override
    public boolean isNetworkConnected() {
        if (getActivity() != null) {
            return GeneralUtils.isOnline(getActivity());
        }
        return false;
    }

    /*
 This method used to show network error alert dialog
  */
    @Override
    public void showNetworkError(String msg) {
        if (getActivity() == null) {
            return;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setMessage(msg);
        builder.setPositiveButton("OK", null);
        builder.create().show();
    }


    @Override
    public Activity getAppContext() {
        return this.getActivity();
    }
}
