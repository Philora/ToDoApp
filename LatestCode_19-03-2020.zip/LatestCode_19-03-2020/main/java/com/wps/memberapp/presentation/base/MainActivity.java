package com.wps.memberapp.presentation.base;

import android.app.Activity;
import android.app.AlertDialog;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;

import com.wps.memberapp.R;
import com.wps.memberapp.utility.GeneralUtils;

/**
 * This Activity contains all the common utility functions of the
 * other activities in this module except dashboard.
 */
public abstract class MainActivity extends AppCompatActivity implements MvpView {

    /*
    This method used to show progress
     */
    @Override
    public void showProgress() {
        GeneralUtils.showProgress(this);
    }

    /*
This method used to hide progress
*/
    @Override
    public void hideProgress() {
        GeneralUtils.hideProgress();
    }

    /*
This method used to show the log messages
 */
    @Override
    public void showLog(String msg) {
        Log.i("info", msg);
    }

    /*
This method used to check whether internet is connected or not
 */
    @Override
    public boolean isNetworkConnected() {
        return GeneralUtils.isOnline(this);
    }

    /*
This method used to show network error alert dialog
*/
    @Override
    public void showNetworkError(String msg) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(msg);
        builder.setPositiveButton(R.string.ok, null);
        builder.create().show();
    }

    @NonNull
    @Override
    public Activity getAppContext() {
        return this;
    }

}
