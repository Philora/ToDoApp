package com.wps.memberapp.presentation.base;

/**
 * This interface contains basic life cycle methods.
 */
public interface MvpPresenter {
    void onAttach(MvpView view);

    void onDetach();
}
