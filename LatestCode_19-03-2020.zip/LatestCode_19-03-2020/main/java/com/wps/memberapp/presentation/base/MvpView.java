package com.wps.memberapp.presentation.base;

import android.app.Activity;
import android.content.Context;

/**
 * This interface contains all the utility functions declarations of this module.
 */
public interface MvpView {
    void showProgress();

    void hideProgress();

    void showLog(String msg);

    boolean isNetworkConnected();

    void showNetworkError(String msg);

    Activity getAppContext();
}
