package com.wps.memberapp.presentation.base;

import android.app.Activity;



public class PegaChatActivity extends Activity {
/*//
//    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
    *//*    GeneralUtils.setLanguage(getApplicationContext());
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view);
        WebView wv = findViewById(R.id.web_view);
        wv.getSettings().setJavaScriptEnabled(true);
        wv.loadUrl("file:///android_asset/PegaChat.html");*//*
    }*/
}


