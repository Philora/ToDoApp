package com.wps.memberapp.presentation.base;

/*

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ProgressBar;

import com.fitbit.authentication.AuthenticationHandler;
import com.fitbit.authentication.AuthenticationManager;
import com.fitbit.authentication.AuthenticationResult;
import com.fitbit.authentication.Scope;
import com.wps.memberapp.R;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.presentation.dashboard.activity.DashboardActivity;
import com.wps.memberapp.presentation.healthtracker.activity.HealthTrackerActivity;


import java.util.Set;

import androidx.appcompat.app.AppCompatActivity;
import butterknife.BindView;
import butterknife.ButterKnife;

public class RootActivity extends AppCompatActivity implements AuthenticationHandler {
    @BindView(R.id.progressBar) ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_root);
        ButterKnife.bind(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        progressBar.setVisibility(View.INVISIBLE);

        */
/**
         *  (Look in FitbitAuthApplication for Step 1)
         *//*


        */
/**
         *  2. If we are logged in, go to next activity
         *      Otherwise, display the login screen
         *//*

        if (AuthenticationManager.isLoggedIn()) {
            onLoggedIn();

        }
    }

    public void onLoggedIn() {
        Intent intent = HealthTrackerActivity.newIntent(this);
        startActivity(intent);
        progressBar.setVisibility(View.INVISIBLE);
    }

    public void onLoginClick(View view) {
        progressBar.setVisibility(View.VISIBLE);
        */
/**
         *  3. Call login to show the login UI
         *//*

        boolean isFirstTime = SharedPreferenceHelper.isFirst(RootActivity.this);
        if (!isFirstTime) {
            AuthenticationManager.login(this);
        }
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        */
/**
         *  4. When the Login UI finishes, it will invoke the `onActivityResult` of this activity.
         *  We call `AuthenticationManager.onActivityResult` and set ourselves as a login listener
         *  (via AuthenticationHandler) to check to see if this result was a login result. If the
         *  result code matches login, the AuthenticationManager will process the login request,
         *  and invoke our `onAuthFinished` method.
         *
         *  If the result code was not a login result code, then `onActivityResult` will return
         *  false, and we can handle other onActivityResult result codes.
         *
         *//*


        if (!AuthenticationManager.onActivityResult(requestCode, resultCode, data, this)) {

            // Handle other activity results,if needed
        }

    }

    public void onAuthFinished(AuthenticationResult authenticationResult) {

        */
/**
         * 5. Now we can parse the auth response! If the auth was successful, we can continue onto
         *      the next activity. Otherwise, we display a generic error message here
         *//*

        if (authenticationResult.isSuccessful()) {
            onLoggedIn();
            finish();
        } else {
            displayAuthError(authenticationResult);
        }
    }

    private void displayAuthError(AuthenticationResult authenticationResult) {
        String message = "";

        switch (authenticationResult.getStatus()) {
            case dismissed:
                message = getString(R.string.login_dismissed);
                break;
            case error:
                message = authenticationResult.getErrorMessage();
                break;
            case missing_required_scopes:
                Set<Scope> missingScopes = authenticationResult.getMissingScopes();
                String missingScopesText = TextUtils.join(", ", missingScopes);
                message = getString(R.string.missing_scopes_error) + missingScopesText;
                break;
            default:
                break;
        }

        new AlertDialog.Builder(this)
                .setTitle(R.string.login_title)
                .setMessage(message)
                .setCancelable(false)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //Do something
                    }
                })
                .create()
                .show();
    }

    @Override
    public void onBackPressed() {
        Intent i = new Intent(RootActivity.this, DashboardActivity.class);
        startActivity(i);

    }
}
*/
