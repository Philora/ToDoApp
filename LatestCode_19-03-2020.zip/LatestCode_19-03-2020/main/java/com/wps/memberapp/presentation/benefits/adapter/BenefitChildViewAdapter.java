package com.wps.memberapp.presentation.benefits.adapter;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.model.BenefitUserProduct;

import java.util.List;

/**
 * This adapter is used to display Benefit Product Details to the user.
 */
public class BenefitChildViewAdapter extends RecyclerView.Adapter<BenefitChildViewAdapter.ProductViewHolder> {

    //This context will be used to inflate the layout
    private final Context mCtx;
    //We are storing all the product in a list
    private final List<BenefitUserProduct> mBenefitList;

    //getting the context and product list with constructor
    public BenefitChildViewAdapter(Context mCtx, List<BenefitUserProduct> mBenefitList) {
        this.mCtx = mCtx;
        this.mBenefitList = mBenefitList;
    }

    /*
Creating ViewHolder based on the layout to bind the data to adapter.
 */
    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.row_frag_benefit_limits, parent, false);
        return new ProductViewHolder(view);
    }

    /*
 Binding data to ViewHolder class object based on the position.
 */
    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, final int position) {
        if (mBenefitList != null && !mBenefitList.isEmpty()) {
            BenefitUserProduct product = mBenefitList.get(position);
            //Binding the data with the viewHolder views
            if (product.getDescription() != null && !product.getDescription().equals("null")) {
                holder.tvHeader.setText(product.getDescription());
            }
            if (product.getCoPay() != null && !product.getCoPay().equals("null")) {
                holder.tvAccumulatedAccountValue.setText(product.getCoPay());
            }
            if (product.getCoinsurance() != null && !product.getCoinsurance().equals("null")) {
                holder.tvRemainingValue.setText(product.getCoinsurance());
            }
            if (product.getDeductible() != null && !product.getDeductible().equals("null")) {
                holder.tvLimitedValue.setText(product.getDeductible());
            }
            if (product.getLimit() != null && !product.getLimit().equals("null")) {
                holder.tvLimitValue.setText(product.getLimit());
            }
        }
    }

    /*
    This method is used to get the items size in array list
     */
    @Override
    public int getItemCount() {
        if (mBenefitList != null) {
            return mBenefitList.size();
        } else {
            return 0;
        }
    }

    /*
       View Holder class to bind the data to views and will improve the performance.
     */
    class ProductViewHolder extends RecyclerView.ViewHolder {

        final TextView tvAccumulatedAccountValue;
        final TextView tvRemainingValue;
        final TextView tvLimitedValue;
        final TextView tvLimitValue;
        final TextView tvHeader;

        private ProductViewHolder(@NonNull View itemView) {
            super(itemView);
            tvHeader = itemView.findViewById(R.id.benefitLimitHeader);
            tvAccumulatedAccountValue = itemView.findViewById(R.id.accumulatedAccountValue);
            tvRemainingValue = itemView.findViewById(R.id.remainingValue);
            tvLimitedValue = itemView.findViewById(R.id.limitedValue);
            tvLimitValue = itemView.findViewById(R.id.limitValue);
        }

    }
}
