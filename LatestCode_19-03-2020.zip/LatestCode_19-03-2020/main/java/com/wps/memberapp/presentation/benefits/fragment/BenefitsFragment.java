package com.wps.memberapp.presentation.benefits.fragment;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import com.appdynamics.eumagent.runtime.Instrumentation;
import com.github.mikephil.charting.charts.BarChart;
import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.AccountBalance;
import com.wps.memberapp.data.model.AccountBalanceOOP;
import com.wps.memberapp.data.model.BenefitUserDetails;
import com.wps.memberapp.data.model.BenefitUserProduct;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.model.MemberEligibleInfo;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.presentation.base.BaseFragment;
import com.wps.memberapp.presentation.benefits.adapter.BenefitChildViewAdapter;
import com.wps.memberapp.presentation.claims.adapter.NothingSelectedSpinnerAdapter;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.CustomRecyclerView;
import com.wps.memberapp.utility.CustomScrollView;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;

/**
 * This fragment is used to display medical benefits to the user.
 */
public class BenefitsFragment extends BaseFragment implements BenefitsView, View.OnClickListener {

    //Member variables declaration
    private TextView tvMemberIdValue;
    private TextView tvMedicalPlanDetailView;
    private TextView tvDobDetailTextView;
    private TextView tvEffectiveDetailTextView;
    private TextView tvBenefitYearTextView;
    private TextView tvMemberName;
    private TextView familyText;
    private TextView individualText;
    private TextView familyTextOOP;
    private TextView individualTextOOP;
    private TextView txtHSBCValue;
    private LinearLayout llChartView;
    private LinearLayout llOOPChartView;
    private CustomRecyclerView recycleView;
    private BenefitsPresenter presenter;
    private AccountBalanceOOP mAccountOOPModel;
    private AccountBalance mAccountModel;
    //    Spanned spanned;
    Spinner spnMembersNames;
    private String mMemberName = "";
    MemberEligibleInfo info;


    /**
     * This override method is used to inflate the layout for Dashboard fragment
     *
     * @return rootView
     */
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if (getActivity() != null) {
            Instrumentation.start(StringConstants.APP_DYNAMICS_KEY, getActivity().getApplicationContext());
        }
        if (container != null) {
            container.removeAllViews();
            container.clearDisappearingChildren();
        }
        View rootView = inflater.inflate(R.layout.fragment_benefit, container, false);
        presenter = new BenefitsPresenterImpl();
        presenter.onAttach(this);
        recycleView = rootView.findViewById(R.id.recyclerBenefitDetailView);
        View view = rootView.findViewById(R.id.account_header);
        View oopView = rootView.findViewById(R.id.accountoop_header);
        spnMembersNames = rootView.findViewById(R.id.spin_member);
        info = ProfileDataCache.getInstance().getMemberEligibleInfo();
        if (info != null && StringConstants.LOB_WPS.equals(info.getLineOfBusiness()) && StringConstants.ENTITY_ID_MEDMARSOL.equals(info.getCurrentRelEntityID())) {
            view.setVisibility(View.GONE);
            oopView.setVisibility(View.GONE);
        }

        ScrollView scrollView = (CustomScrollView) rootView.findViewById(R.id.fragmentContainerScrollViewBenefits);
        recycleView.setHasFixedSize(true);

        //Setting title to fragment
        if (getActivity() != null) {
            TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
            fragmentTitle.setText(R.string.my_benefits);
            ImageView imageViewSearch = getActivity().findViewById(R.id.imageViewSearch);
            imageViewSearch.setVisibility(View.GONE);
            TextView txtDownloadPDF = getActivity().findViewById(R.id.txt_Call);
            txtDownloadPDF.setVisibility(View.GONE);
        }
        recycleView.setLayoutManager(new LinearLayoutManager(getActivity()));
        TextView tvDate = rootView.findViewById(R.id.datesSpinner);
        tvMemberIdValue = rootView.findViewById(R.id.memberIdValue);
        tvMedicalPlanDetailView = rootView.findViewById(R.id.medicalPlanDetailView);
        tvDobDetailTextView = rootView.findViewById(R.id.dobDetailTextView);
        tvEffectiveDetailTextView = rootView.findViewById(R.id.effectiveDetailTextView);
        tvBenefitYearTextView = rootView.findViewById(R.id.benefitYearTextView);
        tvMemberName = rootView.findViewById(R.id.spinnerMemberName);
        llChartView = rootView.findViewById(R.id.chartView);
        llOOPChartView = rootView.findViewById(R.id.oopChartView);
        familyText = rootView.findViewById(R.id.textViewFamily);
        individualText = rootView.findViewById(R.id.textViewIndividual);
        familyTextOOP = rootView.findViewById(R.id.textViewFamilyOOP);
        individualTextOOP = rootView.findViewById(R.id.textViewIndividualOOP);
        txtHSBCValue = rootView.findViewById(R.id.txt_HSBCValue);
        familyText.setOnClickListener(this);
        individualText.setOnClickListener(this);
        familyTextOOP.setOnClickListener(this);
        individualTextOOP.setOnClickListener(this);

/*        txtHSBCValue.setClickable(true);
        txtHSBCValue.setMovementMethod(LinkMovementMethod.getInstance());
        String text = "<a href='https://external.digitalhealth.nttdataservices.com/Customers/HealthGen/NTT_HIX_Portal_PlanDetailExample.pdf'> View </a>";
        txtHSBCValue.setText(Html.fromHtml(text));*/
        /*spanned = Html.fromHtml("<a href='https://external.digitalhealth.nttdataservices.com/Customers/HealthGen/NTT_HIX_Portal_PlanDetailExample.pdf/'>View</a>");
        txtHSBCValue.setMovementMethod(LinkMovementMethod.getInstance());
        txtHSBCValue.setText(spanned);*/
        txtHSBCValue.setOnClickListener(view1 -> {
            Uri uri = Uri.parse(AppConstants.MEDICAL_COVERAGE_PDF);
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        });

        //Touch listener to disable the scroll of the parent view
        recycleView.setOnTouchListener((v, event) -> {
            scrollView.requestDisallowInterceptTouchEvent(false);
            int action = event.getActionMasked();
            scrollView.performClick();
            if (action == MotionEvent.ACTION_UP) {
                scrollView.requestDisallowInterceptTouchEvent(false);
            }
            return false;
        });
        String today = GeneralUtils.getTodayDate();
        today = today.replace("-", "/");
        tvDate.setText(today);
        ProfileDataCache.getInstance().setBenefitEffectiveDate(today);

        //Calling BenefitUserDetails and Account balance related APIs if internet is available
        if (getActivity() != null) {
            if (GeneralUtils.isOnline(getActivity())) {
                presenter.getBenefitUserDetails(0);
                ProfileDataCache.getInstance().setPersonNumber(0);
               // presenter.getBenefitProductDetails();
               /* if (info != null && !StringConstants.ENTITY_ID_MEDMARSOL.equals(info.getCurrentRelEntityID())) {

                    presenter.getAccountBalance();
                    presenter.getAccountBalanceOOP();
                }*/
            } else {
                GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.login_no_internet));
            }
        }
        addItemsOnSpinner1();

        return rootView;
    }

    private void addItemsOnSpinner1() {
        if (getActivity() == null) {
            return;
        }
        //Creating adapter with member name values and setting to spinner
        List<String> list = new ArrayList<>();
        List<MemberDetails> memberDetailsList = ProfileDataCache.getInstance().getmMemberDetails();
        if (memberDetailsList != null) {
            for (MemberDetails details : memberDetailsList) {
                list.add(details.getFirstName() + " " + details.getLastName());
            }
        }
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(getActivity(),
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
       // spnMembersNames.setAdapter(new NothingSelectedSpinnerAdapter(dataAdapter, R.layout.benefits_member_name_spinner_hint, getActivity()));
        spnMembersNames.setAdapter(dataAdapter);
        //Added selected listener to get the selected data
        spnMembersNames.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                try {
                    ((TextView) adapterView.getChildAt(0)).setTextColor(Color.WHITE);
                    ((TextView) adapterView.getChildAt(0)).setPadding(5, 5, 5, 5);
                    if (spnMembersNames.getSelectedItem() != null) {
                        mMemberName = spnMembersNames.getSelectedItem().toString();
                        if (getActivity() != null) {
                            if (GeneralUtils.isOnline(getActivity())) {
                                presenter.getBenefitUserDetails(position);
                                ProfileDataCache.getInstance().setPersonNumber(position);
                               /* presenter.getBenefitProductDetails();
                                presenter.getAccountBalance();
                                presenter.getAccountBalanceOOP();*/
                                /* tried code
                                int posPersonNumber = position - 1;
                                ProfileDataCache.getInstance().setPersonNumber(posPersonNumber);
                                presenter.getBenefitUserDetails(posPersonNumber);
                                 */
                               /* if (info != null && !StringConstants.ENTITY_ID_MEDMARSOL.equals(info.getCurrentRelEntityID())) {
                                    presenter.getBenefitProductDetails();
                                    presenter.getAccountBalance();
                                    presenter.getAccountBalanceOOP();
                                }*/
                            } else {
                                GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.login_no_internet));
                            }
                        }
                    }
                } catch (Exception e) {
                    Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //Do something
            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.textViewFamily:
                familyText.setTypeface(null, Typeface.BOLD);
                individualText.setTypeface(null, Typeface.NORMAL);
                loadAccountBalanceDetails(true);
                break;
            case R.id.textViewIndividual:
                familyText.setTypeface(null, Typeface.NORMAL);
                individualText.setTypeface(null, Typeface.BOLD);
                loadAccountBalanceDetails(false);
                break;
            case R.id.textViewFamilyOOP:
                familyTextOOP.setTypeface(null, Typeface.BOLD);
                individualTextOOP.setTypeface(null, Typeface.NORMAL);
                loadAccountBalanceOOPDetails(true);
                break;
            case R.id.textViewIndividualOOP:
                familyTextOOP.setTypeface(null, Typeface.NORMAL);
                individualTextOOP.setTypeface(null, Typeface.BOLD);
                loadAccountBalanceOOPDetails(false);
                break;
            default:
        }
    }

    /*
     This method is used to load account balance out of packet details in BarChart
     */
    private void loadAccountBalanceOOPDetails(boolean isFamily) {
        if (mAccountOOPModel != null && getActivity() != null) {
            BarChart mBarChart = GeneralUtils.getVerticalChartResultsOOP(getActivity(), mAccountOOPModel, isFamily);
            llOOPChartView.removeAllViews();
            llOOPChartView.addView(mBarChart, new RecyclerView.LayoutParams
                    (RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.MATCH_PARENT));
        }
    }

    /*
     This method is used to load account balance details in BarChart
     */
    private void loadAccountBalanceDetails(boolean isFamily) {
        try {
            if (mAccountModel != null && getActivity() != null) {
                BarChart mBarChart = GeneralUtils.getVerticalChartResults(getActivity(), mAccountModel, isFamily);
                llChartView.removeAllViews();
                llChartView.addView(mBarChart, new RecyclerView.LayoutParams
                        (RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.MATCH_PARENT));
            }
        } catch (Exception e) {
            Logger.i(StringConstants.EXCEPTION, e);
        }
    }

    /*
     This method is a Call back for account balance API call result
     */
    @Override
    public void onAccountBalanceLoading(@NonNull AccountBalance balance) {
        presenter.getAccountBalanceOOP();
        mAccountModel = balance;
        loadAccountBalanceDetails(false);
    }

    /*
    This method is a Call back for account balance oop API call result
    */
    @Override
    public void onAccountBalanceOOPLoading(@NonNull AccountBalanceOOP balanceOOP) {
        mAccountOOPModel = balanceOOP;
        loadAccountBalanceOOPDetails(false);
    }

    /*
    This method is used to handle the response of benefit user details
     API response and bind the response to UI components
     */
    @Override
    public void onUserDetailsLoadingCompleted(@NonNull BenefitUserDetails details) {
        try {
            presenter.getBenefitProductDetails();
            String memberID = details.getSubscriberID() + "-" + details.getPersonNumber();
            tvMemberIdValue.setText(memberID);
            tvMedicalPlanDetailView.setSelected(true);
            tvMedicalPlanDetailView.setText(details.getPlanName());
            tvDobDetailTextView.setText(details.getDateOfBirth());
            tvEffectiveDetailTextView.setText(details.getCoverageDate());
            tvBenefitYearTextView.setText(details.getCoverageDate());
            String name = details.getFirstName() + " " + details.getLastName();
            tvMemberName.setText(name);
        } catch (Exception e) {
            Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
        }
    }

    /*
    This method is used to handle the response of benefit product details
     API response and bind the response to UI components
     */
    @Override
    public void onProductDetailsLoadingCompleted(@NonNull List<BenefitUserProduct> productsList) {
        presenter.getAccountBalance();
        if (!productsList.isEmpty()) {
            BenefitChildViewAdapter adapter = new BenefitChildViewAdapter(getActivity(), productsList);
            recycleView.setItemAnimator(new DefaultItemAnimator());
            recycleView.setAdapter(adapter);
            adapter.notifyDataSetChanged();
        }
    }
}
