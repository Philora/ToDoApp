package com.wps.memberapp.presentation.benefits.fragment;


import com.wps.memberapp.presentation.base.MvpPresenter;

/**
 * This interface contain all the Benefits functionality declarations.
 */
interface BenefitsPresenter extends MvpPresenter {
    void getBenefitUserDetails(int pos);

    void getBenefitProductDetails();

    void getAccountBalanceOOP();

    void getAccountBalance();
}
