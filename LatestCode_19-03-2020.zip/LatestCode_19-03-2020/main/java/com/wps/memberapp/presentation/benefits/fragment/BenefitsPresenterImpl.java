package com.wps.memberapp.presentation.benefits.fragment;

import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.AccountBalance;
import com.wps.memberapp.data.model.AccountBalanceOOP;
import com.wps.memberapp.data.model.BenefitUserDetails;
import com.wps.memberapp.data.model.BenefitUserProduct;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.base.MvpView;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * This class is used to implement all the Benefits functions which
 * are declared in BenefitsPresenter.
 */
public class BenefitsPresenterImpl implements BenefitsPresenter {

    private MvpView mView;

    @Override
    public void onAttach(MvpView mView) {
        this.mView = mView;
    }


    /*
    This method is used to Send API request to get the benefit user details
     */
    @Override
    public void getBenefitUserDetails(int pos) {
        //Used to display infinite progress dilog
        mView.showProgress();
        //Sending API request to get the benefit user details
        VolleyService.getBenefitUserDetailsReq(mView.getAppContext(), AppConstants.GET_BENEFIT_USER_DETAILS, new VolleyResponseListener() {
            @Override
            public void onResponse(String response) {
                mView.hideProgress();
                //Processing the response
                if (response != null) {
                    try {
                        Gson gson = new Gson();
                        JSONArray jsonArray = new JSONArray(response);
                        JSONObject jsonObject = jsonArray.getJSONObject(pos);
                        BenefitUserDetails details = gson.fromJson(jsonObject.toString(), BenefitUserDetails.class);
                        if(details!=null){
                            ProfileDataCache.getInstance().setmBenefitUserDetails(details);
                            if (details.getProductCode() != null) {
                                ProfileDataCache.getInstance().setProductCode(details.getProductCode());
                            }
                            if (details.getCoverageEndDate() != null) {
                                ProfileDataCache.getInstance().setCoverageEndDate(details.getCoverageEndDate());
                            }
                        }
                        ((BenefitsView) mView).onUserDetailsLoadingCompleted(details);
                    } catch (Exception e) {
                        Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
                    }
                }
            }
            @Override
            public void onError(String error) {
                mView.hideProgress();
            }
        });
    }

    /*
   This method is used to Send API request to get the account balance of the user
    */
    @Override
    public void getAccountBalance() {

        //Sending API request to get the account balance of the user
        VolleyService.getAccountBalanceBenefitData(mView.getAppContext(), AppConstants.GET_ACCOUNT_BALANCE, new VolleyResponseListener() {
            @Override
            public void onError(String error) {
                Log.e("Account Error", error);
            }

            @Override
            public void onResponse(String response) {

                //Processing the response
                if (response != null && response.length() > 0) {
                    try {
                        Gson gson = new GsonBuilder().create();
                        String jsonObject = new JSONObject(response).get(StringConstants.BENEFITS_KEY).toString();
                        AccountBalance mAccountModel = gson.fromJson(jsonObject, AccountBalance.class);
                        ((BenefitsView) mView).onAccountBalanceLoading(mAccountModel);
                    } catch (Exception e) {
                        Log.e("Account", StringConstants.EXCEPTION);
                    }
                }
            }
        });
    }

    /*
  This method is used to Send API request to get the account balance OOP of the user
  */
    @Override
    public void getAccountBalanceOOP() {

        //Sending API request to get the account balance of the user
        VolleyService.getAccountBalanceBenefitOOP(mView.getAppContext(), AppConstants.GET_ACCOUNT_BALANCE_OOP, new VolleyResponseListener() {
            @Override
            public void onError(String error) {
                Log.e("Account OOP Error", error);
            }

            @Override
            public void onResponse(String response) {

                //Processing the response
                if (response != null && response.length() > 0) {
                    try {
                        Gson gson = new GsonBuilder().create();
                        String jsonObject = new JSONObject(response).get(StringConstants.BENEFITS_KEY).toString();
                        AccountBalanceOOP mAccountOOPModel = gson.fromJson(jsonObject, AccountBalanceOOP.class);
                        ((BenefitsView) mView).onAccountBalanceOOPLoading(mAccountOOPModel);
                    } catch (Exception e) {
                        Log.e("Account OOP", StringConstants.EXCEPTION);
                    }
                }
            }
        });
    }

    /*
   This method is used to Send API request to get the benefit product details of the user
   */
    @Override
    public void getBenefitProductDetails() {

        //Sending API request to get the benefit product details
        VolleyService.getBenefitProductDetailsReq(mView.getAppContext(), AppConstants.GET_BENEFIT_PRODUCT_DETAILS, new VolleyResponseListener() {
            @Override
            public void onResponse(String response) {
                mView.hideProgress();
                if (response != null) {
                    //Processing the response
                    try {
                        Gson gson = new Gson();
                        List<BenefitUserProduct> productList = new ArrayList<>();
                        JSONArray jsonArray = new JSONObject(response).getJSONArray("MemberProductBSDLList");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            BenefitUserProduct details = gson.fromJson(jsonObject.toString(), BenefitUserProduct.class);
                            productList.add(details);
                        }
                        ((BenefitsView) mView).onProductDetailsLoadingCompleted(productList);
                    } catch (Exception e) {
                        Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
                    }
                }
            }

            @Override
            public void onError(String error) {
                //Do something
                mView.hideProgress();
            }
        });
    }

    @Override
    public void onDetach() {
        mView = null;
    }
}
