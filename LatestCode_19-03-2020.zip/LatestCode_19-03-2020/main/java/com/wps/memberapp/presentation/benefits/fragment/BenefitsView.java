package com.wps.memberapp.presentation.benefits.fragment;

import com.wps.memberapp.data.model.AccountBalance;
import com.wps.memberapp.data.model.AccountBalanceOOP;
import com.wps.memberapp.data.model.BenefitUserDetails;
import com.wps.memberapp.data.model.BenefitUserProduct;
import com.wps.memberapp.presentation.base.MvpView;

import java.util.List;

/**
 * This interface contain UI functions of benefits screen
 */
interface BenefitsView extends MvpView {
    void onUserDetailsLoadingCompleted(BenefitUserDetails details);

    void onProductDetailsLoadingCompleted(List<BenefitUserProduct> productsList);

    void onAccountBalanceLoading(AccountBalance balance);

    void onAccountBalanceOOPLoading(AccountBalanceOOP balanceOOP);
}
