package com.wps.memberapp.presentation.claims.adapter;

import android.app.Activity;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.model.ClaimDetail;
import com.wps.memberapp.data.model.ClaimDiagnosis;
import com.wps.memberapp.data.model.CoInsurance;
import com.wps.memberapp.data.model.Deductible;

/**
 * This adapter is used to display claim detail information to the user.
 */
public class ClaimDetailChildViewAdapter extends RecyclerView.Adapter<ClaimDetailChildViewAdapter.ProductViewHolder> {

    //This context will be used to inflate the layout

    private final Context mCtx;
    //We are storing all the product in a list
    private final ClaimDetail mClaimList;

    //getting the context and product list with constructor
    public ClaimDetailChildViewAdapter(Activity mCtx, ClaimDetail mClaimList) {
        this.mCtx = mCtx;
        this.mClaimList = mClaimList;
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.frag_claim_detail_child_view, parent, false);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, final int position) {

        //Binding the data with the viewHolder views
        if (mClaimList != null && mClaimList.getDiagnosisDetails() != null) {
            ClaimDiagnosis details = mClaimList.getDiagnosisDetails().get(position);
            if (details != null) {
                if (details.getDateofservice() != null && details.getDateofservice().length() > 0 && !details.getDateofservice().equals("null")) {
                    holder.tvServiceDate.setText(String.valueOf(details.getDateofservice()));
                }
                if (details.getProcedureCodeName() != null && details.getProcedureCodeName().length() > 0 && !details.getProcedureCodeName().equals("null")) {
                    holder.tvProcedureCode.setText(String.valueOf(details.getProcedureCodeName()));
                }
                if (details.getBilledAmount() != null && details.getBilledAmount().length() > 0 && !details.getBilledAmount().equals("null")) {
                    String billedAmount = "$" + details.getBilledAmount();
                    holder.tvAmountBilled.setText(billedAmount);
                }
                updateUI(details, holder);
            }
        }
    }

    /*
    Updating claim diagnosis related details to ProductViewHolder
     */
    private void updateUI(ClaimDiagnosis details, @NonNull ProductViewHolder holder) {
        if (details.getYourPlanPaid() != null && details.getYourPlanPaid().length() > 0 && !details.getYourPlanPaid().equals("null")) {
            String planPaid = "$" + details.getYourPlanPaid();
            holder.tvPlanPaid.setText(planPaid);
        }
        if (details.getPlanDiscount() != null && details.getPlanDiscount().length() > 0 && !details.getPlanDiscount().equals("null")) {
            String planDiscount = "$" + details.getPlanDiscount();
            holder.tvPlanDiscount.setText(planDiscount);
        }
        if (details.getYourResponsibility() != null && details.getYourResponsibility().length() > 0 && !details.getYourResponsibility().equals("null")) {
            String responsibility = "$" + details.getYourResponsibility();
            holder.tvResponsibility.setText(responsibility);
        }
        if (details.getCoPayAmount() != null && !details.getCoPayAmount().equals("null")) {
            String coPay = "$" + details.getCoPayAmount();
            holder.tvCoPay.setText(coPay);
        } else {
            holder.tvCoPay.setText("$0.00");
        }
        CoInsurance insurance = details.getCoInsurance();
        if (insurance != null && insurance.getAmount() != null && !insurance.getAmount().equals("null")) {
            String insuranceValue = "$" + insurance.getAmount();
            holder.tvInsurance.setText(insuranceValue);
        } else {
            holder.tvInsurance.setText("$0.00");
        }
        Deductible deductible = details.getDeductible();
        if (deductible != null && deductible.getAmount() != null && !deductible.getAmount().equals("null")) {
            String deductibleValue = "$" + deductible.getAmount();
            holder.tvDeductible.setText(deductibleValue);
        } else {
            holder.tvDeductible.setText("$0.00");
        }
    }

    /*
 This method is used to get the items size in array list
*/
    @Override
    public int getItemCount() {
        if (mClaimList != null && mClaimList.getDiagnosisDetails() != null) {
            return mClaimList.getDiagnosisDetails().size();
        } else {
            return 0;
        }
    }

    /**
     * This class is used to bind the  claim diagnosis related data in adapter
     */
    class ProductViewHolder extends RecyclerView.ViewHolder {

        //Member variables
        final TextView tvServiceDate;
        final TextView tvProcedureCode;
        final TextView tvAmountBilled;
        final TextView tvPlanPaid;
        final TextView tvPlanDiscount;
        final TextView tvResponsibility;
        final TextView tvCoPay;
        final TextView tvInsurance;
        final TextView tvDeductible;

        private ProductViewHolder(@NonNull View itemView) {
            super(itemView);

            //Initializing views
            tvServiceDate = itemView.findViewById(R.id.serviceDateTextView);
            tvProcedureCode = itemView.findViewById(R.id.procedureCodeTextView);
            tvProcedureCode.setSelected(true);
            tvAmountBilled = itemView.findViewById(R.id.amountBilledValue);
            tvPlanPaid = itemView.findViewById(R.id.planPaidValue);
            tvPlanDiscount = itemView.findViewById(R.id.planDiscountValue);
            tvResponsibility = itemView.findViewById(R.id.responsibilityValue);
            tvCoPay = itemView.findViewById(R.id.coPayValue);
            tvInsurance = itemView.findViewById(R.id.insuranceValue);
            tvDeductible = itemView.findViewById(R.id.deductibleValue);
        }

    }
}
