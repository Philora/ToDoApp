package com.wps.memberapp.presentation.claims.adapter;

import android.app.Activity;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.model.ClaimDetail;
import com.wps.memberapp.data.model.ClaimDiagnosis;
import com.wps.memberapp.data.model.CoInsurance;
import com.wps.memberapp.data.model.Deductible;

/**
 * This adapter is used to display claim detail information to the user.
 */
public class ClaimDetailDentalViewAdapter extends RecyclerView.Adapter<ClaimDetailDentalViewAdapter.ProductViewHolder> {

    //This context will be used to inflate the layout
    private final Context mCtx;
    private final ClaimDetail mClaimList;

    //getting the context and product list with constructor
    public ClaimDetailDentalViewAdapter(Activity mCtx, ClaimDetail mClaimList) {
        this.mCtx = mCtx;
        this.mClaimList = mClaimList;
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.frag_child_claim_denatl_, parent, false);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, final int position) {
        try {
            //Binding the data with the viewHolder views
            if (mClaimList != null && mClaimList.getDiagnosisDetails() != null) {
                // Record of Services Provided
                String mFromDateofService = mClaimList.getFromDateofService();
                if (mFromDateofService != null && !mFromDateofService.isEmpty() && !mFromDateofService.equalsIgnoreCase("null")) {
                    holder.txtProcedureDate.setText(mFromDateofService);
                } else {
                    holder.txtProcedureDate.setText("N/A");
                }
                ClaimDiagnosis details = mClaimList.getDiagnosisDetails().get(position);
                if (details != null) {
                    String mProcedureCodeName = details.getProcedureCodeName();
                    String[] parts = mProcedureCodeName.split(", ");
                    String mProcedureCode = parts[0];
                    String mProcedureName = parts[1];
                    holder.txtProcCode.setText(mProcedureCode);
                    holder.txtDentDesc.setText(mProcedureName);
                    String mBilledAmount = details.getBilledAmount();
                    holder.txtAmountBilled.setText(mBilledAmount);
                    String mStatus = details.getStatus();
                    holder.txtDentClaimLineStatus.setText(mStatus);

                    String mService = details.getTypeOfService().getCode();
                    if (mService != null && !mService.isEmpty() && !mService.equalsIgnoreCase("null")) {
                        holder.txtServiceType.setText(mService);
                    } else {
                        holder.txtServiceType.setText("N/A");
                    }

                    String mOralCavity = details.getORAL_CAVITY();
                    if (mOralCavity != null && !mOralCavity.isEmpty() && !mOralCavity.equalsIgnoreCase("null")) {
                        holder.txtOralCavity.setText(mOralCavity);
                    } else {
                        holder.txtOralCavity.setText("N/A");
                    }
                }
            }
        } catch (Exception e) {
            e.getLocalizedMessage();
        }
    }

    /* This method is used to get the items size in array list */
    @Override
    public int getItemCount() {
        if (mClaimList != null) {
            return mClaimList.getDiagnosisDetails().size();
        } else {
            return 0;
        }
    }

    /* This class is used to bind the  claim diagnosis related data in adapter */
    class ProductViewHolder extends RecyclerView.ViewHolder {

        TextView txtProcedureDate;
        TextView txtProcCode;
        TextView txtServiceType;
        TextView txtDentDesc;
        TextView txtAmountBilled;
        TextView txtDentClaimLineStatus;
        TextView txtOralCavity;

        private ProductViewHolder(@NonNull View itemView) {
            super(itemView);

            //Initializing views
            txtProcedureDate = itemView.findViewById(R.id.txt_ProcedureDate);
            txtProcCode = itemView.findViewById(R.id.txt_ProcCode);
            txtServiceType = itemView.findViewById(R.id.txt_ServiceType);
            txtDentDesc = itemView.findViewById(R.id.txt_DentDesc);
            txtAmountBilled = itemView.findViewById(R.id.txt_AmountBilled);
            txtDentClaimLineStatus = itemView.findViewById(R.id.txt_DentClaimLineStatus);
            txtOralCavity = itemView.findViewById(R.id.txt_OralCavity);

        }

    }
}

