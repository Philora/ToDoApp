package com.wps.memberapp.presentation.claims.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.ClaimList;
import com.wps.memberapp.domain.listener.DialogCallbackContract;
import com.wps.memberapp.presentation.claims.fragment.ClaimDetailViewFragment;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

/**
 * This adapter is used to display the list of claims of the user
 * as a list view.
 */
public class ClaimsPagerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>
        implements DialogCallbackContract {

    //This context will be used to inflate the layout
    private static final int BODY = 0;
    private static final int FOOTER = 1;
    private final Context mCtx;
    private final AppCompatActivity mActivity;
    //We are storing all the product in a list
    private final List<ClaimList> mClaimList;

    //getting the context and product list with constructor
    public ClaimsPagerAdapter(Context mCtx, AppCompatActivity mActivity, List<ClaimList> mClaimList) {
        this.mCtx = mCtx;
        this.mClaimList = mClaimList;
        this.mActivity = mActivity;
    }

    /*
    Creating ViewHolder based on the layout to bind the data to adapter.
     */
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.fragment_claim_detail, parent, false);
        return new ProductViewHolder(view);
    }

    /*
     Binding data to ViewHolder class object based on the position.
     */
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {

        if (mClaimList != null && !mClaimList.isEmpty() && holder instanceof ProductViewHolder) {
            //getting the product of the specified position
            final ClaimList claimDetails = mClaimList.get(position);
            //Binding the data with the viewHolder views
            if (claimDetails.getMemberFeed() != null && claimDetails.getMemberFeed().getFirstName() != null && claimDetails.getMemberFeed().getLastName() != null
                    && !claimDetails.getMemberFeed().getFirstName().equals("null") && !claimDetails.getMemberFeed().getLastName().equals("null")) {
                String name = claimDetails.getMemberFeed().getFirstName() + "  " + claimDetails.getMemberFeed().getLastName();
                ((ProductViewHolder) holder).tvTitle.setText(name);
            }
            updateUI(claimDetails, ((ProductViewHolder) holder));
            ((ProductViewHolder) holder).tvPlanDiscount.setText(String.valueOf("$" + claimDetails.getPlanDiscount()));
            ((ProductViewHolder) holder).cardView.setOnClickListener(view -> {
                ClaimDetailViewFragment claimDetailView = new ClaimDetailViewFragment();
                Bundle args = new Bundle();
                if (claimDetails.getNumber() != null && !claimDetails.getNumber().equals("null") && !claimDetails.getNumber().isEmpty()) {
                    args.putString("claimNumber", claimDetails.getNumber());
                    ProfileDataCache.getInstance().setEncryptClaimNumber(claimDetails.getEncryptNumber());
                    ProfileDataCache.getInstance().setHashCode(claimDetails.getHashCode());
                }
                if (claimDetails.getClaimType() != null && !claimDetails.getClaimType().equals("null") && !claimDetails.getClaimType().isEmpty()) {
                    String mResClaimsType = claimDetails.getClaimType();
                    if (mResClaimsType.equalsIgnoreCase(StringConstants.DENTAL)) {
                        mResClaimsType = mResClaimsType.replace(StringConstants.DENTAL, StringConstants.DENTCLAIMDETAILS);
                    } else if (mResClaimsType.equalsIgnoreCase(StringConstants.PHARMACY)) {
                        mResClaimsType = mResClaimsType.replace(StringConstants.PHARMACY, StringConstants.PHARMCLAIMDETAILS);
                    } else if (mResClaimsType.equalsIgnoreCase(StringConstants.PROFESSIONAL)) {
                        mResClaimsType = mResClaimsType.replace(StringConstants.PROFESSIONAL, StringConstants.PROF_CLAIMDETAILS);
                    } else if (mResClaimsType.equalsIgnoreCase(StringConstants.INSTITUTIONAL)) {
                        mResClaimsType = mResClaimsType.replace(StringConstants.INSTITUTIONAL, StringConstants.INSTCLAIMDETAILS);
                    }
                    ProfileDataCache.getInstance().setClaimType(mResClaimsType);
                }
                if (claimDetails.getStatus() != null && !claimDetails.getStatus().isEmpty()) {
                    String mStatus = claimDetails.getStatus();
                    args.putString("status", mStatus);
                }
                if (claimDetails.getMemberFeed() != null && claimDetails.getMemberFeed().getFirstName() != null && claimDetails.getMemberFeed().getLastName() != null
                        && !claimDetails.getMemberFeed().getFirstName().equals("null") && !claimDetails.getMemberFeed().getLastName().equals("null")) {
                    args.putString("name", claimDetails.getMemberFeed().getFirstName() + "  " + claimDetails.getMemberFeed().getLastName());
                }
                if (claimDetails.getDate() != null && !claimDetails.getDate().equals("null")) {
                    args.putString("date", claimDetails.getDate());
                }
                claimDetailView.setArguments(args);
                mActivity.getSupportFragmentManager().beginTransaction().
                        replace(R.id.frame_container, claimDetailView).addToBackStack(null).commit();
            });
        }
    }

    /*
    Updating claim related details to ProductViewHolder
     */
    private void updateUI(ClaimList claimDetails, @NonNull ProductViewHolder holder) {
        if (claimDetails.getNumber() != null && !claimDetails.getNumber().equals("null") && !claimDetails.getNumber().isEmpty()) {
            holder.tvClaimNumber.setText(claimDetails.getNumber());
        }
        if (claimDetails.getDate() != null && !claimDetails.getDate().equals("null")) {
            holder.tvdobValue.setText(claimDetails.getDate());
        }
        if (claimDetails.getStatus() != null && !claimDetails.getStatus().equals("null") && !claimDetails.getStatus().isEmpty()) {
            holder.tvStatus.setText(String.valueOf(claimDetails.getStatus()));
        }
        if (claimDetails.getProvider() != null && claimDetails.getProvider().getFirstName() != null && claimDetails.getProvider().getLastName() != null
                && !claimDetails.getProvider().getFirstName().equals("null") && !claimDetails.getProvider().getLastName().equals("null")) {
            holder.tvProviderDetail.setText(String.valueOf(claimDetails.getProvider().getFirstName()
                    + StringConstants.SPACE_SINGLE + claimDetails.getProvider().getLastName()));
        }

        // three validations check
        if (claimDetails.getTotalBilledAmount() != null && !claimDetails.getTotalBilledAmount().equals("null") && !claimDetails.getTotalBilledAmount().isEmpty()) {
            holder.tvAmountBilled.setText(getFormattedValue(claimDetails.getTotalBilledAmount()));
        }

        if (claimDetails.getPlanPaid() != null && !claimDetails.getPlanPaid().equals("null") && !claimDetails.getPlanPaid().isEmpty()) {
            holder.tvPlanPaid.setText(getFormattedValue(claimDetails.getPlanPaid()));
        }

        if (claimDetails.getDeductible() != null && !claimDetails.getDeductible().equals("null") && !claimDetails.getDeductible().isEmpty()) {
            holder.tvDeductible.setText(getFormattedValue(claimDetails.getDeductible()));
        } else {
            holder.tvDeductible.setText("$0.00");
        }
    }

    @SuppressLint("DefaultLocale")
    private String getFormattedValue(String data) {
        try {
            String value = data.replace(",", "");
            double mDoubleFormat = Double.parseDouble(value);
            value = String.format("%.2f", mDoubleFormat);
            return "$" + value;
        } catch (Exception e) {
            Logger.e(StringConstants.EXCEPTION, e);
        }
        return "$0.00";
    }

    /*
    Getting item view type based on the position
     */
    @Override
    public int getItemViewType(int position) {
        return mClaimList.size();
    }

    /*
 This method is used to get the items size in array list
*/
    @Override
    public int getItemCount() {
        if (mClaimList != null) {
            return mClaimList.size();
        } else {
            return 0;
        }
    }

    /**
     * This class is used to bind the claims data in claims pager adapter
     */
    class ProductViewHolder extends RecyclerView.ViewHolder {

        //Member variables
        final TextView tvTitle;
        final TextView tvClaimNumber;
        final TextView tvdobValue;
        final TextView tvStatus;
        final TextView tvProviderDetail;
        final TextView tvAmountBilled;
        final TextView tvPlanPaid;
        final TextView tvPlanDiscount;
        final TextView tvDeductible;
        final CardView cardView;

        private ProductViewHolder(@NonNull View itemView) {
            super(itemView);

            //Initializing views
            cardView = itemView.findViewById(R.id.claimReferalCardView);
            tvTitle = itemView.findViewById(R.id.claimDetailHeadingTxt);
            tvClaimNumber = itemView.findViewById(R.id.claimDetailNumberValue);
            tvdobValue = itemView.findViewById(R.id.dobClaimValue);
            tvStatus = itemView.findViewById(R.id.statusDetailTextView);
            tvProviderDetail = itemView.findViewById(R.id.referringNameDetailTextView);
            tvAmountBilled = itemView.findViewById(R.id.amountBilledDetailTextView);
            tvPlanPaid = itemView.findViewById(R.id.planPaidDetailTextView);
            tvPlanDiscount = itemView.findViewById(R.id.planDiscountTextView);
            tvDeductible = itemView.findViewById(R.id.deductibleTextView);
            tvProviderDetail.setSelected(true);
        }
    }

//    private class ProgressViewHolder extends RecyclerView.ViewHolder {
//        private ProgressViewHolder(@NonNull View itemView) {
//            super(itemView);
//        }
//    }

}
