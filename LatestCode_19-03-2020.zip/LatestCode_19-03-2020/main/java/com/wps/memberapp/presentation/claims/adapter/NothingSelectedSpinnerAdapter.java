package com.wps.memberapp.presentation.claims.adapter;


import android.content.Context;
import android.database.DataSetObserver;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.SpinnerAdapter;

/**
 * Adapter to allow a Spinner to show a 'Nothing Selected...' initially
 * displayed instead of the first choice in the Adapter.
 */
public class NothingSelectedSpinnerAdapter implements SpinnerAdapter, ListAdapter {

    private static final int EXTRA = 1;
    private final SpinnerAdapter spnAdapter;
    private final Context mContext;
    private final int mNothingSelectedLayout;
    private final int mNothingSelectedDropdownLayout;
    private final LayoutInflater mLayoutInflater;

    /**
     * Use this constructor to have NO 'Select One...' item, instead use
     * the standard prompt or nothing at all.
     *
     * @param spinnerAdapter         wrapped Adapter.
     * @param mNothingSelectedLayout layout for nothing selected, perhaps
     *                               you want text grayed out like a prompt...
     */
    public NothingSelectedSpinnerAdapter(
            SpinnerAdapter spinnerAdapter,
            int mNothingSelectedLayout, Context mContext) {
        this.spnAdapter = spinnerAdapter;
        this.mContext = mContext;
        this.mNothingSelectedLayout = mNothingSelectedLayout;
        this.mNothingSelectedDropdownLayout = -1;
        mLayoutInflater = LayoutInflater.from(mContext);
    }


    @Override
    public final View getView(int position, View convertView, ViewGroup parent) {
        // This provides the View for the Selected Item in the Spinner, not
        // the dropdown (unless dropdownView is not set).
        if (position == 0) {
            return getNothingSelectedView(parent);
        }
        return spnAdapter.getView(position - EXTRA, null, parent); // Could re-use
        // the convertView if possible.
    }

    /**
     * View to show in Spinner with Nothing Selected
     * Override this to do something dynamic... e.g. "37 Options Found"
     */
    private View getNothingSelectedView(ViewGroup parent) {
        return mLayoutInflater.inflate(mNothingSelectedLayout, parent, false);
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        // Android BUG! http://code.google.com/p/android/issues/detail?id=17128 -
        // Spinner does not support multiple view types
        if (position == 0) {
            return mNothingSelectedDropdownLayout == -1 ?
                    new View(mContext) :
                    getNothingSelectedDropdownView(parent);
        }

        // Could re-use the convertView if possible, use setTag...
        return spnAdapter.getDropDownView(position - EXTRA, null, parent);
    }

    /**
     * Override this to do something dynamic... For example, "Pick your favorite
     * of these 37".
     */
    private View getNothingSelectedDropdownView(ViewGroup parent) {
        return mLayoutInflater.inflate(mNothingSelectedDropdownLayout, parent, false);
    }

    @Override
    public int getCount() {
        int count = spnAdapter.getCount();
        return count == 0 ? 0 : count + EXTRA;
    }


    @Override
    public Object getItem(int position) {
        return position == 0 ? null : spnAdapter.getItem(position - EXTRA);
    }

    @Override
    public int getItemViewType(int position) {
        return 0;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public long getItemId(int position) {
        return position >= EXTRA ? spnAdapter.getItemId(position - EXTRA) : position - EXTRA;
    }

    @Override
    public boolean hasStableIds() {
        return spnAdapter.hasStableIds();
    }

    @Override
    public boolean isEmpty() {
        return spnAdapter.isEmpty();
    }

    @Override
    public void registerDataSetObserver(DataSetObserver observer) {
        spnAdapter.registerDataSetObserver(observer);
    }

    @Override
    public void unregisterDataSetObserver(DataSetObserver observer) {
        spnAdapter.unregisterDataSetObserver(observer);
    }

    @Override
    public boolean areAllItemsEnabled() {
        return false;
    }

    @Override
    public boolean isEnabled(int position) {
        return position != 0; // Don't allow the 'nothing selected'
        // item to be picked.
    }

}
