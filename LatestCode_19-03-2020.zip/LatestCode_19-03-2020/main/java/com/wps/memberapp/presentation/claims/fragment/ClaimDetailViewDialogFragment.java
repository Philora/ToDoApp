package com.wps.memberapp.presentation.claims.fragment;

import android.app.DatePickerDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.AdvanceSearchFilters;
import com.wps.memberapp.data.model.ClaimList;
import com.wps.memberapp.data.model.ClaimSearchResults;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.claims.adapter.NothingSelectedSpinnerAdapter;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.DatePickerFragment;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * A Screen which will display dialog to search claim based on start and end date
 */

public class ClaimDetailViewDialogFragment extends DialogFragment {

    //Declaring member variables

    @BindView(R.id.claimmemberName)
    Spinner spnMemberName;

    @BindView(R.id.claimStatus)
    Spinner spnClaimStatus;

    @BindView(R.id.claimType)
    Spinner spnClaimType;

    @BindView(R.id.imgclaimCalendar)
    ImageView ivCalendarView1;

    @BindView(R.id.imgclaimCalendar2)
    ImageView ivCalendarView2;

    @BindView(R.id.txtclaimStartDate)
    TextView tvStartDate;

    @BindView(R.id.txtclaimEndDate)
    TextView tvEndDate;

    @BindView(R.id.btnclaimSearch)
    Button btnSearch;

    @BindView(R.id.btnCancel)
    Button btnCancel;

    @BindView(R.id.close)
    ImageView ivClose;
    @NonNull
    private String mMemberName = "";
    @NonNull
    private String mStartDate = "";
    @NonNull
    private String mEndDate = "";
    @NonNull
    private String mClaimStatus = "";
    private String mAuthorizationType = "";
    private DialogCallbackContract mListener;
    private Unbinder mUnbinder;
    private List<ClaimList> claimList;
    private AdvanceSearchFilters mSearchFilters;
    private ClaimsPresenter mClaimsPresenter;


    //required constructor
    public void setListener(DialogCallbackContract listener) {
        mListener = listener;
    }

    //Callback interface
    interface DialogCallbackContract {
        void returnData(List<ClaimList> claimList);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NORMAL, R.style.DialogFragmentTheme);
    }


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        View rootView = inflater.inflate(R.layout.frag_claim_search, container, false);
        mSearchFilters = new AdvanceSearchFilters();
        mClaimsPresenter = new ClaimsPresenterImpl();
        mUnbinder = ButterKnife.bind(this, rootView);
        ivClose.setOnClickListener(view -> dismiss());
        addItemsOnSpinner2();
        addItemsOnSpinner1();
        return rootView;
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ivCalendarView1.setOnClickListener(v -> showDatePickerforCalendar());
        ivCalendarView2.setOnClickListener(v -> showDatePickerforCalendarNew());
        btnSearch.setOnClickListener(view1 -> {
            if (getActivity() != null) {
                if (GeneralUtils.isOnline(getActivity())) {
                    getAdvanceSearchDetails();
                } else {
                    GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.login_no_internet));
                }
            }
        });
        btnCancel.setOnClickListener(view12 -> dismiss());
    }

    /*
  Adding claims status to spinner by creating adapter
   */
    private void addItemsOnSpinner2() {
        if (getActivity() == null) {
            return;
        }
        //Creating adapter with claim status values and setting to spinner
        List<String> list = Arrays.asList(getActivity().getResources().getStringArray(R.array.claim_status));
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(getActivity(),
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnClaimStatus.setAdapter(new NothingSelectedSpinnerAdapter(
                dataAdapter,
                R.layout.claim_status_spinner_hint,
                // R.layout.contact_spinner_nothing_selected_dropdown, // Optional
                getActivity()));

        //Added selected listener to get the selected data
        spnClaimStatus.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                try {
                    if (spnClaimStatus.getSelectedItem() != null) {
//                        mClaimStatus = spnClaimStatus.getSelectedItem().toString();
                        switch (i) {
                            case 1:
                                mClaimStatus = "D";
                                break;
                            case 2:
                                mClaimStatus = "R";
                                break;
                            case 3:
                                mClaimStatus = "I";
                                break;
                            case 4:
                                mClaimStatus = "A";
                                break;
                            case 5:
                                mClaimStatus = "P";
                                break;
                            default:
                        }
                        mSearchFilters.setStatus(mClaimStatus);
                    }
                } catch (Exception e) {
                    Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //Do something
            }
        });

        if (getActivity() == null) {
            return;
        }
        //Creating adapter with claim status values and setting to spinner
        List<String> claimListType = Arrays.asList(getActivity().getResources().getStringArray(R.array.claim_type));
        ArrayAdapter<String> dataTypeAdapter = new ArrayAdapter<>(getActivity(),
                android.R.layout.simple_spinner_item, claimListType);
        dataTypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnClaimType.setAdapter(new NothingSelectedSpinnerAdapter(
                dataTypeAdapter,
                R.layout.claim_type_spinner_hint,
                // R.layout.contact_spinner_nothing_selected_dropdown, // Optional
                getActivity()));

        //Added selected listener to get the selected data

        spnClaimType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                try {
                    if (spnClaimType.getSelectedItem() != null) {
                        mAuthorizationType = spnClaimType.getSelectedItem().toString();
                        mSearchFilters.setClaimtype(mAuthorizationType);
                    }
                } catch (Exception e) {
                    Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //Do something
            }
        });

    }

    /*
Adding member names to spinner by creating adapter with member details
 */
    private void addItemsOnSpinner1() {
        if (getActivity() == null) {
            return;
        }
        //Creating adapter with member name values and setting to spinner
        List<String> list = new ArrayList<>();
        List<MemberDetails> memberDetailsList = ProfileDataCache.getInstance().getmMemberDetails();
        for (MemberDetails details : memberDetailsList) {
            list.add(details.getFirstName() + " " + details.getLastName());
        }
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(getActivity(),
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnMemberName.setAdapter(new NothingSelectedSpinnerAdapter(
                dataAdapter,
                R.layout.authorization_member_name_spinner_hint,
                // R.layout.contact_spinner_nothing_selected_dropdown, // Optional
                getActivity()));

        //Added selected listener to get the selected data
        spnMemberName.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                try {
                    if (spnMemberName.getSelectedItem() != null) {
                        mMemberName = spnMemberName.getSelectedItem().toString();
                        mSearchFilters.setName(mMemberName);
                    }
                } catch (Exception e) {
                    Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //Do something
            }
        });
    }

    /*
Used to show date picker dialog to user
*/
    private void showDatePickerforCalendar() {
        DatePickerFragment date = new DatePickerFragment();
        // Set up Current Date into Dialog
        Calendar calender = Calendar.getInstance();
        Bundle args = new Bundle();
        args.putInt("year", calender.get(Calendar.YEAR));
        args.putInt("month", calender.get(Calendar.MONTH));
        args.putInt("day", calender.get(Calendar.DAY_OF_MONTH));
        args.putString("CustomDatePicker", "ClaimsDatePicker");
        date.setArguments(args);
        //Set Call back to capture selected date
        date.setCallBack(ondate);
        if (getFragmentManager() != null) {
            date.show(getFragmentManager(), "DatePicker");
        }
    }

    /*
   Used to show date picker dialog to user
    */
    private void showDatePickerforCalendarNew() {
        DatePickerFragment date = new DatePickerFragment();

        //Set Up current Date into dialog

        Calendar calender = Calendar.getInstance();
        Bundle args = new Bundle();
        args.putInt("year", calender.get(Calendar.YEAR));
        args.putInt("month", calender.get(Calendar.MONTH));
        args.putInt("day", calender.get(Calendar.DAY_OF_MONTH));
        args.putString("CustomDatePicker", "ClaimsDatePicker");
        date.setArguments(args);
        // Set Call Back to capture selected date
        date.setCallBack(ondateSecond);
        if (getFragmentManager() != null) {
            date.show(getFragmentManager(), "Date Picker");
        }
    }

    //Creating datepicker dialog listener to get the selected start date value
    private final DatePickerDialog.OnDateSetListener ondate = new DatePickerDialog.OnDateSetListener() {

        public void onDateSet(DatePicker view, int year, int monthOfYear,
                              int dayOfMonth) {
            mStartDate = String.valueOf(monthOfYear + 1) + "/" + dayOfMonth + "/" + year;
            tvStartDate.setError(null);
            tvStartDate.setText(mStartDate);
            mSearchFilters.setStartDate(mStartDate);
        }
    };

    //Creating datepicker dialog listener to get the selected end date value
    private final DatePickerDialog.OnDateSetListener ondateSecond = new DatePickerDialog.OnDateSetListener() {

        public void onDateSet(DatePicker view, int year, int monthOfYear,
                              int dayOfMonth) {
            mEndDate = String.valueOf(monthOfYear + 1) + "/" + dayOfMonth + "/" + year;
            tvEndDate.setError(null);
            tvEndDate.setText(mEndDate);
            mSearchFilters.setEndDate(mEndDate);
        }
    };

    /*
     This method is used to fetch detailedView Claim data
     */

    private void getAdvanceSearchDetails() {
        if (getActivity() == null) {
            return;
        }
        //Validating the fields data is entered or not
        /*if (mMemberName.length() == 0) {
            TextView errorText = (TextView) spnMemberName.getSelectedView();
            errorText.setError("");
            errorText.setTextColor(Color.RED);//just to highlight that this is an error
            errorText.setText(R.string.select_member_name);
            return;
        }
        if (mAuthorizationStatus.length() == 0) {
            TextView errorText = (TextView) spnClaimStatus.getSelectedView();
            errorText.setError("");
            errorText.setTextColor(Color.RED);//just to highlight that this is an error
            errorText.setText(R.string.select_claim_status);
            return;
        }
        if (mStartDate.length() == 0) {
            tvStartDate.requestFocus();
            tvStartDate.setError(getActivity().getString(R.string.select_start_date));
            return;
        }
        if (mEndDate.length() == 0) {
            tvEndDate.requestFocus();
            tvEndDate.setError(getActivity().getString(R.string.select_end_date));
            return;
        }*/


        // Checked in portal after discussing with Shraddha, 13/01/2020
        /*if (mMemberName.length() == 0 && mStartDate.length() == 0 && mEndDate.length() == 0 && mClaimStatus.length() == 0) {
            GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.select_atleast_one_field));
            return;
        }*/

        ProfileDataCache.getInstance().setSearchFilters(mSearchFilters);
        dismiss();
        //Used to display the progress dialog
        GeneralUtils.showProgress(getActivity());
        //Used to send API request to get the claim details based on search criteria
        VolleyService.getAdvanceSearchClaimData(getActivity(), AppConstants.GET_CLAIMS, new VolleyResponseListener() {
            @Override
            public void onError(String error) {
                GeneralUtils.hideProgress();
                Log.i("Error_Claims_Search", StringConstants.ERROR);
//                Toast.makeText(getActivity(), error, Toast.LENGTH_LONG).show();
            }

            @Override
            public void onResponse(String response) {
                try {
                    Log.i("Success_Claims_Search", StringConstants.RESPONSE);
                    GeneralUtils.hideProgress();
                    //Processing the reponse
                    if (response != null) { // Checking Null
                        ClaimSearchResults jsonParseResult = new Gson().fromJson(response, ClaimSearchResults.class);
                        if (jsonParseResult != null && jsonParseResult.getClaimList() != null) {
                            claimList = new ArrayList<>();
                            claimList.addAll(jsonParseResult.getClaimList());
                        }
                        if (mListener != null) {
                            mListener.returnData(claimList);
                        }
                    }
                } catch (Exception e) {
                    Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
                }
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUnbinder.unbind();
    }
}
