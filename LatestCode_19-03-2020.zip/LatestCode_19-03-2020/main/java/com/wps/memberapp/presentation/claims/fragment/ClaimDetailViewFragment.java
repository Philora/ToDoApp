package com.wps.memberapp.presentation.claims.fragment;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.github.mikephil.charting.charts.PieChart;
import com.google.android.material.internal.NavigationMenu;
import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.ClaimDetail;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.model.MemberEligibleInfo;
import com.wps.memberapp.data.model.MessageData;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.base.BaseFragment;
import com.wps.memberapp.presentation.benefits.fragment.BenefitsFragment;
import com.wps.memberapp.presentation.claims.adapter.ClaimDetailChildViewAdapter;
import com.wps.memberapp.presentation.claims.adapter.ClaimDetailDentalViewAdapter;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.CustomRecyclerView;
import com.wps.memberapp.utility.CustomScrollView;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import org.json.JSONException;
import org.json.JSONObject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import io.github.yavski.fabspeeddial.FabSpeedDial;
import io.github.yavski.fabspeeddial.SimpleMenuListenerAdapter;

import static com.wps.memberapp.utility.StringConstants.Claim_Number_Colon;

/**
 * Used to display Claim details along with provider and diagnosis information
 */

public class ClaimDetailViewFragment extends BaseFragment implements ClaimsDetailsView {

    //Declaring member variables

    @BindView(R.id.ProviderValue)
    TextView tvProviderValue;
    @BindView(R.id.txt_ProviderNpiValue)
    TextView txtProviderNpiValue;

    @BindView(R.id.groupValue)
    TextView tvGroupValue;

    @BindView(R.id.nameValue)
    TextView tvNameValue;

    @BindView(R.id.pieChart)
    PieChart mPieChart;

    @BindView(R.id.recyclerClaimDetailView)
    CustomRecyclerView recycleView;

    @BindView(R.id.dateValue)
    TextView tvDateValue;

    @BindView(R.id.fragmentContainerScrollView)
    CustomScrollView scrollView;

    @BindView(R.id.claimDetailNumberValue)
    TextView tvClaimNumber;

    @BindView(R.id.claimTypeValue)
    TextView tvClaimType;

    @BindView(R.id.claimDetailHeadingTxt)
    TextView tvClaimDetailHeadingTxt;

    @BindView(R.id.dobClaimValue)
    TextView tvClaimDate;

    @BindView(R.id.statusDetailTextView)
    TextView tvClaimHeadingStatus;

    @BindView(R.id.claimFabBtn)
    FabSpeedDial fabClaim;
    // No Plan Info - Defect Raised
    @BindView(R.id.txt_planName)
    TextView txtPlanName;

    @BindView(R.id.txt_CoverageGroup)
    TextView txtCoverageGroup;

    @BindView(R.id.txt_ipaCode)
    TextView txtIpaCode;

    @BindView(R.id.ll_MedicalClaims)
    LinearLayout lLMedicalClaims;

    @BindView(R.id.ll_UnifiedClaims)
    LinearLayout lLUnifiedClaims;
    // Unified Claims
    @BindView(R.id.txt_pharmacyName)
    TextView txtPharmacyName;

    @BindView(R.id.txt_address)
    TextView txtAddress;

    @BindView(R.id.txt_phoneNumber)
    TextView txtPhoneNumber;

    @BindView(R.id.txt_dateFilled)
    TextView txtDateFilled;

    @BindView(R.id.txt_rxNumber)
    TextView txtRxNumber;

    @BindView(R.id.txt_drugNameStrength)
    TextView txtDrugNameStrength;

    @BindView(R.id.txt_quantity)
    TextView txtQuantity;

    @BindView(R.id.txt_total)
    TextView txtTotal;

    @BindView(R.id.txt_youOwe)
    TextView txtYouOwe;

    @BindView(R.id.txt_claimLineStatus)
    TextView txtClaimLineStatus;
    // Dental Claims
    @BindView(R.id.ll_DentalClaims)
    LinearLayout llDentalClaims;

    @BindView(R.id.txt_DentProviderName)
    TextView txtDentProviderName;

    @BindView(R.id.txt_DentProvAddress)
    TextView txtDentProvAddress;

    @BindView(R.id.rv_DentalClaims)
    CustomRecyclerView rvDentalClaims;

    @BindView(R.id.txt_ProvPhoneNumber)
    TextView txtProvPhoneNumber;

    private Unbinder mUnbinder;
    private ClaimsPresenter mClaimsPresenter;
    private AlertDialog dialog;
    String claimNo;

    /*
     This override method is used to inflate the layout for Dashboard fragment
     */
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        View rootView = inflater.inflate(R.layout.fragment_claim_detail_view, container, false);
        mUnbinder = ButterKnife.bind(this, rootView);
        mClaimsPresenter = new ClaimsPresenterImpl();
        mClaimsPresenter.onAttach(this);
        //Setting title to action bar
        if (getActivity() != null) {
            TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
            fragmentTitle.setText(R.string.my_claims);
            View view = getActivity().findViewById(R.id.imageViewSearch);
            view.setVisibility(View.GONE);
            TextView txtDownloadPDF = getActivity().findViewById(R.id.txt_Call);
            txtDownloadPDF.setVisibility(View.GONE);
            view.setClickable(false);
        }


        //Setting layout manager and on touch listener to recycleview
        recycleView.setHasFixedSize(true);
        final LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        recycleView.setLayoutManager(layoutManager);

        //Setting ontouch listener to restrict user touch on parent
        rvDentalClaims.setOnTouchListener((v, event) -> {
            scrollView.requestDisallowInterceptTouchEvent(false);
            int action = event.getActionMasked();
            rvDentalClaims.performClick();
            if (action == MotionEvent.ACTION_UP) {
                scrollView.requestDisallowInterceptTouchEvent(false);
            }
            return false;
        });

        final MemberEligibleInfo info = ProfileDataCache.getInstance().getMemberEligibleInfo();

        //Setting menu listener to handle user menu selections
        fabClaim.setMenuListener(new SimpleMenuListenerAdapter() {
            @Override
            public boolean onPrepareMenu(@NonNull NavigationMenu navigationMenu) {
                if (info != null && StringConstants.ENTITY_ID_MEDMARSOL.equalsIgnoreCase(info.getCurrentRelEntityID())) {
                    navigationMenu.removeItemAt(0);
                }
                return true;
            }

            @Override
            public boolean onMenuItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.action_enquiry:
                        showNewMessageDialog();
                        break;
                    case R.id.action_EOB:
                        if (getActivity() != null) {
                            if (GeneralUtils.isOnline(getActivity())) {
                                getClaimDoc();
                            } else {
                                GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.login_no_internet));
                            }
                        }
                        break;
                    case R.id.action_Benifits:
                        if (getActivity() != null) {
                            getActivity().getSupportFragmentManager().beginTransaction().
                                    replace(R.id.frame_container, new BenefitsFragment()).addToBackStack(null).commit();
                        }
                        break;
                    default:
                        break;
                }
                return super.onMenuItemSelected(menuItem);
            }
        });

        //Getting data from the list
        if (getArguments() != null) {
            claimNo = getArguments().getString("claimNumber");
            String name = getArguments().getString("name");
            tvClaimDetailHeadingTxt.setText(name);
            tvClaimNumber.setText(claimNo);
            String status = getArguments().getString("status");
            tvClaimHeadingStatus.setText(status);
            String date = getArguments().getString("date");
            tvClaimDate.setText(date);
        }
        if (getActivity() != null) {
            if (GeneralUtils.isOnline(getActivity())) {
                mClaimsPresenter.getClaimsDetailsViewData();
            } else {
                GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.login_no_internet));
            }
        }
        return rootView;
    }

    /*
    Call back to handle the claim details API response and show the data to user
     */
    @Override
    public void onDetailsLoadingCompleted(ClaimDetail claimViewModel) {
        try {
            if (claimViewModel != null) {
                mClaimsPresenter.getPieChartResults(claimViewModel, mPieChart);
                if (claimViewModel.getProviderList() != null) {
                    tvProviderValue.setText(claimViewModel.getProviderList().getProvider());
                    txtProviderNpiValue.setText(claimViewModel.getProviderList().getmNPI());
                    tvGroupValue.setText(claimViewModel.getProviderList().getGroup());
                    String mProviderName = claimViewModel.getProviderList().getFirstName() + StringConstants.SPACE_SINGLE + claimViewModel.getProviderList().getMiddleName() + StringConstants.SPACE_SINGLE + claimViewModel.getProviderList().getLastName();
                    tvNameValue.setText(mProviderName);
                }
                tvDateValue.setText(claimViewModel.getDate());
                if (claimViewModel.getClaimType().equalsIgnoreCase("") && claimNo.startsWith("R")) {
                    tvClaimType.setText("Pharmacy");
                } else {
                    tvClaimType.setText(claimViewModel.getClaimType());
                }
                // Plan Information
                txtPlanName.setText(claimViewModel.getPlanDescription());
                txtCoverageGroup.setText(claimViewModel.getGroupDescription());
                if (claimViewModel.getIPACode() != null && !claimViewModel.getIPACode().equalsIgnoreCase("") && !claimViewModel.getIPACode().isEmpty()) {
                    txtIpaCode.setText(claimViewModel.getIPACode());
                } else {
                    txtIpaCode.setText("N/A");
                }

                //Setting ClaimDetailChildViewAdapter to recycleview
                ClaimDetailChildViewAdapter adapter = new ClaimDetailChildViewAdapter(getActivity(), claimViewModel);
                recycleView.setItemAnimator(new DefaultItemAnimator());
                recycleView.setAdapter(adapter);
                adapter.notifyDataSetChanged();

                // Unified Claims based on Claim type Pharmacy
                if (claimViewModel.getClaimType() != null && !claimViewModel.getClaimType().isEmpty() && claimViewModel.getClaimType().equalsIgnoreCase("Institutional")) {
                    lLMedicalClaims.setVisibility(View.VISIBLE);
                    fabClaim.setVisibility(View.VISIBLE);
                    lLUnifiedClaims.setVisibility(View.GONE);
                    llDentalClaims.setVisibility(View.GONE);
                } else if (claimViewModel.getClaimType() != null && !claimViewModel.getClaimType().isEmpty() && claimViewModel.getClaimType().equalsIgnoreCase("Dental")) {
                    llDentalClaims.setVisibility(View.VISIBLE);
                    fabClaim.setVisibility(View.VISIBLE);
                    lLMedicalClaims.setVisibility(View.GONE);
                    lLUnifiedClaims.setVisibility(View.GONE);
                    dentalClaimsData(claimViewModel);
                } else {
                    lLUnifiedClaims.setVisibility(View.VISIBLE);
                    fabClaim.setVisibility(View.GONE);
                    lLMedicalClaims.setVisibility(View.GONE);
                    lLMedicalClaims.setVisibility(View.GONE);
                    unifiedClaimsData(claimViewModel);
                }
            }
        } catch (Exception e) {
            e.getLocalizedMessage();
        }
    }

    private void unifiedClaimsData(ClaimDetail claimViewModel) {
        try {
            if (claimViewModel != null) {
                String mPharmacyName = claimViewModel.getProviderList().getFirstName() + " " + claimViewModel.getProviderList().getMiddleName() + " " + claimViewModel.getProviderList().getLastName();
                txtPharmacyName.setText(mPharmacyName);
                String mPharmacyAddress = claimViewModel.getProviderList().getAddress().getAddress1() + ", " + claimViewModel.getProviderList().getAddress().getAddress2() + "," + claimViewModel.getProviderList().getAddress().getCity();
                txtAddress.setText(mPharmacyAddress);
                String mPhoneNumber = claimViewModel.getProviderList().getAddress().getPhoneNumber();
                mPhoneNumber = mPhoneNumber.replaceFirst("(\\d{3})(\\d{3})(\\d+)", "($1) $2-$3");   // US based Phone Number format
                txtPhoneNumber.setText(mPhoneNumber);

                String mDateFilled = claimViewModel.getDiagnosisDetails().get(0).getDateFilled();
                txtDateFilled.setText(mDateFilled);
                String mBilledAmount = "$" + claimViewModel.getDiagnosisDetails().get(0).getBilledAmount();
                txtTotal.setText(mBilledAmount);
                String mYouOwe = "$" + claimViewModel.getDiagnosisDetails().get(0).getYourResponsibility();
                txtYouOwe.setText(mYouOwe);
                String mStatus = claimViewModel.getDiagnosisDetails().get(0).getStatus();
                txtClaimLineStatus.setText(mStatus);

//                String mRxNumber = claimViewModel.getDiagnosisDetails().get(0).getNumber();
                txtRxNumber.setText(claimNo);

                String mDrugNameStrength = claimViewModel.getDiagnosisDetails().get(0).getDrugNameStrength();
                txtDrugNameStrength.setText(mDrugNameStrength);
                String mDrugQuantity = claimViewModel.getDiagnosisDetails().get(0).getDrugQuantity();
                txtQuantity.setText(mDrugQuantity);
            }
        } catch (Exception e) {
            e.getLocalizedMessage();
        }
    }

    private void dentalClaimsData(ClaimDetail claimViewModel) {
        try {
            if (claimViewModel != null) {
                rvDentalClaims.setHasFixedSize(true);
                final LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
                layoutManager.setOrientation(RecyclerView.VERTICAL);
                rvDentalClaims.setLayoutManager(layoutManager);
                //Setting ontouch listener to restrict user touch on parent
                rvDentalClaims.setOnTouchListener((v, event) -> {
                    scrollView.requestDisallowInterceptTouchEvent(false);
                    int action = event.getActionMasked();
                    rvDentalClaims.performClick();
                    if (action == MotionEvent.ACTION_UP) {
                        scrollView.requestDisallowInterceptTouchEvent(false);
                    }
                    return false;
                });
                // Dental Provider Information
                String mPharmacyName = claimViewModel.getProviderList().getFirstName() + " " + claimViewModel.getProviderList().getMiddleName() + " " + claimViewModel.getProviderList().getLastName();
                txtDentProviderName.setText(mPharmacyName);
                String mPharmacyAddress = claimViewModel.getProviderList().getAddress().getAddress1() + ", " + claimViewModel.getProviderList().getAddress().getAddress2() + "," + claimViewModel.getProviderList().getAddress().getCity();
                txtDentProvAddress.setText(mPharmacyAddress);
                String mPhoneNumber = claimViewModel.getProviderList().getAddress().getPhoneNumber();
                mPhoneNumber = mPhoneNumber.replaceFirst("(\\d{3})(\\d{3})(\\d+)", "($1) $2-$3");   // US based Phone Number format
                txtProvPhoneNumber.setText(mPhoneNumber);

                //Setting ClaimDetailDentalViewAdapter to RecyclerView
                ClaimDetailDentalViewAdapter adapter = new ClaimDetailDentalViewAdapter(getActivity(), claimViewModel);
                rvDentalClaims.setItemAnimator(new DefaultItemAnimator());
                rvDentalClaims.setAdapter(adapter);
                adapter.notifyDataSetChanged();
            }
        } catch (Exception e) {
            e.getLocalizedMessage();
        }
    }

    @Override
    public void onResponseNull(ClaimDetail claimViewModel) {
        try {
            AlertDialog.Builder alret = new AlertDialog.Builder(getActivity())
                    .setTitle("Status")
                    .setCancelable(false)
                    .setMessage(R.string.no_records_found)
                    .setPositiveButton(getActivity().getString(R.string.ok), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Fragment fragment = new MyClaimsFragment();
                            FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                            fragmentManager.beginTransaction().replace(R.id.frame_container, fragment).addToBackStack(null).commit();
                            dialog.dismiss();
                            //getActivity().getFragmentManager().popBackStack();
                        }
                    });
            dialog = alret.create();
            dialog.show();
        } catch (Exception e) {
            Logger.e("AddMedication", e);
        }
    }

    /*
    Used to call web service API to get the claim document based on claim number
     */
    private void getClaimDoc() {
        ProfileDataCache.getInstance().setClaimNumber(tvClaimNumber.getText().toString());
        VolleyService.getClaimDocument(getAppContext(), AppConstants.GET_CLAIM_DOCUMENT, new VolleyResponseListener() {
            @Override
            public void onResponse(String response) {
                if (response != null && getActivity() != null) {
                    try {
                        JSONObject jresponse = new JSONObject(response);
                        String pdfURL = jresponse.getString("DocumentPDFURL");
                        if (pdfURL != null && !pdfURL.isEmpty()) {
                            // Need to Launch a webview to launch PDF URL
                            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(AppConstants.VIEW_DOC_PDF_URL));
                            startActivity(intent);


                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onError(String error) {
                Log.i("Doc", StringConstants.ERROR);
            }
        });
    }

    /*
    Used to send new enquiry message with claim number and user message
     */
    private void showNewMessageDialog() {
        if (getActivity() == null) {
            return;
        }
        View view = View.inflate(getActivity(), R.layout.fragment_new_message, null);
        MemberDetails details = ProfileDataCache.getInstance().getmMemberDetails().get(0);
        TextView claimTv = view.findViewById(R.id.claimNo);
        TextView provTv = view.findViewById(R.id.provNo);
        TextView memId = view.findViewById(R.id.memId);
        EditText msgEt = view.findViewById(R.id.msg);
        String claimNoText = getString(R.string.claim_no) + StringConstants.SPACE_SINGLE + tvClaimNumber.getText().toString();
        claimTv.setText(claimNoText);
        if (details != null) {
            String memIdText = getString(R.string.member_id_colon) + StringConstants.SPACE_SINGLE + details.getSubscriberID() + "-" + details.getPersonNumber();
            memId.setText(memIdText);
        }
        String provText = getString(R.string.providerno_colon) + StringConstants.SPACE_SINGLE + tvProviderValue.getText().toString();
        provTv.setText(provText);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setView(view)
                .setPositiveButton(getString(R.string.submit), (dialogInterface, i) -> {

                }).setNegativeButton(getString(R.string.cancel), (dialogInterface, i) -> {
            dialogInterface.cancel();
        })
                .setCancelable(false);
        AlertDialog dialog = builder.create();
        dialog.show();

        //Setting positive button to handle user click action
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view1 -> {
            if (TextUtils.isEmpty(msgEt.getText().toString())) {
                GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.please_enter_message));
            } else {
                dialog.dismiss();
                MessageData data = new MessageData();
                data.setSubject(getString(R.string.claims));
                data.setMessage(msgEt.getText().toString());
                ProfileDataCache.getInstance().setMessageData(data);

                String mDetSubscriberID = details.getSubscriberID();
                String strMessage = msgEt.getText().toString();
                ProfileDataCache.getInstance().setRequestMessageData(StringConstants.Ref_MemberID_Colon + mDetSubscriberID + StringConstants.Claim_Number_Colon + claimNo + StringConstants.Dot_Space + strMessage);
                VolleyService.claimsSendInquiry((AppCompatActivity) getActivity(), false);
            }
        });
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUnbinder.unbind();
    }

}


