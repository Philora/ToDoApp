package com.wps.memberapp.presentation.claims.fragment;

import com.wps.memberapp.data.model.ClaimDetail;
import com.wps.memberapp.presentation.base.MvpView;

/**
 * This interface contain UI functions of ClaimsDetails screen.
 */
interface ClaimsDetailsView extends MvpView {
    void onDetailsLoadingCompleted(ClaimDetail claimViewModel);

    void onResponseNull(ClaimDetail claimViewModel);
}
