package com.wps.memberapp.presentation.claims.fragment;

import com.github.mikephil.charting.charts.PieChart;
import com.wps.memberapp.data.model.ClaimDetail;
import com.wps.memberapp.presentation.base.MvpPresenter;

/**
 * This interface contain all the Claims functionality declarations.
 */
interface ClaimsPresenter extends MvpPresenter {
    void getClaimsDetailsData();

    void getClaimsDetailsViewData();

    void getPieChartResults(ClaimDetail claimDetailsList, PieChart pieChart);
}
