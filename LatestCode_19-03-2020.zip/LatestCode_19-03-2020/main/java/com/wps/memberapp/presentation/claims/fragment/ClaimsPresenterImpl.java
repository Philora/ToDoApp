package com.wps.memberapp.presentation.claims.fragment;

import android.content.DialogInterface;
import android.graphics.Color;
import android.util.Log;
import android.widget.Toast;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.LegendEntry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.google.gson.Gson;
import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.ClaimDetail;
import com.wps.memberapp.data.model.ClaimList;
import com.wps.memberapp.data.model.ClaimSearchResults;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.base.MvpView;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.ClaimsDetailsValueFormatter;
import com.wps.memberapp.utility.ClaimsValueFormatter;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;


/**
 * This class is used to implement all the Claims functions which
 * are declared in ClaimsPresenter.
 */

public class ClaimsPresenterImpl implements ClaimsPresenter {
    private MvpView mView;

    /*
      Used to call web service for list of claims and get response as JSON
      using post method and to return data to view controller
     */
    @Override
    public void getClaimsDetailsData() {
        final List<ClaimList> claimViewList = new ArrayList<>();
        mView.showProgress();
        VolleyService.getClaimSearchResult(mView.getAppContext(), AppConstants.GET_CLAIMS, new VolleyResponseListener() {
            @Override
            public void onError(String error) {
                mView.hideProgress();
                Log.i("ERROR_CLAIM", StringConstants.ERROR);
            }

            @Override
            public void onResponse(String response) {
                try {
                    Log.i("SUCCESS_CLAIM", StringConstants.RESPONSE);
                    if (response != null) {
                        try {
                            mView.hideProgress();
                            ClaimSearchResults jsonParseResult = new Gson().fromJson(response, ClaimSearchResults.class);
                            ProfileDataCache.getInstance().setPageCount(jsonParseResult.getPageCount());
                            if (jsonParseResult != null && jsonParseResult.getClaimList() != null) {
                                claimViewList.addAll(jsonParseResult.getClaimList());
                            }
                        } catch (Exception e) {
                            Log.wtf("Error", e.getMessage());
                        }
                    }
                    ((ClaimsView) mView).onClaimsLoadingCompleted(claimViewList);
                } catch (Exception e) {
                    Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
                }
            }
        });
    }

    /*
    Used to call web service for claim details and get response as JSON
    using post method and to return data to view controller
   */
    @Override
    public void getClaimsDetailsViewData() {
        //Displaying progress dialog
        mView.showProgress();
        VolleyService.getClaimDetailViewData(mView.getAppContext(), AppConstants.GET_CLAIM_DETAILS, new VolleyResponseListener() {
            @Override
            public void onError(String error) {
                mView.hideProgress();
                Log.i("Error_Auth_Referral", StringConstants.ERROR);
            }

            @Override
            public void onResponse(String response) {
                try {
                    //Processing the recieved reponse and attaching to mViews
                    if (response != null && response.length() > 0) {
                        Log.i("_Referral_Detailed", StringConstants.RESPONSE);
                        mView.hideProgress();
                        ClaimDetail claimViewModel = new Gson().fromJson(response, ClaimDetail.class);
                        if (claimViewModel != null && claimViewModel.getClaimType() != null) {
                            ((ClaimsDetailsView) mView).onDetailsLoadingCompleted(claimViewModel);
                        } else {
//                        Toast.makeText(mView.getAppContext(), R.string.details_not_available, Toast.LENGTH_LONG).show();
                            ((ClaimsDetailsView) mView).onResponseNull(claimViewModel);
                        }
                    }
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
            }
        });
    }

    /*
    This method is used to get Pie chart by using claim details data
     */
    @Override
    public void getPieChartResults(@NonNull ClaimDetail claimDetailsList, @NonNull PieChart pieChart) {
        final int[] myColors = {
                Color.rgb(41, 170, 225),
                Color.rgb(44, 49, 120),
                Color.rgb(7, 182, 131),
                Color.rgb(41, 171, 226),
                Color.rgb(7, 182, 131)};

        ArrayList<String> xValues = new ArrayList<>();
        xValues.add(mView.getAppContext().getString(R.string.title_planPaid));
//        xValues.add(mView.getAppContext().getString(R.string.title_planAllowed_Amount));
        xValues.add(mView.getAppContext().getString(R.string.plan_discount));
        xValues.add(mView.getAppContext().getString(R.string.patient_responsiblity));

        //Adding pie chart labels to arrayList
        ArrayList<PieEntry> yvalues = new ArrayList<>();
        float f1 = (float) Double.parseDouble(claimDetailsList.getPlanPaid());
//        float f2 = (float) Double.parseDouble(claimDetailsList.getPlanAllowed_Amount());
        float f2 = (float) Double.parseDouble(claimDetailsList.getPlanDiscount());
        float f3 = (float) Double.parseDouble(claimDetailsList.getResponsibility());
        yvalues.add(new PieEntry((f1), mView.getAppContext().getString(R.string.title_planPaid)));
//        yvalues.add(new PieEntry((f2), mView.getAppContext().getString(R.string.title_planAllowed_Amount)));
        yvalues.add(new PieEntry((f2), mView.getAppContext().getString(R.string.plan_discount)));
        yvalues.add(new PieEntry((f3), mView.getAppContext().getString(R.string.patient_responsiblity)));

        PieDataSet dataSet = new PieDataSet(yvalues, "");
        ArrayList<Integer> colors = new ArrayList<>();
        for (int c : myColors) {
            colors.add(c);
        }
        dataSet.setColors(colors);

        final PieData data = new PieData(dataSet);
//        data.setValueFormatter((value, entry, dataSetIndex, mViewPortHandler) -> "$" + value + 0);
        data.setValueFormatter(new ClaimsDetailsValueFormatter());
        data.setValueTextSize(13f);

        //Initializing pie chart with required data
        pieChart.setData(data);
        pieChart.setNoDataTextColor(Color.TRANSPARENT);
        pieChart.setDrawHoleEnabled(true);
        pieChart.setHoleColor(Color.WHITE);
        pieChart.setTransparentCircleColor(Color.WHITE);
        pieChart.setTransparentCircleAlpha(255);
        pieChart.setHoleRadius(42f);
        pieChart.getDescription().setEnabled(false);
        pieChart.setDrawSlicesUnderHole(false);
        pieChart.setDrawEntryLabels(false);
        pieChart.setDrawCenterText(false);
        dataSet.setYValuePosition(PieDataSet.ValuePosition.OUTSIDE_SLICE);
        Legend l = pieChart.getLegend();
        List<LegendEntry> entries = new ArrayList<>();
        for (int i = 0; i < 3; i++) {   // Make sure on this part ----  if we calling response getPlanAllowed_Amount(), then change the value from 3 -> 4
            LegendEntry entry = new LegendEntry();
            entry.formColor = colors.get(i);
            entry.label = xValues.get(i);
            entries.add(entry);
        }
        l.setCustom(entries);
        l.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
        l.setHorizontalAlignment(Legend.LegendHorizontalAlignment.CENTER);
        l.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        pieChart.setExtraOffsets(-7, -7, -7, -7);
        pieChart.animateXY(1000, 1000);
        pieChart.invalidate();
    }

    @Override
    public void onAttach(MvpView mView) {
        this.mView = mView;
    }

    @Override
    public void onDetach() {
        mView = null;
    }
}
