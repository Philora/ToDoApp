package com.wps.memberapp.presentation.claims.fragment;


import com.wps.memberapp.data.model.ClaimDetail;
import com.wps.memberapp.data.model.ClaimList;
import com.wps.memberapp.presentation.base.MvpView;

import java.util.List;

/**
 * This interface contain UI functions of Claims screen.
 */
interface ClaimsView extends MvpView {
    void onClaimsLoadingCompleted(List<ClaimList> claimViewList);

    void returnData(List<ClaimList> claimViewList);
}
