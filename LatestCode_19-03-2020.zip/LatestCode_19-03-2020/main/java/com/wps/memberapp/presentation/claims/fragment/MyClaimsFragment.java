package com.wps.memberapp.presentation.claims.fragment;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.appdynamics.eumagent.runtime.Instrumentation;
import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.AdvanceSearchFilters;
import com.wps.memberapp.data.model.ClaimDetail;
import com.wps.memberapp.data.model.ClaimList;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.presentation.base.BaseFragment;
import com.wps.memberapp.presentation.claims.adapter.ClaimsPagerAdapter;
import com.wps.memberapp.presentation.claims.adapter.NothingSelectedSpinnerAdapter;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/**
 * Used to display list of claims data of the user in recycler view by using adapter.
 */
public class MyClaimsFragment extends BaseFragment implements View.OnClickListener, ClaimDetailViewDialogFragment.DialogCallbackContract, ClaimsView {

    private RecyclerView recycleView;
    private TextView tvClaimHeader;
    private TextView tvNoData;
    private ClaimsPresenter mClaimsPresenter;
    private boolean isLoading;
    private List<ClaimList> claimList;
    private int pageID = 1;
    private int scrollPosition = 0;
    private AlertDialog dialog;
    Spinner customerSpinner;
    String customerName = "";
    private AdvanceSearchFilters mSearchFilters;

    /* This override method is used to inflate the layout for Dashboard fragment
     */

    @Override
    public void onStart() {
        super.onStart();
        mSearchFilters = new AdvanceSearchFilters();
        ProfileDataCache.getInstance().setSearchFilters(mSearchFilters);
//        Toast.makeText(getActivity(), "OnStart "+mSearchFilters, Toast.LENGTH_SHORT).show();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        if (getActivity() != null) {
            Instrumentation.start(StringConstants.APP_DYNAMICS_KEY, getActivity().getApplicationContext());
        }
        if (container != null) {
            container.removeAllViews();
            container.clearDisappearingChildren();
        }
        View rootView = inflater.inflate(R.layout.fragment_claim_view, container, false);
        recycleView = rootView.findViewById(R.id.recyclerClaimView);
        tvNoData = rootView.findViewById(R.id.nodata);
        Spinner daysSpinner = rootView.findViewById(R.id.daysSpinner);
        customerSpinner = rootView.findViewById(R.id.customerSpinner);
        tvClaimHeader = rootView.findViewById(R.id.claimHeader);
        recycleView.setHasFixedSize(true);
        claimList = new ArrayList<>();
        final LinearLayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        mLayoutManager.setOrientation(RecyclerView.VERTICAL);
        recycleView.setLayoutManager(mLayoutManager);
        if (getActivity() != null) {
            TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
            fragmentTitle.setText(R.string.my_claims);
            View view = getActivity().findViewById(R.id.imageViewSearch);
            view.setVisibility(View.VISIBLE);
            view.setClickable(true);
            view.setOnClickListener(this);
        }
        mClaimsPresenter = new ClaimsPresenterImpl();
        mClaimsPresenter.onAttach(this);
        mSearchFilters = new AdvanceSearchFilters();
        List<String> list = Arrays.asList(getActivity().getResources().getStringArray(R.array.claims_days));
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        daysSpinner.setAdapter(dataAdapter);

        customerNameSpinner();


        //Added OnItemSelectedListener to handle the user selections in the spinner
        daysSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if (i > -1) {
                    pageID = 1;
                    String days = getDaysString(i);
                    claimList.clear();
                    scrollPosition = 0;
                    ProfileDataCache.getInstance().setClaimSearchDays(days);
                    ProfileDataCache.getInstance().setPageID(pageID);
                    if (getActivity() != null) {
                        if (GeneralUtils.isOnline(getActivity())) {
                            mClaimsPresenter.getClaimsDetailsData();
                        } else {
                            GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.login_no_internet));
                        }
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //need to implement
            }
        });

        /*//Added ScrollListener to implement the pagination for each 10 records
        recycleView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                if (claimList.size() > 9) {
                    int visibleItemCount = mLayoutManager.getChildCount();
                    int totalItemCount = mLayoutManager.getItemCount();
                    int pastVisibleItems = mLayoutManager.findFirstVisibleItemPosition();
                    if (pastVisibleItems + visibleItemCount >= totalItemCount && !isLoading) {
                        isLoading = true;
                        pageID = pageID + 1;
                        scrollPosition = scrollPosition + 10;
                        ProfileDataCache.getInstance().setPageID(pageID);
                        if (getActivity() != null) {
                            if (GeneralUtils.isOnline(getActivity())) {
                                mClaimsPresenter.getClaimsDetailsData();
                            } else {
                                GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.login_no_internet));
                            }
                        }
                    }
                }
            }
        });*/
        return rootView;
    }

    private void customerNameSpinner() {
        try {
            if (getActivity() == null) {
                return;
            }
            //Creating adapter with claim status values and setting to spinner
            List<String> list = new ArrayList<>();
            List<MemberDetails> memberDetailsList = ProfileDataCache.getInstance().getmMemberDetails();
            for (MemberDetails details : memberDetailsList) {
                list.add(details.getFirstName() + " " + details.getLastName());
            }
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(getActivity(),
                    android.R.layout.simple_spinner_item, list);
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            customerSpinner.setAdapter(new NothingSelectedSpinnerAdapter(
                    dataAdapter,
                    R.layout.authorization_member_name_spinner_hint,
                    // R.layout.contact_spinner_nothing_selected_dropdown, // Optional
                    getActivity()));

            //Added selected listener to get the selected data
            customerSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                    try {
                        if (customerSpinner.getSelectedItem() != null) {
                            customerName = customerSpinner.getSelectedItem().toString();
                            mSearchFilters.setName(customerName);
//                            Toast.makeText(getActivity(), customerName, Toast.LENGTH_SHORT).show();
                            pageID = 1;
                            claimList.clear();
                            scrollPosition = 0;
                            ProfileDataCache.getInstance().setSearchFilters(mSearchFilters);
                            ProfileDataCache.getInstance().setPageID(pageID);
                            if (getActivity() != null) {
                                if (GeneralUtils.isOnline(getActivity())) {
                                    mClaimsPresenter.getClaimsDetailsData();
                                } else {
                                    GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.login_no_internet));
                                }
                            }
                        }
                    } catch (Exception e) {
                        Logger.e(StringConstants.EXCEPTION, e);
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {
                    //Do something
                }
            });
        } catch (Exception e) {
            Logger.e(StringConstants.EXCEPTION, e);
        }
    }

    /*
  Getting No of days based on the user input
   */
    @NonNull
    private String getDaysString(int i) {
        String days = "";
        switch (i) {
            case 1:
                days = "10";
                break;
            case 2:
                days = "15";
                break;
            case 3:
                days = "30";
                break;
            case 4:
                days = "60";
                break;
            case 5:
                days = "90";
                break;
            case 6:
                int year = Calendar.getInstance().get(Calendar.YEAR);
                days = String.valueOf(year);
                break;
            case 7:
                days = "540";
                break;
            default:
                break;
        }
        return days;
    }

    /*
  Used to show the advance search dialog
   */
    private void showDialog() {
        if (getActivity() != null) {
            FragmentManager fm = getActivity().getSupportFragmentManager();
            ClaimDetailViewDialogFragment addDialog = new ClaimDetailViewDialogFragment();
            addDialog.setTargetFragment(this, 0);
            addDialog.setListener(this);
            addDialog.show(fm, "dialog");
        }
    }

    /*
    Call back to handle the response of the advance search for claims
     */
    @Override
    public void returnData(List<ClaimList> claimList) {
        if (SharedPreferenceHelper.getInstance() != null) {
            String startDate = ProfileDataCache.getInstance().getSearchFilters().getStartDate();
            String endDate = ProfileDataCache.getInstance().getSearchFilters().getEndDate();
            if (startDate != null && endDate != null) {
                String text = getString(R.string.showing_results_between) + " " + startDate + " " + "&" + " " + endDate;
                tvClaimHeader.setText(text);
            }
        }
        if (claimList != null) {
            this.claimList.clear();
            this.claimList.addAll(claimList);
            updateClaimList(this.claimList);
        }
    }

    @Override
    public void onClick(@NonNull View view) {
        if (view.getId() == R.id.imageViewSearch) {
            showDialog();
        }
    }

    /*
    Call back to handle the response of the getting lis of claims API
     */
    @Override
    public void onClaimsLoadingCompleted(List<ClaimList> claimViewList) {
        claimList.remove(null);
        if (claimViewList != null) { // Checking Null
            claimList.addAll(claimViewList);
        }
//        if (claimList.size() > 9) {
//            claimList.add(null);
//        }
        updateClaimList(claimList);
    }

    /*
This method is used to create the adapter with list of claims and attach it to recycle view
 */
    private void updateClaimList(@NonNull List<ClaimList> claimViewList) {
        ClaimsPagerAdapter adapter = new ClaimsPagerAdapter(getActivity(), (AppCompatActivity) getActivity(), claimViewList);
        recycleView.setItemAnimator(new DefaultItemAnimator());
        recycleView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
//        if (scrollPosition > 0) {
//            recycleView.scrollToPosition(scrollPosition - 3);
//        }
//        isLoading = false;
        //Displaying no records found label when search  results are empty
        if (claimViewList.isEmpty()) {
            tvNoData.setVisibility(View.VISIBLE);
        } else {
            tvNoData.setVisibility(View.GONE);
        }
    }
}


