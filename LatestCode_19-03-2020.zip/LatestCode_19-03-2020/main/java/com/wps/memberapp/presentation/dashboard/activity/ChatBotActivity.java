package com.wps.memberapp.presentation.dashboard.activity;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.Html;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.method.LinkMovementMethod;
import android.text.util.Linkify;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import com.ibm.watson.developer_cloud.conversation.v1.Conversation;
import com.ibm.watson.developer_cloud.conversation.v1.model.InputData;
import com.ibm.watson.developer_cloud.conversation.v1.model.MessageOptions;
import com.ibm.watson.developer_cloud.conversation.v1.model.MessageResponse;
import com.ibm.watson.developer_cloud.discovery.v1.Discovery;
import com.ibm.watson.developer_cloud.discovery.v1.model.query.QueryRequest;
import com.ibm.watson.developer_cloud.discovery.v1.model.query.QueryResponse;
import com.ibm.watson.developer_cloud.text_to_speech.v1.TextToSpeech;
import com.wps.memberapp.R;
import com.wps.memberapp.data.model.Message;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.presentation.dashboard.adapter.ChatAdapter;
import com.wps.memberapp.utility.GeneralUtils;

import org.json.JSONObject;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;


public class ChatBotActivity extends Activity {

    @BindView(R.id.recyclerViewChatBot)
    RecyclerView recyclerView;
    @BindView(R.id.message)
    EditText inputMessage;
    @BindView(R.id.btn_send)
    ImageButton btnSend;
    @BindView(R.id.btn_record)
    ImageButton btnRecord;
    private ChatAdapter mAdapter;
    private ArrayList<Message> messageArrayList;
    private Map<String, Object> context = null;
    private boolean initialRequest;
    private static final int REQUEST_RECORD_AUDIO_PERMISSION = 200;
    private static final String TAG = "MainActivity";
    private static final int RECORD_REQUEST_CODE = 101;
    private String workspaceId;
    private String conversationUsername;
    private String conversationPassword;
    private String collectionId;
    private String environmentId;
    private String curTime;
//    private Logger myLogger;
    private static final String WATBOT = "WatBot";
    private static final String TIME_FORMAT = "hh:mm aa";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_bot);
        ButterKnife.bind(this);
        Context mContext = getApplicationContext();
        conversationUsername = mContext.getString(R.string.conversation_username);
        conversationPassword = mContext.getString(R.string.conversation_password);
        workspaceId = mContext.getString(R.string.workspace_id);
        String ttsUsername = mContext.getString(R.string.TTS_username);
        String ttsPassword = mContext.getString(R.string.TTS_password);
        String analyticsAPIKEY = mContext.getString(R.string.mobileanalytics_apikey);

        // collectionId = "dc12059d-24c3-4e66-8894-0b7df4bf11f8"; // original
        collectionId = "8a62de20-e7f6-4b46-8ddd-b93bc8ffaf6f";
        environmentId = "e907a4eb-00d1-43a3-958d-0444c612eeec";

        //BlueMix Mobile Analytics
        /*BMSClient.getInstance().initialize(getApplicationContext(), BMSClient.REGION_US_SOUTH);
        //Analytics is configured to record lifecycle events.
        Analytics.init(getApplication(), WATBOT, analyticsAPIKEY, false, Analytics.DeviceEvent.ALL);
        myLogger = Logger.getLogger("myLogger");
        // Send recorded usage analytics to the Mobile Analytics Service
        Analytics.send(new ResponseListener() {
            @Override
            public void onSuccess(Response response) {
                // Handle Analytics send success here.
            }

            @Override
            public void onFailure(Response response, Throwable throwable, JSONObject jsonObject) {
                // Handle Analytics send failure here.
            }
        });

        // Send logs to the Mobile Analytics Service
        Logger.send(new ResponseListener() {
            @Override
            public void onSuccess(Response response) {
                // Handle Logger send success here.
            }

            @Override
            public void onFailure(Response response, Throwable throwable, JSONObject jsonObject) {
                // Handle Logger send failure here.
            }
        });*/

        inputMessage.setLinksClickable(true);
        inputMessage.setCursorVisible(true);
        inputMessage.setFocusable(true);
        inputMessage.setFocusableInTouchMode(true);
        inputMessage.setClickable(true);
        Linkify.addLinks(inputMessage, Linkify.WEB_URLS);
        inputMessage.setSelected(true);
        inputMessage.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                btnSend.setEnabled(false);
                if (inputMessage.getText().toString().length() > 0) {
                    btnSend.setEnabled(true);
                }
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                //Empty method
            }

            @Override
            public void afterTextChanged(Editable editable) {
                //Empty method
                if (inputMessage.getText().toString().contains(" ")) {
                    inputMessage.setText(inputMessage.getText().toString().replaceAll(" ", ""));
                    inputMessage.setSelection(inputMessage.getText().length());
                }
            }
        });

        inputMessage.setClickable(true);
        inputMessage.setMovementMethod(LinkMovementMethod.getInstance());
        messageArrayList = new ArrayList<>();
        mAdapter = new ChatAdapter(messageArrayList);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);
        this.inputMessage.setText("");
        this.initialRequest = true;
        sendMessage();

        //Watson Text-to-Speech Service on Bluemix
        TextToSpeech textToSpeech = new TextToSpeech();
        textToSpeech.setUsernameAndPassword(ttsUsername, ttsPassword);

        int permission = ContextCompat.checkSelfPermission(this,
                Manifest.permission.RECORD_AUDIO);

        if (permission != PackageManager.PERMISSION_GRANTED) {
            Log.i(TAG, "Permission to record denied");
        }

        btnSend.setOnClickListener(v -> {
            if (checkInternetConnection()) {
                sendMessage();
            }
        });
    }

    // Speech-to-Text Record Audio Permission
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQUEST_RECORD_AUDIO_PERMISSION:
                break;
            case RECORD_REQUEST_CODE:
                if (grantResults.length == 0
                        || grantResults[0] !=
                        PackageManager.PERMISSION_GRANTED) {
                    Log.i(TAG, "Permission has been denied by user");
                } else {
                    Log.i(TAG, "Permission has been granted by user");
                }
                break;
            default:
                break;
        }
    }

    // Sending a message to Watson Conversation Service
    private void sendMessage() {

        final String inputmessage = this.inputMessage.getText().toString().trim();
        if (!this.initialRequest) {
            Message inputMessageObj = new Message();
            inputMessageObj.setMessage(SpannableString.valueOf(inputmessage));
            Format formatter2 = new SimpleDateFormat(TIME_FORMAT, Locale.US);
            long time2 = System.currentTimeMillis();
            Log.i("Dta", formatter2.format(new Date(time2)));
            curTime = formatter2.format(new Date(time2));
            inputMessageObj.setCreatedAt(curTime);
            inputMessageObj.setUserType("User");
            messageArrayList.add(inputMessageObj);
//            myLogger.info("Sending a message to Watson Conversation Service");
        } else {
            Message inputMessageObj = new Message();
            inputMessageObj.setMessage(SpannableString.valueOf(inputmessage));
            inputMessageObj.setId(100);
            this.initialRequest = false;
            Toast.makeText(getApplicationContext(), R.string.tap_on_the_msg, Toast.LENGTH_LONG).show();
        }
        this.inputMessage.setText("");
        mAdapter.notifyDataSetChanged();

        Thread thread = new Thread(() -> {
            try {
                Conversation service = new Conversation(Conversation.VERSION_DATE_2017_05_26);
                service.setUsernameAndPassword(conversationUsername, conversationPassword);
                InputData input = new InputData.Builder(inputmessage).build();
                MessageOptions options = new MessageOptions.Builder(workspaceId).input(input).context((com.ibm.watson.developer_cloud.conversation.v1.model.Context) context).build();
                MessageResponse response = service.message(options).execute();
                //Passing Context of last conversation
                if (response.getContext() != null) {
                    context = response.getContext();
                }
                Message outMessage = new Message();
                if (response.getOutput() != null && response.getOutput().containsKey("text")) {
                    ArrayList responseList = (ArrayList) response.getOutput().get("text");
                    if (null != responseList && !responseList.isEmpty()) {
                        outMessage.setMessage(SpannableString.valueOf((String) responseList.get(0)));
                        Format formatter = new SimpleDateFormat(TIME_FORMAT, Locale.US);
                        long time = System.currentTimeMillis();
                        Log.i("time", formatter.format(new Date(time)));
                        curTime = formatter.format(new Date(time));
                        outMessage.setCreatedAt(curTime);
                        outMessage.setUserType(WATBOT);
                        if (response.getIntents() != null && !response.getIntents().isEmpty() &&
                                response.getIntents().get(0).containsValue("vaccination")) {
                            // Call discovery service to get the data
                            Discovery discovery = new Discovery("2017-11-07");
                            discovery.setEndPoint("https://gateway.watsonplatform.net/discovery/api");
                            discovery.setUsernameAndPassword("apikey", "pjXr9MjJnRr_Ula1tJJR7l1kiQcupaj8OVLBql9D7FJ8");
                            QueryRequest.Builder queryBuilder = new QueryRequest.Builder(environmentId, collectionId);
                            queryBuilder.query(response.getInput().getText());
                            QueryResponse queryResponse = discovery.query(queryBuilder.build()).execute();
                            //print out the results
                            Log.i("Res", "Query Results:");
                            if (queryResponse != null) {
                                List<Map<String, Object>> map = queryResponse.getResults();
                                for (int i = 0; i < map.size(); i++) {
                                    String html;
                                    String pocID = "";
                                    String title = "";
                                    for (Map.Entry<String, Object> entry : map.get(i).entrySet()) {
                                        Log.i("Key is ", entry.getKey());
                                        if (entry.getKey().equals("pocID")) {
                                            pocID = entry.getValue().toString();
                                        }
                                        if (entry.getKey().equals("title")) {
                                            title = entry.getValue().toString();
                                        }
                                    }
                                    if (!pocID.isEmpty() && !title.isEmpty()) {
                                        outMessage = new Message();
                                        html = "<a href=" + ">" + title + "</a>";
                                        Spanned result;
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                                            result = Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY);
                                        } else {
                                            result = Html.fromHtml(html);
                                        }
                                        outMessage.setMessage(result);
                                        outMessage.setUserType(WATBOT);

                                        Format formatter1 = new SimpleDateFormat(TIME_FORMAT, Locale.US);
                                        long time1 = System.currentTimeMillis();
                                        Log.i("Time", formatter1.format(new Date(time1)));
                                        curTime = formatter1.format(new Date(time1));
                                        outMessage.setCreatedAt(curTime);
                                        outMessage.setUrl(pocID);
                                        outMessage.setId(i);
                                        messageArrayList.add(outMessage);
                                    }
                                }
                            }
                        } else {
                            messageArrayList.add(outMessage);
                        }
                    }
                    if (response.getContext() != null && response.getContext().containsKey("redirect_flag")
                            || response.getContext() != null && response.getContext().containsKey("reply_flag")) {
                        String type = SharedPreferenceHelper.getInstance().getPreference(getApplicationContext(), "APPLICATION_ID");
                        if (type != null && type.contains("PEGA")) {
                            //Launch pega customer chat

                        } else if (type != null && type.contains("SFDC")) {
                            //Launch sfdc customer chat

                        } else {
                           /* Intent browserIntent = new Intent(ChatBotActivity.this, WebViewActivity.class); // Checked with Shraddha after Naga raised issue(13-032020)...
                            startActivity(browserIntent);*/
                            Intent intent = new Intent(ChatBotActivity.this, DashboardActivity.class);
                            startActivity(intent);
                            finish();
                        }
                    }

                    if (response.getContext() != null && response.getContext().containsKey("conversation_end")
                            || response.getContext() != null && response.getContext().containsKey("end_conversation")
                            || response.getContext().containsKey("chatbot_close_flag")) {
                        Intent intent = new Intent(ChatBotActivity.this, DashboardActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }
                runOnUiThread(() -> {
                    mAdapter.notifyDataSetChanged();
                    if (mAdapter.getItemCount() > 1) {
                        recyclerView.getLayoutManager().smoothScrollToPosition(recyclerView, null, mAdapter.getItemCount() - 1);
                    }
                });
            } catch (Exception e) {
//                    Logger.getLogger("Exc");
            }
        });
        thread.start();
    }

    private boolean checkInternetConnection() {
        // get Connectivity Manager object to check connection
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) {
            return false;
        }
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();

        // Check for network connections
        if (isConnected) {
            return true;
        } else {
            Toast.makeText(this, " No Internet Connection available ", Toast.LENGTH_LONG).show();
            return false;
        }

    }
}