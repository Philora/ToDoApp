package com.wps.memberapp.presentation.dashboard.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.FragmentManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.TextView;

import com.appdynamics.eumagent.runtime.Instrumentation;
import com.google.android.material.internal.NavigationMenu;
import com.google.android.material.navigation.NavigationView;

/*import com.ibm.mobilefirstplatform.clientsdk.android.core.api.BMSClient;
import com.ibm.mobilefirstplatform.clientsdk.android.push.api.MFPPush;
import com.ibm.mobilefirstplatform.clientsdk.android.push.api.MFPPushException;
import com.ibm.mobilefirstplatform.clientsdk.android.push.api.MFPPushNotificationListener;
import com.ibm.mobilefirstplatform.clientsdk.android.push.api.MFPPushResponseListener;
import com.ibm.mobilefirstplatform.clientsdk.android.push.api.MFPSimplePushNotification;*/
import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.DashboardData;
import com.wps.memberapp.data.model.ExpandedMenuModel;
import com.wps.memberapp.data.model.MemberEligibleInfo;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.global.RootActivity;
import com.wps.memberapp.presentation.authreferral.fragment.AuthorizationReferalFragment;
import com.wps.memberapp.presentation.base.BaseActivity;
import com.wps.memberapp.presentation.benefits.fragment.BenefitsFragment;
//import com.wps.memberapp.presentation.healthtracker.activity.HealthTrackerActivity;
import com.wps.memberapp.presentation.claims.fragment.MyClaimsFragment;
import com.wps.memberapp.presentation.dashboard.fragment.DashboardFragmentPresenter;
import com.wps.memberapp.presentation.dashboard.fragment.DashboardFragmentPresenterImpl;
import com.wps.memberapp.presentation.dashboard.fragment.PegaSearchFragment;
import com.wps.memberapp.presentation.medication.fragment.CustomAddMedicationView;
import com.wps.memberapp.presentation.providersearch.fragment.ProviderSearchFragment;
import com.wps.memberapp.presentation.dashboard.adapter.ExpandableListAdapter;
import com.wps.memberapp.presentation.dashboard.fragment.DashboardFragment;
import com.wps.memberapp.presentation.immunization.fragment.ImmunizationFragment;
import com.wps.memberapp.presentation.logout.LogoutFragment;
import com.wps.memberapp.presentation.profilemanagement.fragment.ChangePasswordFragment;
import com.wps.memberapp.presentation.profilemanagement.fragment.ChangeQuestionsFragment;
import com.wps.memberapp.presentation.profilemanagement.fragment.UpdateDemographicsFragment;
import com.wps.memberapp.presentation.securemessage.fragment.SendMessageFragment;
import com.wps.memberapp.presentation.treatmentcostcalculator.fragment.TCCFragment;
import com.wps.memberapp.presentation.viewidcard.fragment.ViewIDCardFrament;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.LocaleHelper;
import com.wps.memberapp.utility.StringConstants;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import butterknife.BindView;
import butterknife.ButterKnife;
import io.github.yavski.fabspeeddial.SimpleMenuListenerAdapter;

/**
 * This activity is Parent activity for all fragments in this application.
 */
public class DashboardActivity extends BaseActivity {

    // Tags used to attach the fragments
    private static final String TAG_HOME = "home";
//    private static final String TAG = NotificationActivity.class.getSimpleName();

   /* private MFPPush push; // Push client
    private MFPPushNotificationListener notificationListener; // Notification listener to handle a push sent to the phone*/

    @BindView(R.id.drawer_layout)
    DrawerLayout drawerLayoutDashboard;

    @BindView(R.id.textViewHeader)
    TextView tvHeader;

    @BindView(R.id.imageViewSearch)
    ImageView ivSearch;

    @BindView(R.id.nav_view)
    NavigationView navigationView;

    @BindView(R.id.navigationMenuList)
    ExpandableListView expandableListView;
    private HashMap<ExpandedMenuModel, List<String>> mListDataChild;
    private int mPreviousItem = -1;
    private List<ExpandedMenuModel> mListDataHeader;
    private DashboardFragmentPresenter dashboardPresenter;
    NotificationManager notificationManager;
    int notificationID = 101;
    String mPopUpMessage;


    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        Instrumentation.start(StringConstants.APP_DYNAMICS_KEY, getApplicationContext());
        super.onCreate(savedInstanceState);
        GeneralUtils.setLanguage(getApplicationContext());
        setContentView(R.layout.activity_dashboard);
        ButterKnife.bind(this);
        dashboardPresenter = new DashboardFragmentPresenterImpl();
        dashboardPresenter.onAttach(this);

        /*This inbuilt class of IBM cloud SDK is used to grab IBM push client SDK instance*/

        /*BMSClient.getInstance().initialize(this, BMSClient.REGION_US_SOUTH);
        push = MFPPush.getInstance();
        push.initialize(this, AppConstants.APP_UUID, AppConstants.CLIENT_SECRET_ID);
        *//*This method call is used to register device using app UUID and client id with IBM cloud*//*

        registerDevice();
        notificationListener = new MFPPushNotificationListener() {
            @Override
            public void onReceive(final MFPSimplePushNotification message) {
                Log.i(TAG, "Push Notification Response: " + message);
                mPopUpMessage = message.getAlert().toString();
                Log.i(TAG, "Received a Push Notification: " + mPopUpMessage);
                sendNotification(mPopUpMessage);
                //showNotification(DashboardActivity.this, message);

        };*/
        ivSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferenceHelper.getInstance().setPreference(getApplicationContext(), "SearchQuery", "");
                // FragmentManager fragmentManager = mView.getAppContext().getFragmentManager();
                getSupportFragmentManager().beginTransaction().replace(R.id.frame_container, new PegaSearchFragment()).addToBackStack(null).commit();
                //dashboardPresenter.onSearchClicked();
            }
        });

        prepareListData();
        addDrawerItems();
        setNavDrawer();
        if (savedInstanceState == null) {
            try {
                DashboardData data = ProfileDataCache.getInstance().getDashboardData();
                if (data != null && data.getFirstName() != null) {
                    String firstName = data.getFirstName().trim();
                    String lastName = data.getLastName().trim();
                    if (tvHeader != null) {
                        String welcomeText = firstName + StringConstants.SPACE_SINGLE + lastName;
                        tvHeader.setText(welcomeText);
                    }
                }
            } catch (NullPointerException exception) {
                exception.getMessage();
            }
            selectFirstItemAsDefault();
        }
        fabBtn.setMenuListener(new SimpleMenuListenerAdapter() {
            @Override
            public boolean onPrepareMenu(NavigationMenu navigationMenu) {
                //Do something with yout menu items, or return false if you don't want to show them
                return true;
            }

            @Override
            public boolean onMenuItemSelected(MenuItem menuItem) {
                menuItemSelector(menuItem);
                return false;
            }
        });

    }

    private void sendNotification(String messageBody) {
        try {
            Intent intent = new Intent(this, DashboardActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pendingIntent = PendingIntent.getActivity(this, 0 /* Request code */, intent,
                    PendingIntent.FLAG_ONE_SHOT);

            String channelId = getString(R.string.notification_channel_id);
            Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            NotificationCompat.Builder notificationBuilder =
                    new NotificationCompat.Builder(this, channelId)
                            .setSmallIcon(R.drawable.ic_notification_star)
                            .setContentTitle(getString(R.string.member_app))
                            .setContentText(messageBody)
                            .setAutoCancel(true)
                            .setSound(defaultSoundUri)
                            .setContentIntent(pendingIntent);

            NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

            // Since android Oreo notification channel is needed.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel = new NotificationChannel(channelId, getString(R.string.channel_name), NotificationManager.IMPORTANCE_DEFAULT);
                notificationManager.createNotificationChannel(channel);
            }
            notificationManager.notify(0 /* ID of notification */, notificationBuilder.build());
        } catch (Exception e) {
            e.getLocalizedMessage();
        }
    }

    /*private void sendNotification(String messageBody) {
        Intent intent = new Intent(this, DashboardActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0 *//* Request code *//*, intent,
                PendingIntent.FLAG_ONE_SHOT);

        String channelId = getString(R.string.notification_channel_id);
        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationCompat.Builder notificationBuilder =
                new NotificationCompat.Builder(this, channelId)
                        .setSmallIcon(R.drawable.ic_notification_star)
                        .setContentTitle(getString(R.string.app_name))
                        .setContentText(messageBody)
                        .setAutoCancel(true)
                        .setSound(defaultSoundUri)
                        .setContentIntent(pendingIntent);

        NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        // Since android Oreo notification channel is needed.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = getString(R.string.channel_name);
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel(channelId, name, NotificationManager.IMPORTANCE_DEFAULT);
            notificationManager.createNotificationChannel(channel);
        }

        notificationManager.notify(0 , notificationBuilder.build());
    }*/

   /* private void showNotification(Activity activity, MFPSimplePushNotification message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setMessage("Notification Received : " + message.toString());
        builder.setCancelable(true);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg0, int arg1) {

            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }*/

    /**
     * This method is used to initiate default fragment after login at the launch of dashboard
     */
    private void selectFirstItemAsDefault() {
        if (navigationView != null) {
            final DashboardFragment firstFragment = new DashboardFragment();
            getSupportFragmentManager().beginTransaction().replace(R.id.frame_container, firstFragment, TAG_HOME).addToBackStack(null).commit();
            GeneralUtils.showTitle(this, getToolbar(), getResources().getString(R.string.title_activity_dashboard));
        }
    }

    /**
     * This method is used to add navigation menu and submenu items using expandable listView
     * based upon child and group position
     */

    private void addDrawerItems() {
        ExpandableListAdapter mMenuAdapter = new ExpandableListAdapter(DashboardActivity.this, mListDataHeader, mListDataChild);
        expandableListView.setAdapter(mMenuAdapter);
        expandableListView.setOnGroupExpandListener(groupPosition -> {
            if (groupPosition != mPreviousItem) {
                expandableListView.collapseGroup(mPreviousItem);
                mPreviousItem = groupPosition;
            }
        });
        expandableListView.setOnGroupClickListener((parent, v, groupPosition, id) -> {
            replaceFragment(groupPosition);
            return false;
        });
        expandableListView.setOnChildClickListener((expandableListVieww, view, groupPosition, i1, l) -> {
            Fragment fragment = null;
            if (groupPosition == 3) {
                fragment = memberSelfServices(i1);
            } else if (groupPosition == 4) {
                fragment = getProfileManagementView(i1);
            } else if (groupPosition == 5) {
                fragment = getCareManagementView(i1);
            } /* else {
                switch (i1) {
                    case 0:
                        fragment = new DentalFragment();
                        break;
                    case 1:
                        fragment = new VisionFragment();
                        break;
                    default:
                }
            } */
            if (fragment != null) {
                for (int i = 0; i < getSupportFragmentManager().getBackStackEntryCount(); i++) {
                    getSupportFragmentManager().popBackStack();
                }
                getSupportFragmentManager().beginTransaction().replace(R.id.frame_container, fragment).addToBackStack(null).commit();
            }
            drawerLayoutDashboard.closeDrawers();
            return false;
        });
    }

    /*
    This method is used to get all profile management related fragments
     */
    private Fragment getProfileManagementView(int i1) {
        Fragment fragment = null;
        switch (i1) {
            case 0:
                fragment = new ChangeQuestionsFragment();
                break;
            case 1:
                fragment = new ChangePasswordFragment();
                break;
            case 2:
                fragment = new UpdateDemographicsFragment();
                break;
            default:
        }
        return fragment;
    }

    private Fragment getCareManagementView(int i1) {
        Fragment fragment = null;
        switch (i1) {
            case 0:
                fragment = new SendMessageFragment();
                break;
            case 1:
                Intent intTele = new Intent(DashboardActivity.this, TeleMedicineActivity.class);
                startActivity(intTele);
                break;
            case 2:
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(AppConstants.SYMPTOM_CHECKER));
                    startActivity(intent);
                break;
            /*case 3:
                fragment = new ComplexCaseManagementFragment();
                break;*/
            default:
        }
        return fragment;
    }

    private Fragment memberSelfServices(int i1) {
        Fragment fragment = null;
        switch (i1) {
            case 0:
                fragment = new ViewIDCardFrament();
                break;
            case 1:
                fragment = new SendMessageFragment();
                break;
            default:
        }
        return fragment;
    }

    /*
     This method is used to prepare dashboard portlet details data
     based upon child and group position
     */

    private void prepareListData() {
        mListDataHeader = new ArrayList<>();
        mListDataChild = new HashMap<>();
        GeneralUtils.setLanguage(getApplicationContext());
        MemberEligibleInfo info = ProfileDataCache.getInstance().getMemberEligibleInfo();
        String[] groupArrayList;
        if (info != null && StringConstants.LOB_WPS.equals(info.getLineOfBusiness()) && StringConstants.ENTITY_ID_MEDMARSOL.equals(info.getCurrentRelEntityID())) {
            groupArrayList = getResources().getStringArray(R.array.drawer_list_medicare);
        } else {
            groupArrayList = getResources().getStringArray(R.array.drawer_list);
        }
        Resources res = getResources();
    /*
      Recycle requires to free/clear all the data associated with corresponding resource
     */
        TypedArray icons = res.obtainTypedArray(R.array.icons);

        for (int i = 0; i < groupArrayList.length; i++) {
            ExpandedMenuModel group = new ExpandedMenuModel();
            group.setIconName(groupArrayList[i]);
            group.setIconImg(icons.getResourceId(i, -1));
            if (groupArrayList[i].equalsIgnoreCase(getString(R.string.profile_management))) {
                List<String> childs = new ArrayList<>();
                childs.add(getString(R.string.change_questions));
                childs.add(getString(R.string.change_param1));
                try {
                    if (info.getCurrentRelEntityID() != null && !info.getCurrentRelEntityID().isEmpty()) {
                        if (!StringConstants.ENTITY_ID_MEDMARSOL.equals(info.getCurrentRelEntityID()) || !StringConstants.ENTITY_ID_COMMSOLIN.equals(info.getCurrentRelEntityID())) {
                            childs.add(getString(R.string.update_demographics));
                        }
                    }
                } catch (Exception e) {
                    e.getMessage();
                }
                mListDataChild.put(group, childs);
            }
            if (groupArrayList[i].equalsIgnoreCase(getString(R.string.member_self_services))) {
                List<String> childs = new ArrayList<>();
                childs.add(getString(R.string.view_id_card_title));
                childs.add(getString(R.string.secure_messages));
                mListDataChild.put(group, childs);
            }
            if (groupArrayList[i].equalsIgnoreCase(getString(R.string.care_management))) {
                List<String> childs = new ArrayList<>();
                childs.add(getString(R.string.clinicial_communication));
                childs.add(getString(R.string.telemedicine));
                childs.add(getString(R.string.symptom_checker));
//                childs.add(getString(R.string.complex_case_management));
                mListDataChild.put(group, childs);
            }
            mListDataHeader.add(group);
        }
        icons.recycle();
    }

    /*
      This method is used to open a new fragment from navigation drawerLayoutDashboard list
      & update the main content by replacing fragments
     */

    private void replaceFragment(final int position) {
        new Handler().postDelayed(() -> {
            Fragment fragment = null;
            switch (position) {
                case 0:
                    fragment = new DashboardFragment();
                    break;
                case 1:
                    fragment = new MyClaimsFragment();
                    break;
                case 2:
                    fragment = new BenefitsFragment();
                    break;
                case 3:
                case 4:
                case 5:
                    return;
                case 6:
                    MemberEligibleInfo info = ProfileDataCache.getInstance().getMemberEligibleInfo();
                    if (StringConstants.LOB_WPS.equals(info.getLineOfBusiness()) && StringConstants.ENTITY_ID_MEDMARSOL.equals(info.getCurrentRelEntityID())) {
                        fragment = new LogoutFragment();
                    } else if (StringConstants.LOB_AAH.equals(info.getLineOfBusiness()) && StringConstants.ENTITY_ID_COMMSOLGR.equals(info.getCurrentRelEntityID())) {
                        fragment = new AuthorizationReferalFragment();
                    } else if (StringConstants.LOB_WPS.equals(info.getLineOfBusiness()) && StringConstants.ENTITY_ID_COMMSOLGR.equals(info.getCurrentRelEntityID())) {
                        fragment = new AuthorizationReferalFragment();
                    }
                    break;
                case 7:
//                    fragment = new AddMedicationDetailFragment();
                    fragment = new CustomAddMedicationView();
                    break;
                case 8:
                    fragment = new ProviderSearchFragment();
                    break;
                case 9:
                    fragment = new TCCFragment();
                    break;
                case 10:
                    fragment = new ImmunizationFragment();
                    break;
                case 11:
                    Intent in = new Intent(DashboardActivity.this, RootActivity.class);
                    startActivity(in);
                    break;
                case 12:
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(AppConstants.MY_HEALTH_COACH));
                    startActivity(intent);
                    break;
                case 13:
                    fragment = new LogoutFragment();
                    break;
                default:
                    break;
            }
            if (fragment != null) {
                for (int i = 0; i < getSupportFragmentManager().getBackStackEntryCount(); i++) {
                    getSupportFragmentManager().popBackStack();
                }
                getSupportFragmentManager().beginTransaction().replace(R.id.frame_container, fragment).addToBackStack(null).commit();
                expandableListView.setItemChecked(position, true);
                expandableListView.setSelection(position);
                drawerLayoutDashboard.closeDrawers();
            } else {
                // Error in creating fragment
                Log.e(StringConstants.EXCEPTION, "Error in creating fragment");
            }
            drawerLayoutDashboard.closeDrawers();
        }, 100);
    }

    private void menuItemSelector(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.action_call) {
            Intent i = new Intent(DashboardActivity.this, ChatBotActivity.class);
            startActivity(i);
        } else if (menuItem.getItemId() == R.id.action_text) {
            Intent intent = new Intent(DashboardActivity.this, WebViewActivity.class);
            startActivity(intent);
        } else if (menuItem.getItemId() == R.id.action_email1) {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(AppConstants.SFDC_COMMUNITY_URL));
            startActivity(intent);
        } else if (menuItem.getItemId() == R.id.action_email) {
            Intent intent = new Intent(DashboardActivity.this, LaunchChatActivity.class);
            startActivity(intent);
        }
    }

    /*
    This method is used to handle the user back click actions
     */
    @Override
    public void onBackPressed() {
        Log.i("Dashboard", "onBackPressed");
        int fragments = getSupportFragmentManager().getBackStackEntryCount();
        if (drawerLayoutDashboard.isDrawerOpen(GravityCompat.START)) {
            drawerLayoutDashboard.closeDrawers();
        } else if (fragments > 1) {
            getSupportFragmentManager().popBackStack();
        } else if (fragments == 1) {
            Fragment myFragment = getSupportFragmentManager().findFragmentById(R.id.frame_container);
            //If user is in dashboard screen then we are showing logout screen
            if (myFragment instanceof DashboardFragment) {
                Fragment fragment = new LogoutFragment();
                getSupportFragmentManager().beginTransaction().replace(R.id.frame_container, fragment).addToBackStack(null).commit();
            } else {
                //If user is in other than dashboard then we are showing dashboard screen
                getSupportFragmentManager().popBackStack();
                DashboardFragment firstFragment = new DashboardFragment();
                getSupportFragmentManager().beginTransaction().replace(R.id.frame_container,
                        firstFragment, TAG_HOME).addToBackStack(null).commit();
                GeneralUtils.showTitle(this, getToolbar(), getResources().getString(R.string.title_activity_dashboard));
            }
        } else {
            Fragment fragment = new LogoutFragment();
            getSupportFragmentManager().beginTransaction().replace(R.id.frame_container, fragment).addToBackStack(null).commit();
        }
    }

    @Override
    protected void attachBaseContext(Context base) {
//        super.attachBaseContext(LocaleHelper.onAttach(base));
        String lang = SharedPreferenceHelper.getInstance().getPreference(base, "Language");
        if ("es".equalsIgnoreCase(lang)) {
            base = LocaleHelper.setLocale(base, "es");
            super.attachBaseContext(base);
        } else {
            base = LocaleHelper.setLocale(base, "en");
            super.attachBaseContext(base);
        }
    }


    /**
     * Called at the time of registering device when the login button is pressed
     * Attempts to register the device with  push service on BlueMix.
     * If successful, the push client sdk begins listening to the notification listener.
     * Also includes the example option of UserID association with the registration for very targeted Push notifications.
     */
    /*private void registerDevice() {

        // Checks for null in case registration has failed previously
        if (push == null) {
            push = MFPPush.getInstance();
        }
        // Creates response listener to handle the response when a device is registered.
        MFPPushResponseListener<String> registrationResponseListener = new MFPPushResponseListener<String>() {
            @Override
            public void onSuccess(String response) {
                // Split response and convert to JSON object to display User ID confirmation from the backend
                Log.i("TAG", "Successfully registered for push notifications, " + response);

                // Start listening to notification listener now that registration has succeeded
                push.listen(notificationListener);
            }

            @Override
            public void onFailure(MFPPushException exception) {
                String errLog = "Error registering for push notifications: ";
                String errMessage = exception.getErrorMessage();
                int statusCode = exception.getStatusCode();
                // Set error log based on response code and error message
                if (statusCode == 401) {
                    errLog += "Cannot authenticate successfully with BlueMix Push instance, ensure your CLIENT SECRET was set correctly.";
                } else if (statusCode == 404 && errMessage.contains("Push GCM Configuration")) {
                    errLog += "Push GCM Configuration does not exist, ensure you have configured GCM Push credentials on your BlueMix Push dashboard correctly.";
                } else if (statusCode == 404 && errMessage.contains("PushApplication")) {
                    errLog += "Cannot find BlueMix Push instance, ensure your APPLICATION ID was set correctly and your phone can successfully connect to the internet.";
                } else if (statusCode >= 500) {
                    errLog += "BlueMix and/or your Push instance seem to be having problems, please try again later.";
                }

                Log.e("TAG", errLog);
                // make push null since registration failed
                push = null;
            }
        };
        // Attempt to register device using response listener created above
        // Include unique sample user Id instead of Sample UserId in order to send targeted push notifications to specific users
        push.registerDeviceWithUserId("emp1@vol.com", registrationResponseListener);
    }*/

    // If the device has been registered previously, hold push notifications when the app is paused
    /*@Override
    protected void onPause() {
        super.onPause();
        if (push != null) {
            push.hold();
        }
//        sendNotification(mPopUpMessage);
    }*/

    // If the device has been registered previously, ensure the client sdk is still using the notification listener from onCreate when app is resumed
    /*@Override
    protected void onResume() {
        super.onResume();
        if (push != null) {
            push.listen(notificationListener);
        }
        sendNotification(mPopUpMessage);
    }*/

    /*@Override
    protected void onRestart() {
        super.onRestart();
        sendNotification(mPopUpMessage);
    }*/

    /**
     * Manipulates text fields in the UI based on initialization and registration events
     *
     * @param messageText   String main text view
     * @param wasSuccessful Boolean dictates top 2 text view texts
     */
    private void setStatus(final String messageText, boolean wasSuccessful) {
        final String topStatus = wasSuccessful ? "Yay!" : "Bummer";
        final String bottomStatus = wasSuccessful ? "You Are Connected" : "Something Went Wrong";

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                // buttonText.setClickable(true);
                // responseText.setText(messageText);
                //topText.setText(topStatus);
                //bottomText.setText(bottomStatus);
            }
        });
    }

}

