package com.wps.memberapp.presentation.dashboard.activity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Environment;

import com.android.volley.VolleyError;
import com.github.barteksc.pdfviewer.PDFView;
import com.wps.memberapp.R;
import com.wps.memberapp.domain.dataservice.VolleyByteResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.utility.Logger;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import androidx.appcompat.app.AppCompatActivity;
import butterknife.BindView;
import butterknife.ButterKnife;

public class HRAPDFActivity extends AppCompatActivity {
    @BindView(R.id.pdfView)
    PDFView pdfView;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hra_pdfview);
        ButterKnife.bind(this);
        String url = getIntent().getStringExtra("url");
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(false);
        progressDialog.show();
        try {
            VolleyService.getHRAAsPDF(this, url, new VolleyByteResponseListener() {
                @Override
                public void onResponse(byte[] response) {
                    convertBytesToPDF(response);
                    progressDialog.dismiss();
                    File pdfFile = new File(Environment.getExternalStorageDirectory() + "/MayoClinic/" + "HRA.pdf");
                    try {
                        pdfView.fromFile(pdfFile).enableDoubletap(true).load();
                    } catch (Exception e) {
                        Logger.e("Exc1", e);
                    }
                }

                @Override
                public void onError(VolleyError error) {
                    //Empty block
                }
            });
        } catch (Exception e) {
            e.getLocalizedMessage();
        }
    }

    private void convertBytesToPDF(byte[] response) {
        try {
            //covert reponse to input stream
            InputStream input = new ByteArrayInputStream(response);
            //Create a file on desired path and write stream data to it
            String extStorageDirectory = Environment.getExternalStorageDirectory().toString();
            File folder = new File(extStorageDirectory, "MayoClinic");
            folder.mkdir();
            File pdfFile = new File(folder, "HRA.pdf");
            BufferedOutputStream output = new BufferedOutputStream(new FileOutputStream(pdfFile));
            byte data[] = new byte[1024];
            int count;
            while ((count = input.read(data)) != -1) {
                output.write(data, 0, count);
            }
            output.flush();
            output.close();
            input.close();
        } catch (IOException e) {
            Logger.e("Exc", e);
        }
    }
}
