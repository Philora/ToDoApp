package com.wps.memberapp.presentation.dashboard.activity;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;
import com.wps.memberapp.R;
import com.wps.memberapp.data.model.GetKnowledgeBase;
import com.wps.memberapp.presentation.dashboard.adapter.KnowledgeBaseAdapter;
import com.wps.memberapp.utility.AppConstants;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class KnowledgeBaseActivity extends AppCompatActivity implements KnowledgeBaseAdapter.KnowledgeBaseAdapterListener{
    private static final String TAG = KnowledgeBaseActivity.class.getSimpleName();
    private RecyclerView recyclerView;
    private List<GetKnowledgeBase> contactList;
    private KnowledgeBaseAdapter mAdapter;
    private SearchView searchView;
    private String searchMedicalQuery;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_knowledge_base);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // toolbar fancy stuff
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        getSupportActionBar().setTitle(R.string.toolbar_title);

        // Associate searchable configuration with the SearchView
        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        searchView = (SearchView) findViewById(R.id.search_view_knowledge_base);
        recyclerView = (RecyclerView) findViewById(R.id.rv_search_result_knowledge_base);
        contactList = new ArrayList<>();

        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        searchView.setMaxWidth(Integer.MAX_VALUE);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                mAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                try {
                    searchMedicalQuery = newText;
                    if (newText.length() > 2) {
                        mAdapter.getFilter().filter(newText);
                        recyclerView.setVisibility(View.VISIBLE);
//                        searchView.clearFocus();
                    } else {
                        recyclerView.setVisibility(View.GONE);
                    }

                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
                return false;
            }
        });


        mAdapter = new KnowledgeBaseAdapter(this, contactList, this);

        whiteNotificationBar(recyclerView);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.addItemDecoration(new MyDividerItemDecoration(this, DividerItemDecoration.VERTICAL, 36));
        recyclerView.setAdapter(mAdapter);

        fetchContacts();
    }

    private void fetchContacts() {
        Gson gson = new Gson();
        try {
            //getAssets().open("file_name.json")
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(getAssets().open("response.json")));
            JsonReader jsonreader = new JsonReader(reader);
            //JsonReader reader = new JsonReader(new FileReader("response.json"));
            GetKnowledgeBase[] data = gson.fromJson(jsonreader, GetKnowledgeBase[].class);
            contactList.clear();
            List<GetKnowledgeBase> list = Arrays.asList(data);
            contactList.addAll(list);
            // refreshing recycler view
            Log.d(TAG, "fetchContacts: data rendered");
            mAdapter.notifyDataSetChanged();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i = new Intent(KnowledgeBaseActivity.this, DashboardActivity.class);
        startActivity(i);
    }

    private void whiteNotificationBar(View view) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                int flags = view.getSystemUiVisibility();
                flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                view.setSystemUiVisibility(flags);
                getWindow().setStatusBarColor(Color.WHITE);
            }
        } catch (Exception e) {
            e.getLocalizedMessage();
        }
    }

    @Override
    public void onContactSelected(GetKnowledgeBase contact) {
        try {
//        Toast.makeText(getApplicationContext(), "Selected: " + contact.getTitle(), Toast.LENGTH_LONG).show();
            String mPocID = contact.getDocID();
//            Toast.makeText(getApplicationContext(), "Selected Poc_ID: " + mPocID, Toast.LENGTH_LONG).show();
            Uri uri = Uri.parse(AppConstants.PDF_WEB_VIEW + mPocID + "&Language=en");
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, "application/pdf");
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        } catch (Exception e) {
            e.getLocalizedMessage();
        }
    }
}
