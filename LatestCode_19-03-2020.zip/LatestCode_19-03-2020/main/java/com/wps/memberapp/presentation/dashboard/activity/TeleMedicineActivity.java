package com.wps.memberapp.presentation.dashboard.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.wps.memberapp.R;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.GeneralUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import butterknife.BindView;
import butterknife.ButterKnife;

public class TeleMedicineActivity extends AppCompatActivity {

    @BindView(R.id.wv_telemedicine)
    WebView wvTelemedicine;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_telemedicine);
        ButterKnife.bind(this);
        wvTelemedicine.addJavascriptInterface(new TeleMedicineActivity.WebAppInterface(this), "DataTheoremJBridge");
        wvTelemedicine.getSettings().setJavaScriptEnabled(true);
        //Loading URL into webview
        wvTelemedicine.loadUrl(AppConstants.TELE_MEDICINE_URL);
        wvTelemedicine.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(@NonNull WebView view, String url) {
                String url2 = AppConstants.TELE_MEDICINE_URL;
                // all links  with in ur site will be open inside the webview
                //links that start ur domain example(http://www.example.com/)
                if (url != null && url.startsWith(url2) && (Uri.parse(url).getScheme().equalsIgnoreCase("https"))) {
                    return false;
                }
                // all links that points outside the site will be open in a normal android browser
                view.getContext().startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                GeneralUtils.showProgress(TeleMedicineActivity.this);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                GeneralUtils.hideProgress();
            }
        });

    }

    public class WebAppInterface {
        Context mContext;

        /**
         * Instantiate the interface and set the context
         */
        WebAppInterface(Context c) {
            mContext = c;
        }

        /**
         * Show a toast from the web page
         */
        @JavascriptInterface
        public void showToast(String toast) {
            Toast.makeText(mContext, toast, Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    public void onBackPressed() {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setData(Uri.parse(AppConstants.TELE_MEDICINE_INTOUCH));
            startActivity(i);
            finish();
        } catch (Exception e) {
            e.getLocalizedMessage();
        }
    }
}
