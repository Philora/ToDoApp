package com.wps.memberapp.presentation.dashboard.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;


import com.wps.memberapp.R;
import com.wps.memberapp.utility.AppConstants;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import butterknife.BindView;
import butterknife.ButterKnife;

public class WebViewActivity extends Activity {

    @BindView(R.id.webView1)
    WebView webView;

    @SuppressLint("SetJavaScriptEnabled")
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_web);
        ButterKnife.bind(this);
        webView.addJavascriptInterface(new WebViewActivity.WebAppInterface(this), "DataTheoremJBridge");
        webView.getSettings().setJavaScriptEnabled(true);
        //Loading URL into webview
        webView.loadUrl(AppConstants.LIVEZILLA_CHAT_URL);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(@NonNull WebView view, String url) {
                String url2=AppConstants.LIVEZILLA_CHAT_URL;
                // all links  with in ur site will be open inside the webview
                //links that start ur domain example(http://www.example.com/)
                if (url != null && url.startsWith(url2) &&
                        (Uri.parse(url).getScheme().equalsIgnoreCase("https"))){
                    return false;
                }
                // all links that points outside the site will be open in a normal android browser
                view.getContext().startActivity(
                        new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                return true;
            }
        });
    }
    public class WebAppInterface {
        Context mContext;
        /** Instantiate the interface and set the context */
        WebAppInterface(Context c) {
            mContext = c;
        }
        /** Show a toast from the web page */
        @JavascriptInterface
        public void showToast(String toast) {
            Toast.makeText(mContext, toast, Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    public void onBackPressed() {
        Intent i = new Intent(WebViewActivity.this, DashboardActivity.class);
        startActivity(i);
    }
}
