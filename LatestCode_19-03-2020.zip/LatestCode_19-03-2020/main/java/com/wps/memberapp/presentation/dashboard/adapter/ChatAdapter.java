package com.wps.memberapp.presentation.dashboard.adapter;


import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.Message;
import com.wps.memberapp.presentation.immunization.activity.WebViewPDFActivity;
import com.wps.memberapp.utility.AppConstants;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


public class ChatAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final String CHAT_TAG = "ChatAdapter";
    private static final int SELF = 100;
    private final List<Message> messageArrayList;
    private Context context;

    public ChatAdapter(List<Message> messageArrayList) {
        this.messageArrayList = messageArrayList;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView;

        // view type is to identify where to render the chat message
        // left or right
        context = parent.getContext();
        if (viewType == SELF) {
            // self message
            itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.chat_item_self, parent, false);
        } else {
            // WatBot message
            itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.chat_item_watson, parent, false);
        }
        return new MyViewHolder(itemView);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        if (messageArrayList != null && !messageArrayList.isEmpty()) {
            Message message = messageArrayList.get(position);
            if (message.getUserType().equals("User")) {
                return SELF;
            }
        }
        return position;
    }


    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, int position) {
        final Message message = messageArrayList.get(position);
        message.setMessage(message.getMessage());

        ((MyViewHolder) holder).message.setMovementMethod(LinkMovementMethod.getInstance());
        ((MyViewHolder) holder).message.setText(message.getMessage());

        ((MyViewHolder) holder).message.setOnClickListener(view -> {
            Log.i("state", "clicked");
            try {
                if (message.getUrl() != null) { // create one common method for opening the pdf file
                    callPDFView(message.getUrl());
                } else {
                    Toast.makeText(context, "Unable to launch URL!!!", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                e.getLocalizedMessage();
            }
        });
        ((MyViewHolder) holder).itemView.setOnClickListener(view -> {
            try {
                Log.i("state", "clicked");
                if (message.getUrl() != null) {
                    callPDFView(message.getUrl());
                } else {
                    Toast.makeText(context, "Unable to launch URL!!!", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                e.getLocalizedMessage();
            }
        });
        ((MyViewHolder) holder).time.setText(message.getCreatedAt());
    }

    private void callPDFView(String url) {
        Uri uri = Uri.parse(AppConstants.PDF_WEB_VIEW + url + "&Language=en");
        // tried code
                /*Uri uri = Uri.parse(AppConstants.PDF_WEB_VIEW + message.getUrl() + "&Language=en");
                Intent target = new Intent(Intent.ACTION_VIEW);
                target.setDataAndType(uri, "application/pdf");
                Intent intent = Intent.createChooser(target, "Open File");
                context.startActivity(intent);*/
        // Checking with Browser
                /*Uri uri = Uri.parse(AppConstants.PDF_WEB_VIEW + message.getUrl() + "&Language=en");
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                context.startActivity(intent);*/
        // Using flag for opening the PDF
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(uri, "application/pdf");
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        context.startActivity(intent);
/*                Intent intn = new Intent(context, WebViewPDFActivity.class);
                intn.putExtra("PDFUrl", message.getUrl());
                context.startActivity(intn);*/
    }

    @Override
    public int getItemCount() {
        return messageArrayList.size();
    }

    public static boolean isValidURL(String responseURL) {
        String result;
        try {
            URL url = new URL(responseURL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET"); // request method GET OR POST
            conn.connect(); // calling the web address
            int resCode = conn.getResponseCode();
            if (resCode == 200) {
                result = String.valueOf(resCode);
                Log.d(CHAT_TAG, "The response is: " + result);
            } else {
                result = String.valueOf(resCode);
                Log.d(CHAT_TAG, "isValid: " + responseURL + result);
                return false;
            }
        } catch (Exception e) {
            e.getLocalizedMessage();
            return false;
        }
        Log.d(CHAT_TAG, "isValid: " + responseURL + result);
        return true;
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        final TextView message;
        final TextView time;

        MyViewHolder(View view) {
            super(view);
            message = itemView.findViewById(R.id.message);
            time = itemView.findViewById(R.id.messageConfirmation);
        }
    }

}