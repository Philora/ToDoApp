package com.wps.memberapp.presentation.dashboard.adapter;

import android.annotation.TargetApi;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.StyleSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.android.volley.VolleyError;
import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.HorizontalBarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.AccountBalance;
import com.wps.memberapp.data.model.AccountBalanceOOP;
import com.wps.memberapp.data.model.AuthorizationModel;
import com.wps.memberapp.data.model.ClaimSummaryModel;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.model.MemberFeed;
import com.wps.memberapp.data.model.NotificationModel;
import com.wps.memberapp.data.model.Portlet;
import com.wps.memberapp.domain.dataservice.VolleyByteResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.authreferral.adapter.AuthorizationViewHolder;
import com.wps.memberapp.presentation.authreferral.fragment.AuthorizationReferalFragment;
import com.wps.memberapp.presentation.benefits.fragment.BenefitsFragment;
import com.wps.memberapp.presentation.claims.fragment.MyClaimsFragment;
import com.wps.memberapp.presentation.dashboard.activity.HRAPDFActivity;
import com.wps.memberapp.presentation.dashboard.adapter.viewholder.AccountBalanceOOPViewHolder;
import com.wps.memberapp.presentation.dashboard.adapter.viewholder.AccountBalanceViewHolder;
import com.wps.memberapp.presentation.dashboard.adapter.viewholder.DashboardViewHolder;
import com.wps.memberapp.presentation.dashboard.adapter.viewholder.EmptyViewHolder;
import com.wps.memberapp.presentation.dashboard.adapter.viewholder.MyClaimViewHolder;
import com.wps.memberapp.presentation.dashboard.adapter.viewholder.MyCoverageViewHolder;
import com.wps.memberapp.presentation.dashboard.adapter.viewholder.NotificationViewHolder;
import com.wps.memberapp.presentation.dashboard.adapter.viewholder.WellnessViewHolder;
import com.wps.memberapp.presentation.immunization.activity.WebViewPDFActivity;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.AuthReferralValueFormatter;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;

import static com.wps.memberapp.utility.GeneralUtils.hideProgress;

/**
 * This adapter is used to display all the dashboard widgets
 * in a list view format.
 */
public class DashboardAdapter extends RecyclerView.Adapter<ViewHolder> {


    //Member variables
    private final int[] myCOLORS = {
            Color.rgb(140, 198, 64),
            Color.rgb(41, 171, 226),
            Color.rgb(44, 49, 120),
            Color.rgb(4, 85, 165),
            Color.rgb(7, 182, 131)};

    private final AppCompatActivity mContext;
    private final List<Portlet> mPortletList;
    private final List<MemberDetails> mMemberList;
    private AccountBalance mAccountModel;
    private AccountBalanceOOP mAccountOOPModel;
    private final List<MemberFeed> mMemberFeedList;
    private List<AuthorizationModel> mAuthList;
    private PieChart mChart;
    private static final String FILE_NAME = "HRA.pdf";

    public DashboardAdapter(AppCompatActivity context, List<Portlet> portletList,
                            List<MemberDetails> mMemberList, List<MemberFeed> mMemberFeedList) {
        this.mContext = context;
        this.mPortletList = portletList;
        this.mMemberList = mMemberList;
        this.mMemberFeedList = mMemberFeedList;
    }

    /*
  Creating ViewHolder based on the layout to bind the data to adapter.
   */
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        switch (viewType) {
            case Portlet.MEMBER_FEED:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_cardview_member_feed, parent, false);
                return new DashboardViewHolder(view);
            case Portlet.NOTIFICATION:
//                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_cardview_notification, parent, false);
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_notification_list_item, parent, false);
                return new NotificationViewHolder(view);
            case Portlet.CARE_ASSESSMENT:
                view = LayoutInflater.from(parent.getContext()).inflate
                        (R.layout.row_cardview_account_care_assessment, parent, false);
                return new WellnessViewHolder(view);
            case Portlet.MY_COVERAGE:
                view = LayoutInflater.from(parent.getContext()).inflate
                        (R.layout.row_cardview_coverage, parent, false);
                return new MyCoverageViewHolder(view);
            case Portlet.MYCLAIM:
                view = LayoutInflater.from(parent.getContext()).inflate
                        (R.layout.row_cardview_claimsummary, parent, false);
                return new MyClaimViewHolder(view);
            case Portlet.AUTHORIZATION_REFERAL:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_cardview_authorization, parent, false);
                return new AuthorizationViewHolder(view);
            case Portlet.ACCOUNT_BALANCE:
                view = LayoutInflater.from(parent.getContext()).inflate
                        (R.layout.row_cardview_account_balance, parent, false);
                return new AccountBalanceViewHolder(view);
            case Portlet.ACCOUNT_BALANCE_OOP:
                view = LayoutInflater.from(parent.getContext()).inflate
                        (R.layout.row_cardview_account_balanceoop, parent, false);
                return new AccountBalanceOOPViewHolder(view);
            default:
                view = LayoutInflater.from(parent.getContext()).inflate
                        (R.layout.row_empty_view, parent, false);
                return new EmptyViewHolder(view);
        }
    }

    /*
       Binding data to ViewHolder class object based on the position.
       */
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        Portlet portletDetail = mPortletList.get(position);
        if (portletDetail != null) switch (portletDetail.getViewType()) {

            case Portlet.MEMBER_FEED:
                final DashboardViewHolder dashboardViewController = (DashboardViewHolder) holder;
                MemberFeedsAdapter adapter = new MemberFeedsAdapter(mMemberFeedList);
                LinearLayoutManager layoutManager = new LinearLayoutManager(mContext);
                layoutManager.setOrientation(RecyclerView.VERTICAL);
                dashboardViewController.recyclerView.setLayoutManager(layoutManager);
                dashboardViewController.recyclerView.setItemAnimator(new DefaultItemAnimator());
                dashboardViewController.recyclerView.setAdapter(adapter);
                dashboardViewController.recyclerView.addOnItemTouchListener(mScrollTouchListener);
//                dashboardViewController.tvHeading.setText(portletDetail.getHeading());
                dashboardViewController.tvHeading.setText(mContext.getString(R.string.member_news));
                break;
            case Portlet.NOTIFICATION:

                final NotificationViewHolder notificationViewController = (NotificationViewHolder) holder;
//                notificationViewController.notificationHeader.setText(portletDetail.getHeading());
                notificationViewController.notificationHeader.setText(mContext.getString(R.string.notifications));

                notificationViewController.titleTxt6.setOnClickListener(view -> {
                    Uri uri = Uri.parse(AppConstants.SURVEY_URL);
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    mContext.startActivity(intent);
                });

                notificationViewController.titleTxt7.setOnClickListener(view -> {
                    Intent i = new Intent(mContext, HRAPDFActivity.class);
                    //Log.i("PDF URL",AppConstants.WELLNESS_SCORE);
                    i.putExtra("url", AppConstants.WELLNESS_SCORE);
                    mContext.startActivity(i);
                });
                break;

            case Portlet.CARE_ASSESSMENT:

                final WellnessViewHolder wellnessViewController = (WellnessViewHolder) holder;
                wellnessViewController.txtWellnessHeader.setText(mContext.getString(R.string.wellness));
                String mData = "Diabetes";
                /*if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    wellnessViewController.txtDiabetes.setText(Html.fromHtml(mData, Html.FROM_HTML_MODE_LEGACY));
                } else {
                    wellnessViewController.txtDiabetes.setText(Html.fromHtml(mData));
                }*/

                wellnessViewController.txtDiabetes.setOnClickListener(view -> {
                    callPDF();
                });

                wellnessViewController.txtSeeReview.setOnClickListener(view -> {
                    callPDF();
                });

                wellnessViewController.txtCheckMammogram.setOnClickListener(view -> {
                    callPDF();
                });

                wellnessViewController.txtCheckColono.setOnClickListener(view -> {
                    callPDF();
                });
                wellnessViewController.txtImmunization.setOnClickListener(view -> {
                    callPDF();
                });
                break;

            case Portlet.MY_COVERAGE:
                try {
                    populateMyCoverage(portletDetail, holder);
                } catch (Exception e) {
                    Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
                }
                break;

            case Portlet.ACCOUNT_BALANCE:
                updateBalanceWidget(holder, portletDetail.getHeading());
                break;

            case Portlet.ACCOUNT_BALANCE_OOP:
                updateOOPBalanceWidget(holder, portletDetail.getHeading());
                break;

            case Portlet.MYCLAIM:
                updateClaimsWidget(holder, portletDetail.getHeading());
                break;
            case Portlet.AUTHORIZATION_REFERAL:
                updateReferralsWidget(holder);
                break;
            default:
                break;
        }
    }

    private void callPDF() {
        Uri uri = Uri.parse(AppConstants.CARE_WELLNESS_REVIEW);
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        mContext.startActivity(intent);
    }

    /*
  This method is used to get the items size in array list
 */
    @Override
    public int getItemCount() {
        return mPortletList.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        return mPortletList.get(position).getViewType();
    }

    /*
    This method is used to display user claim summary in the adapter
    */
    private void updateClaimsWidget(ViewHolder holder, String header) {
        final MyClaimViewHolder myClaimViewController = (MyClaimViewHolder) holder;
//        myClaimViewController.tvClaimHeader.setText(header);
        myClaimViewController.tvClaimHeader.setText(mContext.getString(R.string.claims_summary));
        ClaimSummaryModel model = ProfileDataCache.getInstance().getClaimSummary();
        if (model != null) {
            populateClaimSummary(model, myClaimViewController);
        } else {
            getClaimSummaryData(myClaimViewController);
        }
        myClaimViewController.btnDetail.setOnClickListener(view -> {
            Fragment fragment = new MyClaimsFragment();
            FragmentManager fragmentManager = mContext.getSupportFragmentManager();
            fragmentManager.beginTransaction().replace(R.id.frame_container, fragment).addToBackStack(null).commit();
        });
    }
    /*
     Used to parse Authorization Referal data through Gson parsing library
     */

    @NonNull
    private List<AuthorizationModel> parseJson(String response) {
        final ArrayList<AuthorizationModel> authStatus = new ArrayList<>();
        try {
            if (response != null) { // Checking Null
                Gson gson = new GsonBuilder().create();
                JSONArray jsonArray = new JSONObject(response).getJSONArray("AuthirizationStatusCount");
                for (int i = 0; i < jsonArray.length(); i++) {
                    AuthorizationModel authModel = gson.fromJson(jsonArray.getString(i), AuthorizationModel.class);
                    if (authModel.getStatus() != null) {
                        authStatus.add(authModel);
                    }
                }
            }
        } catch (Exception e) {
            Log.wtf("error", e.getMessage());
        }
        return authStatus;
    }

    /*
      Used to plot Authorization Referal data and plot it using Pie Chart through MP Android chart library
     */

    private PieChart getPieChartResults(List<AuthorizationModel> mAuthList) {

        ArrayList<PieEntry> yvalues = new ArrayList<>();
        if (mAuthList != null) { // Checking Null
            for (int i = 0; i < mAuthList.size(); i++) {
                float f1 = Integer.parseInt(mAuthList.get(i).getStatusCount());
                if (yvalues.contains(mContext.getString(R.string.value_0))) {
                    yvalues.remove(mAuthList.contains(mContext.getString(R.string.value_0)));
                } else if (mAuthList.get(i).getStatus().equals(mContext.getString(R.string.title_Pending))) {
                    yvalues.add(new PieEntry((f1), mContext.getString(R.string.title_Pending)));
                } else if (mAuthList.get(i).getStatus().equals(mContext.getString(R.string.title_Approved))) {
                    yvalues.add(new PieEntry((f1), mContext.getString(R.string.title_Approved)));
                } else if (mAuthList.get(i).getStatus().equals(mContext.getString(R.string.title_Partially_Approved))) {
                    yvalues.add(new PieEntry((f1), mContext.getString(R.string.title_Partially_Approved)));
                } else if (mAuthList.get(i).getStatus().equals(mContext.getString(R.string.title_Denied))) {
                    yvalues.add(new PieEntry((f1), mContext.getString(R.string.title_Denied)));
                } /*else if (mAuthList.size() > 4 && mAuthList.get(i).getStatus().equals(mContext.getString(R.string.auth_new_value))) { // if in webportal, they add any new items, we need to check the status value on here and below
                    yvalues.add(new PieEntry((f1), mContext.getString(R.string.auth_new_value)));
                }*/
            }
        }

        // BackUp Code from Existing
        /*ArrayList<PieEntry> yvalues = new ArrayList<>();
        ArrayList<String> xVals = new ArrayList<>();
        for (int i = 0; i < mAuthList.size(); i++) {
            xVals.add(mAuthList.get(i).getStatus());
        }
        xVals.add("open");
        String[] array = new String[xVals.size()];
        array = xVals.toArray(array);

        for (int i = 0; i < mAuthList.size(); i++) {
            float f1 = Integer.parseInt(mAuthList.get(i).getStatusCount());
            yvalues.add(new PieEntry((f1), array[i]));
        }*/

        PieDataSet dataSet = new PieDataSet(yvalues, "");
//        dataSet.setSliceSpace(3f);
        ArrayList<Integer> colors = new ArrayList<>();
        for (int c : myCOLORS)
            colors.add(c);
        dataSet.setColors(colors);
        PieData data = new PieData(dataSet);
        data.setValueFormatter(new AuthReferralValueFormatter());
//        data.setValueFormatter(new PercentFormatter());
        data.setValueTextSize(13f);
        data.setValueTextColor(Color.BLACK);
        mChart = new PieChart(mContext);
        mChart.setData(data);
        dataSet.setYValuePosition(PieDataSet.ValuePosition.OUTSIDE_SLICE);
        mChart.setDrawHoleEnabled(true);
        mChart.setDrawEntryLabels(false);
        mChart.setDrawCenterText(false);
        mChart.setHoleColor(Color.WHITE);
        mChart.setTransparentCircleColor(Color.WHITE);
        mChart.setTransparentCircleAlpha(255);
//        mChart.setHoleRadius(30f);
        mChart.getDescription().setEnabled(false);
        Legend l = mChart.getLegend();
        l.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
        l.setHorizontalAlignment(Legend.LegendHorizontalAlignment.CENTER);
        l.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        mChart.setExtraOffsets(-9, -9, -9, -9);
        mChart.spin(1000, mChart.getRotationAngle(), mChart.getRotationAngle()
                + 360, Easing.EasingOption
                .EaseInCubic);
        mChart.invalidate();
        return mChart;
    }

    /*
    Used to call web service for Get Notifications
    and get response as JSON using post method and display the results in recycle view
   */
    private void loadNotifications(@NonNull final NotificationViewHolder holder) {
        VolleyService.getNotificationsContent(mContext, AppConstants.GET_NOTIFICATIONS_CONTENT, new VolleyResponseListener() {
            @Override
            public void onResponse(String response) {
                try {
                    ProfileDataCache.getInstance().setNotificationContent(response);
                    VolleyService.getNotifications(mContext, AppConstants.GET_NOTIFICATIONS, new VolleyResponseListener() {
                        @Override
                        public void onResponse(String message) {
                            try {
                                Gson gson = new Gson();
                                JSONArray jsonArray = new JSONArray(message);
                                List<NotificationModel> detailsList = new ArrayList<>();
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                                    NotificationModel details = gson.fromJson(jsonObject.toString(), NotificationModel.class);
                                    detailsList.add(details);
                                }
                                // updateNotifications(holder, detailsList);
                            } catch (Exception e) {
                                Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
                            }
                        }

                        @Override
                        public void onError(String error) {
                            Log.i("Error", StringConstants.ERROR);
                        }
                    });
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
            }

            @Override
            public void onError(String error) {
                Log.i("Error", StringConstants.ERROR);
            }
        });
    }

    /*
    This method is used to display user notifications in the adapter
    */
   /* private void updateNotifications(NotificationViewHolder holder, List<NotificationModel> detailsList) {
        MemberNotificationsAdapter adapter = new MemberNotificationsAdapter(detailsList);
        LinearLayoutManager layoutManager = new LinearLayoutManager(mContext);
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        holder.recyclerView.setLayoutManager(layoutManager);
        holder.recyclerView.setItemAnimator(new DefaultItemAnimator());
        holder.recyclerView.setAdapter(adapter);
        if (detailsList.isEmpty()) {
            holder.tvNoNotifications.setVisibility(View.VISIBLE);
        } else {
            holder.tvNoNotifications.setVisibility(View.GONE);
        }
    }*/

    /*
      Volley Post Request String responses from the Web API to populate charts using MP Android chart
      Planning to move this codebase into separate modules
      Used to call web service for claimSummary and get response as JSON
      using post method and to plot the horizontal bar chart
     */

    private void getClaimSummaryData(@NonNull final MyClaimViewHolder holder) {
        VolleyService.getClaimSummaryData(mContext, AppConstants.GET_CLAIMS_SUMMARY, new VolleyResponseListener() {
            @Override
            public void onError(String error) {
                Log.i("POST_ERROR_SUMMARY", StringConstants.ERROR);
            }

            @Override
            public void onResponse(String response) {
                try {
                    Log.i("Claim response", StringConstants.RESPONSE);
                    if (response != null && response.length() > 0) {
                        ClaimSummaryModel model = new Gson().fromJson(response, ClaimSummaryModel.class);
                        ProfileDataCache.getInstance().setClaimSummary(model);
                        populateClaimSummary(model, holder);
                    }
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
            }
        });
    }

    /*
    This method is used to display claim summary details in the adapter
    */
    private void populateClaimSummary(ClaimSummaryModel model, MyClaimViewHolder holder) {
        if (model != null) {
            HorizontalBarChart mHorizontalChart = GeneralUtils.getHorizontalChartResults(mContext, model);
            holder.llclaimSummary.removeAllViews();
            holder.llclaimSummary.addView(mHorizontalChart,
                    new RecyclerView.LayoutParams(RecyclerView.LayoutParams.MATCH_PARENT,
                            RecyclerView.LayoutParams.MATCH_PARENT));
        }
    }

    /*
    This method is used to handle user clicks on the individual and family buttons
   */
    private void updateBalanceWidget(ViewHolder holder, String header) {
        AccountBalanceViewHolder accountBalanceView =
                (AccountBalanceViewHolder) holder;
//        accountBalanceView.tvHeader.setText(header);
        accountBalanceView.tvHeader.setText(mContext.getString(R.string.deductible_balance));
        accountBalanceView.tvFamily.setOnClickListener(view -> {
            accountBalanceView.tvFamily.setTypeface(null, Typeface.BOLD);
            accountBalanceView.tvIndividual.setTypeface(null, Typeface.NORMAL);
            loadAccountBalanceDetails(holder, true);
        });
        accountBalanceView.tvIndividual.setOnClickListener(view -> {
            accountBalanceView.tvFamily.setTypeface(null, Typeface.NORMAL);
            accountBalanceView.tvIndividual.setTypeface(null, Typeface.BOLD);
            loadAccountBalanceDetails(holder, false);
        });
        mAccountModel = ProfileDataCache.getInstance().getAccountBalance();
        if (mAccountModel != null) {
            loadAccountBalanceDetails(holder, false);
        } else {
            getAccountBalance(holder);
        }
    }

    /*
    This method is used to handle user clicks on the individual and family buttons
     */
    private void updateOOPBalanceWidget(ViewHolder holder, String header) {
        AccountBalanceOOPViewHolder accountBalanceOOPView = (AccountBalanceOOPViewHolder) holder;
        accountBalanceOOPView.tvHeader.setText(header);
        accountBalanceOOPView.tvHeader.setText(mContext.getString(R.string.out_of_pocket_balance));
        accountBalanceOOPView.tvFamilyOOP.setOnClickListener(view -> {
            accountBalanceOOPView.tvFamilyOOP.setTypeface(null, Typeface.BOLD);
            accountBalanceOOPView.tvIndividualOOP.setTypeface(null, Typeface.NORMAL);
            loadAccountBalanceOOPDetails(holder, true);
        });
        accountBalanceOOPView.tvIndividualOOP.setOnClickListener(view -> {
            accountBalanceOOPView.tvFamilyOOP.setTypeface(null, Typeface.NORMAL);
            accountBalanceOOPView.tvIndividualOOP.setTypeface(null, Typeface.BOLD);
            loadAccountBalanceOOPDetails(holder, false);
        });
        mAccountOOPModel = ProfileDataCache.getInstance().getAccountBalanceOOP();
        if (mAccountOOPModel != null) {
            loadAccountBalanceOOPDetails(holder, false);
        } else {
            getAccountBalanceOOP(holder);
        }
    }

    /*
      Used to call web service for Get Account Balance
      and get response as JSON using post method and to plot the Pie chart
     */

    private void getAccountBalance(@NonNull final ViewHolder holder) {
        VolleyService.getAccountBalanceData(mContext, AppConstants.GET_ACCOUNT_BALANCE, new VolleyResponseListener() {
            @Override
            public void onError(String error) {
                //Not used
                Log.e("Account Error", StringConstants.ERROR);
            }

            @Override
            public void onResponse(String response) {
                if (response != null && response.length() > 0) {
                    try {
                        Gson gson = new GsonBuilder().create();
                        String jsonObject = new JSONObject(response).get(StringConstants.BENEFITS_KEY).toString();
                        mAccountModel = gson.fromJson(jsonObject, AccountBalance.class);
                        ProfileDataCache.getInstance().setAccountBalance(mAccountModel);
                    } catch (Exception e) {
                        Log.e("Account Success", StringConstants.EXCEPTION);
                    }
                    loadAccountBalanceDetails(holder, false);
                }
            }
        });
    }

    /*
    This method is used to display account balance details in the adapter
    */
    private void loadAccountBalanceDetails(@NonNull ViewHolder holder, boolean isFamily) {
        if (mAccountModel != null) {
            BarChart mBarChart = GeneralUtils.getVerticalChartResults(mContext, mAccountModel, isFamily);
            ((AccountBalanceViewHolder) holder).llChartView.removeAllViews();
            ((AccountBalanceViewHolder) holder).llChartView.addView(mBarChart, new RecyclerView.LayoutParams
                    (RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.MATCH_PARENT));
        }
    }

    /*
     Used to call web service for Get Account Balance
     and get response as JSON using post method and to plot the Pie chart
     */

    private void getAccountBalanceOOP(@NonNull final ViewHolder holder) {
        VolleyService.getAccountBalanceOOP(mContext, AppConstants.GET_ACCOUNT_BALANCE_OOP, new VolleyResponseListener() {
            @Override
            public void onError(String error) {
                Log.e("Account OOP Error", error);
            }

            @Override
            public void onResponse(String response) {
                if (response != null && response.length() > 0) {
                    try {
                        Log.e("Account OOP success", response);
                        Gson gson = new GsonBuilder().create();
                        String jsonObject = new JSONObject(response).get(StringConstants.BENEFITS_KEY).toString();
                        mAccountOOPModel = gson.fromJson(jsonObject, AccountBalanceOOP.class);
                        ProfileDataCache.getInstance().setAccountBalanceOOP(mAccountOOPModel);
                    } catch (Exception e) {
                        Log.e("Account OOP", StringConstants.EXCEPTION);
                    }
                    loadAccountBalanceOOPDetails(holder, false);
                }
            }
        });
    }

    /*
    This method is used to display account balance OOP details in the adapter
     */
    private void loadAccountBalanceOOPDetails(@NonNull ViewHolder holder, boolean isFamily) {
        if (mAccountOOPModel != null) {
            BarChart mBarChart = GeneralUtils.getVerticalChartResultsOOP(mContext, mAccountOOPModel, isFamily);
            ((AccountBalanceOOPViewHolder) holder).llChartViewOOP.removeAllViews();
            ((AccountBalanceOOPViewHolder) holder).llChartViewOOP.addView(mBarChart, new RecyclerView.LayoutParams
                    (RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.MATCH_PARENT));
        }
    }

    /*
    This method is used to display coverage details in the adapter
     */
    private void populateMyCoverage(Portlet portletDetail, ViewHolder holder) throws ParseException {
        final MyCoverageViewHolder coverageViewController = (MyCoverageViewHolder) holder;
        coverageViewController.tvCoverageHeader.setText(R.string.my_coverage);
        if (mMemberList != null && !mMemberList.isEmpty()) {
            if (mMemberList.get(0).getCoverageDate() != null && !mMemberList.get(0).getCoverageDate().equals("null")
                    && !mMemberList.get(0).getCoverageDate().isEmpty()) {
                String date = mMemberList.get(0).getCoverageDate();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                Date testDate = sdf.parse(date);
                SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault());
                String newFormat = formatter.format(testDate);
                coverageViewController.tvCoveragePeriod.setText(newFormat);
            }
            if (mMemberList.get(0).getPlanName() != null && !mMemberList.get(0).getPlanName().equals("null")
                    && !mMemberList.get(0).getPlanName().isEmpty()) {
                coverageViewController.tvPlanDetails.setSelected(true);
                coverageViewController.tvPlanDetails.setText(mMemberList.get(0).getPlanName());
            }
            if (mMemberList.get(0).getGroupId() != null && !mMemberList.get(0).getGroupId().equals("null")
                    && !mMemberList.get(0).getGroupId().isEmpty()) {
                coverageViewController.tvPolicyDetails.setText
                        (mMemberList.get(0).getGroupId());
            }
            if (mMemberList.get(0).getGroupName() != null && !mMemberList.get(0).getGroupName().equals("null")
                    && !mMemberList.get(0).getGroupName().isEmpty()) {
                coverageViewController.tvGroupDetails.setText
                        (mMemberList.get(0).getGroupName());
            }
        }
        coverageViewController.btnCoverageDetailView.setOnClickListener(view -> {
            Fragment fragment = new BenefitsFragment();
            mContext.getSupportFragmentManager().beginTransaction().replace(R.id.frame_container, fragment).addToBackStack(null).commit();
        });
    }

    //Creating sub class touch listener to handle user touch actions
    private final RecyclerView.OnItemTouchListener mScrollTouchListener = new RecyclerView.OnItemTouchListener() {
        @Override
        public boolean onInterceptTouchEvent(@NonNull RecyclerView rv, MotionEvent e) {
            int action = e.getAction();
            if (action == MotionEvent.ACTION_MOVE || action == MotionEvent.ACTION_DOWN) {
                rv.getParent().requestDisallowInterceptTouchEvent(true);
            }
            return false;
        }

        @Override
        public void onTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {
            //Do something
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {
            //Do something
        }
    };


    private void updateReferralsWidget(ViewHolder holder) {
        try {
            final AuthorizationViewHolder authorizationViewController = (AuthorizationViewHolder) holder;
            authorizationViewController.tvHeader.setText(mContext.getString(R.string.auth_referral));
            authorizationViewController.btnDetailAuthView.setOnClickListener(view -> {
                AuthorizationReferalFragment authDetailView = new AuthorizationReferalFragment();
                mContext.getSupportFragmentManager().beginTransaction().
                        replace(R.id.frame_container, authDetailView).addToBackStack(null).commit();

            });
            mAuthList = ProfileDataCache.getInstance().getAuthList();
            if (mAuthList != null) {
                populateAuthReferralData(mAuthList, authorizationViewController);
            } else {
                getAuthorizationReferalData(holder);
            }
        } catch (Exception e) {
            e.getLocalizedMessage();
        }
    }

    private void populateAuthReferralData(List<AuthorizationModel> authList, AuthorizationViewHolder holder) {
        if (authList != null) {
            mChart = getPieChartResults(authList);
        }
        holder.mChart.removeAllViews();
        holder.mChart.addView
                (mChart, new RecyclerView.LayoutParams
                        (RecyclerView.LayoutParams.MATCH_PARENT,
                                RecyclerView.LayoutParams.MATCH_PARENT));
    }


    private void getAuthorizationReferalData(@NonNull final ViewHolder holder) {

        VolleyService.getAuthorizationReferalData(mContext, AppConstants.GET_AUTHORIZATION_REFERAL_DETAILS, new VolleyResponseListener() {
            @Override
            public void onError(String error) {
                //Not used
            }

            @Override
            public void onResponse(String response) {
                try {
                    Log.e("POST_SUCCESS", StringConstants.RESPONSE);
                    if (response != null) {
                        mAuthList = parseJson(response);
                        if (!mAuthList.isEmpty()) {
                            ProfileDataCache.getInstance().setAuthList(mAuthList);
                            populateAuthReferralData(mAuthList, (AuthorizationViewHolder) holder);
                        }
                    }

                } catch (Exception e) {
                    Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
                }
            }
        });

    }
}