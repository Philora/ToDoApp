package com.wps.memberapp.presentation.dashboard.adapter;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.model.ExpandedMenuModel;

import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * This adapter is used to display navigation view items
 * in the dashboard screen.
 */
public class ExpandableListAdapter extends BaseExpandableListAdapter {

    private final Context mContext;
    private final List<ExpandedMenuModel> mListDataHeader; // header titles
    // Child Data in format of header title, child title
    private final Map<ExpandedMenuModel, List<String>> mListDataChild;
    private static final int[] EMPTY_STATE_SET = {};
    private static final int[] GROUP_EXPANDED_STATE_SET = {android.R.attr.state_expanded};
    private static final int[][] GROUP_STATE_SETS = {EMPTY_STATE_SET, // 0
            GROUP_EXPANDED_STATE_SET // 1
    };

    public ExpandableListAdapter(Activity context, List<ExpandedMenuModel> listDataHeader,
                                 Map<ExpandedMenuModel, List<String>> listChildData) {
        this.mContext = context;
        this.mListDataHeader = listDataHeader;
        this.mListDataChild = listChildData;
    }


    @Override
    public Object getChild(int groupPosition, int childPosition) {
        if (mListDataChild.get(mListDataHeader.get(groupPosition)) != null) {
            return Objects.requireNonNull(mListDataChild.get(mListDataHeader.get(groupPosition))).get(childPosition);
        }
        return null;
    }

    /*
    Used to get no of group items count
     */
    @Override
    public int getGroupCount() {
        return this.mListDataHeader.size();
    }


    /*
Used to get the child view in the adapter
 */
    @Override
    public View getChildView(int groupPosition, int childPosition,
                             boolean isLastChild, View convertView, ViewGroup parent) {

        final String childText = (String) getChild(groupPosition, childPosition);

        if (convertView == null) {
            LayoutInflater infalInflater = (LayoutInflater) this.mContext
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            if (infalInflater != null) {
                convertView = View.inflate(this.mContext, R.layout.row_navigation_adapter_child, null);
            }
        }
        if (convertView != null) {
            TextView txtListChild = convertView.findViewById(R.id.textView);
            txtListChild.setText(childText);
        }
        return convertView;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }

    /*
   Used to get no of child items count
    */
    @Override
    public int getChildrenCount(int groupPosition) {
        List childList = mListDataChild.get(mListDataHeader.get(groupPosition));
        if (childList != null && !childList.isEmpty()) {
            return childList.size();
        } else {
            return 0;
        }
    }

    @Override
    public Object getGroup(int groupPosition) {
        return this.mListDataHeader.get(groupPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }


    /*
Used to get the Grou view in the adapter
*/
    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {

        ExpandedMenuModel headerTitle = (ExpandedMenuModel) getGroup(groupPosition);
        if (convertView == null) {
            LayoutInflater infalInflater = (LayoutInflater) this.mContext
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            if (infalInflater != null) {
                convertView = View.inflate(this.mContext, R.layout.row_navigation_adapter, null);
            }
        }
        if (convertView != null) {
            ImageView indicator = convertView.findViewById(R.id.indicator);
            if (getChildrenCount(groupPosition) == 0) {
                indicator.setVisibility(View.GONE);
            } else {
                indicator.setVisibility(View.VISIBLE);
                int stateSetIndex = (isExpanded ? 1 : 0);

                /*Toggles down button to change upwards when list has expanded*/
                if (stateSetIndex == 1) {
                    indicator.setVisibility(View.VISIBLE);
                    indicator.setImageResource(R.drawable.ic_arrow_up);
                    Drawable drawable = indicator.getDrawable();
                    drawable.setState(GROUP_STATE_SETS[stateSetIndex]);
                } else {
                    indicator.setVisibility(View.VISIBLE);
                    indicator.setImageResource(R.drawable.ic_arrow_down);
                    Drawable drawable = indicator.getDrawable();
                    drawable.setState(GROUP_STATE_SETS[stateSetIndex]);
                }
            }
            TextView lblListHeader = convertView.findViewById(R.id.headerTxt);
            lblListHeader.setText(headerTitle.getIconName());
            ImageView headerIcon = convertView.findViewById(R.id.iconimage);
            headerIcon.setImageResource(headerTitle.getIconImg());
        }
        return convertView;
    }
}
