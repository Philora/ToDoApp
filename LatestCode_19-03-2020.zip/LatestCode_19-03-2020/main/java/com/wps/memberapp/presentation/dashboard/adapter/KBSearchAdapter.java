package com.wps.memberapp.presentation.dashboard.adapter;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.TextView;
import android.widget.Toast;

import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.GetKnowledgeBase;
import com.wps.memberapp.data.model.GetProcedureCode;
import com.wps.memberapp.presentation.treatmentcostcalculator.adapter.TCCSearchAdapter;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.GeneralUtils;

import java.util.ArrayList;
import java.util.List;

import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;

public class KBSearchAdapter extends RecyclerView.Adapter<KBSearchAdapter.ViewHolder> {
    private final Activity activity;
    View v;
    OnItemClickListener onItemClickListner;
    private Context context;
    private List<GetKnowledgeBase> kbSearchList;
    private List<GetKnowledgeBase> kbSearchListFilter;

    public KBSearchAdapter(Activity appContext, List<GetKnowledgeBase> kbSearchList, OnItemClickListener onItemClickListner) {
        this.activity = appContext;
        this.kbSearchList = kbSearchList;
        this.kbSearchListFilter = kbSearchList;
        this.onItemClickListner = onItemClickListner;
    }

    @Override
    public KBSearchAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        v = inflater.inflate(R.layout.search_item_text, parent, false);
        context = parent.getContext();
        return new KBSearchAdapter.ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(KBSearchAdapter.ViewHolder holder, final int position) {
        try {
            if (kbSearchListFilter != null && !kbSearchListFilter.isEmpty() && kbSearchListFilter.size() > 0) {
                final GetKnowledgeBase mkbSearchList = kbSearchListFilter.get(position);
                if (mkbSearchList.getTitle() != null) {
                    holder.txtName.setText(mkbSearchList.getTitle());
                }
                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        onItemClickListner.onItemClicked(position, kbSearchListFilter.get(position).getTitle());
                        Toast.makeText(activity, kbSearchListFilter.get(position).getTitle(), Toast.LENGTH_SHORT).show();
                        String mPocID = kbSearchListFilter.get(position).getDocID();
                        Uri uri = Uri.parse(AppConstants.PDF_WEB_VIEW + mPocID + "&Language=en");
                        Intent intent = new Intent(Intent.ACTION_VIEW);
                        intent.setDataAndType(uri, "application/pdf");
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        context.startActivity(intent);
                    }
                });
            } else {
                GeneralUtils.showAlertDialog(activity, activity.getString(R.string.no_search_results));
            }
        } catch (Exception e) {
            e.getLocalizedMessage();
        }
    }

    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if (charString.isEmpty()) {
                    kbSearchListFilter = kbSearchList;
                } else {
                    List<GetKnowledgeBase> filteredList = new ArrayList<>();
                    for (GetKnowledgeBase row : kbSearchList) {
                        // name match condition. this might differ depending on your requirement
                        // here we are looking for name or procedure code
                        if (row.getDocID().toLowerCase().contains(charString.toLowerCase()) || row.getTitle().toLowerCase().contains(charString.toLowerCase())) {
                            filteredList.add(row);
                        }
                    }
                    kbSearchListFilter = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = kbSearchListFilter;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                kbSearchListFilter = (ArrayList<GetKnowledgeBase>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }

    @Override
    public int getItemCount() {
        if (kbSearchListFilter != null) {
            return kbSearchListFilter.size();
        } else {
            return 0;
        }
    }

    public interface OnItemClickListener {
        void onItemClicked(int position, String mkbSearchList);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.txt_name)
        TextView txtName;

        public ViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}

