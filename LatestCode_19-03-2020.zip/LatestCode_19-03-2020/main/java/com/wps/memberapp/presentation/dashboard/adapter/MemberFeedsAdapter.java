package com.wps.memberapp.presentation.dashboard.adapter;

import android.os.Build;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.model.MemberFeed;
import com.wps.memberapp.presentation.dashboard.adapter.viewholder.EmptyViewHolder;
import com.wps.memberapp.utility.StringConstants;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

/**
 * This adapter is used to display updated news feeds to
 * the user in the dashboard widget.
 */
class MemberFeedsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    //We are storing all the product in a list
    private final List<MemberFeed> mMemberFeedList;

    //getting the context and product list with constructor
    MemberFeedsAdapter(List<MemberFeed> memberFeedList) {
        this.mMemberFeedList = memberFeedList;
    }

    /*
  Creating ViewHolder based on the layout to bind the data to adapter.
   */
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        switch (viewType) {
            case MemberFeed.TEXT:
                view = LayoutInflater.from(parent.getContext()).inflate
                        (R.layout.news_textview_layout, parent, false);
                return new NewsTextViewHolder(view);
            case MemberFeed.VIDEO:
                view = LayoutInflater.from(parent.getContext()).inflate
                        (R.layout.news_webview_layout, parent, false);
                return new NewsWebViewHolder(view);
            default:
                view = LayoutInflater.from(parent.getContext()).inflate
                        (R.layout.row_empty_view, parent, false);
                return new EmptyViewHolder(view);
        }
    }

    /*
  Binding data to ViewHolder class object based on the position.
  */
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
        //getting the product of the specified position
        if (mMemberFeedList != null && !mMemberFeedList.isEmpty()) {
            MemberFeed memberFeed = mMemberFeedList.get(position);
            String data = memberFeed.getValue();
            Log.i("news", data);
            int type = memberFeed.getViewType();
            switch (type) {
                case MemberFeed.TEXT:
                    ((NewsTextViewHolder) holder).textViewTitle.setMovementMethod(LinkMovementMethod.getInstance());
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        ((NewsTextViewHolder) holder).textViewTitle.setText(Html.fromHtml(data, Html.FROM_HTML_MODE_LEGACY));
                    } else {
                        ((NewsTextViewHolder) holder).textViewTitle.setText(Html.fromHtml(data));
                    }
                    break;
                case MemberFeed.VIDEO:
//                    ((NewsWebViewHolder) holder).webView.loadDataWithBaseURL("https://www.youtube.com/embed/", data+"?feature=oembed", StringConstants.MIME_TYPE_HTML, StringConstants.DEFAULT_TEXT_ENCODING, "");

                    ((NewsWebViewHolder) holder).webView.setWebViewClient(new WebViewClient() {
                        @Override
                        public boolean shouldOverrideUrlLoading(WebView view, String url) {
                            return false;
                        }
                    });
                    WebSettings webSettings = ((NewsWebViewHolder) holder).webView.getSettings();
                    webSettings.setJavaScriptEnabled(true);
                    webSettings.setLoadWithOverviewMode(true);
                    webSettings.setUseWideViewPort(true);
                    ((NewsWebViewHolder) holder).webView.loadUrl("https://www.youtube.com/embed/KZaY6LAlCEY?feature=oembed");
                    break;
                default:
                    break;
            }
        }
    }

    /*
  This method is used to get the items size in array list
 */
    @Override
    public int getItemCount() {
        if (mMemberFeedList != null) {
            return mMemberFeedList.size();
        } else {
            return 0;
        }
    }

    @Override
    public int getItemViewType(int position) {
        return mMemberFeedList.get(position).getViewType();
    }

    /*
     This class is used to bind the text news data to adapter
     */
    class NewsTextViewHolder extends RecyclerView.ViewHolder {
        final TextView textViewTitle;

        private NewsTextViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewTitle = itemView.findViewById(R.id.newsTextView);
        }
    }

    /*
   This class is used to bind the Web news data to adapter
   */
    class NewsWebViewHolder extends RecyclerView.ViewHolder {
        final WebView webView;

        private NewsWebViewHolder(@NonNull View itemView) {
            super(itemView);
            webView = itemView.findViewById(R.id.newsWebview);
        }
    }
}
