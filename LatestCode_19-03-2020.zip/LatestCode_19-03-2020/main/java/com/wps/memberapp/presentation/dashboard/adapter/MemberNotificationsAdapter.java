package com.wps.memberapp.presentation.dashboard.adapter;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.NotificationModel;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

/**
 * This adapter is used to display updated notifications to
 * the user in the dashboard widget.
 */
public class MemberNotificationsAdapter extends RecyclerView.Adapter<MemberNotificationsAdapter.NotificationsHolder> {

    //We are storing all the product in a list
    private final List<NotificationModel> mNotificationsList;

    //getting the context and product list with constructor
    MemberNotificationsAdapter(List<NotificationModel> mNotificationsList) {
        this.mNotificationsList = mNotificationsList;
    }

    /*
  Creating ViewHolder based on the layout to bind the data to adapter.
   */
    @NonNull
    @Override
    public NotificationsHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate
                (R.layout.notification_item_layout, parent, false);
        return new NotificationsHolder(view);
    }

    /*
   Binding data to ViewHolder class object based on the position.
   */
    @Override
    public void onBindViewHolder(@NonNull NotificationsHolder holder, final int position) {
        //getting the product of the specified position
        if (mNotificationsList != null && !mNotificationsList.isEmpty()) {
            NotificationModel memberFeed = mNotificationsList.get(position);
            holder.textViewTitle.setText(memberFeed.getTitle());
            String message = getProperMessage(memberFeed.getContent(), memberFeed);
            holder.textViewContent.setText(message);
        }
    }

    /*
This method is used to get the items size in array list
*/
    @Override
    public int getItemCount() {
        if (mNotificationsList != null) {
            return mNotificationsList.size();
        } else {
            return 0;
        }
    }

    /*
    This method is used to parse the given message and will return proper message
     */
    private String getProperMessage(String key, @NonNull NotificationModel memberFeed) {
        try {
            String notificationContent = ProfileDataCache.getInstance().getNotificationContent();
            if (notificationContent != null) {
                JSONObject object = new JSONObject(notificationContent);
                String message = object.getString(key);
                if (message != null && message.contains(StringConstants.STARTDATE)) {
                    message = message.replace(StringConstants.STARTDATE, memberFeed.getStartDate());
                    message = message.replace(StringConstants.ENDDATE, memberFeed.getEndDate());
                }
                return message;
            }
        } catch (JSONException ex) {
            Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
        }
        return key;
    }

    /*
  This class is used to bind the notifications data to adapter
  */
    class NotificationsHolder extends RecyclerView.ViewHolder {
        final TextView textViewTitle;
        final TextView textViewContent;

        private NotificationsHolder(@NonNull View itemView) {
            super(itemView);
            textViewTitle = itemView.findViewById(R.id.notificationTitle);
            textViewContent = itemView.findViewById(R.id.notificationContent);
        }
    }
}
