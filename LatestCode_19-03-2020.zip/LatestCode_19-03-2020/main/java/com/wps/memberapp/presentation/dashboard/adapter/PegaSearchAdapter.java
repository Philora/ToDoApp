package com.wps.memberapp.presentation.dashboard.adapter;

import android.content.Context;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.model.PegaSearchResult;

import java.util.List;

import androidx.recyclerview.widget.RecyclerView;

public class PegaSearchAdapter extends RecyclerView.Adapter<PegaSearchAdapter.SearchViewHolder> {

    //This context will be used to inflate the layout
    private final Context mCtx;
    private final List<PegaSearchResult> searchResultList;
    private final OnItemClickListener listener;

    //getting the context and product list with constructor
    public PegaSearchAdapter(Context mCtx, List<PegaSearchResult> searchResultList, OnItemClickListener listener) {
        this.mCtx = mCtx;
        this.searchResultList = searchResultList;
        this.listener = listener;
    }

    public interface OnItemClickListener {
        void onItemClick(PegaSearchResult item);
    }

    @Override
    public PegaSearchAdapter.SearchViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.pega_search_item, parent,false);
        return new PegaSearchAdapter.SearchViewHolder(view);
    }

    @Override
    public void onBindViewHolder(PegaSearchAdapter.SearchViewHolder holder, final int position) {
        final PegaSearchResult result = searchResultList.get(position);
        //getting the product of the specified position
        SpannableString content = new SpannableString(result.getTitle());
        content.setSpan(new UnderlineSpan(), 0, content.length(), 0);
        holder.textViewTitle.setText(content);
        String msg=result.getMessage()+" ...Read More";
        holder.textViewMessage.setText(msg);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onItemClick(result);
            }
        });
    }

    @Override
    public int getItemCount() {
        return searchResultList.size();
    }

    class SearchViewHolder extends RecyclerView.ViewHolder {

        final TextView textViewTitle;
        final TextView textViewMessage;

        SearchViewHolder(View itemView) {
            super(itemView);
            textViewTitle = itemView.findViewById(R.id.title);
            textViewMessage = itemView.findViewById(R.id.message);
        }
    }

}

