package com.wps.memberapp.presentation.dashboard.adapter.viewholder;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.wps.memberapp.R;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

/**
 * This class is used to bind the account balance OOP data in dashboard adapter
 */
public class AccountBalanceOOPViewHolder extends RecyclerView.ViewHolder {

    //Member variables
    public final TextView tvHeader;
    public final TextView tvFamilyOOP;
    public final TextView tvIndividualOOP;
    public final LinearLayout llChartViewOOP;

    public AccountBalanceOOPViewHolder(@NonNull View accountItemView) {
        super(accountItemView);

        //Initializing views
        tvHeader = accountItemView.findViewById(R.id.headingTxtOOP);
        tvFamilyOOP =  accountItemView.findViewById(R.id.textViewFamilyOOP);
        tvIndividualOOP =  accountItemView.findViewById(R.id.textViewIndividualOOP);
        llChartViewOOP = accountItemView.findViewById(R.id.oopChartView);
    }
}
