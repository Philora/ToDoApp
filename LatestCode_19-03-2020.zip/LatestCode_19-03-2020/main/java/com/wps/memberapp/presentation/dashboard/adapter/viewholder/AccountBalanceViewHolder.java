package com.wps.memberapp.presentation.dashboard.adapter.viewholder;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.wps.memberapp.R;

/**
 * This class is used to bind the account balance data in dashboard adapter
 */
public class AccountBalanceViewHolder extends RecyclerView.ViewHolder {

    //Member variables
    public final TextView tvHeader;
    public final TextView tvFamily;
    public final TextView tvIndividual;
    public final LinearLayout llChartView;

    public AccountBalanceViewHolder(@NonNull View accountItemView) {
        super(accountItemView);

        //Initializing views
        tvHeader = accountItemView.findViewById(R.id.headingTxt);
        tvFamily =  accountItemView.findViewById(R.id.textViewFamily);
        tvIndividual =  accountItemView.findViewById(R.id.textViewIndividual);
        llChartView = accountItemView.findViewById(R.id.chartView);
    }
}
