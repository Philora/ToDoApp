package com.wps.memberapp.presentation.dashboard.adapter.viewholder;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.wps.memberapp.R;

/**
 * This class is used to show latest member news in dashboard adapter
 */
public class DashboardViewHolder extends RecyclerView.ViewHolder {

    //Member variables
    public final RecyclerView recyclerView;
    public final TextView tvHeading;

    public DashboardViewHolder(@NonNull View dashboardItemView) {
        super(dashboardItemView);

        //Initializing views
        recyclerView = dashboardItemView.findViewById(R.id.recyclerViewNews);
        tvHeading = dashboardItemView.findViewById(R.id.headingTxt);
    }
}

