package com.wps.memberapp.presentation.dashboard.adapter.viewholder;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

/**
 * This class is used to handle the empty reponse from the API
 */
public class EmptyViewHolder extends RecyclerView.ViewHolder {

    public EmptyViewHolder(@NonNull View view) {
        super(view);
    }
}
