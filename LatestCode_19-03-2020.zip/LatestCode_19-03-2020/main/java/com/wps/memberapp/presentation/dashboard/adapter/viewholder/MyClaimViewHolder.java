package com.wps.memberapp.presentation.dashboard.adapter.viewholder;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.wps.memberapp.R;

/**
 * This class is used to bind the user claims summary data in dashboard adapter
 */
public class MyClaimViewHolder extends RecyclerView.ViewHolder {

    //Member variables
    public final TextView tvClaimHeader;
    public final LinearLayout llclaimSummary;
    public final Button btnDetail;

    public MyClaimViewHolder(@NonNull View myclaimItemView) {
        super(myclaimItemView);
        tvClaimHeader = myclaimItemView.findViewById(R.id.headingTxt);
        llclaimSummary = myclaimItemView.findViewById(R.id.claimSummaryLinearLayout);
        btnDetail = myclaimItemView.findViewById(R.id.btnDetailClaimView);
    }
}
