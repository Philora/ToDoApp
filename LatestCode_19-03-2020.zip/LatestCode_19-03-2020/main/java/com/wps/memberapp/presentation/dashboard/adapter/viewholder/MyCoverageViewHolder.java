package com.wps.memberapp.presentation.dashboard.adapter.viewholder;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.wps.memberapp.R;

/**
 * This class is used to show user coverage data in dashboard adapter
 */
public class MyCoverageViewHolder extends RecyclerView.ViewHolder {

    //Member variables
    public final TextView tvCoveragePeriod;
    public final TextView tvPlanDetails;
    public final TextView tvPolicyDetails;
    public final TextView tvGroupDetails;
    public final TextView tvCoverageHeader;
    public final Button btnCoverageDetailView;

    public MyCoverageViewHolder(@NonNull View mycoverageItemView) {
        super(mycoverageItemView);

        //Initializing views
        tvCoverageHeader = mycoverageItemView.findViewById(R.id.headingTxt);
        tvCoveragePeriod = mycoverageItemView.findViewById(R.id.coveragePeriodDetailTextView);
        tvPlanDetails = mycoverageItemView.findViewById(R.id.planNameDetailsTextView);
        tvPolicyDetails = mycoverageItemView.findViewById(R.id.policyNumberDetailsTextView);
        tvGroupDetails = mycoverageItemView.findViewById(R.id.groupDetailsTextView);
        btnCoverageDetailView = mycoverageItemView.findViewById(R.id.btnCoverageDetailView);
    }
}
