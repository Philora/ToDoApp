package com.wps.memberapp.presentation.dashboard.adapter.viewholder;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.wps.memberapp.R;

/**
 * This class is used to show latest member notifications in dashboard adapter
 */
public class NotificationViewHolder extends RecyclerView.ViewHolder {

    /*//Member variables
    public final TextView tvNoNotifications;
    public final TextView tvNotificationHeader;
    public final RecyclerView recyclerView;

    NotificationViewHolder(@NonNull View notificationItemView) {
        super(notificationItemView);

        //Initializing views
        tvNoNotifications = notificationItemView.findViewById(R.id.noNotifications);
        tvNotificationHeader = notificationItemView.findViewById(R.id.headingTxt);
        recyclerView = notificationItemView.findViewById(R.id.recyclerNotificationsView);
    }*/
    public final TextView titleTxt1;
    public final TextView titleTxt2;
    public final TextView titleTxt6;
    public final TextView titleTxt7;
    public final TextView titleTxt8;

    public final TextView notificationTxt1;
    public final TextView notificationTxt2;
    public final TextView notificationTxt6;

    public final TextView timeTxt1;

    public final TextView notificationHeader;
    public final RelativeLayout relativeLayout;

    public NotificationViewHolder(View notificationItemView) {
        super(notificationItemView);

        titleTxt1 = notificationItemView.findViewById(R.id.titleTxt1);
        titleTxt2 = notificationItemView.findViewById(R.id.titleTxt2);
        titleTxt6 = notificationItemView.findViewById(R.id.titleTxt6);
        titleTxt7 = notificationItemView.findViewById(R.id.titleTxt7);
        titleTxt8 = notificationItemView.findViewById(R.id.titleTxt8);

        notificationTxt1 = notificationItemView.findViewById(R.id.notificationTxt1);
        notificationTxt2 = notificationItemView.findViewById(R.id.notificationTxt2);
        notificationTxt6 = notificationItemView.findViewById(R.id.notificationTxt6);

        notificationHeader = notificationItemView.findViewById(R.id.headingTxt);
        relativeLayout = notificationItemView.findViewById(R.id.layoutHeader);

        timeTxt1 = notificationItemView.findViewById(R.id.timeTxt1);
    }

}
