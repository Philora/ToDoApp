package com.wps.memberapp.presentation.dashboard.adapter.viewholder;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.wps.memberapp.R;

public class WellnessViewHolder extends RecyclerView.ViewHolder {

    public final LinearLayout txtDiabetes;
    public final LinearLayout txtSeeReview;
    public final LinearLayout txtCheckMammogram;
    public final LinearLayout txtCheckColono;
    public final LinearLayout txtImmunization;
    public final TextView txtWellnessHeader;

    public WellnessViewHolder(View notificationItemView) {
        super(notificationItemView);

        txtDiabetes = notificationItemView.findViewById(R.id.txt_Diabetes);
        txtSeeReview = notificationItemView.findViewById(R.id.txt_SeeReview);
        txtCheckMammogram = notificationItemView.findViewById(R.id.txt_CheckMammogram);
        txtCheckColono = notificationItemView.findViewById(R.id.txt_CheckColono);
        txtImmunization = notificationItemView.findViewById(R.id.txt_Immunization);
        txtWellnessHeader = notificationItemView.findViewById(R.id.headingTxt);
    }

}

