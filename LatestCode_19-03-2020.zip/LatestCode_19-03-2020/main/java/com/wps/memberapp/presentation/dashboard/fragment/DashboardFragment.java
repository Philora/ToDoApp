package com.wps.memberapp.presentation.dashboard.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.appdynamics.eumagent.runtime.Instrumentation;
import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.model.MemberEligibleInfo;
import com.wps.memberapp.data.model.MemberFeed;
import com.wps.memberapp.data.model.Portlet;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.presentation.base.BaseFragment;
import com.wps.memberapp.presentation.dashboard.activity.KnowledgeBaseActivity;
import com.wps.memberapp.presentation.dashboard.adapter.DashboardAdapter;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * The type Dashboard fragment which will display all needed features of the app.
 */
public class DashboardFragment extends BaseFragment implements DashboardFragmentView {

    //member variables declaration
    private RecyclerView recycleView;
    private Unbinder mUnbinder;
    ImageView imageViewSearch;
    private DashboardFragmentPresenter dashboardPresenter;

    /*
     This override method is used to inflate the layout for Dashboard fragment
     */
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getContext());
        if (getActivity() != null) {
            Instrumentation.start(StringConstants.APP_DYNAMICS_KEY, getActivity().getApplicationContext());
        }
        if (container != null) {
            container.removeAllViews();
            container.clearDisappearingChildren();
        }
        View rootView = inflater.inflate(R.layout.fragment_dashboard, container, false);
        mUnbinder = ButterKnife.bind(this, rootView);
        dashboardPresenter = new DashboardFragmentPresenterImpl();
        dashboardPresenter.onAttach(this);
        //Inflating views from XML layout
        recycleView = rootView.findViewById(R.id.recyclerView);
        recycleView.setHasFixedSize(true);
        if (getActivity() != null) {
            imageViewSearch = getActivity().findViewById(R.id.imageViewSearch);
            imageViewSearch.setVisibility(View.VISIBLE);
            TextView txtDownloadPDF = getActivity().findViewById(R.id.txt_Call);
            txtDownloadPDF.setVisibility(View.GONE);
            TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
            fragmentTitle.setText(R.string.dashboard);
        }
        imageViewSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*//dashboardPresenter.onSearchClicked();
                SharedPreferenceHelper.getInstance().setPreference(getActivity(), "SearchQuery", "");
                // FragmentManager fragmentManager = mView.getAppContext().getFragmentManager();
                getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.frame_container, new KnowledgeBaseFragment()).addToBackStack(null).commit();*/

                Intent myIntent = new Intent(getActivity(), KnowledgeBaseActivity.class);
                getActivity().startActivity(myIntent);

            }
        });
        DashboardFragmentPresenter presenter = new DashboardFragmentPresenterImpl();
        presenter.onAttach(this);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        recycleView.setLayoutManager(layoutManager);
        List<Portlet> portletList = ProfileDataCache.getInstance().getPortletList();
        if (GeneralUtils.isOnline(getActivity())) {
            if (portletList != null) {
                presenter.getMemberNews();
            } else {
                presenter.getDashboardPortletDetails();
            }
        } else {
            GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.login_no_internet));
        }
        return rootView;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUnbinder.unbind();
    }

    /*
    This callback is used to handle the response of the member details,member news and portlet API
     */
    @Override
    public void onDashboardPortletDetailsLoadingCompleted(@NonNull List<Portlet> portletList, List<MemberDetails> memberDetails, List<MemberFeed> memberFeeds) {
        ProfileDataCache.getInstance().setPortletList(portletList);
        updateDashboardData(portletList, memberDetails, memberFeeds);
    }

    /*
    This method is used to create the adapter and attach that adapter to recycler view to show data to user
     */
    private void updateDashboardData(@NonNull List<Portlet> portletList, List<MemberDetails> memberDetails, List<MemberFeed> memberFeeds) {
        try { // Checking Null -> cant able to verify, because web portal isn't working while cross checking
            MemberEligibleInfo info = ProfileDataCache.getInstance().getMemberEligibleInfo();
            List<Portlet> tempList = new ArrayList<>(portletList);
            if (StringConstants.LOB_WPS.equals(info.getLineOfBusiness()) && StringConstants.ENTITY_ID_MEDMARSOL.equals(info.getCurrentRelEntityID())) {
                for (Portlet portlet : tempList) {
                    if (Portlet.ACCOUNT_BALANCE == portlet.getViewType()) {
                        portletList.remove(portlet);
                    }
                    if (Portlet.AUTHORIZATION_REFERAL == portlet.getViewType()) {
                        portletList.remove(portlet);
                    }
                }
            }
        } catch (Exception e) {
            Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
        }
        if (getActivity() != null && recycleView != null) {
            DashboardAdapter adapter = new DashboardAdapter((AppCompatActivity) getActivity(), portletList, memberDetails, memberFeeds);
            recycleView.setItemAnimator(new DefaultItemAnimator());
            recycleView.setAdapter(adapter);
        }
    }
}

