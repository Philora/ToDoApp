package com.wps.memberapp.presentation.dashboard.fragment;


import com.wps.memberapp.presentation.base.MvpPresenter;

/**
 * This interface contain all the Dashboard functionality declarations.
 */
public interface DashboardFragmentPresenter extends MvpPresenter {
    void getDashboardPortletDetails();

    void getMemberNews();

    void onSearchClicked();
}
