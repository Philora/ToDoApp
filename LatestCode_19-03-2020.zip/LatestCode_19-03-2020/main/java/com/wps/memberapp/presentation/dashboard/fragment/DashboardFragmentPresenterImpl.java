package com.wps.memberapp.presentation.dashboard.fragment;

import android.app.FragmentManager;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.model.MemberFeed;
import com.wps.memberapp.data.model.Portlet;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.base.MvpView;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used to implement all the Dashboard functions which
 * are declared in DashboardFragmentPresenter.
 */
public class DashboardFragmentPresenterImpl implements DashboardFragmentPresenter {
    private MvpView mView;
    private List<Portlet> mPortletList;
    private ArrayList<MemberFeed> memberFeedList;

    @Override
    public void onSearchClicked() {
        /*SharedPreferenceHelper.getInstance().setPreference(mView.getAppContext(), "SearchQuery", "");
        FragmentManager fragmentManager = mView.getAppContext().getFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.frame_container, new PegaSearchFragment()).addToBackStack(null).commit();*/
    }

    @Override
    public void getDashboardPortletDetails() {
        mView.showProgress();
        VolleyService.getDashboardPortletDetails(mView.getAppContext(), AppConstants.GET_FULL_DASHBOARD,new VolleyResponseListener() {
            @Override
            public void onResponse(String response) {
                try {
                    mView.hideProgress();
                    parseDashboardResponse(response);
                    getMemberNews();
                }catch (Exception e){
                    e.getLocalizedMessage();
                }
            }

            @Override
            public void onError(String error) {
                mView.hideProgress();
                Log.i("Dashboard Error", StringConstants.ERROR);
            }
        });
    }

    /*
    This method is used to call API to get member new and parse that response
     */
    @Override
    public void getMemberNews() {
        mView.showProgress();
        VolleyService.getMemberFeedData(mView.getAppContext(), AppConstants.GET_NEWS_CONTENT,new VolleyResponseListener() {
            @Override
            public void onResponse(String response) {
                mView.hideProgress();
                Log.i("News Response", StringConstants.RESPONSE);
                try {
                    if (response != null && response.length() > 0) {
                        JSONArray memberFeed = parseMemberFeedJson(response);
                        getMemberFeedList(memberFeed);
                        if (mPortletList == null) {
                            mPortletList = ProfileDataCache.getInstance().getPortletList();
                        }
                    }
                    List<MemberDetails> memberInfo = ProfileDataCache.getInstance().getmMemberDetails(); // Checking Null -> cant able to verify, because web portal isn't working while cross checking
                    ((DashboardFragmentView) mView).onDashboardPortletDetailsLoadingCompleted(mPortletList, memberInfo, memberFeedList);
                } catch (Exception e) {
                    Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
                }
            }

            @Override
            public void onError(String error) {
                mView.hideProgress();
                Log.i("News Error", StringConstants.ERROR);
            }
        });
    }

    /*
    This method is used to get member notifications list based on given JSON Array
     */
    private void getMemberFeedList(JSONArray memberFeed) throws JSONException {
        memberFeedList = new ArrayList<>();
        if (memberFeed != null) {
            for (int j = 0; j < memberFeed.length(); j++) {
                MemberFeed member = new MemberFeed();
                String value = memberFeed.getJSONObject(j).getString("value");
                String alias = memberFeed.getJSONObject(j).getJSONObject("editor").getString("alias");
                if (alias.contains("media")) {
                    member.setViewType(2);
                } else if (alias.contains("embed")) {
                    member.setViewType(3);
                } else {
                    member.setViewType(1);
                }
                member.setValue(value);
                memberFeedList.add(member);
            }
        }
    }

    /*
    Used to parse Dashboard data through GSON parsing library
    */
    private void parseDashboardResponse(String response) {
        Log.i("Dashboard Response", StringConstants.RESPONSE);
        if (response != null && response.length() > 0) {
            try {
                Gson gson = new GsonBuilder().create();
                mPortletList = new ArrayList<>();
                JSONArray array = new JSONObject(response).getJSONArray("DashboardDetails");
                for (int i = 0; i < array.length(); i++) {
                    Portlet feed = gson.fromJson(array.getString(i), Portlet.class);
                    if (feed.getHeading() != null) {
                        mPortletList.add(feed);
                    }
                }
                Portlet portlet=new Portlet();
                portlet.setViewType(19);
                portlet.setHeading("Care Assessment Review");
                mPortletList.add(portlet);
            } catch (JSONException e1) {
                Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
            }
        }
    }

    /*
     Used to parse Member Feed data through GSON parsing library
     */
    private JSONArray parseMemberFeedJson(String response) {
        JSONArray lControls = null;
        try {
            JSONArray array = new JSONArray(response);
            JSONObject mainObj = new JSONObject(array.get(0).toString());
            JSONArray lSection;
            lSection = mainObj.getJSONArray("sections");
            if (lSection != null && lSection.length() > 0) {
                //get the rows array
                JSONObject lSectionObject = new JSONObject(lSection.get(0).toString());
                JSONArray lRowsArray = lSectionObject.getJSONArray("rows");
                if (lRowsArray != null && lRowsArray.length() > 0) {
                    JSONObject lRowObject = lRowsArray.getJSONObject(0);
                    JSONArray lArea = lRowObject.getJSONArray("areas");
                    if (lArea != null && lArea.length() > 0) {
                        lControls = lArea.getJSONObject(0).getJSONArray("controls");
                    }
                }
            }
        } catch (JSONException e) {
            Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
        }
        return lControls;
    }

    @Override
    public void onAttach(MvpView mView) {
        this.mView = mView;
    }

    @Override
    public void onDetach() {
        mView = null;
    }
}
