package com.wps.memberapp.presentation.dashboard.fragment;

import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.model.MemberFeed;
import com.wps.memberapp.data.model.Portlet;
import com.wps.memberapp.presentation.base.MvpView;

import java.util.List;

/**
 * This interface contain UI functions of Dashboard screen.
 */
interface DashboardFragmentView extends MvpView {
    void onDashboardPortletDetailsLoadingCompleted(List<Portlet> portletsList, List<MemberDetails> memberDetails, List<MemberFeed> memberFeeds);
}
