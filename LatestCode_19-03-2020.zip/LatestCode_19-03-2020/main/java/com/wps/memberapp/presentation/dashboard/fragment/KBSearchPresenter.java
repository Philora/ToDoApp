package com.wps.memberapp.presentation.dashboard.fragment;

import com.wps.memberapp.presentation.base.MvpPresenter;

interface KBSearchPresenter extends MvpPresenter {

    void getKnowledgeBase();
}
