package com.wps.memberapp.presentation.dashboard.fragment;
import com.google.gson.Gson;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.GetKnowledgeBase;
import com.wps.memberapp.data.model.GetProcedureCode;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.base.MvpView;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class KBSearchPresenterImp implements KBSearchPresenter {
    private MvpView mView;

    @Override
    public void onAttach(MvpView mView) {
        this.mView = mView;
    }

    @Override
    public void getKnowledgeBase() {
        mView.showProgress();
        VolleyService.getKnowledgeBase(mView.getAppContext(), AppConstants.GET_KNOWLEDGE_BASE, new VolleyResponseListener() {
            public void onResponse(String response) {
                List<GetKnowledgeBase> knowledgeBase = new ArrayList<>();
                mView.hideProgress();
                //Processing the response
                if (response != null) {
                    try {
                        Gson gson = new Gson();
                        JSONArray jsonArray = new JSONArray(response);
                        for (int i = 0; i < jsonArray.length(); i++) {
                            GetKnowledgeBase details = gson.fromJson(jsonArray.getString(i), GetKnowledgeBase.class);
                            knowledgeBase.add(details);
                        }
                        ProfileDataCache.getInstance().setKnowledgeBase(knowledgeBase);
                        ((KBSearchView) mView).onKBSearchResponse(knowledgeBase);
                    } catch (Exception e) {
                        Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
                    }
                }
            }

            @Override
            public void onError(String error) {
                mView.hideProgress();
            }
        });
    }

    @Override
    public void onDetach() {
        mView = null;
    }
}
