package com.wps.memberapp.presentation.dashboard.fragment;

import com.wps.memberapp.data.model.GetKnowledgeBase;

import java.util.List;

interface KBSearchView {
    void onKBSearchResponse(List<GetKnowledgeBase> knowledgeBase);
}
