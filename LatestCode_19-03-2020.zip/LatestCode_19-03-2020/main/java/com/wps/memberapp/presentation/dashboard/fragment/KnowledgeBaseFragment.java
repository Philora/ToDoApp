package com.wps.memberapp.presentation.dashboard.fragment;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.GetKnowledgeBase;
import com.wps.memberapp.data.model.GetProcedureCode;
import com.wps.memberapp.presentation.base.BaseFragment;
import com.wps.memberapp.presentation.dashboard.activity.MyDividerItemDecoration;
import com.wps.memberapp.presentation.dashboard.adapter.KBSearchAdapter;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.Logger;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

public class KnowledgeBaseFragment extends BaseFragment implements KBSearchView {

    private Unbinder mUnbinder;
    KBSearchPresenter KBSearchPresenter;
    List<GetKnowledgeBase> mKnowledgeBaseList;
    @BindView(R.id.search_view_knowledge_base)
    SearchView svKnowledge;
    @BindView(R.id.rv_search_result_knowledge_base)
    RecyclerView rvSearchKnowledge;

    private String searchMedicalQuery;
    private KBSearchAdapter mAdapter;
    private AlertDialog dialog;
    private boolean isMedicProcedure = false;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_knowledge_base, container, false);
        mUnbinder = ButterKnife.bind(this, rootView);
        if (getActivity() != null) {
            TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
            fragmentTitle.setText(R.string.search_knowledge_base);
            ImageView imageViewSearch = getActivity().findViewById(R.id.imageViewSearch);
            imageViewSearch.setVisibility(View.GONE);
        }
        KBSearchPresenter = new KBSearchPresenterImp();
        KBSearchPresenter.onAttach(this);

        if (ProfileDataCache.getInstance().getKnowledgeBase() == null) {
            KBSearchPresenter.getKnowledgeBase();
        } else {
            updateKBProcedure(mKnowledgeBaseList);
        }

        svKnowledge.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                try {
                    searchMedicalQuery = newText;
                    if (newText.length() > 2) {
                        mKnowledgeBaseList = ProfileDataCache.getInstance().getKnowledgeBase();
                        updateKBProcedure(mKnowledgeBaseList);
                        mAdapter.getFilter().filter(newText);
                        rvSearchKnowledge.setVisibility(View.VISIBLE);
                        svKnowledge.clearFocus();
                    /*try {
                        if (ProfileDataCache.getInstance().getFilterResults()!= null) {
                            svMedical.setQuery("", true);
                        }
                    }catch (Exception e){
                        e.getLocalizedMessage();
                    }*/
                    } else {
                        rvSearchKnowledge.setVisibility(View.GONE);
//                    Toast.makeText(getActivity(), "No data Found", Toast.LENGTH_SHORT).show();
                    }

                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
                return false;
            }
        });

        return rootView;
    }

    private void showDialogError(String title, String string) {
        try {
            AlertDialog.Builder alret = new AlertDialog.Builder(getActivity())
                    .setTitle(title)
                    .setCancelable(false)
                    .setMessage(string)
                    .setPositiveButton(getActivity().getString(R.string.ok), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialog.dismiss();
                            getActivity().getFragmentManager().popBackStack();
                        }
                    });
            dialog = alret.create();
            dialog.show();
        } catch (Exception e) {
            Logger.e("KBFragment", e);
        }
    }

    private void updateKBProcedure(List<GetKnowledgeBase> mKnowledgeBaseList) {
        try {
            rvSearchKnowledge.setHasFixedSize(true);
            rvSearchKnowledge.setNestedScrollingEnabled(false);
            final LinearLayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
            mLayoutManager.setOrientation(RecyclerView.VERTICAL);
            rvSearchKnowledge.setLayoutManager(mLayoutManager);

            mAdapter = new KBSearchAdapter(getAppContext(), mKnowledgeBaseList, new KBSearchAdapter.OnItemClickListener() {
                @Override
                public void onItemClicked(int position, String mKnowledgeBaseList) {
                    try {
                        // Handle Object of list item here
                        svKnowledge.setQuery(mKnowledgeBaseList, true);
                        svKnowledge.clearFocus();
                        rvSearchKnowledge.setVisibility(View.GONE);
                        if (mKnowledgeBaseList != null) {
                            ProfileDataCache.getInstance().setKBaseItem(mKnowledgeBaseList);
                        } else {
                            ProfileDataCache.getInstance().setKBaseItem("");
                        }
                    } catch (Exception e) {
                        e.getLocalizedMessage();
                    }
                }
            });
            rvSearchKnowledge.setAdapter(mAdapter);
            rvSearchKnowledge.getRecycledViewPool().clear();
            mAdapter.notifyDataSetChanged();

        } catch (Exception e) {
            e.getLocalizedMessage();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUnbinder.unbind();
    }

    @Override
    public void onKBSearchResponse(List<GetKnowledgeBase> knowledgeBase) {
        if (knowledgeBase != null) {
            mKnowledgeBaseList = ProfileDataCache.getInstance().getKnowledgeBase();
            isMedicProcedure = false;
            ProfileDataCache.getInstance().setTCCProcSelected(false);
            Toast.makeText(getActivity(), mKnowledgeBaseList.size(), Toast.LENGTH_SHORT).show();
        }
    }
}
