package com.wps.memberapp.presentation.dashboard.fragment;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.ibm.watson.developer_cloud.discovery.v1.Discovery;
import com.ibm.watson.developer_cloud.discovery.v1.model.query.QueryRequest;
import com.ibm.watson.developer_cloud.discovery.v1.model.query.QueryResponse;
import com.wps.memberapp.R;
import com.wps.memberapp.data.model.PegaSearchResult;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.presentation.base.BaseFragment;
import com.wps.memberapp.presentation.dashboard.adapter.PegaSearchAdapter;
import com.wps.memberapp.presentation.immunization.activity.WebViewPDFActivity;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class PegaSearchFragment extends BaseFragment {

    private EditText searchEt;
    private RecyclerView searchList;
    private String collectionId;
    private String environmentId;
    private TextView noRecords;
    private ProgressDialog progressDialog;

    /**
     * This override method is used to inflate the layout for fragment
     *
     * @return rootView
     */
    @SuppressLint("WrongConstant")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        View rootView = inflater.inflate(R.layout.activity_pega_search, container, false);
        noRecords = rootView.findViewById(R.id.noRecords);
        /*collectionId = "391576b4-f54e-4ba6-a36e-be5f6d9b1b15";   //old code
        environmentId = "e907a4eb-00d1-43a3-958d-0444c612eeec";*/
        collectionId = "8a62de20-e7f6-4b46-8ddd-b93bc8ffaf6f";
        environmentId = "e907a4eb-00d1-43a3-958d-0444c612eeec";
        searchEt = rootView.findViewById(R.id.searchText);
        final ImageView search = rootView.findViewById(R.id.searchIcon);
        searchList = rootView.findViewById(R.id.resultList);
        ImageView imageViewSearch = getActivity().findViewById(R.id.imageViewSearch);
        imageViewSearch.setVisibility(View.GONE);
        TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
        fragmentTitle.setText(R.string.search_knowledge_base);
        //Setting dynamic layout manager to recycle view
        searchList.setHasFixedSize(true);
        final LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity().getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        searchList.setLayoutManager(layoutManager);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String query = searchEt.getText().toString().trim();
                if(query.length()==0){
                    searchEt.requestFocus();
                    searchEt.setError("Please enter search keyword");
                    return;
                }
                loadSearchResults(query);
            }
        });
        String query = SharedPreferenceHelper.getInstance().getPreference(getActivity(), "SearchQuery");
        if (query != null && query.length() > 0) {
            searchEt.setText(query);
            loadSearchResults(query);
        }
        return rootView;
    }

    private void loadSearchResults(final String query) {
        SharedPreferenceHelper.getInstance().setPreference(getActivity(), "SearchQuery", query);
        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage(getString(R.string.loading_wait));
        progressDialog.setCancelable(false);
        progressDialog.show();
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                // Call discovery service to get the data
                final ArrayList<PegaSearchResult> list = new ArrayList<>();
                Discovery discovery = new Discovery("2017-11-07");
                discovery.setEndPoint("https://gateway.watsonplatform.net/discovery/api");
                discovery.setUsernameAndPassword("apikey", "pjXr9MjJnRr_Ula1tJJR7l1kiQcupaj8OVLBql9D7FJ8");
                QueryRequest.Builder queryBuilder = new QueryRequest.Builder(environmentId, collectionId);
                queryBuilder.query(query);
                QueryResponse queryResponse = discovery.query(queryBuilder.build()).execute();
                try {
                    if (queryResponse != null) {
                        List<Map<String, Object>> map = queryResponse.getResults();
                        for (int i = 0; i < map.size(); i++) {
                            String sourceUrl = "";
                            String title = "";
                            String summary = "";
                            for (Map.Entry<String, Object> entry : map.get(i).entrySet()) {
                                Log.i("Key is ", entry.getKey());
                                PegaSearchResult result = new PegaSearchResult();
                                if (entry.getKey().equals("sourceUrl")) {
                                    sourceUrl = entry.getValue().toString();
                                }
                                if (entry.getKey().equals("title")) {
                                    title = entry.getValue().toString();
                                }
                                if (entry.getKey().equals("description")) {
                                    summary = entry.getValue().toString();
                                }
                                if (title != null && sourceUrl != null && title.length() > 0) {
                                    result.setURL(sourceUrl);
                                    result.setTitle(title);
                                    if (summary != null) {
                                        summary = summary.trim();
                                        if (summary.length() > 80) {
                                            summary = summary.substring(0, 80);
                                        }
                                        result.setMessage(summary);
                                    }
                                    list.add(result);
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    Logger.e("exc",e);
                }
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        progressDialog.dismiss();
                        //Creating adapter object and setting to recycle view along with default animation
                        if (list.isEmpty()) {
                            noRecords.setVisibility(View.VISIBLE);
                        } else {
                            noRecords.setVisibility(View.GONE);
                        }
                        PegaSearchAdapter adapter = new PegaSearchAdapter(getActivity(), list, new PegaSearchAdapter.OnItemClickListener() {
                            @Override
                            public void onItemClick(PegaSearchResult item) {
                                Intent i = new Intent(getActivity(), WebViewPDFActivity.class);
                                Log.i("PDF URL",item.getURL());
                                String mPocId = "";
                                if (item.getURL().contains("=")){
                                    String[] arr = item.getURL().split("=", 2);
                                    mPocId = arr[1];
                                }
                                i.putExtra("url", mPocId);
                                getActivity().startActivity(i);
                            }
                        });
                        searchList.setItemAnimator(new DefaultItemAnimator());
                        searchList.setAdapter(adapter);
                    }
                });
            }
        });
        t.start();
    }
}

