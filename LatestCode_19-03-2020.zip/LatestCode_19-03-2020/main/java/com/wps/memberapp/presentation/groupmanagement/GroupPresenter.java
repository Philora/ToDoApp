package com.wps.memberapp.presentation.groupmanagement;

import com.wps.memberapp.presentation.base.MvpPresenter;

/*
This interface contain all the Group Management functionality declarations.
 */
public interface GroupPresenter extends MvpPresenter {
    void updateMemberGroupData();
}
