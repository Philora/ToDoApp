package com.wps.memberapp.presentation.groupmanagement;

import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.base.MvpView;
import com.wps.memberapp.utility.AppConstants;

/*
This class is used to implement all Group Management functions which
are declared in GroupPresenter.
 */
public class GroupPresenterImpl implements GroupPresenter {

    private MvpView mView;

    @Override
    public void onAttach(MvpView mView) {
        this.mView = mView;
    }

    @Override
    public void updateMemberGroupData() {
        VolleyService.updateMemberGroupPreference(mView.getAppContext(), AppConstants.UPDATE_MEMBER_GROUP_LIST, new VolleyResponseListener() {
            @Override
            public void onResponse(String message) {
                try {
                    ((GroupView) mView).onUpdateGroupDetailsCompleted();
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
            }

            @Override
            public void onError(String error) {
                mView.hideProgress();
            }
        });
    }

    @Override
    public void onDetach() {
        mView = null;
    }
}
