package com.wps.memberapp.presentation.groupmanagement;


import com.wps.memberapp.presentation.base.MvpView;

/*
This interface contain UI functions of Group Management.
 */
public interface GroupView extends MvpView {
    void onUpdateGroupDetailsCompleted();
    void onAPIsLoadingCompleted();
}
