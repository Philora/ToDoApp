package com.wps.memberapp.presentation.groupmanagement.activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MemberGroupDetails;
import com.wps.memberapp.presentation.base.MainActivity;
import com.wps.memberapp.presentation.dashboard.activity.DashboardActivity;
import com.wps.memberapp.presentation.groupmanagement.GroupPresenter;
import com.wps.memberapp.presentation.groupmanagement.GroupPresenterImpl;
import com.wps.memberapp.presentation.groupmanagement.GroupView;
import com.wps.memberapp.presentation.groupmanagement.adapter.GroupAdapter;
import com.wps.memberapp.presentation.login.LoginPresenterImpl;
import com.wps.memberapp.utility.GeneralUtils;

import java.util.List;

import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;

/*
This activity is used to display the list of plans available for a
particular user and provide a feature to select particular plan.
 */
public class GroupActivity extends MainActivity implements GroupView, GroupAdapter.OnCheckChangeListener {
    private LoginPresenterImpl presenter;
    @BindView(R.id.next)
    TextView tvNext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group);
        ButterKnife.bind(GroupActivity.this);
        RecyclerView recyclerView = findViewById(R.id.recyclerViewGroup);
        //Setting layout manager to recycler view
        recyclerView.setHasFixedSize(true);
        GroupPresenter mPresenter = new GroupPresenterImpl();
        presenter = new LoginPresenterImpl();
        mPresenter.onAttach(this);
        presenter.onAttach(this);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        List<MemberGroupDetails> mGroupDetailsList = ProfileDataCache.getInstance().getmMemberGroupDetails();
        GroupAdapter mAdapter = new GroupAdapter(this, mGroupDetailsList, this);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);
        tvNext.setOnClickListener(view -> {
            if (mAdapter.getSelectedPosition() == -1) {
                Toast.makeText(getApplicationContext(), R.string.select_one_plan, Toast.LENGTH_SHORT).show();
                return;
            }
            //Updating user selection
            if (mGroupDetailsList.get(mAdapter.getSelectedPosition()) != null) {
                ProfileDataCache.getInstance().setMemberGroupUserDefined(mGroupDetailsList.get(mAdapter.getSelectedPosition()).getUserDefined());
            }
            if (GeneralUtils.isOnline(this)) {
                showProgress();
                mPresenter.updateMemberGroupData();
            } else {
                GeneralUtils.showAlertDialog(this, getString(R.string.login_no_internet));
            }
        });
    }

    /*
    Call back when user click on one plan
     */
    @Override
    public void onCheckChanged() {
        tvNext.setTextColor(Color.WHITE);
        tvNext.setBackgroundColor(Color.parseColor("#005289"));
    }

    @Override
    public void onUpdateGroupDetailsCompleted() {
        presenter.callProfileAPIs();
    }

    /*
    This method is used to start the DashboardActivity after all profile APIs loading completed.
     */
    @Override
    public void onAPIsLoadingCompleted() {
        hideProgress();
        Intent i = new Intent(GroupActivity.this, DashboardActivity.class);
        startActivity(i);
        finish();
    }

    /*
   This method is used to logout from the app if user click on back button.
    */
    @Override
    public void onBackPressed() {
        GeneralUtils.logoutApp(getApplicationContext());
        super.onBackPressed();
    }
}
