package com.wps.memberapp.presentation.groupmanagement.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.model.MemberGroupDetails;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

/**
 * This adapter is used to display the list of plans available in a list view form.
 */
public class GroupAdapter extends RecyclerView.Adapter<GroupAdapter.IdCardViewHolder> {

    //This context  will be used to inflate the layout
    private final Activity mCtx;
    private final List<MemberGroupDetails> mMemberDetailList;
    private int mSelectedPosition = -1;
    private final OnCheckChangeListener listener;

    public GroupAdapter(Activity mCtx, List<MemberGroupDetails> mMemberDetailList, OnCheckChangeListener listener) {
        this.mCtx = mCtx;
        this.mMemberDetailList = mMemberDetailList;
        this.listener = listener;
    }

    /*
 Creating ViewHolder based on the layout to bind the data to adapter.
  */
    @NonNull
    @Override
    public IdCardViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.row_plans_group_adapter, parent, false);
        return new IdCardViewHolder(view);
    }

    /*
  Binding data to ViewHolder class object based on the position.
  */
    @Override
    public void onBindViewHolder(@NonNull final IdCardViewHolder holder, int position) {
        if (mMemberDetailList != null && !mMemberDetailList.isEmpty()) {
            MemberGroupDetails details = mMemberDetailList.get(position);
            //Binding list of plans to view holder views
            if (details != null) {
                holder.tvGroupName.setSelected(true);
                holder.tvGroupName.setText(details.getGroupName());
                String status = mCtx.getString(R.string.active);
                if (details.getIsActive() != null && details.getIsActive().equalsIgnoreCase("false")) {
                    status = mCtx.getString(R.string.inactive);
                }
                holder.tvStatus.setText(status);
                holder.tvMemberId.setText(details.getSubscriberID());
            }
            holder.rbSelector.setChecked(position == mSelectedPosition);
            //Click listener to notify the user when user click on one plan.
            holder.rbSelector.setOnCheckedChangeListener((compoundButton, b) -> listener.onCheckChanged());
            holder.cardView.setOnClickListener(v -> {
                mSelectedPosition = holder.getAdapterPosition();
                notifyDataSetChanged();
            });
        }
    }

    /*
This method is used to get the items size in array list
*/
    @Override
    public int getItemCount() {
        if (mMemberDetailList != null) {
            return mMemberDetailList.size();
        } else {
            return 0;
        }
    }

    /*
    View Holder class to bind the data to views.
     */
    class IdCardViewHolder extends RecyclerView.ViewHolder {

        final TextView tvGroupName;
        final TextView tvMemberId;
        final TextView tvStatus;
        final RadioButton rbSelector;
        final CardView cardView;

        private IdCardViewHolder(@NonNull View itemView) {
            super(itemView);
            tvGroupName = itemView.findViewById(R.id.groupName);
            tvMemberId = itemView.findViewById(R.id.memberId);
            tvStatus = itemView.findViewById(R.id.status);
            rbSelector = itemView.findViewById(R.id.selector);
            cardView = itemView.findViewById(R.id.groupCardView);
        }
    }

    public int getSelectedPosition() {
        return mSelectedPosition;
    }

    /*
    This listener is used to communicate to Group Activity
     */
    public interface OnCheckChangeListener {
        void onCheckChanged();
    }
}
