package com.wps.memberapp.presentation.healthtracker.activity;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import com.wps.memberapp.R;
import com.wps.memberapp.presentation.dashboard.activity.DashboardActivity;
import com.wps.memberapp.presentation.healthtracker.fragment.HealthTracker;

import androidx.appcompat.widget.Toolbar;
import butterknife.BindView;
import butterknife.ButterKnife;

public class HealthTrackerActivity extends Activity {

    @BindView(R.id.toolbarFitbit)
    Toolbar toolbar;

    public static Intent newIntent(Context context) {
        return new Intent(context, HealthTrackerActivity.class);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_health_tracker);
        ButterKnife.bind(this);
        if (savedInstanceState == null) {
            selectFirstItemAsDefault();
        }
    }

/**
     * This method is used to initiate default fragment after login at the launch of dashboard
     */

    private void selectFirstItemAsDefault() {
        final HealthTracker firstFragment = new HealthTracker();
        getFragmentManager().beginTransaction().replace
                (R.id.fitbitContainer, firstFragment, "HOME").commit();
    }

    @Override
    public void onBackPressed() {
        if (getFragmentManager().getBackStackEntryCount() > 0) {
            getFragmentManager().popBackStack();
            toolbar.setBackgroundColor(getResources().getColor(R.color.green));
        } else {
            Intent i = new Intent(HealthTrackerActivity.this, DashboardActivity.class);
            startActivity(i);
        }
    }

}

