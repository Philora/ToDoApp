package com.wps.memberapp.presentation.healthtracker.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.wps.memberapp.utility.GridCustomView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 133580 on 2/11/2018.
 */

public class GridViewAdapter extends BaseAdapter {

    private Context context;

    private String [] medicationTime;
    public List<Integer> selectedPositions = new ArrayList<>();

    public GridViewAdapter(Context context, String [] medicationTime) {
        this.context=context;
        this.medicationTime=medicationTime;
    }

    @Override
    public int getCount() {
        return medicationTime.length;
    }

    @Override
    public Object getItem(int position) {
        return medicationTime[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup viewGroup) {
        GridCustomView customView = (convertView == null) ?
                new GridCustomView(context) : (GridCustomView) convertView;
        customView.display(medicationTime[position], selectedPositions.contains(position));
        return customView;
    }

}
