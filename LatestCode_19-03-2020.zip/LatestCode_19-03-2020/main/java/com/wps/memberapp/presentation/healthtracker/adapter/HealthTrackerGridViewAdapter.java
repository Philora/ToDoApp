package com.wps.memberapp.presentation.healthtracker.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.wps.memberapp.R;

/**
 * Created by 133580 on 2/27/2018.
 */

public class HealthTrackerGridViewAdapter extends BaseAdapter {

    private Context context;
    private String [] medicationTime;

    public HealthTrackerGridViewAdapter(Context context, String [] medicationTime) {
        this.context=context;
        this.medicationTime=medicationTime;
    }

    @Override
    public int getCount() {
        return medicationTime.length;
    }

    @Override
    public Object getItem(int i) {
        return medicationTime[i];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        LayoutInflater inflater= (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if(convertView==null) {
            convertView = inflater.inflate(R.layout.fragment_health_tracker_grid, null);
        }
        final TextView name=(TextView)convertView.findViewById(R.id.textView);
        name.setText(medicationTime[position]);
        return convertView;
    }
}
