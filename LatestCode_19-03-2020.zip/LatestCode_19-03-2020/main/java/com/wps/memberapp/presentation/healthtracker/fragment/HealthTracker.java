package com.wps.memberapp.presentation.healthtracker.fragment;

import android.app.Activity;
import android.app.Fragment;
import android.app.LoaderManager;
import android.app.ProgressDialog;
import android.content.AsyncTaskLoader;
import android.content.Context;
import android.content.Intent;
import android.content.Loader;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.google.gson.Gson;
import com.wps.memberapp.R;
import com.wps.memberapp.data.APIUtils;
import com.wps.memberapp.data.loaders.ResourceLoaderResult;
import com.wps.memberapp.data.models.CaloriesSummary;
import com.wps.memberapp.data.models.DistanceSummary;
import com.wps.memberapp.data.models.DurationSummary;
import com.wps.memberapp.data.models.FitbitValueSummary;
import com.wps.memberapp.data.models.FloorsSummary;
import com.wps.memberapp.data.models.Goals;
import com.wps.memberapp.data.models.HeartRateSummary;
import com.wps.memberapp.data.models.HeartRateZone;
import com.wps.memberapp.domain.fitbitauth.authentication.Scope;
import com.wps.memberapp.data.models.SleepSummary;
import com.wps.memberapp.data.models.StepsSummary;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.domain.fitbitauth.authentication.AuthenticationManager;
import com.wps.memberapp.domain.fitbitnetwork.BasicHttpRequest;
import com.wps.memberapp.domain.fitbitnetwork.BasicHttpResponse;
import com.wps.memberapp.presentation.healthtracker.adapter.HealthTrackerGridViewAdapter;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;

import androidx.annotation.Nullable;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;


/*
 Created by Shraddha_V_Pandey on 9/20/2017.
*/



public class HealthTracker extends Fragment implements LoaderManager.LoaderCallbacks, View.OnClickListener {

    @BindView(R.id.stepsValue)
    TextView stepsValue;
    @BindView(R.id.goalValue)
    TextView goalValue;
    @BindView(R.id.pieChartFitbit)
    PieChart pieChart;
    @BindView(R.id.durationValue)
    TextView durationValue;
    @BindView(R.id.dateLabel)
    TextView dateLabel;
    @BindView(R.id.caloriesValue)
    TextView calorieValue;
    @BindView(R.id.heartRateValue)
    TextView mHeartRate;
    @BindView(R.id.milesValue)
    TextView mMilesValue;
    @BindView(R.id.floorValue)
    TextView mFloorValue;
    @BindView(R.id.sleepValue)
    TextView sleepValue;
    @BindView(R.id.btnBackward)
    ImageView btnBackward;
    @BindView(R.id.btnForward)
    ImageView btnForward;
    @BindView(R.id.sleepRelativeLayout)
    RelativeLayout sleepRelativeLayout;
    @BindView(R.id.heartRateLayout)
    RelativeLayout heartRateLayout;
    @BindView(R.id.dayGridView)
    GridView daysGridView;
    @BindView(R.id.scrollViewDashboard)
    ScrollView scrollViewSteps;
    private String mStepValue;
    private String mGoalValue;
    private static final String EOL = System.getProperty("line.separator");
    private static Context context = null;
    private static LinkedHashMap<String, FitbitValueSummary> fitbitValues;
    private Date minDate;
    private Date maxDate;
    private String goals;
    private ProgressDialog progressDialog;
    private static String minDateValue;
    private Date displayDate;
    private static String displayDateValue;
    FitbitValueSummary fitbitValueSummary;
    private String dateFormat = "yyyy-MM-dd";
    private String stepGoal = "step_goal";
    private String mins = "mins";
    private String dateFormat1 = "EEE, MMM dd, ''yy";
    private static String contentType = "Application/json";
    private String fitbitValues1 = "FitbitValues";
    private String space = "-- --";
    static String errorText = "Error making request:%s\tHTTP Code:%d%s\tResponse Body:%s%s%s%n";
    private Unbinder unbinder;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        context = getActivity();
        fitbitValues = new LinkedHashMap<>();
        SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);

        //getting current date
        Date todaysDate = Calendar.getInstance().getTime();
        displayDate = todaysDate;

        //formatting current date
        displayDateValue = formatter.format(displayDate);
        try {
            displayDate = formatter.parse(displayDateValue);
        } catch (ParseException e) {
            Logger.e("HealthTracker", e);
        }
        Log.i("Health", "" + displayDate);

        //getting max date
        maxDate = displayDate;

        //getting min date
        try {
            Date d = formatter.parse(displayDateValue);
            minDate = new Date(d.getTime() - 6 * 24 * 3600 * 1000);
            //formatting min date
            minDateValue = formatter.format(minDate);
            minDate = formatter.parse(minDateValue);
            Log.i("Health", "" + minDate);
        } catch (ParseException pe) {
            pe.getMessage();
        }
    }

    private void initLoaders() {
        getLoaderManager().initLoader(0, null, this).forceLoad();
        getLoaderManager().initLoader(1, null, this).forceLoad();
        getLoaderManager().initLoader(2, null, this).forceLoad();
        getLoaderManager().initLoader(3, null, this).forceLoad();
        getLoaderManager().initLoader(4, null, this).forceLoad();
        getLoaderManager().initLoader(5, null, this).forceLoad();
        getLoaderManager().initLoader(6, null, this).forceLoad();
        getLoaderManager().initLoader(7, null, this).forceLoad();

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        View rootView = inflater.inflate(R.layout.fragment_health_tracker, container, false);
        unbinder = ButterKnife.bind(this, rootView);
        scrollViewSteps.scrollTo(0, 100);
        setDate(dateLabel);
        setClickableStatus();
        btnBackward.setOnClickListener(this);
        btnForward.setOnClickListener(this);
        dateLabel.setOnClickListener(this);
        heartRateLayout.setOnClickListener(this);
        sleepRelativeLayout.setOnClickListener(this);

        if (SharedPreferenceHelper.getInstance() != null) {
            SharedPreferenceHelper.getInstance().clearPreference(context, stepGoal);
        }
        daysGridView.setAdapter(new HealthTrackerGridViewAdapter(getActivity(), getActivity().getResources().getStringArray(R.array.days)));
        return rootView;
    }

    @Override
    public Loader onCreateLoader(int i, Bundle bundle) {
        if (i == 0) {
            progressDialog = new ProgressDialog(context);
            progressDialog.setMessage("Loading Fitbit data ..");
            progressDialog.show();
            return new FetchSleepData(getActivity());
      } else if (i == 1) {
            return new FetchHeartRate(getActivity());
        } else if (i == 2) {
            return new FetchStepsData(getActivity());
        } else if (i == 3) {
            return new FetchCaloriesData(getActivity());
        } else if (i == 4) {
            return new FetchDistanceData(getActivity());
        } else if (i == 5) {
            return new FetchFloorsData(getActivity());
        } else if (i == 6) {
            return new FetchGoals(getActivity());
        } else if (i == 7) {
            return new FetchDurationData(getActivity());
        }
        return null;
    }

    @Override
    public void onLoadFinished(Loader loader, Object data) {
        if (data != null) {
            if (SharedPreferenceHelper.getInstance() != null) {
                goals = SharedPreferenceHelper.getInstance().getPreference(context, stepGoal);
            }
            if (fitbitValues != null && fitbitValues.size() > 0 && fitbitValues.get(displayDateValue) != null) {
                goalValue.setText(goals);
                mGoalValue = goals;
                if (fitbitValues.get(displayDateValue).getHeart_rate() != null && !fitbitValues.get(displayDateValue).getHeart_rate().equals("null")) {
                    mHeartRate.setText(String.valueOf(fitbitValues.get(displayDateValue).getHeart_rate() + " " + "BPM"));
                }
                if (fitbitValues.get(displayDateValue).getSteps() != null && !fitbitValues.get(displayDateValue).getSteps().equals("null")) {
                    stepsValue.setText(String.valueOf(fitbitValues.get(displayDateValue).getSteps()));
                    mStepValue = String.valueOf(fitbitValues.get(displayDateValue).getSteps());
                }
                if (fitbitValues.get(displayDateValue).getDistance() != null && !fitbitValues.get(displayDateValue).getDistance().equals("null")) {
                    String miles = "" + convertKmsToMiles(Double.valueOf(fitbitValues.get(displayDateValue).getDistance()), 2);
                    mMilesValue.setText(miles);
                }
                if (fitbitValues.get(displayDateValue).getFloors() != null && !fitbitValues.get(displayDateValue).getFloors().equals("null")) {
                    mFloorValue.setText(fitbitValues.get(displayDateValue).getFloors());
                }
                if (fitbitValues.get(displayDateValue).getCalories() != null && !fitbitValues.get(displayDateValue).getCalories().equals("null")) {
                    calorieValue.setText(fitbitValues.get(displayDateValue).getCalories());
                }
                if (fitbitValues.get(displayDateValue).getDuration() != null && !fitbitValues.get(displayDateValue).getDuration().equals("null")) {
                    String duration = String.valueOf(fitbitValues.get(displayDateValue).getDuration());
                    durationValue.setText(duration);
                }
                if (fitbitValues.get(displayDateValue).getSleep() != null && !fitbitValues.get(displayDateValue).getSleep().equals("null")) {
                    Integer sleep = Integer.parseInt(String.valueOf(fitbitValues.get(displayDateValue).getSleep()));
                    int hours = sleep / 60;
                    Integer minutes = sleep % 60;
                    sleepValue.setText(String.valueOf(hours) + " hr" + " " + minutes + " " + mins);
                } else {
                    sleepValue.setText(space);
                }
                getPieChartResults();
            }
        }
        progressDialog.dismiss();
    }

    @Override
    public void onLoaderReset(Loader loader) {
        progressDialog.dismiss();
    }

    @Override
    public void onResume() {
        super.onResume();
        initLoaders();
    }

    private PieChart getPieChartResults() {

        final int[] myColors = {Color.rgb(255, 255, 255), Color.rgb(138, 219, 124)};

        ArrayList<PieEntry> yvalues = new ArrayList<>();

        if (mGoalValue != null && !mGoalValue.equals("null") && mStepValue != null && !mStepValue.equals("null")) {
            Double goal = Double.valueOf(mGoalValue);
            Double steps = Double.valueOf(mStepValue);
            if (steps >= goal) {
                float f1 = (float) Double.parseDouble(mGoalValue);
                float f2 = (float) Double.parseDouble(mGoalValue);
                float f3 = f1 - f2;
                yvalues.add(new PieEntry((f2)));
                yvalues.add(new PieEntry((f3)));
            } else {
                float f1 = (float) Double.parseDouble(mGoalValue);
                float f2 = (float) Double.parseDouble(mStepValue);
                float f3 = f1 - f2;
                yvalues.add(new PieEntry((f2)));
                yvalues.add(new PieEntry((f3)));
            }
            PieDataSet dataSet = new PieDataSet(yvalues, "");
            dataSet.setSliceSpace(3f);
            dataSet.setDrawValues(false);

            ArrayList<Integer> colors = new ArrayList<>();
            for (int c : myColors) colors.add(c);
            dataSet.setColors(colors);

            PieData data = new PieData(dataSet);
            pieChart.setData(data);
            pieChart.setDrawHoleEnabled(true);
            pieChart.setHoleColor(Color.WHITE);
            pieChart.setCenterTextSize(60);
            pieChart.setTransparentCircleAlpha(50);
            pieChart.setHoleRadius(95f);
            pieChart.setHoleColor(Color.argb(0, 0, 0, 0));
            pieChart.setDrawSliceText(false);
            pieChart.getDescription().setEnabled(false);
            pieChart.setDrawCenterText(true);
            pieChart.spin(1000, pieChart.getRotationAngle(), pieChart.getRotationAngle()
                    + 360, Easing.EasingOption
                    .EaseInCubic);
            pieChart.invalidate();
        }

        return pieChart;
    }

    public void setDate(TextView view) {
        Date today = Calendar.getInstance().getTime();//getting date
        SimpleDateFormat formatter = new SimpleDateFormat(dateFormat1);//formating according to my need
        String date = formatter.format(today);
        view.setText(date.substring(0, 11));
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnBackward:
                SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
                try {
                    Date d = formatter.parse(displayDateValue);
                    displayDate = new Date(d.getTime() - 1 * 24 * 3600 * 1000);
                    displayDateValue = formatter.format(displayDate);
                } catch (ParseException pe) {
                    pe.getMessage();
                }

                stepsValue.setText(String.valueOf("0"));
                mStepValue = String.valueOf("0.0");
                mMilesValue.setText("0.0");
                mFloorValue.setText("0.0");
                durationValue.setText("0.0");
                calorieValue.setText("0.0");

                SimpleDateFormat labelFormatterBackward = new SimpleDateFormat(dateFormat1);
                String labelTextBackward = labelFormatterBackward.format(displayDate);
                dateLabel.setText(labelTextBackward.substring(0, 11));

                setClickableStatus();

                fitbitValueSummary = new FitbitValueSummary();

                if (SharedPreferenceHelper.getInstance() != null) {
                    goals = SharedPreferenceHelper.getInstance().getPreference(context, stepGoal);
                }

                if (fitbitValues != null && fitbitValues.size() > 0) {
                    fitbitValueSummary = fitbitValues.get(displayDateValue);
                    if (fitbitValueSummary != null) {
                        goalValue.setText(goals);
                        mGoalValue = goals;
                        if (fitbitValueSummary.getHeart_rate() != null &&
                                !fitbitValueSummary.getHeart_rate().equals("null")) {
                            mHeartRate.setText(String.valueOf(fitbitValueSummary.getHeart_rate() + " " + "BPM"));
                        }
                        if (fitbitValues.get(displayDateValue).getCalories() != null && !fitbitValues.get(displayDateValue).getCalories().equals("null")) {
                            calorieValue.setText(fitbitValues.get(displayDateValue).getCalories());
                        }

                        if (fitbitValues.get(displayDateValue).getHeart_rate() != null && !fitbitValues.get(displayDateValue).getHeart_rate().equals("null")) {
                            mHeartRate.setText(String.valueOf(fitbitValues.get(displayDateValue).getHeart_rate() + " " + "BPM"));
                        }
                        if (fitbitValues.get(displayDateValue).getSteps() != null && !fitbitValues.get(displayDateValue).getSteps().equals("null")) {
                            stepsValue.setText(String.valueOf(fitbitValues.get(displayDateValue).getSteps()));
                            mStepValue = String.valueOf(fitbitValues.get(displayDateValue).getSteps());
                        }
                        if (fitbitValues.get(displayDateValue).getDistance() != null && !fitbitValues.get(displayDateValue).getDistance().equals("null")) {
                            String miles = "" + convertKmsToMiles(Double.valueOf(fitbitValues.get(displayDateValue).getDistance()), 2);
                            mMilesValue.setText(miles);
                        }
                        if (fitbitValues.get(displayDateValue).getFloors() != null && !fitbitValues.get(displayDateValue).getFloors().equals("null")) {
                            mFloorValue.setText(fitbitValues.get(displayDateValue).getFloors());
                        }
                        if (fitbitValues.get(displayDateValue).getDuration() != null && !fitbitValues.get(displayDateValue).getDuration().equals("null")) {
                            String duration = String.valueOf(fitbitValues.get(displayDateValue).getDuration());
                            durationValue.setText(duration);
                        }
                        if (fitbitValues.get(displayDateValue).getSleep() != null && !fitbitValues.get(displayDateValue).getSleep().equals("null")) {
                            Integer sleep = Integer.parseInt(String.valueOf(fitbitValues.get(displayDateValue).getSleep()));
                            int hours = sleep / 60;
                            Integer minutes = sleep % 60;
                            sleepValue.setText(String.valueOf(hours) + " hr" + " " + minutes + " " + mins);
                        } else {
                            sleepValue.setText("-- --");
                        }
                        getPieChartResults();
                    }
                }

                break;

            case R.id.btnForward:

                SimpleDateFormat formatterForward = new SimpleDateFormat(dateFormat);
                try {
                    Date d = formatterForward.parse(displayDateValue);
                    displayDate = new Date(d.getTime() + 1 * 24 * 3600 * 1000);
                    displayDateValue = formatterForward.format(displayDate);
                } catch (ParseException pe) {
                    pe.getMessage();
                }

                stepsValue.setText(String.valueOf("0.0"));
                mStepValue = String.valueOf("0");
                mMilesValue.setText("0.0");
                mFloorValue.setText("0.0");
                durationValue.setText("0.0");
                calorieValue.setText("0.0");

                SimpleDateFormat labelFormatterForward = new SimpleDateFormat(dateFormat1);
                String labelTextForward = labelFormatterForward.format(displayDate);
                dateLabel.setText(labelTextForward.substring(0, 11));
                setClickableStatus();

                if (SharedPreferenceHelper.getInstance() != null) {
                    goals = SharedPreferenceHelper.getInstance().getPreference(context, stepGoal);
                }
                fitbitValueSummary = new FitbitValueSummary();
                if (fitbitValues != null && fitbitValues.size() > 0) {
                    fitbitValueSummary = fitbitValues.get(displayDateValue);
                    if (fitbitValueSummary != null) {
                        goalValue.setText(goals);
                        mGoalValue = goals;
                        if (fitbitValueSummary.getHeart_rate() != null &&
                                !fitbitValueSummary.getHeart_rate().equals("null")) {
                            mHeartRate.setText(String.valueOf(fitbitValueSummary.getHeart_rate() + " " + "BPM"));
                        }
                        if (fitbitValues.get(displayDateValue).getCalories() != null && !fitbitValues.get(displayDateValue).getCalories().equals("null")) {
                            calorieValue.setText(fitbitValues.get(displayDateValue).getCalories());
                        }
                        if (fitbitValues.get(displayDateValue).getHeart_rate() != null && !fitbitValues.get(displayDateValue).getHeart_rate().equals("null")) {
                            mHeartRate.setText(String.valueOf(fitbitValues.get(displayDateValue).getHeart_rate() + " " + "BPM"));
                        }
                        if (fitbitValues.get(displayDateValue).getSteps() != null && !fitbitValues.get(displayDateValue).getSteps().equals("null")) {
                            stepsValue.setText(String.valueOf(fitbitValues.get(displayDateValue).getSteps()));
                            mStepValue = String.valueOf(fitbitValues.get(displayDateValue).getSteps());
                        }
                        if (fitbitValues.get(displayDateValue).getDistance() != null && !fitbitValues.get(displayDateValue).getDistance().equals("null")) {
                            String miles = "" + convertKmsToMiles(Double.valueOf(fitbitValues.get(displayDateValue).getDistance()), 2);
                            mMilesValue.setText(miles);
                        }
                        if (fitbitValues.get(displayDateValue).getFloors() != null && !fitbitValues.get(displayDateValue).getFloors().equals("null")) {
                            mFloorValue.setText(fitbitValues.get(displayDateValue).getFloors());
                        }
                        if (fitbitValues.get(displayDateValue).getDuration() != null && !fitbitValues.get(displayDateValue).getDuration().equals("null")) {
                            String duration = String.valueOf(fitbitValues.get(displayDateValue).getDuration());
                            durationValue.setText(duration);
                        }
                        if (fitbitValues.get(displayDateValue).getSleep() != null && !fitbitValues.get(displayDateValue).getSleep().equals("null")) {
                            Integer sleep = Integer.parseInt(String.valueOf(fitbitValues.get(displayDateValue).getSleep()));
                            int hours = sleep / 60;
                            Integer minutes = sleep % 60;
                            sleepValue.setText(String.valueOf(hours) + " hr" + " " + minutes + " mins");
                        } else {
                            sleepValue.setText(space);
                        }
                        getPieChartResults();
                    }
                }


                break;

            case R.id.dateLabel:
                if (SharedPreferenceHelper.getInstance() != null) {
                    goals = SharedPreferenceHelper.getInstance().getPreference(context, stepGoal);
                }
                StepsFragment stepsFragment = new StepsFragment();
                Bundle extras = new Bundle();
                if (fitbitValues != null && goals != null && fitbitValues.size() > 0 && goals.length() > 0) {
                    extras.putSerializable(fitbitValues1, fitbitValues);
                    extras.putString("goals", goals);
                }
                stepsFragment.setArguments(extras);
                getActivity().getFragmentManager().beginTransaction().
                        replace(R.id.fitbitContainer, stepsFragment).addToBackStack("null").commit();
                break;

            case R.id.heartRateLayout:

                HeartRateFragment heartFragment = new HeartRateFragment();
                Bundle extra = new Bundle();
                if (fitbitValues != null && fitbitValues.size() > 0) {
                    extra.putSerializable(fitbitValues1, fitbitValues);
                }
                heartFragment.setArguments(extra);
                getActivity().getFragmentManager().beginTransaction().
                        replace(R.id.fitbitContainer, heartFragment).addToBackStack("null").commit();
                break;

            case R.id.sleepRelativeLayout:

                SleepFragment sleepFragment = new SleepFragment();
                Bundle arg = new Bundle();
                if (fitbitValues != null && fitbitValues.size() > 0) {
                    arg.putSerializable(fitbitValues1, fitbitValues);
                }
                sleepFragment.setArguments(arg);
                getActivity().getFragmentManager().beginTransaction().
                        replace(R.id.fitbitContainer, sleepFragment).addToBackStack("null").commit();
                break;
            default:
                break;
        }
    }

// This loader inner class is used to fetch heart rate of one month from FitBit cloud and update UI accordingly

    private static class FetchGoals extends AsyncTaskLoader<ResourceLoaderResult<Goals>> {
        String dateTime;
        String time;
        FitbitValueSummary summary;
        public final String url;
        public final Activity contextActivity;
        public final Handler handler;
        public final Scope[] requiredScopes;

        public FetchGoals(Activity context) {
            super(context);
            this.contextActivity = context;
            this.url = "https://api.fitbit.com/1/user/-/activities/goals/daily.json";
            this.handler = new Handler();
            this.requiredScopes = new Scope[]{Scope.heartrate};
        }

        @Override
        public ResourceLoaderResult<Goals> loadInBackground() {
            try {
                APIUtils.validateToken(contextActivity, AuthenticationManager.getCurrentAccessToken(), requiredScopes);
                BasicHttpRequest request = AuthenticationManager
                        .createSignedRequest()
                        .setContentType(contentType)
                        .setUrl(url)
                        .build();

                final BasicHttpResponse response = request.execute();
                int responseCode = response.getStatusCode();
                final String json = response.getBodyAsString();
                JSONObject jsonObject = new JSONObject(json);
                if (response.isSuccessful()) {
                    final Goals resource = new Gson().fromJson(json, Goals.class);
                    JSONObject json2 = jsonObject.getJSONObject("goals");
                    SharedPreferenceHelper.getInstance().setPreference(context, "step_goal", json2.getString("steps"));
                    return ResourceLoaderResult.onSuccess(resource);
                } else {
                    if (responseCode == 401) {
                        if (AuthenticationManager.getAuthenticationConfiguration().isLogoutOnAuthFailure()) {
                            // Token may have been revoked or expired
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    AuthenticationManager.logout(contextActivity);
                                }
                            });
                        }
                        return ResourceLoaderResult.onLoggedOut();
                    } else {
                        String errorMessage =
                                String.format(Locale.ENGLISH,errorText
                                        ,
                                        EOL,
                                        responseCode,
                                        EOL,
                                        EOL,
                                        json,
                                        EOL);
                        return ResourceLoaderResult.onError(errorMessage);
                    }
                }
            } catch (Exception e) {
                return ResourceLoaderResult.onException(e);
            }
        }

        @Override
        public void deliverResult(ResourceLoaderResult<Goals> data) {
            super.deliverResult(data);
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Log.d("Goal Summary", data.toString());
        }
    }


    private static class FetchHeartRate extends AsyncTaskLoader<ResourceLoaderResult<HeartRateSummary>> {
        String dateTime;
        String time;
        FitbitValueSummary summary;
        public final String url;
        public final Activity contextActivity;
        public final Handler handler;
        public final Scope[] requiredScopes;

        public FetchHeartRate(Activity context) {
            super(context);
            this.contextActivity = context;
            this.url = "https://api.fitbit.com/1/user/-/activities/heart/date/today/7d.json";
            this.handler = new Handler();
            this.requiredScopes = new Scope[]{Scope.heartrate};
        }

        @Override
        public ResourceLoaderResult<HeartRateSummary> loadInBackground() {
            try {
                APIUtils.validateToken(contextActivity, AuthenticationManager.getCurrentAccessToken(), requiredScopes);
                BasicHttpRequest request = AuthenticationManager
                        .createSignedRequest()
                        .setContentType(contentType)
                        .setUrl(url)
                        .build();

                final BasicHttpResponse response = request.execute();
                int responseCode = response.getStatusCode();
                final String json = response.getBodyAsString();
                if (response.isSuccessful()) {
                    final HeartRateSummary resource = new Gson().fromJson(json, HeartRateSummary.class);
                    for (int i = 0; i < resource.getActivities().size(); i++) {
                        summary = new FitbitValueSummary();
                        dateTime = resource.getActivities().get(i).getDate();
                        if (fitbitValues.get(dateTime) != null) {
                            summary = fitbitValues.get(dateTime);
                        }
                        if (resource.getActivities().get(i).getValue().getRestingHeartRate() != null) {
                            summary.setHeart_rate(Integer.parseInt(resource.getActivities().get(i).getValue().getRestingHeartRate()));
                        }
                        List<HeartRateZone> heartRateZoneList = resource.getActivities().get(i).getValue().getActivities();

                        if (heartRateZoneList != null && !heartRateZoneList.isEmpty()) {
                            for (int j = 0; j < heartRateZoneList.size(); j++) {
                                if (heartRateZoneList.get(j).getName().equals("Fat Burn")) {
                                    summary.setMin(String.valueOf(heartRateZoneList.get(j).getMin()));
                                    summary.setMax(String.valueOf(heartRateZoneList.get(j).getMax()));
                                    summary.setName(String.valueOf(heartRateZoneList.get(j).getName()));
                                }
                                if (heartRateZoneList.get(j).getName().equals("Cardio")) {
                                    summary.setCardioMin(String.valueOf(heartRateZoneList.get(j).getMin()));
                                    summary.setCardioMax(String.valueOf(heartRateZoneList.get(j).getMax()));
                                    summary.setCardioName(String.valueOf(heartRateZoneList.get(j).getName()));
                                }
                                if (heartRateZoneList.get(j).getName().equals("Peak")) {
                                    summary.setPeakMin(String.valueOf(heartRateZoneList.get(j).getMin()));
                                    summary.setPeakMax(String.valueOf(heartRateZoneList.get(j).getMax()));
                                    summary.setPeakName(String.valueOf(heartRateZoneList.get(j).getName()));
                                }
                            }
                            fitbitValues.put(dateTime, summary);
                        }
                    }
                    return ResourceLoaderResult.onSuccess(resource);
                } else {
                    if (responseCode == 401) {
                        if (AuthenticationManager.getAuthenticationConfiguration().isLogoutOnAuthFailure()) {
                            // Token may have been revoked or expired
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    AuthenticationManager.logout(contextActivity);
                                }
                            });
                        }
                        return ResourceLoaderResult.onLoggedOut();
                    } else {
                        String errorMessage =
                                String.format(Locale.ENGLISH,
                                        errorText,
                                        EOL,
                                        responseCode,
                                        EOL,
                                        EOL,
                                        json,
                                        EOL);
                        return ResourceLoaderResult.onError(errorMessage);
                    }
                }
            } catch (Exception e) {
                return ResourceLoaderResult.onException(e);
            }
        }

        @Override
        public void deliverResult(ResourceLoaderResult<HeartRateSummary> data) {
            super.deliverResult(data);
            Log.d("Heart Rate Summary", data.toString());
        }
    }

// This loader inner class is used to fetch total steps data of one month from FitBit cloud and update UI accordingly


    private static class FetchStepsData extends AsyncTaskLoader<ResourceLoaderResult<StepsSummary>> {
        String dateTime;
        FitbitValueSummary summary;
        public final String url;
        public final Activity contextActivity;
        public final Handler handler;
        public final com.wps.memberapp.domain.fitbitauth.authentication.Scope[] requiredScopes;

        public FetchStepsData(Activity context) {
            super(context);
            this.contextActivity = context;
            this.url = "https://api.fitbit.com/1/user/-/activities/steps/date/today/7d.json";
            this.handler = new Handler();
            this.requiredScopes = new Scope[]{Scope.activity};
        }

        @Override
        public ResourceLoaderResult<StepsSummary> loadInBackground() {
            try {
                APIUtils.validateToken(contextActivity, AuthenticationManager.getCurrentAccessToken(), requiredScopes);
                BasicHttpRequest request = AuthenticationManager
                        .createSignedRequest()
                        .setContentType(contentType)
                        .setUrl(url)
                        .build();

                final BasicHttpResponse response = request.execute();
                int responseCode = response.getStatusCode();
                final String json = response.getBodyAsString();
                if (response.isSuccessful()) {
                    final StepsSummary resource = new Gson().fromJson(json, StepsSummary.class);
                    for (int i = 0; i < resource.getActivities().size(); i++) {
                        summary = new FitbitValueSummary();
                        dateTime = resource.getActivities().get(i).getDate();
                        if (fitbitValues.get(dateTime) != null) {
                            summary = fitbitValues.get(dateTime);
                        }
                        if (resource.getActivities().get(i).getValue() != null) {
                            summary.setSteps(resource.getActivities().get(i).getValue());
                            fitbitValues.put(dateTime, summary);
                        }
                    }
                    return ResourceLoaderResult.onSuccess(resource);
                } else {
                    if (responseCode == 401) {
                        if (AuthenticationManager.getAuthenticationConfiguration().isLogoutOnAuthFailure()) {
                            // Token may have been revoked or expired
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    AuthenticationManager.logout(contextActivity);
                                }
                            });
                        }
                        return ResourceLoaderResult.onLoggedOut();
                    } else {
                        String errorMessage =
                                String.format(Locale.ENGLISH,
                                        errorText,
                                        EOL,
                                        responseCode,
                                        EOL,
                                        EOL,
                                        json,
                                        EOL);
                        return ResourceLoaderResult.onError(errorMessage);
                    }
                }
            } catch (Exception e) {
                return ResourceLoaderResult.onException(e);
            }
        }

        @Override
        public void deliverResult(ResourceLoaderResult<StepsSummary> data) {
            super.deliverResult(data);
            Log.d("Steps_Summary", data.toString());
        }
    }

// This loader inner class is used to fetch Calories rate of one month from FitBit cloud and update UI accordingly

    private static class FetchCaloriesData extends AsyncTaskLoader<ResourceLoaderResult<CaloriesSummary>> {
        String dateTime;
        FitbitValueSummary summary;
        public final String url;
        public final Activity contextActivity;
        public final Handler handler;
        public final Scope[] requiredScopes;

        public FetchCaloriesData(Activity context) {
            super(context);
            this.contextActivity = context;
            this.url = "https://api.fitbit.com/1/user/-/activities/calories/date/today/7d.json";
            this.handler = new Handler();
            this.requiredScopes = new Scope[]{Scope.activity};

        }

        @Override
        public ResourceLoaderResult<CaloriesSummary> loadInBackground() {
            try {
                APIUtils.validateToken(contextActivity, AuthenticationManager.getCurrentAccessToken(), requiredScopes);
                BasicHttpRequest request = AuthenticationManager
                        .createSignedRequest()
                        .setContentType(contentType)
                        .setUrl(url)
                        .build();

                final BasicHttpResponse response = request.execute();
                int responseCode = response.getStatusCode();
                final String json = response.getBodyAsString();
                if (response.isSuccessful()) {
                    final CaloriesSummary resource = new Gson().fromJson(json, CaloriesSummary.class);
                    for (int i = 0; i < resource.getActivities().size(); i++) {
                        summary = new FitbitValueSummary();
                        dateTime = resource.getActivities().get(i).getDate();
                        if (fitbitValues.get(dateTime) != null) {
                            summary = fitbitValues.get(dateTime);
                        }
                        if (resource.getActivities().get(i).getValue() != null) {
                            summary.setCalories(resource.getActivities().get(i).getValue());
                            fitbitValues.put(dateTime, summary);
                        }
                    }
                    return ResourceLoaderResult.onSuccess(resource);
                } else {
                    if (responseCode == 401) {
                        if (AuthenticationManager.getAuthenticationConfiguration().isLogoutOnAuthFailure()) {
                            // Token may have been revoked or expired
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    AuthenticationManager.logout(contextActivity);
                                }
                            });
                        }
                        return ResourceLoaderResult.onLoggedOut();
                    } else {
                        String errorMessage =
                                String.format(Locale.ENGLISH,
                                        errorText,
                                        EOL,
                                        responseCode,
                                        EOL,
                                        EOL,
                                        json,
                                        EOL);
                        return ResourceLoaderResult.onError(errorMessage);
                    }
                }
            } catch (Exception e) {
                return ResourceLoaderResult.onException(e);
            }
        }

        @Override
        public void deliverResult(ResourceLoaderResult<CaloriesSummary> data) {
            super.deliverResult(data);
            Log.d("Calories Summary", data.toString());
        }
    }

// This loader inner class is used to fetch Floors rate of one month from FitBit cloud and update UI accordingly

    private static class FetchFloorsData extends AsyncTaskLoader<ResourceLoaderResult<FloorsSummary>> {
        String dateTime;
        FitbitValueSummary summary;
        public final String url;
        public final Activity contextActivity;
        public final Handler handler;
        public final Scope[] requiredScopes;

        public FetchFloorsData(Activity context) {
            super(context);
            this.contextActivity = context;
            this.url = "https://api.fitbit.com/1/user/-/activities/floors/date/today/7d.json";
            this.handler = new Handler();
            this.requiredScopes = new Scope[]{Scope.activity};

        }

        @Override
        public ResourceLoaderResult<FloorsSummary> loadInBackground() {
            try {
                APIUtils.validateToken(contextActivity, AuthenticationManager.getCurrentAccessToken(), requiredScopes);
                BasicHttpRequest request = AuthenticationManager
                        .createSignedRequest()
                        .setContentType(contentType)
                        .setUrl(url)
                        .build();

                final BasicHttpResponse response = request.execute();
                int responseCode = response.getStatusCode();
                final String json = response.getBodyAsString();
                if (response.isSuccessful()) {
                    final FloorsSummary resource = new Gson().fromJson(json, FloorsSummary.class);
                    for (int i = 0; i < resource.getActivities().size(); i++) {
                        summary = new FitbitValueSummary();
                        dateTime = resource.getActivities().get(i).getDate();
                        if (fitbitValues.get(dateTime) != null) {
                            summary = fitbitValues.get(dateTime);
                        }
                        if (resource.getActivities().get(i).getValue() != null) {
                            summary.setFloors(resource.getActivities().get(i).getValue());
                            fitbitValues.put(dateTime, summary);
                        }
                    }
                    return ResourceLoaderResult.onSuccess(resource);
                } else {
                    if (responseCode == 401) {
                        if (AuthenticationManager.getAuthenticationConfiguration().isLogoutOnAuthFailure()) {
                            // Token may have been revoked or expired
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    AuthenticationManager.logout(contextActivity);
                                }
                            });
                        }
                        return ResourceLoaderResult.onLoggedOut();
                    } else {
                        String errorMessage =
                                String.format(Locale.ENGLISH,
                                        errorText,
                                        EOL,
                                        responseCode,
                                        EOL,
                                        EOL,
                                        json,
                                        EOL);
                        return ResourceLoaderResult.onError(errorMessage);
                    }
                }
            } catch (Exception e) {
                return ResourceLoaderResult.onException(e);
            }
        }

        @Override
        public void deliverResult(ResourceLoaderResult<FloorsSummary> data) {
            super.deliverResult(data);
            Log.d("Floors Summary", data.toString());
        }

    }

// This loader inner class is used to fetch Duration rate of one month from FitBit cloud and update UI accordingly

    private static class FetchDurationData extends AsyncTaskLoader<ResourceLoaderResult<DurationSummary>> {
        String dateTime;
        FitbitValueSummary summary;
        public final String url;
        public final Activity contextActivity;
        public final Handler handler;
        public final Scope[] requiredScopes;

        public FetchDurationData(Activity context) {
            super(context);
            this.contextActivity = context;
            this.url = "https://api.fitbit.com/1/user/-/activities/minutesVeryActive/date/today/7d.json";
            this.handler = new Handler();
            this.requiredScopes = new Scope[]{Scope.activity};
        }

        @Override
        public ResourceLoaderResult<DurationSummary> loadInBackground() {
            try {
                APIUtils.validateToken(contextActivity, AuthenticationManager.getCurrentAccessToken(), requiredScopes);
                BasicHttpRequest request = AuthenticationManager
                        .createSignedRequest()
                        .setContentType(contentType)
                        .setUrl(url)
                        .build();

                final BasicHttpResponse response = request.execute();
                int responseCode = response.getStatusCode();
                final String json = response.getBodyAsString();
                if (response.isSuccessful()) {
                    final DurationSummary resource = new Gson().fromJson(json, DurationSummary.class);
                    for (int i = 0; i < resource.getActivities().size(); i++) {
                        summary = new FitbitValueSummary();
                        dateTime = resource.getActivities().get(i).getDate();
                        if (fitbitValues.get(dateTime) != null) {
                            summary = fitbitValues.get(dateTime);
                        }
                        if (resource.getActivities().get(i).getValue() != null) {
                            summary.setDuration(Double.parseDouble(resource.getActivities().get(i).getValue()));
                            fitbitValues.put(dateTime, summary);
                        }
                    }
                    return ResourceLoaderResult.onSuccess(resource);
                } else {
                    if (responseCode == 401) {
                        if (AuthenticationManager.getAuthenticationConfiguration().isLogoutOnAuthFailure()) {
                            // Token may have been revoked or expired
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    AuthenticationManager.logout(contextActivity);
                                }
                            });
                        }
                        return ResourceLoaderResult.onLoggedOut();
                    } else {
                        String errorMessage =
                                String.format(Locale.ENGLISH,
                                        errorText,
                                        EOL,
                                        responseCode,
                                        EOL,
                                        EOL,
                                        json,
                                        EOL);
                        return ResourceLoaderResult.onError(errorMessage);
                    }
                }
            } catch (Exception e) {
                return ResourceLoaderResult.onException(e);
            }
        }

        @Override
        public void deliverResult(ResourceLoaderResult<DurationSummary> data) {
            super.deliverResult(data);
            Log.d("Duration Summary", data.toString());
        }
    }

// This loader inner class is used to fetch Distance rate of one month from FitBit cloud and update UI accordingly

    private static class FetchDistanceData extends AsyncTaskLoader<ResourceLoaderResult<DistanceSummary>> {
        String dateTime;
        FitbitValueSummary summary;
        public final String url;
        public final Activity contextActivity;
        public final Handler handler;
        public final Scope[] requiredScopes;

        public FetchDistanceData(Activity context) {
            super(context);
            this.contextActivity = context;
            this.url = "https://api.fitbit.com/1/user/-/activities/distance/date/today/7d.json";
            this.handler = new Handler();
            this.requiredScopes = new Scope[]{Scope.activity};
        }

        @Override
        public ResourceLoaderResult<DistanceSummary> loadInBackground() {
            try {
                APIUtils.validateToken(contextActivity, AuthenticationManager.getCurrentAccessToken(), requiredScopes);
                BasicHttpRequest request = AuthenticationManager
                        .createSignedRequest()
                        .setContentType(contentType)
                        .setUrl(url)
                        .build();

                final BasicHttpResponse response = request.execute();
                int responseCode = response.getStatusCode();
                final String json = response.getBodyAsString();
                if (response.isSuccessful()) {
                    final DistanceSummary resource = new Gson().fromJson(json, DistanceSummary.class);
                    for (int i = 0; i < resource.getActivities().size(); i++) {
                        summary = new FitbitValueSummary();
                        dateTime = resource.getActivities().get(i).getDate();
                        if (fitbitValues.get(dateTime) != null) {
                            summary = fitbitValues.get(dateTime);
                        }
                        if (resource.getActivities().get(i).getValue() != null) {
                            summary.setDistance(Double.parseDouble(resource.getActivities().get(i).getValue()));
                            fitbitValues.put(dateTime, summary);
                        }
                    }
                    return ResourceLoaderResult.onSuccess(resource);
                } else {
                    if (responseCode == 401) {
                        if (AuthenticationManager.getAuthenticationConfiguration().isLogoutOnAuthFailure()) {
                            // Token may have been revoked or expired
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    AuthenticationManager.logout(contextActivity);
                                }
                            });
                        }
                        return ResourceLoaderResult.onLoggedOut();
                    } else {
                        String errorMessage =
                                String.format(Locale.ENGLISH,
                                        errorText,
                                        EOL,
                                        responseCode,
                                        EOL,
                                        EOL,
                                        json,
                                        EOL);
                        return ResourceLoaderResult.onError(errorMessage);
                    }
                }
            } catch (Exception e) {
                return ResourceLoaderResult.onException(e);
            }
        }

        @Override
        public void deliverResult(ResourceLoaderResult<DistanceSummary> data) {
            super.deliverResult(data);
            Log.d("Distance Summary", data.toString());
        }
    }

// This loader inner class is used to fetch Distance rate of one month from FitBit cloud and update UI accordingly

    private static class FetchSleepData extends AsyncTaskLoader<ResourceLoaderResult<SleepSummary>> {
        String dateTime;
        FitbitValueSummary summary;
        public final String url;
        public final Activity contextActivity;
        public final Handler handler;
        public final Scope[] requiredScopes;

        public FetchSleepData(Activity context) {
            super(context);
            this.contextActivity = context;
            this.url = "https://api.fitbit.com/1/user/-/sleep/date/" + minDateValue + "/" + displayDateValue + ".json";
            this.handler = new Handler();
            this.requiredScopes = new Scope[]{Scope.sleep};
        }

        @Override
        public ResourceLoaderResult<SleepSummary> loadInBackground() {
            try {
                APIUtils.validateToken(contextActivity, AuthenticationManager.getCurrentAccessToken(), requiredScopes);
                BasicHttpRequest request = AuthenticationManager
                        .createSignedRequest()
                        .setContentType(contentType)
                        .setUrl(url)
                        .build();

                final BasicHttpResponse response = request.execute();
                int responseCode = response.getStatusCode();
                final String json = response.getBodyAsString();
                if (response.isSuccessful()) {
                    final SleepSummary resource = new Gson().fromJson(json, SleepSummary.class);
                    if (resource != null) {
                        for (int i = 0; i < resource.getSleepPattern().size(); i++) {
                            summary = new FitbitValueSummary();
                            dateTime = resource.getSleepPattern().get(i).getDateOfSleep();
                            if (fitbitValues.get(dateTime) != null) {
                                summary = fitbitValues.get(dateTime);
                            }
                            if (resource.getSleepPattern().get(i).getTotalSleepRecords() != null) {
                                summary.setSleep(Integer.parseInt(String.valueOf(resource.getSleepPattern().get(i).getTotalSleepRecords())));
                                summary.setAwakeCount(String.valueOf(resource.getSleepPattern().get(i).getAwakeningsCount()));
                                summary.setResttLessCount(String.valueOf(resource.getSleepPattern().get(i).getRestlessCount()));
                                fitbitValues.put(dateTime, summary);
                            }
                        }

                    }
                    return ResourceLoaderResult.onSuccess(resource);

                } else {
                    if (responseCode == 401) {
                        if (AuthenticationManager.getAuthenticationConfiguration().isLogoutOnAuthFailure()) {
                            // Token may have been revoked or expired
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    AuthenticationManager.logout(contextActivity);
                                }
                            });
                        }
                        return ResourceLoaderResult.onLoggedOut();
                    } else {
                        String errorMessage =
                                String.format(Locale.ENGLISH,
                                        "Error making request:%s\tHTTP Code:%d%s\tResponse Body:%s%s%s%n",
                                        EOL,
                                        responseCode,
                                        EOL,
                                        EOL,
                                        json,
                                        EOL);
                        return ResourceLoaderResult.onError(errorMessage);
                    }
                }
            } catch (Exception e) {
                return ResourceLoaderResult.onException(e);
            }
        }

        @Override
        public void deliverResult(ResourceLoaderResult<SleepSummary> data) {
            super.deliverResult(data);
            Log.d("Sleep Summary", data.toString());
        }
    }

    private void setClickableStatus() {
        if (displayDate.after(minDate)) {
            btnBackward.setEnabled(true);
            btnBackward.setClickable(true);
            btnBackward.setVisibility(View.VISIBLE);

        } else if (!displayDate.after(minDate)) {
            btnBackward.setEnabled(false);
            btnBackward.setClickable(false);
            btnBackward.setVisibility(View.GONE);
        }
        if (displayDate.before(maxDate)) {
            btnForward.setEnabled(true);
            btnForward.setClickable(true);
            btnForward.setVisibility(View.VISIBLE);
        } else if (!displayDate.before(maxDate)) {
            btnForward.setEnabled(false);
            btnForward.setClickable(false);
            btnForward.setVisibility(View.GONE);
        }
        if (displayDate.equals(maxDate)) {
            btnForward.setEnabled(false);
            btnForward.setClickable(false);
            btnForward.setVisibility(View.GONE);
        }
        if (displayDate.equals(minDate)) {
            btnBackward.setEnabled(false);
            btnBackward.setClickable(false);
            btnBackward.setVisibility(View.GONE);
        }
    }

    public double convertKmsToMiles(double kms, int decimalPlaces) {
        double miles = 0.621371 * kms;

        long factor = (long) Math.pow(10, decimalPlaces);
        miles = miles * factor;
        long tmp = Math.round(miles);
        return (double) tmp / factor;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }
}
