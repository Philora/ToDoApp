package com.wps.memberapp.presentation.healthtracker.fragment;


import com.wps.memberapp.presentation.base.MvpPresenter;

public interface HealthTrackerPresenter extends MvpPresenter {
    void getStepsData();
    void getHeartData();
    void getSleepData();
    void getGoalsData();
}
