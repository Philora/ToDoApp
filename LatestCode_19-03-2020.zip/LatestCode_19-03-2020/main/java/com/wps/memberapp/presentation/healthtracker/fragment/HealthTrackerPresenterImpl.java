package com.wps.memberapp.presentation.healthtracker.fragment;


import com.wps.memberapp.presentation.base.MvpView;

public class HealthTrackerPresenterImpl implements HealthTrackerPresenter {
    private MvpView view;

    @Override
    public void onAttach(MvpView view) {
        this.view=view;
    }

    @Override
    public void onDetach() {
        view=null;
    }

    @Override
    public void getStepsData() {
        //Load steps data
    }

    @Override
    public void getHeartData() {
        //Load heart data
    }

    @Override
    public void getSleepData() {
        //Load sleep data
    }

    @Override
    public void getGoalsData() {
        //Load goals data
    }
}
