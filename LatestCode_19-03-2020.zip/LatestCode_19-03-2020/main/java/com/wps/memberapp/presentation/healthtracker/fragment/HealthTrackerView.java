package com.wps.memberapp.presentation.healthtracker.fragment;


import com.wps.memberapp.presentation.base.MvpView;

public interface HealthTrackerView extends MvpView {
    void onStepsDataLoadingCompleted();
    void onHeartDataLoadingCompleted();
    void onSleepDataLoadingCompleted();
    void onGoalsDataLoadingCompleted();
}
