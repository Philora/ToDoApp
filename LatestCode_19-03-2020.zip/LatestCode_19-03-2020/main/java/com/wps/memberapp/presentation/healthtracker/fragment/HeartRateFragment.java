package com.wps.memberapp.presentation.healthtracker.fragment;


import android.app.Activity;
import android.app.Fragment;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.LimitLine;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.formatter.IFillFormatter;
import com.github.mikephil.charting.formatter.LargeValueFormatter;
import com.github.mikephil.charting.interfaces.dataprovider.LineDataProvider;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.wps.memberapp.R;
import com.wps.memberapp.data.models.FitbitValueSummary;
import com.wps.memberapp.presentation.healthtracker.adapter.HealthTrackerGridViewAdapter;
import com.wps.memberapp.utility.CustomScrollView;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;


public class HeartRateFragment extends Fragment implements View.OnClickListener {

    @BindView(R.id.btnBackwardHeart) ImageView btnBackward;
    @BindView(R.id.btnForwardHeart) ImageView btnForward;
    @BindView(R.id.pieChartHeartCount) PieChart pieChart;
    @BindView(R.id.barChartlinearLayout) LinearLayout mChartView;
    @BindView(R.id.totalHeartCount) TextView totalHeartCount;
    @BindView(R.id.heartLabelDefault) TextView heartLabelDefault;
    @BindView(R.id.heartValueDefault) TextView heartValueDefault;
    @BindView(R.id.dateHeartValue) TextView dateHeartValue;
    @BindView(R.id.minCardioValue) TextView minCardioValue;
    @BindView(R.id.maxCardioValue) TextView maxCardioValue;
    @BindView(R.id.heartRateValue) TextView heartValue;
    @BindView(R.id.minFatBurnValue) TextView minFatBurnValue;
    @BindView(R.id.maxFatBurnValue) TextView maxFatBurnValue;
    @BindView(R.id.minPeakValue) TextView minPeakValue;
    @BindView(R.id.maxPeakValue) TextView maxPeakValue;
    @BindView(R.id.monHeartLabel) TextView monheartLabel;
    @BindView(R.id.monHeartValue) TextView monHeartValue;
    @BindView(R.id.tueHeartLabel) TextView tueHeartLabel;
    @BindView(R.id.tueHeartValue) TextView tueHeartValue;
    @BindView(R.id.wedHeartLabel) TextView wedHeartLabel;
    @BindView(R.id.wedHeartValue) TextView wedHeartValue;
    @BindView(R.id.thurHeartLabel) TextView thurHeartLabel;
    @BindView(R.id.thurHeartValue) TextView thurHeartValue;
    @BindView(R.id.FriHeartLabel) TextView friHeartLabel;
    @BindView(R.id.FriHeartValue) TextView friHeartValue;
    @BindView(R.id.satHeartLabel) TextView satHeartLabel;
    @BindView(R.id.satHeartValue) TextView satHeartValue;
    @BindView(R.id.headingHeartTxt) TextView headingTxtLabel;
    @BindView(R.id.dayStepGridView) GridView daysGridView;
    @BindView(R.id.scrollViewHeart)
    CustomScrollView scrollView;
    private LineChart mChart;
    private LinkedHashMap<String, FitbitValueSummary> mMap;
    private Date displayDate;
    private String displayDateValue;
    private String mHeartValue;
    private FitbitValueSummary fitbitValueSummary;
    private int sum = 0;
    private Date minDate;
    private int count = 0;
    private Date maxDate;
    private final String bpmResting=" bpm resting";
    private final String dateFormat="yyyy-MM-dd";
    private final String dateFormat1="EEE, MMM dd, ''yy";
    private final String space="-- --";
    private Unbinder unbinder;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SimpleDateFormat formatter = new SimpleDateFormat(dateFormat, Locale.US);

        //getting current date
        displayDate = Calendar.getInstance().getTime();

        //formatting current date
        displayDateValue = formatter.format(displayDate);
        try {
            displayDate = formatter.parse(displayDateValue);
        } catch (ParseException e) {
            Logger.e("Heart", e);
        }
        Log.i("Heartfr", "" + displayDate);

        //getting max date
        maxDate = displayDate;


        //getting min date
        try {
            Date d = formatter.parse(displayDateValue);
            minDate = new Date(d.getTime() - 6 * 24 * 3600 * 1000);
            //formatting min date
            String minDateValue = formatter.format(minDate);
            minDate = formatter.parse(minDateValue);
            Log.i("Heart", "" + minDate);
        } catch (ParseException pe) {
            pe.getMessage();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        View rootView = inflater.inflate(R.layout.frag_heart_rate, container, false);
        unbinder= ButterKnife.bind(this,rootView);
        scrollView.scrollTo(0, 100);
        btnBackward.setOnClickListener(this);
        btnForward.setOnClickListener(this);
        setDate(dateHeartValue);
        setClickableStatus();
        mMap = new LinkedHashMap<>();
        Bundle b = this.getArguments();
        if (b.getSerializable("FitbitValues") != null) {
            mMap = (LinkedHashMap<String, FitbitValueSummary>) b.getSerializable("FitbitValues");
            if (mMap != null && mMap.size() > 0) {
                fitbitValueSummary = mMap.get(displayDateValue);
                if (fitbitValueSummary != null && fitbitValueSummary.getMin() != null &&
                        !fitbitValueSummary.getMin().equals("null") && !fitbitValueSummary.getMin().isEmpty()) {
                    minFatBurnValue.setText(fitbitValueSummary.getMin());
                }
                if (fitbitValueSummary != null && fitbitValueSummary.getMax() != null
                        && !fitbitValueSummary.getMax().equals("null") && !fitbitValueSummary.getMax().isEmpty()) {
                    maxFatBurnValue.setText(fitbitValueSummary.getMax());
                }
                if (fitbitValueSummary != null && fitbitValueSummary.getCardioMin() != null
                        && !fitbitValueSummary.getCardioMin().equals("null")
                        && !fitbitValueSummary.getCardioMin().isEmpty()) {
                    minCardioValue.setText(fitbitValueSummary.getCardioMin());
                }

                if (fitbitValueSummary != null && fitbitValueSummary.getCardioMax() != null
                        && !fitbitValueSummary.getCardioMax().equals("null")
                        && !fitbitValueSummary.getCardioMax().isEmpty()) {
                    maxCardioValue.setText(fitbitValueSummary.getCardioMax());
                }

                if (fitbitValueSummary != null && fitbitValueSummary.getCardioMax() != null
                        && !fitbitValueSummary.getCardioMax().equals("null")
                        && !fitbitValueSummary.getCardioMax().isEmpty()) {
                    maxCardioValue.setText(fitbitValueSummary.getCardioMax());
                }
                if ((fitbitValueSummary != null && fitbitValueSummary.getPeakMin() != null
                        && !fitbitValueSummary.getPeakMin().equals("null")
                        && !fitbitValueSummary.getPeakMin().isEmpty())) {
                    minPeakValue.setText(fitbitValueSummary.getPeakMin());
                }
                if ((fitbitValueSummary != null && fitbitValueSummary.getPeakMax() != null
                        && !fitbitValueSummary.getPeakMax().equals("null")
                        && !fitbitValueSummary.getPeakMax().isEmpty())) {
                    minPeakValue.setText(fitbitValueSummary.getPeakMax());
                }

            }
        }

        headingTxtLabel.setText("This Week");
        SimpleDateFormat outFormat = new SimpleDateFormat("EEEE",Locale.US);
        String dayValue = outFormat.format(displayDate);
        heartLabelDefault.setText(dayValue);
        if (fitbitValueSummary != null) {
            if (fitbitValueSummary.getHeart_rate() != null ) {
                heartValue.setText(String.valueOf(fitbitValueSummary.getHeart_rate() + " " + bpmResting));
                mHeartValue = String.valueOf(fitbitValueSummary.getHeart_rate());
            } else {
                heartValue.setText(space);
            }
        }
        getPieChartResults();
        mChart = getLineChartResults();
        mChartView.removeAllViews();
        mChartView.addView(mChart, new RecyclerView.LayoutParams
                (RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.MATCH_PARENT));
        daysGridView.setAdapter(new HealthTrackerGridViewAdapter(getActivity(), getActivity().getResources().getStringArray(R.array.days)));
        return rootView;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        Toolbar toolbar = activity.findViewById(R.id.toolbarFitbit);
        toolbar.setBackgroundColor(getResources().getColor(R.color.accentBright));
    }

 // Used to plot vertical bar chart for step count and plot it using Vertical bar Chart through MP Android chart library

    private LineChart getLineChartResults() {

        mChart = new LineChart(getActivity());
        ArrayList<String> xVals = new ArrayList<>();
        ArrayList<Entry> yVals = new ArrayList<>();

        mChart.setDrawGridBackground(false);

        // no description text
        mChart.getDescription().setEnabled(false);

        // enable touch gestures
        mChart.setTouchEnabled(true);

        // enable scaling and dragging
        mChart.setDragEnabled(true);
        mChart.setScaleEnabled(true);

        // if disabled, scaling can be done on x- and y-axis separately
        mChart.setPinchZoom(true);

        // x-axis limit line
        LimitLine llXAxis = new LimitLine(10f, "Index 10");
        llXAxis.setLineWidth(4f);
        llXAxis.enableDashedLine(10f, 10f, 0f);
        llXAxis.setLabelPosition(LimitLine.LimitLabelPosition.RIGHT_BOTTOM);
        llXAxis.setTextSize(10f);

        XAxis xAxis = mChart.getXAxis();
        xAxis.enableGridDashedLine(10f, 10f, 0f);

        YAxis leftAxis = mChart.getAxisLeft();
        leftAxis.setValueFormatter(new IAxisValueFormatter() {
            @Override
            public String getFormattedValue(float value, AxisBase axis) {
                return String.valueOf((int) Math.floor(value));
            }
        });
        leftAxis.removeAllLimitLines();

        leftAxis.enableGridDashedLine(10f, 10f, 0f);
        leftAxis.setDrawZeroLine(false);

        // limit lines are drawn behind data (and not on top)
        leftAxis.setDrawLimitLinesBehindData(true);

        mChart.getAxisRight().setEnabled(false);

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",Locale.US);

        SimpleDateFormat outFormat = new SimpleDateFormat("EEEE",Locale.US);
        String dayValue1 = outFormat.format(displayDate);

        if (mMap != null && mMap.size() > 0) {

            fitbitValueSummary = mMap.get(displayDateValue);
            if (fitbitValueSummary != null) {
                if (fitbitValueSummary.getHeart_rate() != null ) {
                    yVals.add(new Entry(1, Float.parseFloat(String.valueOf(fitbitValueSummary.getHeart_rate()))));
                    xVals.add(displayDateValue);
                    count++;
                    sum += fitbitValueSummary.getHeart_rate();
                    heartValue.setText(fitbitValueSummary.getHeart_rate() + " " + bpmResting);
                    heartValueDefault.setText(fitbitValueSummary.getHeart_rate() + " " + bpmResting);
                }
                heartLabelDefault.setText(dayValue1);

                try {
                    Date d = formatter.parse(displayDateValue);
                    Date displayDateForMon = new Date(d.getTime() - 24 * 3600 * 1000);
                    String displayDateValueForMon = formatter.format(displayDateForMon);
                    String dayValue2 = outFormat.format(displayDateForMon);

                    fitbitValueSummary = mMap.get(displayDateValueForMon);
                    if (fitbitValueSummary.getHeart_rate() != null) {
                        yVals.add(new Entry(2, Float.parseFloat(String.valueOf(fitbitValueSummary.getHeart_rate()))));
                        xVals.add(dayValue2);
                        count++;
                        sum += fitbitValueSummary.getHeart_rate();
                        monHeartValue.setText(fitbitValueSummary.getHeart_rate() + " " + bpmResting);
                    }
                    monheartLabel.setText(dayValue2);

                    Date d2 = formatter.parse(displayDateValueForMon);
                    Date displayDateForTue = new Date(d2.getTime() - 24 * 3600 * 1000);
                    String displayDateValueForTue = formatter.format(displayDateForTue);
                    String dayValue3 = outFormat.format(displayDateForTue);

                    fitbitValueSummary = mMap.get(displayDateValueForTue);

                    if (fitbitValueSummary.getHeart_rate() != null ) {
                        yVals.add(new Entry(3, Float.parseFloat(String.valueOf(fitbitValueSummary.getHeart_rate()))));
                        xVals.add(dayValue3);
                        count++;
                        sum += fitbitValueSummary.getHeart_rate();
                        tueHeartValue.setText(fitbitValueSummary.getHeart_rate() + " " + bpmResting);
                    }
                    tueHeartLabel.setText(dayValue3);

                    Date d3 = formatter.parse(displayDateValueForTue);
                    Date displayDateForWed = new Date(d3.getTime() - 24 * 3600 * 1000);
                    String displayDateValueForWed = formatter.format(displayDateForWed);

                    String dayValue4 = outFormat.format(displayDateForWed);

                    fitbitValueSummary = mMap.get(displayDateValueForWed);

                    if (fitbitValueSummary.getHeart_rate() != null) {
                        yVals.add(new Entry(4, Float.parseFloat(String.valueOf(fitbitValueSummary.getHeart_rate()))));
                        xVals.add(dayValue4);
                        count++;
                        sum += fitbitValueSummary.getHeart_rate();
                        wedHeartValue.setText(fitbitValueSummary.getHeart_rate() + " " + bpmResting);
                    }
                    wedHeartLabel.setText(dayValue4);

                    Date d4 = formatter.parse(displayDateValueForWed);
                    Date displayDateForThur = new Date(d4.getTime() - 24 * 3600 * 1000);
                    String displayDateValueForThur = formatter.format(displayDateForThur);

                    String dayValue5 = outFormat.format(displayDateForThur);
                    fitbitValueSummary = mMap.get(displayDateValueForThur);


                    if (fitbitValueSummary.getHeart_rate() != null) {
                        yVals.add(new Entry(5, Float.parseFloat(String.valueOf(fitbitValueSummary.getHeart_rate()))));
                        xVals.add(dayValue5);
                        count++;
                        sum += fitbitValueSummary.getHeart_rate();
                        thurHeartValue.setText(fitbitValueSummary.getHeart_rate() + " " + bpmResting);
                    }

                    thurHeartLabel.setText(dayValue5);

                    Date d5 = formatter.parse(displayDateValueForThur);
                    Date displayDateForFri = new Date(d5.getTime() - 24 * 3600 * 1000);
                    String displayDateValueForFri = formatter.format(displayDateForFri);

                    String dayValue6 = outFormat.format(displayDateForFri);
                    fitbitValueSummary = mMap.get(displayDateValueForFri);


                    if (fitbitValueSummary.getHeart_rate() != null) {
                        yVals.add(new Entry(6, Float.parseFloat(String.valueOf(fitbitValueSummary.getHeart_rate()))));
                        xVals.add(dayValue6);
                        count++;
                        sum += fitbitValueSummary.getHeart_rate();
                        friHeartValue.setText(fitbitValueSummary.getHeart_rate() + " " + "bpm resting");
                    }
                    friHeartLabel.setText(dayValue6);

                    Date d6 = formatter.parse(displayDateValueForFri);
                    Date displayDateForSat = new Date(d6.getTime() - 24 * 3600 * 1000);
                    String displayDateValueForSat = formatter.format(displayDateForFri);


                    String dayValue7 = outFormat.format(displayDateForSat);
                    fitbitValueSummary = mMap.get(displayDateValueForSat);

                    if (fitbitValueSummary.getHeart_rate() != null) {
                        yVals.add(new Entry(7, Float.parseFloat(String.valueOf(fitbitValueSummary.getHeart_rate()))));
                        xVals.add(dayValue7);
                        count++;
                        sum += fitbitValueSummary.getHeart_rate();
                        satHeartValue.setText(fitbitValueSummary.getHeart_rate() + " " + "bpm resting");
                    }
                    satHeartLabel.setText(dayValue7);
                    if (count > 0) {
                        int average = sum / count;
                        totalHeartCount.setText(average + " " + "BPM resting/Average");
                    }

                } catch (ParseException pe) {
                    pe.getMessage();
                }
                LineDataSet set1;

                if (mChart.getData() != null && mChart.getData().getDataSetCount() > 0) {
                    set1 = (LineDataSet) mChart.getData().getDataSetByIndex(1);
                    if (!yVals.isEmpty()) {
                        set1.setValues(yVals);
                        mChart.getData().notifyDataChanged();
                        mChart.notifyDataSetChanged();
                    }
                } else {
                    if (!yVals.isEmpty()) {
                        set1 = new LineDataSet(yVals, "");
                        set1.setColor(getResources().getColor(R.color.accentBright));
                        set1.setCircleColor(Color.WHITE);
                        set1.setLineWidth(2f);
                        set1.setMode(LineDataSet.Mode.HORIZONTAL_BEZIER);
                        set1.setCubicIntensity(0.1f);
                        set1.setDrawFilled(true);
                        set1.setDrawCircles(false);
                        set1.setLineWidth(1.8f);
                        mChart.getLegend().setEnabled(false);
                        mChart.setTouchEnabled(false);
                        set1.setCircleRadius(4f);
                        set1.setCircleColor(getResources().getColor(R.color.accentBright));
                        set1.setColor(getResources().getColor(R.color.accentBright));
                        set1.setFillColor(getResources().getColor(R.color.accentBright));
                        set1.setFillAlpha(100);
                        set1.setDrawHorizontalHighlightIndicator(false);
                        set1.setFillFormatter(new IFillFormatter() {
                            @Override
                            public float getFillLinePosition(ILineDataSet dataSet, LineDataProvider dataProvider) {
                                return -10;
                            }
                        });
                        set1.setVisible(true);
                        ArrayList<ILineDataSet> dataSets = new ArrayList<>();
                        dataSets.add(set1);
                        LineData data = new LineData(dataSets);
                        data.setValueFormatter(new LargeValueFormatter());
                        data.addDataSet(set1);
                        mChart.setData(data);
                    }
                }
            }
        }
        return mChart;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnBackwardHeart:
                SimpleDateFormat formatter = new SimpleDateFormat(dateFormat,Locale.US);
                try {
                    Date d = formatter.parse(displayDateValue);
                    displayDate = new Date(d.getTime() - 24 * 3600 * 1000);
                    displayDateValue = formatter.format(displayDate);
                } catch (ParseException pe) {
                    pe.getMessage();
                }

                SimpleDateFormat labelFormatterBackward = new SimpleDateFormat(dateFormat1,Locale.US);
                String labelTextBackward = labelFormatterBackward.format(displayDate);
                dateHeartValue.setText(labelTextBackward.substring(0, 11));
                setClickableStatus();

                fitbitValueSummary = new FitbitValueSummary();
                if (mMap != null && mMap.size() > 0) {
                    fitbitValueSummary = mMap.get(displayDateValue);
                    if (fitbitValueSummary != null) {

                        if (fitbitValueSummary.getHeart_rate() != null) {
                            heartValue.setText(String.valueOf(fitbitValueSummary.getHeart_rate() + " " + bpmResting));
                            mHeartValue = String.valueOf(fitbitValueSummary.getHeart_rate());
                            getPieChartResults();
                        } else {
                            heartValue.setText(space);
                        }

                        minFatBurnValue.setText(fitbitValueSummary.getMin());
                        maxFatBurnValue.setText(fitbitValueSummary.getMax());
                        minCardioValue.setText(fitbitValueSummary.getCardioMin());
                        maxCardioValue.setText(fitbitValueSummary.getCardioMax());
                        maxPeakValue.setText(fitbitValueSummary.getPeakMax());
                        minPeakValue.setText(fitbitValueSummary.getPeakMin());

                    }
                }


                break;

            case R.id.btnForwardHeart:

                SimpleDateFormat formatterForward = new SimpleDateFormat(dateFormat,Locale.US);
                try {
                    Date d = formatterForward.parse(displayDateValue);
                    displayDate = new Date(d.getTime() + 24 * 3600 * 1000);
                    displayDateValue = formatterForward.format(displayDate);
                } catch (ParseException pe) {
                    pe.getMessage();
                }
                SimpleDateFormat labelFormatterForward = new SimpleDateFormat(dateFormat1,Locale.US);
                String labelTextForward = labelFormatterForward.format(displayDate);
                dateHeartValue.setText(labelTextForward.substring(0, 11));
                setClickableStatus();

                fitbitValueSummary = new FitbitValueSummary();
                if (mMap != null && mMap.size() > 0) {
                    fitbitValueSummary = mMap.get(displayDateValue);
                    if (fitbitValueSummary != null) {

                        if (fitbitValueSummary.getHeart_rate() != null) {
                            heartValue.setText(String.valueOf(fitbitValueSummary.getHeart_rate() + " " + bpmResting));
                            mHeartValue = String.valueOf(fitbitValueSummary.getHeart_rate());
                            getPieChartResults();
                        } else {
                            heartValue.setText(space);
                        }

                        minFatBurnValue.setText(fitbitValueSummary.getMin());
                        maxFatBurnValue.setText(fitbitValueSummary.getMax());
                        minCardioValue.setText(fitbitValueSummary.getCardioMin());
                        maxCardioValue.setText(fitbitValueSummary.getCardioMax());
                        maxPeakValue.setText(fitbitValueSummary.getPeakMax());
                        minPeakValue.setText(fitbitValueSummary.getPeakMin());
                    }
                }

                break;
            default:
                break;
        }

    }

    private void getPieChartResults() {

        final int[] myColors = {Color.rgb(255, 255, 255), Color.rgb(138, 219, 124)};

        ArrayList<PieEntry> yvalues = new ArrayList<>();
        if (mMap != null && mMap.size() > 0 && mMap.get(displayDateValue) != null) {
            mHeartValue = String.valueOf(mMap.get(displayDateValue).getHeart_rate());
            if (mHeartValue != null && !mHeartValue.equals("null")) {
                float f1 = (float) Double.parseDouble(mHeartValue);
                float f2 = (float) Double.parseDouble(mHeartValue);
                float f3 = f1 - f2;
                yvalues.add(new PieEntry((f2)));
                yvalues.add(new PieEntry((f3)));
            }
            PieDataSet dataSet = new PieDataSet(yvalues, "");
            dataSet.setSliceSpace(3f);
            dataSet.setDrawValues(false);

            ArrayList<Integer> colors = new ArrayList<>();
            for (int c : myColors) colors.add(c);
            dataSet.setColors(colors);

            PieData data = new PieData(dataSet);
            pieChart.setData(data);
            pieChart.setDrawHoleEnabled(true);
            pieChart.setHoleColor(Color.argb(0, 0, 0, 0));
            pieChart.setCenterTextSize(60);
            pieChart.setTransparentCircleAlpha(50);
            pieChart.setHoleRadius(95f);
            pieChart.getDescription().setEnabled(false);
            pieChart.setDrawCenterText(true);
            pieChart.getLegend().setEnabled(false);
            pieChart.spin(1000, pieChart.getRotationAngle(), pieChart.getRotationAngle()
                    + 360, Easing.EasingOption
                    .EaseInCubic);
            pieChart.invalidate();
        }
    }

    private void setClickableStatus() {
        if (displayDate.after(minDate)) {
            btnBackward.setEnabled(true);
            btnBackward.setClickable(true);
            btnBackward.setVisibility(View.VISIBLE);
        } else if (!displayDate.after(minDate)) {
            btnBackward.setEnabled(false);
            btnBackward.setClickable(false);
            btnBackward.setVisibility(View.GONE);
        }
        if (displayDate.before(maxDate)) {
            btnForward.setEnabled(true);
            btnForward.setClickable(true);
            btnForward.setVisibility(View.VISIBLE);
        } else if (!displayDate.before(maxDate)) {
            btnForward.setEnabled(false);
            btnForward.setClickable(false);
            btnForward.setVisibility(View.GONE);
        }
        if (displayDate.equals(maxDate)) {
            btnForward.setEnabled(false);
            btnForward.setClickable(false);
            btnForward.setVisibility(View.GONE);
        }
        if (displayDate.equals(minDate)) {
            btnBackward.setEnabled(false);
            btnBackward.setClickable(false);
            btnBackward.setVisibility(View.GONE);
        }
    }

    private void setDate(TextView view) {
        Date today = Calendar.getInstance().getTime();//getting date
        SimpleDateFormat formatter = new SimpleDateFormat(dateFormat1,Locale.US);
        String date = formatter.format(today);
        view.setText(date.substring(0, 11));
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }
}

