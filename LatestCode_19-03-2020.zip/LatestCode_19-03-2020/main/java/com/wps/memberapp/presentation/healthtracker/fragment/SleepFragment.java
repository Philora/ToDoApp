package com.wps.memberapp.presentation.healthtracker.fragment;


import android.app.Activity;
import android.app.Fragment;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.formatter.LargeValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.wps.memberapp.R;
import com.wps.memberapp.data.models.FitbitValueSummary;
import com.wps.memberapp.presentation.healthtracker.adapter.HealthTrackerGridViewAdapter;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;


/* Created by 133580 on 3/12/2018.*/




public class SleepFragment extends Fragment implements View.OnClickListener {
    LinkedHashMap<String, FitbitValueSummary> mMap;
    private final int[] myColorsChart = {Color.rgb(157, 211, 244), Color.rgb(0, 41, 78)};
    private Date displayDate;
    private String displayDateValue;
    BarChart mChart;
    PieChart pieChart;
    LinearLayout mChartView;
    String mSleepValue;
    private ImageView btnBackward;
    private ImageView btnForward;
    FitbitValueSummary fitbitValueSummary;
    int sum = 0;
    int count = 0;
    private Date minDate;
    private Date maxDate;
    TextView sleepTxtValue;
    TextView totalSleepCount;
    TextView goalValue;
    private TextView sleepLabelDefault;
    private TextView sleepValueDefault;
    TextView monSleepLabel;
    TextView monSleepValue;
    TextView tueSleepLabel;
    TextView tueSleepValue;
    TextView wedSleepLabel;
    TextView wedSleepValue;
    TextView thruSleepValue;
    TextView thruSleepLabel;
    TextView friSleepValue;
    TextView friSleepLabel;
    TextView satSleepLabel;
    TextView satSleepValue;
    TextView headingTxtLabel;
    TextView dateSleepLabel;
    TextView awakeCount;
    TextView restLessCount;
    private String mins = " mins";
    private String space = "-- --";
    private String dateFormat = "yyyy-MM-dd";
    private String dateFormat1 = "EEE, MMM dd, ''yy";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
        //getting current date
        Date todaysDate = Calendar.getInstance().getTime();
        displayDate = todaysDate;

        //formatting current date
        displayDateValue = formatter.format(displayDate);
        try {
            displayDate = formatter.parse(displayDateValue);
        } catch (ParseException e) {
            Logger.e("ParseException", e);
        }
        Log.i("ddate", "" + displayDate);
        //getting max date
        maxDate = displayDate;
        //getting min date
        try {
            Date d = formatter.parse(displayDateValue);
            minDate = new Date(d.getTime() - 6 * 24 * 3600 * 1000);
            //formatting min date
            String minDateValue = formatter.format(minDate);
            minDate = formatter.parse(minDateValue);
            Log.i("mdate", "" + minDate);
        } catch (ParseException pe) {
            pe.getMessage();
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        View rootView = inflater.inflate(R.layout.frag_sleep, container, false);
        mChartView = (LinearLayout) rootView.findViewById(R.id.barChartSleeplinearLayout);
        pieChart = (PieChart) rootView.findViewById(R.id.pieChartSleepCount);
        sleepTxtValue = (TextView) rootView.findViewById(R.id.SleepValue);
        dateSleepLabel = (TextView) rootView.findViewById(R.id.dateSleepValue);
        totalSleepCount = (TextView) rootView.findViewById(R.id.totalSleepCount);
        goalValue = (TextView) rootView.findViewById(R.id.goalValue);
        monSleepLabel = (TextView) rootView.findViewById(R.id.monSleepLabel);
        monSleepValue = (TextView) rootView.findViewById(R.id.monSleepValue);
        tueSleepLabel = (TextView) rootView.findViewById(R.id.tueSleepLabel);
        tueSleepValue = (TextView) rootView.findViewById(R.id.tueSleepValue);
        wedSleepLabel = (TextView) rootView.findViewById(R.id.wedSleepLabel);
        wedSleepValue = (TextView) rootView.findViewById(R.id.wedSleepValue);
        thruSleepLabel = (TextView) rootView.findViewById(R.id.thurSleepLabel);
        thruSleepValue = (TextView) rootView.findViewById(R.id.thurSleepValue);
        friSleepLabel = (TextView) rootView.findViewById(R.id.FriSleepLabel);
        friSleepValue = (TextView) rootView.findViewById(R.id.FriSleepValue);
        satSleepLabel = (TextView) rootView.findViewById(R.id.satSleepLabel);
        satSleepValue = (TextView) rootView.findViewById(R.id.satSleepValue);
        headingTxtLabel = (TextView) rootView.findViewById(R.id.headingSleepTxt);
        totalSleepCount = (TextView) rootView.findViewById(R.id.totalSleepCount);
        btnBackward = (ImageView) rootView.findViewById(R.id.btnBackwardSleep);
        btnForward = (ImageView) rootView.findViewById(R.id.btnForwardSleep);
        GridView daysGridView = (GridView) rootView.findViewById(R.id.daySleepGridView);
        ScrollView scrollView = (ScrollView) rootView.findViewById(R.id.scrollViewSleep);
        sleepValueDefault = (TextView) rootView.findViewById(R.id.sleepValueDefault);
        sleepLabelDefault = (TextView) rootView.findViewById(R.id.sleepLabelDefault);
        awakeCount = (TextView) rootView.findViewById(R.id.awakeCountValue);
        restLessCount = (TextView) rootView.findViewById(R.id.restLessCountValue);
        scrollView.scrollTo(0, 100);
        btnBackward.setOnClickListener(this);
        btnForward.setOnClickListener(this);
        setDate(dateSleepLabel);
        setClickableStatus();
        mMap = new LinkedHashMap<>();
        Bundle b = this.getArguments();
        if (b.getSerializable("FitbitValues") != null) {
            mMap = (LinkedHashMap<String, FitbitValueSummary>) b.getSerializable("FitbitValues");
            if (mMap != null && mMap.size() > 0) {
                fitbitValueSummary = mMap.get(displayDateValue);
            }
        }
        headingTxtLabel.setText("This Week");
        SimpleDateFormat outFormat = new SimpleDateFormat("EEEE");
        String dayValue = outFormat.format(displayDate);

        sleepLabelDefault.setText(dayValue);
        if (fitbitValueSummary != null) {
            if (fitbitValueSummary.getSleep() != null && !fitbitValueSummary.getSleep().equals("null")
                    && fitbitValueSummary.getAwakeCount() != null && !fitbitValueSummary.getAwakeCount().equals("null")
                    && fitbitValueSummary.getResttLessCount() != null && !fitbitValueSummary.getResttLessCount().equals("null")) {
                Integer sleep = Integer.parseInt(String.valueOf(fitbitValueSummary.getSleep()));
                int hours = sleep / 60;
                Integer minutes = sleep % 60;
                sleepTxtValue.setText(hours + " hr" + " " + minutes + mins);
                awakeCount.setText(fitbitValueSummary.getAwakeCount());
                restLessCount.setText(fitbitValueSummary.getResttLessCount());
            } else {
                sleepTxtValue.setText(space);
                awakeCount.setText(space);
                restLessCount.setText(space);
            }
        }
        getPieChartResults();
        mChart = getBarChartResults();
        mChartView.removeAllViews();
        mChartView.addView(mChart, new RecyclerView.LayoutParams
                (RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.MATCH_PARENT));
        daysGridView.setAdapter(new HealthTrackerGridViewAdapter(getActivity(), getActivity().getResources().getStringArray(R.array.days)));
        return rootView;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        Toolbar toolbar = (Toolbar) activity.findViewById(R.id.toolbarFitbit);
        toolbar.setBackgroundColor(getResources().getColor(R.color.blue));
    }

/* Used to plot vertical bar chart for step count and plot it using Vertical bar Chart through MP Android chart library*/
    private BarChart getBarChartResults() {

        mChart = new BarChart(getActivity());
        ArrayList<BarEntry> yVals = new ArrayList<>();
        ArrayList<String> xVals = new ArrayList<>();

        mChart.getDescription().setEnabled(false);
        // scaling can now only be done on x- and y-axis separately
        mChart.setPinchZoom(false);
        mChart.setDrawGridBackground(false);
        mChart.setDrawBarShadow(false);
        mChart.setDrawValueAboveBar(false);
        mChart.setHighlightFullBarEnabled(false);

        // Change the position of the y-labels
        YAxis leftAxis = mChart.getAxisRight();
        leftAxis.setDrawGridLines(false);
        leftAxis.setEnabled(false);
        mChart.getAxisRight().setEnabled(false);
        leftAxis.setValueFormatter(new IAxisValueFormatter() {
            @Override
            public String getFormattedValue(float value, AxisBase axis) {
                return String.valueOf((int) Math.floor(value) + " " + "hr");
            }
        });
        leftAxis.setLabelCount(7);
        leftAxis.setAxisMaximum(8);
        leftAxis.setAxisMinimum(0);

        SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);

        SimpleDateFormat outFormat = new SimpleDateFormat("EEEE");
        String dayValue1 = outFormat.format(displayDate);

        if (mMap != null && mMap.size() > 0 && mMap.get(displayDateValue) != null) {
            fitbitValueSummary = mMap.get(displayDateValue);
            if (fitbitValueSummary != null) {
                if (fitbitValueSummary.getSleep() != null && !fitbitValueSummary.getSleep().
                        equals("null")) {
                    yVals.add(new BarEntry(1, new float[]{Float.valueOf(fitbitValueSummary.getSleep() / 60)}));
                    xVals.add(displayDateValue);
                    count++;
                    sum += fitbitValueSummary.getSleep();
                    Integer sleep = Integer.parseInt(String.valueOf(fitbitValueSummary.getSleep()));
                    int hours = sleep / 60;
                    Integer minutes = sleep % 60;
                    sleepTxtValue.setText(hours + " hr" + " " + minutes + mins);
                    sleepValueDefault.setText(hours + " hr" + " " + minutes + mins);
                }
                sleepLabelDefault.setText(dayValue1);
                xVals.add(displayDateValue);

                try {
                    Date d = formatter.parse(displayDateValue);
                    Date displayDateForMon = new Date(d.getTime() - 1 * 24 * 3600 * 1000);
                    String displayDateValueForMon = formatter.format(displayDateForMon);
                    String dayValue2 = outFormat.format(displayDateForMon);

                    fitbitValueSummary = mMap.get(displayDateValueForMon);
                    if (fitbitValueSummary.getSleep() != null && !fitbitValueSummary.getSleep().
                            equals("null")) {
                        yVals.add(new BarEntry(2, new float[]{Float.valueOf(fitbitValueSummary.getSleep() / 60)}));
                        xVals.add(displayDateValueForMon);
                        count++;
                        sum += fitbitValueSummary.getSleep();
                        Integer sleep = Integer.parseInt(String.valueOf(fitbitValueSummary.getSleep()));
                        int hours = sleep / 60;
                        Integer minutes = sleep % 60;
                        monSleepValue.setText(hours + " hr" + " " + minutes +mins);
                    }
                    monSleepLabel.setText(dayValue2);
                    xVals.add(displayDateValueForMon);

                    Date d2 = formatter.parse(displayDateValueForMon);
                    Date displayDateForTue = new Date(d2.getTime() - 1 * 24 * 3600 * 1000);
                    String displayDateValueForTue = formatter.format(displayDateForTue);
                    String dayValue3 = outFormat.format(displayDateForTue);

                    fitbitValueSummary = mMap.get(displayDateValueForTue);

                    if (fitbitValueSummary.getSleep() != null &&
                            !fitbitValueSummary.getSleep().equals("null")) {
                        yVals.add(new BarEntry(3, new float[]{Float.valueOf(fitbitValueSummary.getSleep() / 60)}));
                        xVals.add(displayDateValueForTue);
                        count++;
                        sum += fitbitValueSummary.getSleep();
                        Integer sleep = Integer.parseInt(String.valueOf(fitbitValueSummary.getSleep()));
                        int hours = sleep / 60;
                        Integer minutes = sleep % 60;
                        tueSleepValue.setText(hours + " hr" + " " + minutes + mins);
                    }
                    tueSleepLabel.setText(dayValue3);
                    xVals.add(displayDateValueForTue);

                    Date d3 = formatter.parse(displayDateValueForTue);
                    Date displayDateForWed = new Date(d3.getTime() - 1 * 24 * 3600 * 1000);
                    String displayDateValueForWed = formatter.format(displayDateForWed);

                    String dayValue4 = outFormat.format(displayDateForWed);

                    fitbitValueSummary = mMap.get(displayDateValueForWed);

                    if (fitbitValueSummary.getSleep() != null && !fitbitValueSummary.getSleep().
                            equals("null")) {
                        yVals.add(new BarEntry(4, new float[]{Float.valueOf(fitbitValueSummary.getSleep() / 60)}));
                        xVals.add(displayDateValueForWed);
                        count++;
                        sum += fitbitValueSummary.getSleep();
                        Integer sleep = Integer.parseInt(String.valueOf(fitbitValueSummary.getSleep()));
                        int hours = sleep / 60;
                        Integer minutes = sleep % 60;
                        wedSleepValue.setText(hours + " hr" + " " + minutes + mins);
                    }
                    wedSleepLabel.setText(dayValue4);
                    xVals.add(displayDateValueForWed);


                    Date d4 = formatter.parse(displayDateValueForWed);
                    Date displayDateForThur = new Date(d4.getTime() - 1 * 24 * 3600 * 1000);
                    String displayDateValueForThur = formatter.format(displayDateForThur);

                    String dayValue5 = outFormat.format(displayDateForThur);
                    fitbitValueSummary = mMap.get(displayDateValueForThur);


                    if (fitbitValueSummary.getSleep() != null && !fitbitValueSummary.getSleep().
                            equals("null")) {
                        yVals.add(new BarEntry(5, new float[]{Float.valueOf(fitbitValueSummary.getSleep() / 60)}));
                        xVals.add(displayDateValueForThur);

                        sum += fitbitValueSummary.getSleep();
                        count++;
                        Integer sleep = Integer.parseInt(String.valueOf(fitbitValueSummary.getSleep()));
                        int hours = sleep / 60;
                        Integer minutes = sleep % 60;
                        thruSleepValue.setText(hours + " hr" + " " + minutes + mins);
                    }

                    thruSleepLabel.setText(dayValue5);
                    xVals.add(displayDateValueForThur);

                    Date d5 = formatter.parse(displayDateValueForThur);
                    Date displayDateForFri = new Date(d5.getTime() - 1 * 24 * 3600 * 1000);
                    String displayDateValueForFri = formatter.format(displayDateForFri);

                    String dayValue6 = outFormat.format(displayDateForFri);
                    fitbitValueSummary = mMap.get(displayDateValueForFri);


                    if (fitbitValueSummary.getSleep() != null && !fitbitValueSummary.getSleep().
                            equals("null")) {
                        yVals.add(new BarEntry(6, new float[]{Float.valueOf(fitbitValueSummary.getSleep() / 60)}));
                        xVals.add(displayDateValueForFri);
                        sum += fitbitValueSummary.getSleep();
                        count++;
                        Integer sleep = Integer.parseInt(String.valueOf(fitbitValueSummary.getSleep()));
                        int hours = sleep / 60;
                        Integer minutes = sleep % 60;
                        friSleepValue.setText(hours + " hr" + " " + minutes + mins);
                    }
                    friSleepLabel.setText(dayValue6);
                    xVals.add(displayDateValueForFri);

                    Date d6 = formatter.parse(displayDateValueForFri);
                    Date displayDateForSat = new Date(d6.getTime() - 1 * 24 * 3600 * 1000);
                    String displayDateValueForSat = formatter.format(displayDateForFri);

                    String dayValue7 = outFormat.format(displayDateForSat);
                    fitbitValueSummary = mMap.get(displayDateValueForSat);

                    if (fitbitValueSummary.getSleep() != null && !fitbitValueSummary.getSleep().equals("null")) {
                        yVals.add(new BarEntry(7, new float[]{Float.valueOf(fitbitValueSummary.getSleep() / 60)}));
                        xVals.add(displayDateValueForSat);
                        sum += fitbitValueSummary.getSleep();
                        count++;
                        Integer sleep = Integer.parseInt(String.valueOf(fitbitValueSummary.getSleep()));
                        int hours = sleep / 60;
                        Integer minutes = sleep % 60;
                        satSleepValue.setText(hours + " hr" + " " + minutes + mins);
                    }
                    satSleepLabel.setText(dayValue7);
                    xVals.add(displayDateValueForSat);
                    if (count > 0) {
                        int average = sum / count;
                        int hours = average / 60;
                        Integer minutes = average % 60;
                        totalSleepCount.setText("Average" + " " + hours + " hr" + " " + minutes + mins);
                    }

                } catch (ParseException pe) {
                    pe.getMessage();
                }

                BarDataSet set1;
                if (mChart.getData() != null && mChart.getData().getDataSetCount() > 0) {
                    set1 = (BarDataSet) mChart.getData().getDataSetByIndex(1);
                    set1.setValues(yVals);
                    mChart.getData().notifyDataChanged();
                    mChart.notifyDataSetChanged();
                } else {
                    set1 = new BarDataSet(yVals, "");
                    set1.setColors(myColorsChart);
                    set1.setDrawValues(true);
                    set1.setVisible(true);
                    ArrayList<IBarDataSet> dataSets = new ArrayList<>();
                    dataSets.add(set1);
                    BarData data = new BarData(dataSets);
                    data.setValueFormatter(new LargeValueFormatter());
                    data.setValueTextColor(Color.WHITE);
                    data.setBarWidth(0.5f);
                    mChart.setData(data);
                }

                XAxis xAxis = mChart.getXAxis();
                xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
                xAxis.setLabelCount(7);
                xAxis = mChart.getXAxis();
                mChart.getLegend().setEnabled(false);
                xAxis.setAvoidFirstLastClipping(true);
                xAxis.setCenterAxisLabels(false);
                xAxis.setDrawLabels(false);
                xAxis.setValueFormatter(new IAxisValueFormatter() {
                    @Override
                    public String getFormattedValue(float value, AxisBase axis) {
                        return String.valueOf((int) Math.floor(value) + " " + "hr");
                    }
                });
                xAxis.disableGridDashedLine();
                xAxis.setDrawGridLines(false);
                xAxis.disableGridDashedLine();
                xAxis.setDrawAxisLine(false);
                xAxis.setGranularity(1f);
                mChart.setTouchEnabled(false);
                mChart.invalidate();
            }
        }
        return mChart;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnBackwardSleep:
                SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
                try {
                    Date d = formatter.parse(displayDateValue);
                    displayDate = new Date(d.getTime() - 1 * 24 * 3600 * 1000);
                    displayDateValue = formatter.format(displayDate);
                } catch (ParseException pe) {
                    pe.getMessage();
                }
                sleepTxtValue.setText(String.valueOf("0"));
                mSleepValue = String.valueOf("0");
                awakeCount.setText("0");
                restLessCount.setText("0");

                SimpleDateFormat labelFormatterBackward = new SimpleDateFormat(dateFormat1);
                String labelTextBackward = labelFormatterBackward.format(displayDate);
                dateSleepLabel.setText(labelTextBackward.substring(0, 11));
                setClickableStatus();

                fitbitValueSummary = new FitbitValueSummary();

                if (mMap != null && mMap.size() > 0) {
                    fitbitValueSummary = mMap.get(displayDateValue);
                    if (fitbitValueSummary != null) {
                        if (fitbitValueSummary.getSleep() != null && !fitbitValueSummary.getSleep().equals("null")
                                && fitbitValueSummary.getAwakeCount() != null && !fitbitValueSummary.getAwakeCount().equals("null")
                                && fitbitValueSummary.getResttLessCount() != null && !fitbitValueSummary.getResttLessCount().equals("null")) {
                            Integer sleep = Integer.parseInt(String.valueOf(fitbitValueSummary.getSleep()));
                            int hours = sleep / 60;
                            Integer minutes = sleep % 60;
                            sleepTxtValue.setText(hours + " hr" + " " + minutes + mins);
                            awakeCount.setText(fitbitValueSummary.getAwakeCount());
                            restLessCount.setText(fitbitValueSummary.getResttLessCount());
                            getPieChartResults();
                        } else {
                            sleepTxtValue.setText(space);
                            awakeCount.setText(space);
                            restLessCount.setText(space);
                        }
                    }
                }

                break;

            case R.id.btnForwardSleep:

                SimpleDateFormat formatterForward = new SimpleDateFormat("yyyy-MM-dd");
                try {
                    Date d = formatterForward.parse(displayDateValue);
                    displayDate = new Date(d.getTime() + 1 * 24 * 3600 * 1000);
                    displayDateValue = formatterForward.format(displayDate);
                } catch (ParseException pe) {
                    pe.getMessage();
                }
                sleepTxtValue.setText(String.valueOf("0"));
                mSleepValue = String.valueOf("0");

                SimpleDateFormat labelFormatterForward = new SimpleDateFormat(dateFormat1);
                String labelTextForward = labelFormatterForward.format(displayDate);
                dateSleepLabel.setText(labelTextForward.substring(0, 11));
                setClickableStatus();

                fitbitValueSummary = new FitbitValueSummary();
                if (mMap != null && mMap.size() > 0) {
                    fitbitValueSummary = mMap.get(displayDateValue);
                    if (fitbitValueSummary != null) {
                        if (fitbitValueSummary.getSleep() != null && !fitbitValueSummary.getSleep().equals("null")
                                && fitbitValueSummary.getAwakeCount() != null && !fitbitValueSummary.getAwakeCount().equals("null")
                                && fitbitValueSummary.getResttLessCount() != null && !fitbitValueSummary.getResttLessCount().equals("null")) {
                            Integer sleep = Integer.parseInt(String.valueOf(fitbitValueSummary.getSleep()));
                            int hours = sleep / 60;
                            Integer minutes = sleep % 60;
                            sleepTxtValue.setText(hours + " hr" + " " + minutes + mins);
                            awakeCount.setText(fitbitValueSummary.getAwakeCount());
                            restLessCount.setText(fitbitValueSummary.getResttLessCount());
                            getPieChartResults();
                        } else {
                            sleepTxtValue.setText(space);
                            awakeCount.setText(space);
                            restLessCount.setText(space);
                        }
                    }
                }


                break;
            default:
                break;
        }
    }

    private PieChart getPieChartResults() {

        final int[] myColors = {Color.rgb(255, 255, 255), Color.rgb(138, 219, 124)};

        ArrayList<PieEntry> yvalues = new ArrayList<>();
        if (mMap != null && mMap.size() > 0 && mMap.get(displayDateValue) != null) {
            if (mSleepValue != null && !mSleepValue.equals("null")) {
                mSleepValue = String.valueOf(mMap.get(displayDateValue).getSleep() / 60);
                float f1 = (float) Double.parseDouble(mSleepValue);
                float f2 = (float) Double.parseDouble(mSleepValue);
                float f3 = f1 - f2;
                yvalues.add(new PieEntry((f2)));
                yvalues.add(new PieEntry((f3)));
            }
            PieDataSet dataSet = new PieDataSet(yvalues, "");
            dataSet.setSliceSpace(3f);
            dataSet.setDrawValues(false);

            ArrayList<Integer> colors = new ArrayList<>();
            for (int c : myColors) colors.add(c);
            dataSet.setColors(colors);

            PieData data = new PieData(dataSet);
            pieChart.setData(data);
            pieChart.setDrawHoleEnabled(true);
            pieChart.setHoleColor(Color.argb(0, 0, 0, 0));
            pieChart.setCenterTextSize(60);
            pieChart.setTransparentCircleAlpha(50);
            pieChart.setHoleRadius(95f);
            pieChart.setDrawSliceText(false);
            pieChart.getDescription().setEnabled(false);
            pieChart.setDrawCenterText(true);
            pieChart.getLegend().setEnabled(false);
            pieChart.spin(1000, pieChart.getRotationAngle(), pieChart.getRotationAngle()
                    + 360, Easing.EasingOption
                    .EaseInCubic);
            pieChart.invalidate();
        }
        return pieChart;
    }

    private void setClickableStatus() {
        if (displayDate.after(minDate)) {
            btnBackward.setEnabled(true);
            btnBackward.setClickable(true);
            btnBackward.setVisibility(View.VISIBLE);

        } else if (!displayDate.after(minDate)) {
            btnBackward.setEnabled(false);
            btnBackward.setClickable(false);
            btnBackward.setVisibility(View.GONE);
        }
        if (displayDate.before(maxDate)) {
            btnForward.setEnabled(true);
            btnForward.setClickable(true);
            btnForward.setVisibility(View.VISIBLE);
        } else if (!displayDate.before(maxDate)) {
            btnForward.setEnabled(false);
            btnForward.setClickable(false);
            btnForward.setVisibility(View.GONE);
        }
        if (displayDate.equals(maxDate)) {
            btnForward.setEnabled(false);
            btnForward.setClickable(false);
            btnForward.setVisibility(View.GONE);
        }
        if (displayDate.equals(minDate)) {
            btnBackward.setEnabled(false);
            btnBackward.setClickable(false);
            btnBackward.setVisibility(View.GONE);
        }
    }

    public void setDate(TextView view) {
        Date today = Calendar.getInstance().getTime();//getting date
        SimpleDateFormat formatter = new SimpleDateFormat(dateFormat1);//formating according to my need
        String date = formatter.format(today);
        view.setText(date.substring(0, 11));
    }
}