package com.wps.memberapp.presentation.healthtracker.fragment;


import android.app.Activity;
import android.app.Fragment;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.LargeValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.wps.memberapp.R;
import com.wps.memberapp.data.models.FitbitValueSummary;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.presentation.healthtracker.adapter.HealthTrackerGridViewAdapter;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;

import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;


public class StepsFragment extends Fragment implements View.OnClickListener {
    LinkedHashMap<String, FitbitValueSummary> mMap;
    private final int[] myColorsChart = {Color.rgb(83, 198, 148), Color.rgb(72, 171, 128)};
    private Date todaysDate;
    private Date displayDate;
    private String displayDateValue;
    private String goals;
    BarChart mChart;
    PieChart pieChart;
    LinearLayout mChartView;
    String mStepValue;
    String mGoalValue;
    private ImageView btnBackward;
    private ImageView btnForward;
    FitbitValueSummary fitbitValueSummary;
    Double sum;
    private Date minDate;
    private Date maxDate;
    TextView stepsValue;
    TextView totalStepCount;
    TextView goalValue;
    private TextView stepLabelDefault;
    private TextView stepValueDefault;
    private TextView durationValue;
    private TextView calorieValue;
    private TextView mMilesValue;
    private TextView mFloorValue;
    TextView monStepLabel;
    TextView monStepsValue;
    TextView tueStepLabel;
    TextView tueStepsValue;
    TextView wedStepLabel;
    TextView wedStepsValue;
    TextView thruStepsValue;
    TextView thruStepLabel;
    TextView friStepsValue;
    TextView friStepLabel;
    TextView satStepsLabel;
    TextView satStepsValue;
    TextView headingTxtLabel;
    TextView dateStepsLabel;
    private String steps = "Steps";
    private String dateFormat = "yyyy-MM-dd";
    private String dateFormat1 = "EEE, MMM dd, ''yy";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);

        //getting current date
        todaysDate = Calendar.getInstance().getTime();
        displayDate = todaysDate;

        //formatting current date
        displayDateValue = formatter.format(displayDate);
        try {
            displayDate = formatter.parse(displayDateValue);
        } catch (ParseException e) {
            Logger.e("ParseException", e);
        }
        Log.i("ddate", "" + displayDate);

        //getting max date
        maxDate = displayDate;

        //getting min date
        try {
            Date d = formatter.parse(displayDateValue);
            minDate = new Date(d.getTime() - 6 * 24 * 3600 * 1000);
            //formatting min date
            String minDateValue = formatter.format(minDate);
            minDate = formatter.parse(minDateValue);
            Log.i("mdate", "" + minDate);
        } catch (ParseException pe) {
            pe.getMessage();
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        View rootView = inflater.inflate(R.layout.fragment_step_count_detail, container, false);
        mChartView = (LinearLayout) rootView.findViewById(R.id.barChartlinearLayout);
        pieChart = (PieChart) rootView.findViewById(R.id.pieChartStepCount);
        stepsValue = (TextView) rootView.findViewById(R.id.stepsValue);
        dateStepsLabel = (TextView) rootView.findViewById(R.id.dateStepsLabel);
        totalStepCount = (TextView) rootView.findViewById(R.id.totalStepCount);
        goalValue = (TextView) rootView.findViewById(R.id.goalValue);
        monStepLabel = (TextView) rootView.findViewById(R.id.monStepLabel);
        monStepsValue = (TextView) rootView.findViewById(R.id.monStepValue);
        tueStepLabel = (TextView) rootView.findViewById(R.id.tueStepLabel);
        tueStepsValue = (TextView) rootView.findViewById(R.id.tueStepValue);
        wedStepLabel = (TextView) rootView.findViewById(R.id.wedStepLabel);
        wedStepsValue = (TextView) rootView.findViewById(R.id.wedStepValue);
        thruStepLabel = (TextView) rootView.findViewById(R.id.thurStepLabel);
        thruStepsValue = (TextView) rootView.findViewById(R.id.thurStepValue);
        friStepLabel = (TextView) rootView.findViewById(R.id.FriStepLabel);
        friStepsValue = (TextView) rootView.findViewById(R.id.FriStepValue);
        satStepsLabel = (TextView) rootView.findViewById(R.id.satStepLabel);
        satStepsValue = (TextView) rootView.findViewById(R.id.satStepValue);
        headingTxtLabel = (TextView) rootView.findViewById(R.id.headingStepTxt);
        dateStepsLabel = (TextView) rootView.findViewById(R.id.dateStepsLabel);
        btnBackward = (ImageView) rootView.findViewById(R.id.btnBackwardSteps);
        btnForward = (ImageView) rootView.findViewById(R.id.btnForwardSteps);
        GridView daysGridView = (GridView) rootView.findViewById(R.id.dayStepGridView);
        mMilesValue = (TextView) rootView.findViewById(R.id.milesStepsValue);
        mFloorValue = (TextView) rootView.findViewById(R.id.floorStepsValue);
        durationValue = (TextView) rootView.findViewById(R.id.durationStepsValue);
        calorieValue = (TextView) rootView.findViewById(R.id.caloriesStepsValue);
        ScrollView scrollView = (ScrollView) rootView.findViewById(R.id.scrollViewSteps);
        stepValueDefault = (TextView) rootView.findViewById(R.id.stepValueDefault);
        stepLabelDefault = (TextView) rootView.findViewById(R.id.stepLabelDefault);
        scrollView.scrollTo(0, 100);
        btnBackward.setOnClickListener(this);
        btnForward.setOnClickListener(this);
        setDate(dateStepsLabel);
        setClickableStatus();
        mMap = new LinkedHashMap<>();
        Bundle b = this.getArguments();
        if (b.getSerializable("FitbitValues") != null) {
            mMap = (LinkedHashMap<String, FitbitValueSummary>) b.getSerializable("FitbitValues");
            if (getArguments() != null) {
                goals = getArguments().getString("goals");
            }
            if (mMap != null && mMap.size() > 0) {
                fitbitValueSummary = mMap.get(displayDateValue);
                if (fitbitValueSummary != null) {
                    sum = 0.0;
                    for (FitbitValueSummary f : mMap.values()) {
                        if (f.getSteps() != null) {
                            sum += Double.parseDouble(f.getSteps());
                            String totalSteps = NumberFormat.getNumberInstance(Locale.US).format(sum);
                            totalStepCount.setText(totalSteps + " " + "total steps");

                        }
                    }
                    goalValue.setText(goals);
                    stepsValue.setText(String.valueOf(mMap.get(displayDateValue).getSteps()));
                    mStepValue = String.valueOf(mMap.get(displayDateValue).getSteps());
                    String miles = "" + convertKmsToMiles(Double.valueOf(fitbitValueSummary.getDistance()), 2);
                    mMilesValue.setText(miles);
                    mFloorValue.setText(fitbitValueSummary.getFloors());
                    String duration = String.valueOf(fitbitValueSummary.getDuration());
                    String desiredDurationString = duration.substring(0, 3);
                    durationValue.setText(desiredDurationString);
                    calorieValue.setText(fitbitValueSummary.getCalories());
                }
            }
        }

        SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);

        //getting current date
        todaysDate = Calendar.getInstance().getTime();
        displayDate = todaysDate;
        //formatting current date
        displayDateValue = formatter.format(displayDate);
        try {
            getPieChartResults();
        } catch (Exception e) {
            Logger.e("Exception", e);
        }
        mChart = getVerticalChartResults();
        mChartView.removeAllViews();
        mChartView.addView(mChart, new RecyclerView.LayoutParams
                (RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.MATCH_PARENT));
        daysGridView.setAdapter(new HealthTrackerGridViewAdapter(getActivity(), getActivity().getResources().getStringArray(R.array.days)));
        return rootView;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        Toolbar toolbar = (Toolbar) activity.findViewById(R.id.toolbarFitbit);
        toolbar.setBackgroundColor(getResources().getColor(R.color.green));
    }


/*Used to plot vertical bar chart for step count and plot it using Vertical bar Chart through MP Android chart library*/


    private BarChart getVerticalChartResults() {
        mChart = new BarChart(getActivity());
        ArrayList<BarEntry> yVals1 = new ArrayList<>();

        mChart.getDescription().setEnabled(false);
        // scaling can now only be done on x- and y-axis separately
        mChart.setPinchZoom(false);
        mChart.setDrawGridBackground(false);
        mChart.setDrawBarShadow(false);
        mChart.setDrawValueAboveBar(false);
        mChart.setHighlightFullBarEnabled(false);

        // Change the position of the y-labels
        YAxis leftAxis = mChart.getAxisRight();
        leftAxis.setDrawGridLines(false);
        leftAxis.setEnabled(false);
        mChart.getAxisRight().setEnabled(false);
        leftAxis.setLabelCount(7);
        if (goals != null && goals.length() > 0) {
            leftAxis.setAxisMaximum(Float.valueOf(goals));
        }
        leftAxis.setAxisMinimum(0);

        SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);

        SimpleDateFormat outFormat = new SimpleDateFormat("EEEE");
        String dayValue = outFormat.format(displayDate);

        if (mMap != null && mMap.size() > 0 && mMap.get(displayDateValue) != null) {
            if (mMap.get(displayDateValue).getSteps() != null && !mMap.get(displayDateValue).getSteps().equals("null")) {
                FitbitValueSummary fitbitSummary = mMap.get(displayDateValue);
                yVals1.add(new BarEntry(0, new float[]{Float.valueOf(fitbitSummary.getSteps())}));
                headingTxtLabel.setText("This Week");
                stepLabelDefault.setText(dayValue);
                stepsValue.setText(fitbitSummary.getSteps() + " " + steps);
                stepValueDefault.setText(fitbitSummary.getSteps() + " " + steps);
            }

            try {
                Date d = formatter.parse(displayDateValue);
                Date displayDateForMon = new Date(d.getTime() - 1 * 24 * 3600 * 1000);
                String displayDateValueForMon = formatter.format(displayDateForMon);
                String dayValue1 = outFormat.format(displayDateForMon);

                if (mMap.get(displayDateValueForMon).getSteps() != null && !mMap.get(displayDateValueForMon).getSteps().equals("null")) {
                    FitbitValueSummary fitbitSummary = mMap.get(displayDateValueForMon);
                    yVals1.add(new BarEntry(1, new float[]{Float.valueOf(fitbitSummary.getSteps())}));
                    monStepLabel.setText(dayValue1);
                    monStepsValue.setText(fitbitSummary.getSteps() + " " + steps);
                }

                Date d2 = formatter.parse(displayDateValueForMon);
                Date displayDateForTue = new Date(d2.getTime() - 1 * 24 * 3600 * 1000);
                String displayDateValueForTue = formatter.format(displayDateForTue);
                String dayValue2 = outFormat.format(displayDateForTue);

                if (mMap.get(displayDateValueForTue).getSteps() != null && !mMap.get(displayDateValueForTue).getSteps().equals("null")) {
                    FitbitValueSummary fitbitSummary = mMap.get(displayDateValueForTue);
                    yVals1.add(new BarEntry(2, new float[]{Float.valueOf(fitbitSummary.getSteps())}));
                    tueStepLabel.setText(dayValue2);
                    tueStepsValue.setText(fitbitSummary.getSteps() + " " + steps);
                }

                Date d3 = formatter.parse(displayDateValueForTue);
                Date displayDateForWed = new Date(d3.getTime() - 1 * 24 * 3600 * 1000);
                String displayDateValueForWed = formatter.format(displayDateForWed);
                String dayValue3 = outFormat.format(displayDateForWed);

                if (mMap.get(displayDateValueForWed).getSteps() != null && !mMap.get(displayDateValueForWed).getSteps().equals("null")) {
                    FitbitValueSummary fitbitSummary = mMap.get(displayDateValueForWed);
                    yVals1.add(new BarEntry(3, new float[]{Float.valueOf(fitbitSummary.getSteps())}));
                    wedStepLabel.setText(dayValue3);
                    wedStepsValue.setText(fitbitSummary.getSteps() + " " + steps);
                }

                Date d4 = formatter.parse(displayDateValueForWed);
                Date displayDateForThur = new Date(d4.getTime() - 1 * 24 * 3600 * 1000);
                String displayDateValueForThur = formatter.format(displayDateForThur);

                String dayValue4 = outFormat.format(displayDateForThur);

                if (mMap.get(displayDateValueForThur).getSteps() != null && !mMap.get(displayDateValueForThur).getSteps().equals("null")) {
                    FitbitValueSummary fitbitSummary = mMap.get(displayDateValueForThur);
                    yVals1.add(new BarEntry(4, new float[]{Float.valueOf(fitbitSummary.getSteps())}));
                    thruStepLabel.setText(dayValue4);
                    thruStepsValue.setText(fitbitSummary.getSteps() + " " + steps);
                }

                Date d5 = formatter.parse(displayDateValueForThur);
                Date displayDateForFri = new Date(d5.getTime() - 1 * 24 * 3600 * 1000);
                String displayDateValueForFri = formatter.format(displayDateForFri);

                String dayValue5 = outFormat.format(displayDateForFri);

                if (mMap.get(displayDateValueForFri).getSteps() != null && !mMap.get(displayDateValueForFri).getSteps().equals("null")) {
                    FitbitValueSummary fitbitSummary = mMap.get(displayDateValueForFri);
                    yVals1.add(new BarEntry(5, new float[]{Float.valueOf(fitbitSummary.getSteps())}));
                    friStepLabel.setText(dayValue5);
                    friStepsValue.setText(fitbitSummary.getSteps() + " " + steps);
                }

                Date d6 = formatter.parse(displayDateValueForFri);
                Date displayDateForSat = new Date(d6.getTime() - 1 * 24 * 3600 * 1000);
                String displayDateValueForSat = formatter.format(displayDateForSat);
                String dayValue6 = outFormat.format(displayDateForSat);

                if (mMap.get(displayDateValueForSat).getSteps() != null && !mMap.get(displayDateValueForSat).getSteps().equals("null")) {
                    FitbitValueSummary fitbitSummary = mMap.get(displayDateValueForSat);
                    yVals1.add(new BarEntry(6, new float[]{Float.valueOf(fitbitSummary.getSteps())}));
                    satStepsLabel.setText(dayValue6);
                    satStepsValue.setText(fitbitSummary.getSteps() + " " + steps);
                }

            } catch (ParseException pe) {
                pe.getMessage();
            }
            BarDataSet set1;
            if (mChart.getData() != null &&
                    mChart.getData().getDataSetCount() > 0) {
                set1 = (BarDataSet) mChart.getData().getDataSetByIndex(0);
                set1.setValues(yVals1);
                mChart.getData().notifyDataChanged();
                mChart.notifyDataSetChanged();
            } else {
                set1 = new BarDataSet(yVals1, "");
                set1.setColors(myColorsChart);
                set1.setDrawValues(true);
                set1.setVisible(true);
                ArrayList<IBarDataSet> dataSets = new ArrayList<>();
                dataSets.add(set1);
                BarData data = new BarData(dataSets);
                data.setValueFormatter(new LargeValueFormatter());
                data.setValueTextColor(Color.WHITE);
                mChart.setExtraRightOffset(30f);
                mChart.getLegend().setEnabled(false);
                data.setBarWidth(0.8f);
                mChart.setData(data);
            }

            XAxis xAxis = mChart.getXAxis();
            xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
            xAxis.setAvoidFirstLastClipping(true);
            xAxis.setCenterAxisLabels(false);
            xAxis.setDrawLabels(false);
            xAxis.disableGridDashedLine();
            xAxis.setDrawGridLines(false);
            xAxis.setDrawAxisLine(false);
            xAxis.setGranularity(1f);
            mChart.setTouchEnabled(false);
            mChart.invalidate();
        }
        return mChart;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnBackwardSteps:
                SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
                try {
                    Date d = formatter.parse(displayDateValue);
                    displayDate = new Date(d.getTime() - 1 * 24 * 3600 * 1000);
                    displayDateValue = formatter.format(displayDate);
                } catch (ParseException pe) {
                    pe.getMessage();
                }
                stepsValue.setText(String.valueOf("0"));
                mStepValue = String.valueOf("0");
                mMilesValue.setText("0.0");
                mFloorValue.setText("0.0");
                durationValue.setText("0.0");
                calorieValue.setText("0.0");

                SimpleDateFormat labelFormatterBackward = new SimpleDateFormat(dateFormat1);
                String labelTextBackward = labelFormatterBackward.format(displayDate);
                dateStepsLabel.setText(labelTextBackward.substring(0, 11));
                setClickableStatus();

                fitbitValueSummary = new FitbitValueSummary();

                if (SharedPreferenceHelper.getInstance() != null) {
                    goals = SharedPreferenceHelper.getInstance().getPreference(getActivity(), "step_goal");
                }

                if (mMap != null && mMap.size() > 0) {
                    fitbitValueSummary = mMap.get(displayDateValue);
                    if (fitbitValueSummary != null) {
                        goalValue.setText(goals);
                        mGoalValue = goals;
                        if (fitbitValueSummary.getSteps() != null &&
                                !fitbitValueSummary.getSteps().equals("null")) {
                            stepsValue.setText(String.valueOf(fitbitValueSummary.getSteps()));
                            mStepValue = String.valueOf(mMap.get(displayDateValue).getSteps());
                            String miles = "" + convertKmsToMiles(Double.valueOf(fitbitValueSummary.getDistance()), 2);
                            mMilesValue.setText(miles);
                            mFloorValue.setText(fitbitValueSummary.getFloors());
                            String duration = String.valueOf(fitbitValueSummary.getDuration());
                            String desiredDurationString = duration.substring(0, 3);
                            durationValue.setText(desiredDurationString);
                            calorieValue.setText(fitbitValueSummary.getCalories());
                            getPieChartResults();
                        }
                    }
                }


                break;

            case R.id.btnForwardSteps:

                SimpleDateFormat formatterForward = new SimpleDateFormat(dateFormat);
                try {
                    Date d = formatterForward.parse(displayDateValue);
                    displayDate = new Date(d.getTime() + 1 * 24 * 3600 * 1000);
                    displayDateValue = formatterForward.format(displayDate);
                } catch (ParseException pe) {
                    pe.getMessage();
                }
                stepsValue.setText(String.valueOf("0"));
                mStepValue = String.valueOf("0");
                mMilesValue.setText("0.0");
                mFloorValue.setText("0.0");
                durationValue.setText("0.0");
                calorieValue.setText("0.0");
                SimpleDateFormat labelFormatterForward = new SimpleDateFormat(dateFormat1);
                String labelTextForward = labelFormatterForward.format(displayDate);
                dateStepsLabel.setText(labelTextForward.substring(0, 11));
                setClickableStatus();

                if (SharedPreferenceHelper.getInstance() != null) {
                    goals = SharedPreferenceHelper.getInstance().getPreference(getActivity(), "step_goal");
                }
                fitbitValueSummary = new FitbitValueSummary();
                if (mMap != null && mMap.size() > 0) {
                    fitbitValueSummary = mMap.get(displayDateValue);
                    if (fitbitValueSummary != null) {
                        goalValue.setText(goals);
                        mGoalValue = goals;
                        if (fitbitValueSummary.getSteps() != null &&
                                !fitbitValueSummary.getSteps().equals("null")) {
                            stepsValue.setText(String.valueOf(fitbitValueSummary.getSteps()));
                            mStepValue = String.valueOf(mMap.get(displayDateValue).getSteps());
                            String miles = "" + convertKmsToMiles(Double.valueOf(fitbitValueSummary.getDistance()), 2);
                            mMilesValue.setText(miles);
                            mFloorValue.setText(fitbitValueSummary.getFloors());
                            String duration = String.valueOf(fitbitValueSummary.getDuration());
                            String desiredDurationString = duration.substring(0, 3);
                            durationValue.setText(desiredDurationString);
                            calorieValue.setText(fitbitValueSummary.getCalories());
                            getPieChartResults();
                        }
                    }
                }
                break;
            default:
                break;
        }
    }

    private PieChart getPieChartResults() {

        final int[] myColors = {Color.rgb(255, 255, 255), Color.rgb(138, 219, 124)};

        ArrayList<PieEntry> yvalues = new ArrayList<>();

        if (mMap != null && mMap.size() > 0 && mMap.get(displayDateValue) != null && mMap.get(displayDateValue).getSteps() != null) {
            mStepValue = String.valueOf(mMap.get(displayDateValue).getSteps());
            if (goals != null && !goals.equals("null") && mStepValue != null && !mStepValue.equals("null")) {
                float f1 = (float) Double.parseDouble(goals);
                float f2 = (float) Double.parseDouble(mStepValue);
                float f3 = f1 - f2;
                yvalues.add(new PieEntry((f2)));
                yvalues.add(new PieEntry((f3)));
            }
            PieDataSet dataSet = new PieDataSet(yvalues, "");
            dataSet.setSliceSpace(3f);
            dataSet.setDrawValues(false);

            ArrayList<Integer> colors = new ArrayList<>();
            for (int c : myColors) colors.add(c);
            dataSet.setColors(colors);

            PieData data = new PieData(dataSet);
            pieChart.setData(data);
            pieChart.setDrawHoleEnabled(true);
            pieChart.setHoleColor(Color.argb(0, 0, 0, 0));
            pieChart.setCenterTextSize(60);
            pieChart.setTransparentCircleAlpha(50);
            pieChart.setHoleRadius(95f);
            pieChart.setDrawSliceText(false);
            pieChart.getDescription().setEnabled(false);
            pieChart.setDrawCenterText(true);
            pieChart.getLegend().setEnabled(false);
            pieChart.spin(1000, pieChart.getRotationAngle(), pieChart.getRotationAngle()
                    + 360, Easing.EasingOption
                    .EaseInCubic);
            pieChart.invalidate();
        }
        return pieChart;
    }

    private void setClickableStatus() {
        if (displayDate.after(minDate)) {
            btnBackward.setEnabled(true);
            btnBackward.setClickable(true);
            btnBackward.setVisibility(View.VISIBLE);

        } else if (!displayDate.after(minDate)) {
            btnBackward.setEnabled(false);
            btnBackward.setClickable(false);
            btnBackward.setVisibility(View.GONE);
        }
        if (displayDate.before(maxDate)) {
            btnForward.setEnabled(true);
            btnForward.setClickable(true);
            btnForward.setVisibility(View.VISIBLE);
        } else if (!displayDate.before(maxDate)) {
            btnForward.setEnabled(false);
            btnForward.setClickable(false);
            btnForward.setVisibility(View.GONE);
        }
        if (displayDate.equals(maxDate)) {
            btnForward.setEnabled(false);
            btnForward.setClickable(false);
            btnForward.setVisibility(View.GONE);
        }
        if (displayDate.equals(minDate)) {
            btnBackward.setEnabled(false);
            btnBackward.setClickable(false);
            btnBackward.setVisibility(View.GONE);
        }

    }

    public void setDate(TextView view) {
        Date today = Calendar.getInstance().getTime();//getting date
        SimpleDateFormat formatter = new SimpleDateFormat(dateFormat1);//formating according to my need
        String date = formatter.format(today);
        view.setText(date.substring(0, 11));
    }

    public double convertKmsToMiles(double kms, int decimalPlaces) {
        double miles = 0.621371 * kms;

        long factor = (long) Math.pow(10, decimalPlaces);
        miles = miles * factor;
        long tmp = Math.round(miles);
        return (double) tmp / factor;

    }
}
