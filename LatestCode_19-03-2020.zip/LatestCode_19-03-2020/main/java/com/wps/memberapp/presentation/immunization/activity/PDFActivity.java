package com.wps.memberapp.presentation.immunization.activity;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;


import com.github.barteksc.pdfviewer.PDFView;
import com.wps.memberapp.R;
import com.wps.memberapp.utility.Logger;


import java.io.File;

import butterknife.BindView;
import butterknife.ButterKnife;

public class PDFActivity extends Activity {
    @BindView(R.id.pdfView) PDFView pdfView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pdf);
        ButterKnife.bind(this);
        File pdfFile = new File(Environment.getExternalStorageDirectory() + "/Immunization History/" + "ihistory.pdf");
        try {
            pdfView.fromFile(pdfFile).enableDoubletap(true).load();
        } catch (Exception e) {
            Logger.e("Ex",e);
        }
    }
}
