package com.wps.memberapp.presentation.immunization.adapter;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.presentation.immunization.fragment.ImmunizationAppointmentFragment;
import com.wps.memberapp.utility.Logger;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

public class ImmunizationAppointmentAdapter extends RecyclerView.Adapter<ImmunizationAppointmentAdapter.IdCardViewHolder> {

    //This context  will be used to inflate the layout
    private final Context mCtx;
    private final Activity context;
    //We are storing all the product in a list
    private final List<MemberDetails> memberDetailList;

    //getting the context and product list with constructor
    public ImmunizationAppointmentAdapter(Context mCtx, Activity activity, List<MemberDetails> memberDetailList) {
        this.mCtx = mCtx;
        this.memberDetailList=memberDetailList;
        this.context=activity;
    }

    @NonNull
    @Override
    public IdCardViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.frag_immunization_member_detail, parent,false);
        return new IdCardViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final IdCardViewHolder holder, final int position) {

        final MemberDetails memberDetails = memberDetailList.get(position);

        if(memberDetails!=null){
            String name=memberDetails.getFirstName()+ "  " + memberDetails.getLastName();
            holder.idCardMemberDetailTextView.setText(name);
            if(memberDetails.getFirstName().equals("John")){
                holder.imageView1.setBackgroundResource(R.drawable.ic_avatar);
            }
            else{
                holder.imageView1.setBackgroundResource(R.drawable.ic_avatar);
            }
            SimpleDateFormat format = new SimpleDateFormat("yyyy-mm-dd", Locale.ENGLISH);
            Date newDate = null;
            try {
                if(memberDetails.getDateOfBirth()!=null && !memberDetails.getDateOfBirth().equals("null"))
                {
                    newDate = format.parse(memberDetails.getDateOfBirth());
                }
            } catch (ParseException e) {
                Logger.e("ex",e);
            }
            format = new SimpleDateFormat("mm/dd/yyyy", Locale.ENGLISH);
            String date = format.format(newDate);
            holder.dobDetailsTextView.setText(date);
            holder.cardView.setOnClickListener(view -> {
                ImmunizationAppointmentFragment idCardDetailView = new ImmunizationAppointmentFragment();
                SharedPreferenceHelper.getInstance().setPreference(context,"id","3");
                Bundle data=new Bundle();
                data.putParcelable("data",memberDetails);
                idCardDetailView.setArguments(data);
                ((AppCompatActivity)context).getSupportFragmentManager().beginTransaction().
                        replace(R.id.frame_container,idCardDetailView).addToBackStack("null").commit();
            });

        }
    }

    @Override
    public int getItemCount() {
        return memberDetailList.size();
    }

    class IdCardViewHolder extends RecyclerView.ViewHolder {

        final TextView idCardMemberDetailTextView;
        final TextView dobDetailsTextView;
        private final CardView cardView;
        private final ImageView imageView1;

        IdCardViewHolder(View itemView) {
            super(itemView);
            cardView=itemView.findViewById(R.id.immunizationHistory);
            idCardMemberDetailTextView =  itemView.findViewById(R.id.memberValue);
            dobDetailsTextView = itemView.findViewById(R.id.dobValue);
            imageView1= itemView.findViewById(R.id.imageViewAvatar);
        }

    }

}
