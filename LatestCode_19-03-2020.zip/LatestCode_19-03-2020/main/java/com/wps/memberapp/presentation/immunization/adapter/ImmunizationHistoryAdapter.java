package com.wps.memberapp.presentation.immunization.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import com.wps.memberapp.R;
import com.wps.memberapp.data.model.ImmunizationHistory;
import com.wps.memberapp.presentation.immunization.fragment.ImmunizationHistoryProvider;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


public class ImmunizationHistoryAdapter extends RecyclerView.Adapter<ImmunizationHistoryAdapter.MyViewHolder> {

    private final Context context;
    private final List<ImmunizationHistoryProvider> medicineList;

    class MyViewHolder extends RecyclerView.ViewHolder {
        final TextView medicine;
        final RecyclerView recyclerView;
        final TextView tvProvider;
        final TextView tvDateofservice;
        final TextView tvSno;

        MyViewHolder(View view) {
            super(view);
            medicine = view.findViewById(R.id.tv_medicine_name);
            recyclerView = view.findViewById(R.id.rv_immunization_history_sub_list);
            tvProvider = view.findViewById(R.id.tv_provider_name);
            tvSno = view.findViewById(R.id.tv_sno);
            tvDateofservice = view.findViewById(R.id.tv_dateof_service);
        }
    }

    public ImmunizationHistoryAdapter(Context context, List<ImmunizationHistoryProvider> medicineList) {
        this.context = context;
        this.medicineList = medicineList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.immunization_history_item,
                parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        ImmunizationHistoryProvider med = medicineList.get(position);
        holder.medicine.setText(med.getVaccineGroupID());
        holder.tvSno.setText("1");
        holder.tvProvider.setText(med.getProviderName());
        holder.tvDateofservice.setText(med.getDateOfService());
       /* RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(context);
        holder.recyclerView.setLayoutManager(mLayoutManager);
        holder.recyclerView.setItemAnimator(new DefaultItemAnimator());
        holder.recyclerView.setAdapter(new ImmunizationHistorySubAdapter(med.getProvidersList()));*/
    }

    @Override
    public int getItemCount() {
        return medicineList.size();
    }
}
