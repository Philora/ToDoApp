package com.wps.memberapp.presentation.immunization.adapter;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.presentation.immunization.fragment.ImmunizationHistoryProvider;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ImmunizationHistorySubAdapter extends RecyclerView.Adapter<ImmunizationHistorySubAdapter.MyViewHolder> {

    private final List<ImmunizationHistoryProvider> providerList;
    private int i=0;

     class MyViewHolder extends RecyclerView.ViewHolder {
         final TextView tvProvider;
         final TextView tvDateofservice;
         final TextView tvSno;


         MyViewHolder(View view) {
            super(view);
            tvProvider = view.findViewById(R.id.tv_provider_name);
            tvSno =  view.findViewById(R.id.tv_sno);
            tvDateofservice =  view.findViewById(R.id.tv_dateof_service);
        }
    }

     ImmunizationHistorySubAdapter(List<ImmunizationHistoryProvider> providerList) {
        this.providerList = providerList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.immunization_history_sub_item, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        i++;
        holder.tvSno.setText(""+i);
        ImmunizationHistoryProvider med=providerList.get(position);
        holder.tvProvider.setText(med.getProviderName());
        holder.tvDateofservice.setText(med.getDateOfService());
    }

    @Override
    public int getItemCount() {
        return providerList.size();
    }
}
