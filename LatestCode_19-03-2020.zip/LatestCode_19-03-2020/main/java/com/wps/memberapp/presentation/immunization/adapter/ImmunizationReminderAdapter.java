package com.wps.memberapp.presentation.immunization.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.utility.Logger;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;


public class ImmunizationReminderAdapter extends RecyclerView.Adapter<ImmunizationReminderAdapter.IdCardViewHolder> {

    //This context  will be used to inflate the layout
    private final Context mCtx;
    //We are storing all the product in a list
    private final List<MemberDetails> memberDetailList;
    private final List<String> dependentsList;
    //getting the context and product list with constructor

    public ImmunizationReminderAdapter(Context mCtx, List<MemberDetails> memberDetailList) {
        this.mCtx = mCtx;
        dependentsList = new ArrayList<>();
        this.memberDetailList = memberDetailList;
    }

    @NonNull
    @Override
    public IdCardViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.immunization_reminder_item, parent, false);
        return new IdCardViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final IdCardViewHolder holder, final int position) {

        final MemberDetails memberDetails = memberDetailList.get(position);

        if (memberDetails != null) {
            String name = memberDetails.getFirstName() + "  " + memberDetails.getLastName();
            holder.idCardMemberDetailTextView.setText(name);
            holder.imageView.setBackgroundResource(R.drawable.ic_avatar);
            SimpleDateFormat format = new SimpleDateFormat("yyyy-mm-dd", Locale.ENGLISH);
            Date newDate = null;
            try {
                if (memberDetails.getDateOfBirth() != null && !memberDetails.getDateOfBirth().equals("null")) {
                    newDate = format.parse(memberDetails.getDateOfBirth());
                }
            } catch (ParseException e) {
                Logger.e("ex", e);
            }
            format = new SimpleDateFormat("mm/dd/yyyy", Locale.ENGLISH);
            String date = format.format(newDate);
            holder.dobDetailsTextView.setText(date);
            holder.reminderSwitch.setActivated(false);
            holder.reminderSwitch.setOnClickListener(view -> {
                if (holder.reminderSwitch.isActivated()) {
                    dependentsList.remove(memberDetails.getPersonNumber());
                    holder.reminderSwitch.setActivated(false);
                } else {
                    dependentsList.add(memberDetails.getPersonNumber());
                    holder.reminderSwitch.setActivated(true);
                }
            });
            holder.cardView.setOnClickListener(view -> {
                //Not used
            });

        }
    }

    @Override
    public int getItemCount() {
        return memberDetailList.size();
    }

    class IdCardViewHolder extends RecyclerView.ViewHolder {

        final TextView idCardMemberDetailTextView;
        final TextView dobDetailsTextView;
        private final CardView cardView;
        private final ImageView imageView;
        private final ImageView reminderSwitch;

        IdCardViewHolder(View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.immunizationReminder);
            idCardMemberDetailTextView = itemView.findViewById(R.id.memberName);
            dobDetailsTextView = itemView.findViewById(R.id.dobValue);
            imageView = itemView.findViewById(R.id.imageViewAvatar);
            reminderSwitch = itemView.findViewById(R.id.switch_reminder);
        }

    }

    public List<String> getDependentsList() {
        return dependentsList;
    }
}
