package com.wps.memberapp.presentation.immunization.fragment;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;


import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.base.BaseFragment;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;


public class AddVaccineFragment extends BaseFragment implements View.OnClickListener {

    @BindView(R.id.dateValue)
    EditText dateValue;
    @BindView(R.id.vaccine)
    EditText vaccine;
    @BindView(R.id.dateIcon)
    ImageView dateIcon;
    @BindView(R.id.dropdown)
    ImageView dropdown;
    @BindView(R.id.btn_save)
    Button save;
    @BindView(R.id.memberPhoto)
    ImageView photo;
    @BindView(R.id.memberName)
    TextView name;
    @BindView(R.id.memberDob)
    TextView dob;
    @BindView(R.id.edt_providerValue)
    EditText edtProviderName;
    private PopupMenu menu;
    private AlertDialog dialog;
    private HashMap<String, String> vaccinesMap;
    private Unbinder unbinder;

    public static AddVaccineFragment newInstance() {
        return new AddVaccineFragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        View rootView = inflater.inflate(R.layout.fragment_add_vaccine, container, false);
        unbinder = ButterKnife.bind(this, rootView);
        MemberDetails details = getArguments().getParcelable("data");
        if (details != null) {
            String nameVale = details.getFirstName() + " " + details.getLastName();
            name.setText(nameVale);
            String dobValue = details.getDateOfBirth() + " (DOB)";
            dob.setText(dobValue);
            SharedPreferenceHelper.getInstance().setPreference(getActivity(), "MEMBER_ID", details.getfMSSeqMemberId());
            SharedPreferenceHelper.getInstance().setPreference(getActivity(), "MEMBER_FNAME", details.getFirstName());
            SharedPreferenceHelper.getInstance().setPreference(getActivity(), "MEMBER_LNAME", details.getLastName());
            SharedPreferenceHelper.getInstance().setPreference(getActivity(), "MEMBER_DOB", details.getDateOfBirth());
        }
        dateIcon.setOnClickListener(this);
        dropdown.setOnClickListener(this);
        save.setOnClickListener(this);
        TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
        fragmentTitle.setText(R.string.add_vaccine);
        menu = new PopupMenu(getActivity(), dropdown);
        vaccinesMap = ProfileDataCache.getInstance().getVaccinesList();
        if (vaccinesMap == null) {
            vaccinesMap = new LinkedHashMap<>();
            getVaccineList();
        } else {
            for (Map.Entry entry : vaccinesMap.entrySet()) {
                menu.getMenu().add(entry.getKey().toString());
            }
        }

        menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                vaccine.setError(null);
                vaccine.setText(menuItem.getTitle());
                String vaccineValue = vaccinesMap.get(menuItem.getTitle().toString());
                SharedPreferenceHelper.getInstance().setPreference(getActivity(), "VACCINE_GROUP_ID", vaccineValue);
                return false;
            }
        });
        return rootView;
    }

    /* Used to create the datepicker dialog to select the data and populate*/
    private void showDatePickerforCalendar() {
        Calendar calender = Calendar.getInstance();
        DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(),
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {
                        dateValue.setError(null);
                        String date = year + "-" + (monthOfYear + 1) + "-" + dayOfMonth;
                        dateValue.setText(date);
                    }
                }, calender.get(Calendar.YEAR), calender.get(Calendar.MONTH), calender.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        datePickerDialog.show();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.dropdown:
                menu.show();
                break;
            case R.id.btn_save:
                if (vaccine.getText().toString().length() == 0) {
                    vaccine.requestFocus();
                    vaccine.setError(getString(R.string.please_select_vaccine));
                    return;
                }
                if (dateValue.getText().toString().length() == 0) {
                    dateValue.requestFocus();
                    dateValue.setError(getString(R.string.please_select_date));
                    return;
                }
                if (dateValue.getText().toString().length() == 0) {
                    dateValue.requestFocus();
                    dateValue.setError(getString(R.string.please_select_date));
                    return;
                }
                String dos = dateValue.getText().toString();
                String mProviderName = edtProviderName.getText().toString();
                SharedPreferenceHelper.getInstance().setPreference(getActivity(), "DATE_OF_SERVICE", dos);
                SharedPreferenceHelper.getInstance().setPreference(getActivity(), "PROVIDER_NAME", mProviderName);
                dateValue.setText("");
                vaccine.setText("");
                addVaccine();
                break;
            case R.id.dateIcon:
                showDatePickerforCalendar();
                break;
            default:
                break;
        }
    }

    private void getVaccineList() {
//Displaying progress dialog
        final ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage("Please Wait ...");
        progressDialog.setCancelable(false);
        progressDialog.show();
        VolleyService.getVaccineList(getActivity(),
                AppConstants.GET_VACCINE_LIST_URL, new VolleyResponseListener() {
                    @Override
                    public void onError(String error) {
                        progressDialog.dismiss();
                        showLog(error);
                    }

                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        showLog(response);
                        try {
                            JSONArray data = new JSONArray(response);
                            for (int i = 0; i < data.length(); i++) {
                                JSONObject obj = data.getJSONObject(i);
                                String item = obj.getString("Text");
                                String value = obj.getString("Value");
                                vaccinesMap.put(item, value);
                            }
                            for (Map.Entry entry : vaccinesMap.entrySet()) {
                                menu.getMenu().add(entry.getKey().toString());
                            }
                            ProfileDataCache.getInstance().setVaccinesList(vaccinesMap);
                        } catch (Exception e) {
                            Logger.e("Exc", e);
                        }
                    }

                });
    }

    private void addVaccine() {
//Displaying progress dialog
        final ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage("Please Wait ...");
        progressDialog.setCancelable(false);
        progressDialog.show();
        VolleyService.addVaccine(getActivity(), AppConstants.ADD_VACCINE_URL, new VolleyResponseListener() {
            @Override
            public void onError(String error) {
                progressDialog.dismiss();
                showLog(error);
            }

            @Override
            public void onResponse(String response) {
                try {
                    progressDialog.dismiss();
                    showResponse(response);
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
            }

        });
    }

    private void showResponse(String response) {
        showLog(response);
        try {
            if ("true".equals(response)) {
                AlertDialog.Builder alret = new AlertDialog.Builder(getActivity())
                        .setTitle("Status")
                        .setMessage("Vaccine added successful")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialog.dismiss();
                                getActivity().getFragmentManager().popBackStack();
                            }
                        });
                dialog = alret.create();
                dialog.show();
            } else {
                Toast.makeText(getActivity(), "Vaccine not added", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Logger.e("Exception", e);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }
}
