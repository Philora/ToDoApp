package com.wps.memberapp.presentation.immunization.fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.google.android.material.bottomnavigation.BottomNavigationItemView;
import com.google.android.material.bottomnavigation.BottomNavigationMenuView;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.wps.memberapp.R;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.presentation.base.BaseFragment;
import java.lang.reflect.Field;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class ImmunizationDashBoard extends BaseFragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        container.clearDisappearingChildren();
        View rootView = inflater.inflate(R.layout.fragment_immunization_dashboard, container, false);
        BottomNavigationView bottomNavigationView = rootView.findViewById(R.id.navigationView);
        BottomNavigationViewHelper.removeShiftMode(bottomNavigationView);
        TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
        fragmentTitle.setText(R.string.text_immunization_history);
        bottomNavigationView.setOnNavigationItemSelectedListener
                (new BottomNavigationView.OnNavigationItemSelectedListener() {

                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                        Fragment selectedFragment;
                        switch (item.getItemId()) {
                            case R.id.action_item1:
                                selectedFragment = ImmunizationMemberDetailsFragment.newInstance();
                                break;
                            case R.id.action_item2:
                                selectedFragment = ImmunizationReminderFragment.newInstance();
                                break;
                            case R.id.action_item3:
                                selectedFragment = ImmunizationAppointmentHistoryFragment.newInstance();
                                break;
                            case R.id.action_item4:
                                selectedFragment = ImmunizationVaccineFragment.newInstance();
                                break;
                            default:
                                selectedFragment = ImmunizationMemberDetailsFragment.newInstance();
                                break;
                        }

                        FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
                        transaction.replace(R.id.frame_layout_immunization, selectedFragment);
                        transaction.addToBackStack(null).commit();
                        return true;
                    }
                });

        //Manually displaying the first fragment - one time only
        int id = Integer.parseInt(SharedPreferenceHelper.getInstance().getPreference(getActivity(), "id"));
        Fragment selectedFragment;
        switch (id) {
            case 1:
                selectedFragment = ImmunizationMemberDetailsFragment.newInstance();
                break;
            case 2:
                selectedFragment = ImmunizationReminderFragment.newInstance();
                break;
            case 3:
                selectedFragment = ImmunizationAppointmentHistoryFragment.newInstance();
                break;
            case 4:
                selectedFragment = ImmunizationVaccineFragment.newInstance();
                break;
            default:
                selectedFragment = ImmunizationMemberDetailsFragment.newInstance();
                break;
        }
        FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
        transaction.replace(R.id.frame_layout_immunization, selectedFragment);
        transaction.addToBackStack(null).commit();
        return rootView;

    }
}

class BottomNavigationViewHelper {
    private BottomNavigationViewHelper() {
    }

    static void removeShiftMode(BottomNavigationView view) {
        BottomNavigationMenuView menuView = (BottomNavigationMenuView) view.getChildAt(0);
        try {
            Field shiftingMode = menuView.getClass().getDeclaredField("mShiftingMode");
            shiftingMode.setAccessible(true);
            shiftingMode.setBoolean(menuView, false);
            shiftingMode.setAccessible(false);
            for (int i = 0; i < menuView.getChildCount(); i++) {
                BottomNavigationItemView item = (BottomNavigationItemView) menuView.getChildAt(i);
                //item.setShiftingMode(false);
                // set once again checked value, so view will be updated
                item.setChecked(item.getItemData().isChecked());
            }
        } catch (NoSuchFieldException e) {
            Log.e("ERROR NO SUCH FIELD", "Unable to get shift mode field");
        } catch (IllegalAccessException e) {
            Log.e("ERROR ILLEGAL ALG", "Unable to change value of shift mode");
        }
    }
}

