package com.wps.memberapp.presentation.immunization.fragment;


import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.StringConstants;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public class ImmunizationFragment extends Fragment implements View.OnClickListener {

    /**
     * This override method is used to inflate the layout for Dashboard fragment
     *
     * @return rootView
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        if (container != null) {
            container.removeAllViews();
            container.clearDisappearingChildren();
        }

        View rootView = inflater.inflate(R.layout.frag_immunization, container, false);

        if (getActivity() != null) {
            ImageView imageViewSearch = getActivity().findViewById(R.id.imageViewSearch);
            imageViewSearch.setVisibility(View.GONE);
            TextView txtDownloadPDF = getActivity().findViewById(R.id.txt_Call);
            txtDownloadPDF.setVisibility(View.GONE);
            TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
            fragmentTitle.setText(R.string.my_immunization);
        }

        ImageView imageViewSearch = getActivity().findViewById(R.id.imageViewSearch);
        imageViewSearch.setVisibility(View.GONE);
        imageViewSearch.setOnClickListener(view -> {
            SharedPreferenceHelper.getInstance().setPreference(getActivity(), "SearchQuery", "");
            FragmentManager fragmentManager = getFragmentManager();
            //fragmentManager.beginTransaction().replace(R.id.frame_container, new PegaSearchFragment()).addToBackStack(null).commit();
        });
        TextView txtProfileName = rootView.findViewById(R.id.txt_profile_name);
        CardView immunizationHistoryCardView =  rootView.findViewById(R.id.immunizationHistoryCardView);
        CardView immunizationReminderCardView =  rootView.findViewById(R.id.reminderCardView);
        CardView immunizationAppointmentCardView =  rootView.findViewById(R.id.appointmentCardView);
        CardView immunizationvaccineCardView =  rootView.findViewById(R.id.vaccineCardView);

        immunizationHistoryCardView.setOnClickListener(this);
        immunizationReminderCardView.setOnClickListener(this);
        immunizationAppointmentCardView.setOnClickListener(this);
        immunizationvaccineCardView.setOnClickListener(this);

        MemberDetails details = ProfileDataCache.getInstance().getmMemberDetails().get(0);
        String name = ProfileDataCache.getInstance().getFirstName() + StringConstants.SPACE_SINGLE + ProfileDataCache.getInstance().getLastName();
        txtProfileName.setText(String.valueOf(getActivity().getString(R.string.hello)+StringConstants.SPACE_SINGLE+name));
        return rootView;
    }

    @Override
    public void onClick(View view) {
        ImmunizationDashBoard historyFragment = new ImmunizationDashBoard();
        switch (view.getId()) {
            case R.id.immunizationHistoryCardView:
                SharedPreferenceHelper.getInstance().setPreference(getActivity(),"id","1");
                break;
            case R.id.reminderCardView:
                SharedPreferenceHelper.getInstance().setPreference(getActivity(),"id","2");
                break;
            case R.id.vaccineCardView:
                SharedPreferenceHelper.getInstance().setPreference(getActivity(),"id","4");
                break;
            case R.id.appointmentCardView:
                SharedPreferenceHelper.getInstance().setPreference(getActivity(),"id","3");
                break;
            default:
        }
        getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.frame_container, historyFragment).addToBackStack(null).commit();
    }
}
