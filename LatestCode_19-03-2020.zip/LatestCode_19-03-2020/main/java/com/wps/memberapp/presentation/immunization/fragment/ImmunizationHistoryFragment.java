package com.wps.memberapp.presentation.immunization.fragment;

import android.app.AlertDialog;
import android.app.Fragment;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.VolleyError;
import com.google.gson.Gson;
import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.ImmunizationHistory;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.domain.dataservice.VolleyByteResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.base.BaseFragment;
import com.wps.memberapp.presentation.immunization.activity.PDFActivity;
import com.wps.memberapp.presentation.immunization.adapter.ImmunizationHistoryAdapter;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import androidx.core.app.NotificationCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

public class ImmunizationHistoryFragment extends BaseFragment {
    private final List<ImmunizationHistory> immunizationHistoryList = new ArrayList<>();
    private ImmunizationHistoryAdapter mAdapter;
    private ProgressDialog progressDialog;
    private TextView noImmunizations;
    private static final String EXCEPTION = "exception";
    private NotificationManager mNotifyManager;
    private NotificationCompat.Builder mBuilder;
    @BindView(R.id.photo)
    ImageView photo;
    @BindView(R.id.name)
    TextView name;
    @BindView(R.id.dob)
    TextView dob;
    private Unbinder unbinder;
    String nameVale = "";
    RecyclerView recyclerView;

    public static ImmunizationHistoryFragment newInstance() {
        return new ImmunizationHistoryFragment();
    }

    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_immunization_history, container, false);
        unbinder = ButterKnife.bind(this, view);
        MemberDetails details = getArguments().getParcelable("data");
        if (details != null) {
            nameVale = details.getFirstName() + " " + details.getLastName();
            name.setText(nameVale);
            String dobValue = details.getDateOfBirth() + " (DOB)";
            dob.setText(dobValue);
            SharedPreferenceHelper.getInstance().setPreference(getActivity(), "MEMBER_ID", details.getfMSSeqMemberId());
        }
        recyclerView = view.findViewById(R.id.rv_immunization_history_list);
        Button download = view.findViewById(R.id.btn_download);
        noImmunizations = view.findViewById(R.id.no_immunizations);
        download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                File pdfFile = new File(Environment.getExternalStorageDirectory() + "/Immunization History/" + "ihistory.pdf");
                boolean status = pdfFile.delete();
                if (status) {
                    Toast.makeText(getActivity(), "Please check notification bar for progress", Toast.LENGTH_SHORT).show();
                }
              /*  mNotifyManager = (NotificationManager) getActivity().getSystemService(Context.NOTIFICATION_SERVICE);
                mBuilder = new NotificationCompat.Builder(getActivity());
                mBuilder.setContentTitle("Immunization History").setContentText("Downloading...");
                // Start a lengthy operation in a background thread
                mBuilder.setProgress(0, 0, true);
                mBuilder.setAutoCancel(true);
                mNotifyManager.notify(1, mBuilder.build());*/
                downloadHistoryAsPDF();
            }
        });
        TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
        fragmentTitle.setText(R.string.text_immunization_history);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        getImmunizationHistoryByMemberID();

/*        if (ProfileDataCache.getInstance().getProviderVaccine() == null) {
            getImmunizationHistoryByMemberID();
        }*/

        return view;
    }

    private void getImmunizationHistoryByMemberID() {
        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setCancelable(false);
        progressDialog.show();
        VolleyService.getImmunizationHistoryByMemberID(getActivity(), AppConstants.GET_IMMUNIZATION_BY_SUBSCRIBER_ID_URL, new VolleyResponseListener() {
            @Override
            public void onResponse(String message) {
                progressDialog.dismiss();
                showLog(message);
                try {
                    if (message == null || message.equals("[]")) {
                        noImmunizations.setVisibility(View.VISIBLE);
                    } else {
                        noImmunizations.setVisibility(View.INVISIBLE);
                        JSONArray array = new JSONArray(message);
                        for (int j = 0; j < array.length(); j++) {
                            ImmunizationHistory history = new ImmunizationHistory();
                            List<ImmunizationHistoryProvider> mImmProvList = new ArrayList<>();
                            JSONObject jsonObject = array.getJSONObject(j);
                            JSONArray arrayVaccine = jsonObject.getJSONArray("memberVaccines");
                            for (int i = 0; i < arrayVaccine.length(); i++) {
                                ImmunizationHistoryProvider immProvHist = new ImmunizationHistoryProvider();
                                JSONObject jsonVaccine = arrayVaccine.getJSONObject(i);
                                if (jsonVaccine.getString("PROVIDER_FIRST_NAME") != null && jsonVaccine.getString("DATE_OF_SERVICE") != null && jsonVaccine.getString("VACCINE_GROUP_ID") != null) {
                                    String prov = jsonVaccine.getString("PROVIDER_FIRST_NAME");
                                    String dos = jsonVaccine.getString("DATE_OF_SERVICE");
                                    String groupID = jsonVaccine.getString("VACCINE_GROUP_ID");
                                    if (prov.equals("null")) {
                                        prov = "";
                                    }
                                    if (dos.equals("null")) {
                                        dos = "";
                                    }
                                    if (groupID.equals("null")) {
                                        groupID = "";
                                    }
                                    if (dos.length() > 1 && dos.contains("T")) {
                                        dos = dos.split("T")[0];
                                    }
                                    immProvHist.setProviderName(prov);
                                    immProvHist.setDateOfService(dos);
                                    immProvHist.setVaccineGroupID(groupID);
                                    mImmProvList.add(immProvHist);
                                }
                            }
                            String mname = jsonObject.getString("MEMBER_FIRST_NAME") + " " + jsonObject.getString("MEMBER_LAST_NAME");
                            if (mname.equalsIgnoreCase(nameVale)) {
                                history.setProvidersList(mImmProvList);
                                immunizationHistoryList.add(history);
                            }
                        }
                        if (!immunizationHistoryList.get(0).getProvidersList().isEmpty()) {
                            mAdapter = new ImmunizationHistoryAdapter(getActivity(), immunizationHistoryList.get(0).getProvidersList());
                            recyclerView.setAdapter(mAdapter);
                        }
                    }
                } catch (Exception e) {
                    noImmunizations.setVisibility(View.VISIBLE);
                    Logger.e(EXCEPTION, e);
                }

            }

            @Override
            public void onError(String error) {
                progressDialog.dismiss();
                showLog(error);
                noImmunizations.setVisibility(View.VISIBLE);
            }
        });
    }

    private void downloadHistoryAsPDF() {
        try {
            VolleyService.getImmunizationHistoyAsPDF(getActivity(), AppConstants.GET_IMMUNIZATION_HISTORY_URL, new VolleyByteResponseListener() {
                @Override
                public void onResponse(byte[] response) {
                    convertBytesToPDF(response);
                    Toast.makeText(getActivity(), "Download completed", Toast.LENGTH_LONG).show();
                    /*mBuilder.setContentText("Download completed");
                    mBuilder.setProgress(100, 100, false);
                    Intent notificationIntent = new Intent(getActivity(), PDFActivity.class);
                    notificationIntent.putExtra("isURL", false);
                    notificationIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    PendingIntent intent = PendingIntent.getActivity(getActivity(), 0, notificationIntent, 0);
                    mBuilder.setContentIntent(intent);
                    // Displays the progress bar for the first time.
                    mNotifyManager.notify(1, mBuilder.build());*/
                    showDialog();
                }

                @Override
                public void onError(VolleyError error) {
//                    Toast.makeText(getActivity(), "Download failed", Toast.LENGTH_LONG).show();
                    /*mBuilder.setContentText("Download failed");
                    mBuilder.setProgress(100, 100, false);
                    // Displays the progress bar for the first time.
                    mNotifyManager.notify(1, mBuilder.build());*/
                }
            });
        } catch (Exception e) {
            Logger.e("Exception", e);
        }
    }

    private void convertBytesToPDF(byte[] response) {
        BufferedOutputStream output = null;
        try {
            //covert reponse to input stream
            InputStream input = new ByteArrayInputStream(response);
            //Create a file on desired path and write stream data to it
            String extStorageDirectory = Environment.getExternalStorageDirectory().toString();
            File folder = new File(extStorageDirectory, "Immunization History");
            folder.mkdir();
            File pdfFile = new File(folder, "ihistory.pdf");
            output = new BufferedOutputStream(new FileOutputStream(pdfFile));
            byte[] data = new byte[1024];
            int count;
            while ((count = input.read(data)) != -1) {
                output.write(data, 0, count);
            }
            output.flush();

            input.close();
        } catch (IOException e) {
            Logger.e("ex", e);
        } finally {
            try {
                if (output != null)
                    output.close();
            } catch (Exception e) {
                Logger.e("Ec", e);
            }
        }
    }

    private void showDialog() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(getActivity());

        // Setting Dialog Title
        alertDialog.setTitle("Member App");

        // Setting Dialog Message
        alertDialog.setMessage("Immunization history download is completed, do you want to open?");

        // Setting OK Button
        alertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                // Write your code here to execute after dialog closed
                dialog.dismiss();
                startActivity(new Intent(getActivity(), PDFActivity.class));
            }
        });

        // Setting OK Button
        alertDialog.setNegativeButton("No", null);

        AlertDialog dialog = alertDialog.create();

        // Showing Alert Message
        dialog.show();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }
}
