package com.wps.memberapp.presentation.immunization.fragment;


public class ImmunizationHistoryProvider {
    private String providerName;
    private String dateOfService;

    public String getVaccineGroupID() {
        return vaccineGroupID;
    }

    public void setVaccineGroupID(String vaccineGroupID) {
        this.vaccineGroupID = vaccineGroupID;
    }

    private String vaccineGroupID;

    public String getProviderName() {
        return providerName;
    }

    void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    public String getDateOfService() {
        return dateOfService;
    }

    void setDateOfService(String dateOfService) {
        this.dateOfService = dateOfService;
    }
}
