package com.wps.memberapp.presentation.immunization.fragment;

import android.app.Activity;
import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;


import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.base.BaseFragment;
import com.wps.memberapp.presentation.immunization.adapter.ImmunizationReminderAdapter;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.GeneralUtils;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


public class ImmunizationReminderFragment extends BaseFragment {

    private ProgressDialog progressDialog;
    private Switch immuFlag;
    private Switch appointFlag;
    private ImmunizationReminderAdapter adapter;
    private AlertDialog dialog;

    public static ImmunizationReminderFragment newInstance() {
        return new ImmunizationReminderFragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        container.clearDisappearingChildren();
        View rootView = inflater.inflate(R.layout.frag_view_immunization_reminder, container, false);
        immuFlag = rootView.findViewById(R.id.switch_reminder);
        appointFlag = rootView.findViewById(R.id.switch_reminder1);
        RecyclerView rv = rootView.findViewById(R.id.recyclerImmunizationReminderView);
        rv.setHasFixedSize(true);
        rv.setNestedScrollingEnabled(false);
        Button mSave = rootView.findViewById(R.id.btn_save);
        mSave.setOnClickListener(view -> registerForImmunization());
        final LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        rv.setLayoutManager(layoutManager);

        if (getActivity() != null) {
            ImageView imageViewSearch = getActivity().findViewById(R.id.imageViewSearch);
            imageViewSearch.setVisibility(View.GONE);
            TextView txtDownloadPDF = getActivity().findViewById(R.id.txt_Call);
            txtDownloadPDF.setVisibility(View.GONE);
            TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
            fragmentTitle.setText(R.string.text_immunization_reminder);
        }

        List<MemberDetails> detailsList = ProfileDataCache.getInstance().getmMemberDetails();
        adapter = new ImmunizationReminderAdapter(getActivity(), detailsList);
        rv.setItemAnimator(new DefaultItemAnimator());
        rv.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        return rootView;

    }

    private void registerForImmunization() {
        List<String> list = adapter.getDependentsList();
        if (list.isEmpty()) {
            GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.please_select_any_one_member));
        } else {
            showAlertDialog(getActivity(), getActivity().getString(R.string.immunization_reminder_saved_success));

        }
        /*ProfileDataCache.getInstance().setIdsList(list);
        SharedPreferenceHelper.getInstance().setPrefBoolean(getActivity(), "APPOINTMENT_FLAG", appointFlag.isChecked());
        SharedPreferenceHelper.getInstance().setPrefBoolean(getActivity(), "REMINDER_FLAG", immuFlag.isChecked());
        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setCancelable(false);
        progressDialog.show();
        VolleyService.registerImmunization(getActivity(),
                AppConstants.IMMUNIZATION_REGISTRATION_URL, new VolleyResponseListener() {
                    @Override
                    public void onError(String error) {
                        progressDialog.dismiss();
                        showLog(error);
                    }

                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        showLog(response);
                        if (getActivity() != null) {
                            adapter.notifyDataSetChanged();
                            Toast.makeText(getActivity(), "Details saved succesfully", Toast.LENGTH_SHORT).show();
                        }
                    }
                });*/
    }

    private void showAlertDialog(@NonNull Activity activity, String msg) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setCancelable(false)
                .setMessage(msg)
                .setPositiveButton(getActivity().getString(R.string.ok), (dialogInterface, i) -> {
                    dialog.dismiss();
                    ((AppCompatActivity) getActivity()).getSupportFragmentManager().popBackStack();
                });
        dialog = builder.create();
        dialog.show();
    }
}
