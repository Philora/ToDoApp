package com.wps.memberapp.presentation.immunization.fragment;

import android.app.Fragment;
import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.presentation.base.BaseFragment;
import com.wps.memberapp.presentation.immunization.adapter.ImmunizationVaccineAdapter;
import com.wps.memberapp.utility.GeneralUtils;

import java.util.List;

import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


public class ImmunizationVaccineFragment extends BaseFragment {

    public static ImmunizationVaccineFragment newInstance() {
        return new ImmunizationVaccineFragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        if (container != null) {
            container.removeAllViews();
            container.clearDisappearingChildren();
        }
        View rootView = inflater.inflate(R.layout.fragment_vaccine, container, false);
        RecyclerView rv = rootView.findViewById(R.id.recyclerImmunizationHistoryView);
        rv.setHasFixedSize(true);
        final LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        rv.setLayoutManager(layoutManager);

        if (getActivity() != null) {
            ImageView imageViewSearch = getActivity().findViewById(R.id.imageViewSearch);
            imageViewSearch.setVisibility(View.GONE);
            TextView txtDownloadPDF = getActivity().findViewById(R.id.txt_Call);
            txtDownloadPDF.setVisibility(View.GONE);
            TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
            fragmentTitle.setText(R.string.add_vaccine_history);
        }

        List<MemberDetails> detailsList = ProfileDataCache.getInstance().getmMemberDetails();
        ImmunizationVaccineAdapter adapter = new ImmunizationVaccineAdapter(getActivity(), getActivity(), detailsList);
        rv.setItemAnimator(new DefaultItemAnimator());
        rv.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        return rootView;
    }
}

