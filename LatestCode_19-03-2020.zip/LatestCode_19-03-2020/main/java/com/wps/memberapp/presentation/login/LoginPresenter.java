package com.wps.memberapp.presentation.login;


import com.wps.memberapp.presentation.base.MvpPresenter;

import javax.crypto.Cipher;

/*
This interface contain all the login functionality declarations.
 */
public interface LoginPresenter extends MvpPresenter {
    boolean isUsernameValid(String param2);
    boolean isPasswordValid(String param1);
    void onLoginClicked();
    void onForgotPasswordClicked();
    void onFingerPrintSelected(Cipher cipher, String key);
    void onFingerPrintLogin();

    void onFaceAuthLogin();
}
