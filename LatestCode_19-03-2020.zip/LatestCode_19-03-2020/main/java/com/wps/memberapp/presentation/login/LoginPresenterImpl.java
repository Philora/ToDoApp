package com.wps.memberapp.presentation.login;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Build;
import android.preference.PreferenceManager;
import android.util.Log;
import android.util.Patterns;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.exception.CipherException;
import com.wps.memberapp.data.model.DashboardData;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.model.MemberEligibleInfo;
import com.wps.memberapp.data.model.MemberGroupDetails;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.base.MvpView;
import com.wps.memberapp.presentation.groupmanagement.GroupView;
import com.wps.memberapp.presentation.login.activity.ConfirmFacePrintActivity;
import com.wps.memberapp.presentation.login.activity.ConfirmFingerprintActivity;
import com.wps.memberapp.presentation.login.activity.LoginActivity;
import com.wps.memberapp.presentation.login.fragment.FingerprintAuthenticationDialogFragment;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;

/**
 * This class is used to implement all the login functions which
 * are declared in LoginPresenter.
 */
public class LoginPresenterImpl implements LoginPresenter {
    private MvpView mView;
    private KeyStore mKeyStore;
    private static final String DEFAULT_KEY_NAME = "default_key";
    private static final String DIALOG_FRAGMENT_TAG = "myFragment";

    /*
    This method is used to validate the username.
     */
    @Override
    public boolean isUsernameValid(@NonNull String param2) {
        boolean isValid = true;
        if (param2.length() < 6 || param2.length() > 40) {
            isValid = false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(param2).matches()) {
            Pattern p = Pattern.compile(StringConstants.USERNAME_REGEX, Pattern.CASE_INSENSITIVE);
            Matcher m = p.matcher(param2);
            if (m.find()) {
                isValid = false;
            }
        }
        return isValid;
    }

    /*
   This method is used to validate the password.
    */
    @Override
    public boolean isPasswordValid(@NonNull String param1) {
        boolean isValid = true;
        Pattern pattern = Pattern.compile(StringConstants.MPARAM_REGEX);
        if (param1.length() < 9 || param1.length() > 20) {
            isValid = false;
        }
        if (!pattern.matcher(param1).matches()) {
            isValid = false;
        }
        return isValid;
    }

    @Override
    public void onLoginClicked() {
        if (mView.isNetworkConnected()) {

            issueSTCTokenRequest();
        } else {
            mView.hideProgress();
            mView.showNetworkError(mView.getAppContext().getString(R.string.login_no_internet));
        }
    }

    @Override
    public void onFingerPrintLogin() {
        if (mView.isNetworkConnected()) {
            issueSTCTokenRequest();
        } else {
            mView.hideProgress();
            mView.showNetworkError(mView.getAppContext().getString(R.string.login_no_internet));
        }
    }

    @Override
    public void onFaceAuthLogin() {
        if (mView.isNetworkConnected()) {
            issueSTCTokenRequest();
        } else {
            mView.hideProgress();
            mView.showNetworkError(mView.getAppContext().getString(R.string.login_no_internet));
        }
    }

    @Override
    public void onForgotPasswordClicked() {
        ((LoginView) mView).openForgotPasswordActivity();
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onFingerPrintSelected(Cipher mCipher, String mKeyName) {
        try {
            if (initCipher(mCipher, mKeyName)) {

                FingerprintAuthenticationDialogFragment fragment
                        = new FingerprintAuthenticationDialogFragment();
                fragment.setCryptoObject(new FingerprintManager.CryptoObject(mCipher));
                SharedPreferences mSharedPreferences = PreferenceManager.getDefaultSharedPreferences(mView.getAppContext());
                boolean useFingerprintPreference = mSharedPreferences.getBoolean(mView.getAppContext().getString(R.string.use_fingerprint_to_authenticate_key), true);
                if (useFingerprintPreference) {
                    fragment.setStage(
                            FingerprintAuthenticationDialogFragment.Stage.FINGERPRINT);
                } else {
                    fragment.setStage(
                            FingerprintAuthenticationDialogFragment.Stage.PASSWORD);
                }
                fragment.show(mView.getAppContext().getFragmentManager(), DIALOG_FRAGMENT_TAG);
            } else {
                FingerprintAuthenticationDialogFragment fragment
                        = new FingerprintAuthenticationDialogFragment();
                fragment.setCryptoObject(new FingerprintManager.CryptoObject(mCipher));
                fragment.setStage(
                        FingerprintAuthenticationDialogFragment.Stage.NEW_FINGERPRINT_ENROLLED);
                fragment.show(mView.getAppContext().getFragmentManager(), DIALOG_FRAGMENT_TAG);
            }
        } catch (Exception e) {
            Logger.e("tag", e);
        }
    }

    @Override
    public void onAttach(MvpView mView) {
        this.mView = mView;
        /*
         * Creates a symmetric key in the Android Key Store which can only be used after the user has
         * authenticated with fingerprint
         */
        try {
            mKeyStore = KeyStore.getInstance("AndroidKeyStore");
        } catch (KeyStoreException e) {
            Log.d(DEFAULT_KEY_NAME, e.getMessage());
        }
    }

    @Override
    public void onDetach() {
        mView = null;
    }

    /**
     * Volley Post Request String responses from the Web API
     * In case of static Json response, load file from assets
     */
    private void issueSTCTokenRequest() {
        VolleyService.issueSTCToken
                (mView.getAppContext(), AppConstants.LOGIN_STC_TOKEN, new VolleyResponseListener() {
                    @Override
                    public void onError(String error) {
                        ProfileDataCache.getInstance().clearCache();
                        mView.hideProgress();
                        ((LoginView) mView).onInvalidaCredentialsEntered(error);
                        Log.d("LoginPresenterImp", "onError: " + error);
                    }

                    @Override
                    public void onResponse(String response) {
                        try {
                            mView.showLog(response);
                            if (response != null) {
                                VolleyService.issueSAMLFedAuth(mView.getAppContext(),
                                        AppConstants.LOGIN_FED_AUTH_TOKEN, new VolleyResponseListener() {
                                            @Override
                                            public void onError(String error) {
                                                mView.hideProgress();
                                                mView.showLog(error);
                                            }

                                            @Override
                                            public void onResponse(String response) {
                                                try {
                                                    mView.showLog(response);
                                                    ProfileDataCache.getInstance().clearCache();

                                                    VolleyService.getMemberGroupList(mView.getAppContext(), AppConstants.GET_MEMBER_GROUP_LIST, new VolleyResponseListener() {
                                                        @Override
                                                        public void onError(String error) {
                                                            mView.hideProgress();
                                                        }

                                                        @Override
                                                        public void onResponse(String message) {
                                                            try {
                                                                parseMemberGroupResponse(message);
                                                            } catch (Exception e) {
                                                                e.getLocalizedMessage();
                                                            }
                                                        }
                                                    });
                                                } catch (Exception e) {
                                                    e.getLocalizedMessage();
                                                }
                                            }
                                        });
                            }

                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    }
                });
    }


    /*
     * This method is used to call Get Profile, Get user profile, Get member details , member eligible info APIs.
     */
    public void callProfileAPIs() {
        VolleyService.getProfileData(mView.getAppContext(), AppConstants.GET_PROFILE_DETAILS, new VolleyResponseListener() {
            @Override
            public void onError(String error) {
                mView.hideProgress();
                mView.showLog(error);
            }

            @Override
            public void onResponse(String response) {
                try {
                    mView.showLog(response);
                    if (response != null) {
                        ProfileDataCache.getInstance().clearCache();
                        DashboardData data = new Gson().fromJson(response, DashboardData.class);
                        ProfileDataCache.getInstance().setDashboardData(data);
                        SharedPreferenceHelper.getInstance().setPreference(mView.getAppContext(), "ProfileID", data.getProfileId());
                        SharedPreferenceHelper.getInstance().setPreference(mView.getAppContext(), "UserID", data.getUserId());
                        if (LoginActivity.isFingerFlow) {
                            mView.hideProgress();
                            SharedPreferenceHelper.getInstance().clearPreference(mView.getAppContext(), "sessionid");
                            Intent intent = new Intent(mView.getAppContext(), ConfirmFingerprintActivity.class);
                            mView.getAppContext().startActivity(intent);
                            return;
                        }
                        if (LoginActivity.isFaceFlow) {
                            mView.hideProgress();
                            SharedPreferenceHelper.getInstance().clearPreference(mView.getAppContext(), "sessionid");
                            Intent intent = new Intent(mView.getAppContext(), ConfirmFacePrintActivity.class);
                            mView.getAppContext().startActivity(intent);
                            return;
                        }
                    }
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
                VolleyService.getUserProfileData(mView.getAppContext(), AppConstants.GET_USER_PROFILE_DETAILS, new VolleyResponseListener() {
                    @Override
                    public void onError(String error) {
                        mView.hideProgress();
                        mView.showLog(error);
                    }

                    @Override
                    public void onResponse(String response) {
                        try {
                            mView.showLog(response);
                            parseUserProfileResponse(response);
                            VolleyService.getMemberEligInfo(mView.getAppContext(), AppConstants.GET_MEMBER_ELIGINFO, new VolleyResponseListener() {
                                @Override
                                public void onError(String error) {
                                    mView.hideProgress();
                                    mView.showLog(error);
                                }

                                @Override
                                public void onResponse(String response) {
                                    try {
                                        mView.showLog(response);
                                        if (response != null) {
                                            MemberEligibleInfo data = new Gson().fromJson(response, MemberEligibleInfo.class);
                                            ProfileDataCache.getInstance().setMemberEligibleInfo(data);
                                        }
                                        VolleyService.getMemberDetails(mView.getAppContext(), AppConstants.GET_MEMBER_DETAILS, new VolleyResponseListener() {
                                            @Override
                                            public void onError(String error) {
                                                mView.hideProgress();
                                                Log.i("Member Error", error);
                                            }

                                            @Override
                                            public void onResponse(String response) {
                                                try {
                                                    if (response !=null) { // Checking Null
                                                        parseMemberDetailsResponse(response);
                                                    }
                                                    if (mView instanceof LoginView) {
                                                        ((LoginView) mView).openDashboardActivity(new ArrayList<>());
                                                    } else {
                                                        ((GroupView) mView).onAPIsLoadingCompleted();
                                                    }
                                                }catch (Exception e){
                                                    e.getLocalizedMessage();
                                                }
                                            }
                                        });
                                    } catch (Exception e){
                                        e.getLocalizedMessage();
                                    }
                                }
                            });
                        }catch (Exception e){
                            e.getLocalizedMessage();
                        }
                    }
                });

            }
        });
    }

    /*
     * This method is used to parse Get plans API response.
     */
    private void parseMemberGroupResponse(String message) {
        if (message != null) {
            try {
                Gson gson = new Gson();
                JSONArray jsonArray = new JSONArray(message);
                List<MemberGroupDetails> detailsList = new ArrayList<>();
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    MemberGroupDetails details = gson.fromJson(jsonObject.toString(), MemberGroupDetails.class);
                    detailsList.add(details);
                }
                if (detailsList.size() == 1) {
                    callProfileAPIs();
                } else {
                    ((LoginView) mView).openDashboardActivity(detailsList);
                }
            } catch (Exception e) {
                Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
            }
        }
    }

    /*
     * This method is used to parse Get UserProfile API response.
     */
    private void parseUserProfileResponse(String response) {
        if (response != null) {
            try {
                JSONObject obj = new JSONObject(response);
                String key = obj.getString("External_System_Key2");

                String mAliasName = obj.getString("Alias_Name");
                String mFirstName = obj.getString("First_Name");
                String mLastName = obj.getString("Last_Name");
                String mUserId = obj.getString("User_Id");

                ProfileDataCache.getInstance().setExternalKey2(key);
                ProfileDataCache.getInstance().setMessageBy(mUserId + "/" + mFirstName + " " + mLastName);
            } catch (Exception e) {
                Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
            }
        }
    }

    /*
     * This method is used to parse Get MemberDetails API response.
     */
    private void parseMemberDetailsResponse(String response) {
        final ArrayList<MemberDetails> memberInfo = new ArrayList<>();
        if (response != null && response.length() > 0) {
            try {
                Gson gson = new GsonBuilder().create();
                JSONArray array = new JSONObject
                        (response).getJSONArray("MemberDetails");
                for (int i = 0; i < array.length(); i++) {
                    MemberDetails feed = gson.fromJson
                            (array.getString(i), MemberDetails.class);
                    if (feed.getPersonNumber() != null && feed.getSubscriberID() != null) {
                        memberInfo.add(feed);
                    }
                }
                ProfileDataCache.getInstance().setmMemberDetails(memberInfo);
            } catch (JSONException e) {
                Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
            }
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private boolean initCipher(Cipher cipher, String keyName) throws CipherException {
        try {
            mKeyStore.load(null);
            SecretKey key = (SecretKey) mKeyStore.getKey(keyName, null);
            cipher.init(Cipher.ENCRYPT_MODE, key);
            return true;
        } catch (KeyStoreException | CertificateException | UnrecoverableKeyException | IOException
                | NoSuchAlgorithmException e) {
            throw new CipherException("Failed to init Cipher", e);
        } catch (InvalidKeyException e) {
            Logger.e("Exception", e);
            return false;
        }
    }

    private void sendNotification() {

    }
}
