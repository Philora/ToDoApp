package com.wps.memberapp.presentation.login;

import com.wps.memberapp.data.model.MemberGroupDetails;
import com.wps.memberapp.presentation.base.MvpView;

import java.util.List;
/*
This interface contain UI functions of Login
 */
public interface LoginView extends MvpView {
    void openDashboardActivity(List<MemberGroupDetails> detailsList);
    void openForgotPasswordActivity();
    void onInvalidaCredentialsEntered(String error);
}
