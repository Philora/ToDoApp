package com.wps.memberapp.presentation.login.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.microsoft.projectoxford.face.FaceServiceClient;
import com.microsoft.projectoxford.face.FaceServiceRestClient;
import com.microsoft.projectoxford.face.contract.CreatePersonResult;
import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import butterknife.BindView;
import butterknife.ButterKnife;

public class ConfirmFacePrintActivity extends AppCompatActivity implements View.OnClickListener {

    @BindView(R.id.tvNotRightNow)
    TextView tvNotRightNow;
    @BindView(R.id.btEnable)
    TextView btEnable;
    ProgressDialog mProgressDialog;
    private static FaceServiceClient sFaceServiceClient;
    String uniqueId;
    String groupName;
    String personName;
    AsyncTask<String, String, String> addPersonTask = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_faceprint);
        ButterKnife.bind(this);
        mProgressDialog = new ProgressDialog(ConfirmFacePrintActivity.this);
        mProgressDialog.setCancelable(false);
        tvNotRightNow.setPaintFlags(tvNotRightNow.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        tvNotRightNow.setOnClickListener(this);
        btEnable.setOnClickListener(this);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tvNotRightNow:
                LoginActivity.isFingerFlow = false;
                LoginActivity.isFaceFlow = false;
                try {
                    if (addPersonTask != null) {
                        addPersonTask.cancel(true);
                        super.onBackPressed();
                    } else {
                        super.onBackPressed();
                    }
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
                finish();
                break;
            case R.id.btEnable:
                // take profile ID dynamically append like "PersonGroup_profileID"
                String profileId = SharedPreferenceHelper.getInstance().getPreference(this, "ProfileID");
                if (profileId != null) {
                    uniqueId = profileId;
                } else uniqueId = "";
                String userId = SharedPreferenceHelper.getInstance().getPreference(this, "UserID");
                if (userId != null) {
                    groupName = "PersonGroup_Name_" + userId;
                } else groupName = "";

                if (userId != null) {
                    personName = "PersonGroup_Name_" + userId;
                } else personName = "";

                SharedPreferenceHelper.getInstance().setPreference(ConfirmFacePrintActivity.this, "PersonGroupUniqueId", uniqueId);
                //Log.i("unique id",uniqueId);
                if (uniqueId != null && uniqueId.length() > 0) {
                    new AddPersonGroupTask(ConfirmFacePrintActivity.this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, uniqueId);
                }
                break;
        }
    }

    // Background task of adding a person group.
    class AddPersonGroupTask extends AsyncTask<String, String, String> {
        private Context mContext;

        public AddPersonGroupTask(Context context) {
            this.mContext = context;
            uniqueId = SharedPreferenceHelper.getInstance().getPreference(mContext, "PersonGroupUniqueId");
        }

        @Override
        protected void onPreExecute() {
            try {
                mProgressDialog.show();
            } catch (Exception e) {
                e.getLocalizedMessage();
            }
        }

        @Override
        protected void onProgressUpdate(String... progress) {
            mProgressDialog.setMessage(progress[0]);
        }

        // Indicate the next step is to add person in this group, or finish editing this group.
        @Override
        protected String doInBackground(String... params) {

            // Get an instance of face service client.
            try {
                publishProgress("Registering User");
                // Start creating person group in server.
                sFaceServiceClient = new FaceServiceRestClient("https://faceres1.cognitiveservices.azure.com/face/v1.0", "2237e0c5a27c4dccb1881948767448a3");
                sFaceServiceClient.createLargePersonGroup(
                        params[0],
                        groupName,
                        "User-Data");
                return params[0];
            } catch (Exception e) {
                Log.d("Group exists error", e.getMessage());
                if (e.getMessage().contains("already exists")) {
                    if (uniqueId != null) {
                        addPersonTask = new AddPersonTask(ConfirmFacePrintActivity.this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, uniqueId);
                    }
                } else {
                    Log.d("Error in adding person", e.getMessage());
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            try {
                mProgressDialog.dismiss();
                if (result != null) {
                    Log.d("Response: Success ", " created");
                    // Add groupId dynamically
                    if (uniqueId != null) {
                        new AddPersonTask(ConfirmFacePrintActivity.this).execute(uniqueId);
                    }
                }
            } catch (Exception e) {
                e.getLocalizedMessage();
            }
        }
    }

    // Background task of adding a person to person group.
    class AddPersonTask extends AsyncTask<String, String, String> {
        private Context mContext;

        public AddPersonTask(Context context) {
            this.mContext = context;
        }

        // Indicate the next step is to add face in this person, or finish editing this person.
        @Override
        protected String doInBackground(String... params) {
            // Get an instance of face service client.
            try {
                publishProgress("Syncing with server to add person...");
                Log.d("Creating Person", "success");
                // Start the request to creating person.
                sFaceServiceClient = new FaceServiceRestClient("https://faceres1.cognitiveservices.azure.com/face/v1.0", "2237e0c5a27c4dccb1881948767448a3");
                CreatePersonResult result = sFaceServiceClient.createPersonInLargePersonGroup(
                        params[0],
                        personName,
                        "User data");
                return result.personId.toString();
            } catch (Exception e) {
                publishProgress(e.getMessage());
                Log.d("failure", "failure");
                return null;
            }
        }

        @Override
        protected void onPreExecute() {
            try {
                mProgressDialog.show();
            } catch (Exception e) {
                e.getLocalizedMessage();
            }
        }

        @Override
        protected void onProgressUpdate(String... progress) {
            mProgressDialog.setMessage(progress[0]);
        }

        @Override
        protected void onPostExecute(String result) {
            try {
                if (result != null) {
                    mProgressDialog.dismiss();
                    //SharedPreferenceHelper.getInstance().setPreference(mContext, "PersonId", result);
                    Log.d("Response: Success", "Person Added");
                    Intent intent = new Intent(ConfirmFacePrintActivity.this, DetectionActivity.class);
                    intent.putExtra("PersonId",result);
                    startActivity(intent);
                }
            } catch (Exception e) {
                e.getLocalizedMessage();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    public void onBackPressed() {
        try {
            if (addPersonTask != null) {
                addPersonTask.cancel(true);
                super.onBackPressed();
            } else {
                super.onBackPressed();
            }
        } catch (Exception e) {
            e.getLocalizedMessage();
        }
    }
}
