package com.wps.memberapp.presentation.login.activity;

import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Paint;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.exception.CipherException;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.presentation.login.fragment.FingerprintAuthenticationDialogFragment;
import com.wps.memberapp.utility.Logger;

import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import butterknife.BindView;
import butterknife.ButterKnife;

public class ConfirmFingerprintActivity extends AppCompatActivity implements View.OnClickListener {

    @BindView(R.id.tvNotRightNow)
    TextView tvNotRightNow;
    @BindView(R.id.btEnable)
    TextView btEnable;
    public KeyStore mKeyStore;
    private KeyGenerator mKeyGenerator;
    public static final String DEFAULT_KEY_NAME = "default_key";
    private static final String DIALOG_FRAGMENT_TAG = "myFragment";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_fingerprint);
        ButterKnife.bind(this);
        tvNotRightNow.setPaintFlags(tvNotRightNow.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        tvNotRightNow.setOnClickListener(this);
        btEnable.setOnClickListener(this);
        try {
            mKeyGenerator = KeyGenerator
                    .getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        } catch (NoSuchAlgorithmException | NoSuchProviderException e) {
            Log.d(DEFAULT_KEY_NAME, e.getMessage());
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tvNotRightNow:
               /* Intent intent = new Intent(ConfirmFingerprintActivity.this, LoginActivityFitbit.class);
                startActivity(intent);*/
                LoginActivity.isFingerFlow = false;
                LoginActivity.isFaceFlow = false;
                finish();
                break;
            case R.id.btEnable:
                showConfirmDialog();
                break;
        }
    }

    private void showConfirmDialog() {
        View view = getLayoutInflater().inflate(R.layout.dialog_fingerprint_use, null);
        TextView tvDontUse = view.findViewById(R.id.tvDontUse);
        TextView tvUse = view.findViewById(R.id.tvUse);
        AlertDialog.Builder dilog = new AlertDialog.Builder(this);
        dilog.setView(view);
        dilog.setCancelable(false);
        AlertDialog dialog = dilog.create();
        tvDontUse.setOnClickListener(view1 -> {
            LoginActivity.isFingerFlow = false;
            dialog.dismiss();
        });
        tvUse.setOnClickListener(view12 -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Cipher defaultCipher = null;
                try {
                    defaultCipher = Cipher.getInstance(KeyProperties.KEY_ALGORITHM_AES + "/"
                            + KeyProperties.BLOCK_MODE_CBC + "/"
                            + KeyProperties.ENCRYPTION_PADDING_PKCS7);
                    Cipher.getInstance(KeyProperties.KEY_ALGORITHM_AES + "/"
                            + KeyProperties.BLOCK_MODE_CBC + "/"
                            + KeyProperties.ENCRYPTION_PADDING_PKCS7);
                } catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
                    Log.d(DEFAULT_KEY_NAME, e.getMessage());
                }
                onFingerPrintSelected(defaultCipher, DEFAULT_KEY_NAME);
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void onFingerPrintSelected(Cipher mCipher, String mKeyName) {
        try {
            if (initCipher(mCipher, mKeyName)) {

                FingerprintAuthenticationDialogFragment fragment
                        = new FingerprintAuthenticationDialogFragment();
                fragment.setCryptoObject(new FingerprintManager.CryptoObject(mCipher));
                SharedPreferences mSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
                boolean useFingerprintPreference = mSharedPreferences.getBoolean(getString(R.string.use_fingerprint_to_authenticate_key), true);
                if (useFingerprintPreference) {
                    fragment.setStage(
                            FingerprintAuthenticationDialogFragment.Stage.FINGERPRINT);
                } else {
                    fragment.setStage(
                            FingerprintAuthenticationDialogFragment.Stage.PASSWORD);
                }
                fragment.show(getFragmentManager(), DIALOG_FRAGMENT_TAG);
            } else {
                FingerprintAuthenticationDialogFragment fragment
                        = new FingerprintAuthenticationDialogFragment();
                fragment.setCryptoObject(new FingerprintManager.CryptoObject(mCipher));
                fragment.setStage(
                        FingerprintAuthenticationDialogFragment.Stage.NEW_FINGERPRINT_ENROLLED);
                fragment.show(getFragmentManager(), DIALOG_FRAGMENT_TAG);
            }
        } catch (Exception e) {
            Logger.e("tag", e);
        }
    }

    /**
     * This method is used to initialize Cipher key using keystore and handle eystore exception if any
     */

    @RequiresApi(api = Build.VERSION_CODES.M)
    private boolean initCipher(Cipher cipher, String keyName) throws CipherException {
        try {
            KeyStore mKeyStore = KeyStore.getInstance("AndroidKeyStore");
            mKeyStore.load(null);
            SecretKey key = (SecretKey) mKeyStore.getKey(keyName, null);
            cipher.init(Cipher.ENCRYPT_MODE, key);
            return true;
        } catch (KeyStoreException | CertificateException | UnrecoverableKeyException | IOException
                | NoSuchAlgorithmException e) {
            throw new CipherException("Failed to init Cipher", e);
        } catch (InvalidKeyException e) {
            Logger.e("Exception", e);
            return false;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void createKey(String keyName, boolean invalidatedByBiometricEnrollment) {
// The enrolling flow for fingerprint. This is where we ask the user to set up fingerprint
// for our flow. Use of keys is necessary if we need to know if the set of
// enrolled fingerprints has changed.
        try {
            mKeyStore.load(null);
// Set the alias of the entry in Android KeyStore where the key will appear
// and the constrains (purposes) in the constructor of the Builder

            KeyGenParameterSpec.Builder builder = new KeyGenParameterSpec.Builder(keyName,
                    KeyProperties.PURPOSE_ENCRYPT |
                            KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_CBC)
                    // Require the user to authenticate with a fingerprint to authorize every use
                    // of the key
                    .setUserAuthenticationRequired(true)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_PKCS7);

            // This is a workaround to avoid crashes on devices whose API level is < 24
            // because KeyGenParameterSpec.Builder#setInvalidatedByBiometricEnrollment is only
            // visible on API level +24.
            // Ideally there should be a compat library for KeyGenParameterSpec.Builder but
            // which isn't available yet.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                builder.setInvalidatedByBiometricEnrollment(invalidatedByBiometricEnrollment);
            }
            mKeyGenerator.init(builder.build());
            mKeyGenerator.generateKey();
        } catch (NoSuchAlgorithmException | InvalidAlgorithmParameterException
                | CertificateException | IOException e) {
            Log.d("Failed KeyGenerator", e.getMessage());
        }
    }

    @TargetApi(Build.VERSION_CODES.M)
    public void onPurchased(boolean withFingerprint,
                            @Nullable FingerprintManager.CryptoObject cryptoObject) {
        if (withFingerprint) {
            // If the user has authenticated with fingerprint, verify that using cryptography and
            // then show the confirmation message.
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setCancelable(false)
                    .setMessage("Fingerprint Registered Successfully")
                    .setPositiveButton(getString(R.string.ok), (dialogInterface, i) -> {
                        LoginActivity.isFingerFlow = false;
                        LoginActivity.isFaceFlow = false;
                        Intent intent = new Intent(ConfirmFingerprintActivity.this, LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        SharedPreferenceHelper.getInstance().setPrefBoolean(getApplicationContext(), "isFingerPrint", true);
                        startActivity(intent);
                        finish();
                    }).create().show();

        }
    }
}
