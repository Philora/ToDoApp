
package com.wps.memberapp.presentation.login.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.microsoft.projectoxford.face.FaceServiceClient;
import com.microsoft.projectoxford.face.FaceServiceRestClient;
import com.microsoft.projectoxford.face.contract.Face;
import com.microsoft.projectoxford.face.contract.IdentifyResult;
import com.microsoft.projectoxford.face.contract.TrainingStatus;
import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.DashboardData;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.model.MemberEligibleInfo;
import com.wps.memberapp.data.model.MemberGroupDetails;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.dashboard.activity.DashboardActivity;
import com.wps.memberapp.presentation.groupmanagement.activity.GroupActivity;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.ImageHelper;
import com.wps.memberapp.utility.LogHelper;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;

import static com.wps.memberapp.utility.GeneralUtils.hideProgress;

public class DetectionActivity extends AppCompatActivity {

    private static FaceServiceClient sFaceServiceClient;
    // The URI of photo taken with camera
    private static final int REQUEST_TAKE_PHOTO = 100;
    private static final int CAMERA_PERMISSION_CODE = 2;
    ImageView mCapturedImage;
    String imageFilePath;
    private Uri mImageUri;
    ProgressDialog mProgressDialog;
    boolean mUserRegistered;
    private LoginActivity mActivity;

    // When the activity is created, set all the member variables to initial state.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detection);
        mCapturedImage = (ImageView) findViewById(R.id.image);
        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setCancelable(false);
        mActivity = new LoginActivity();
        sFaceServiceClient = new FaceServiceRestClient("https://faceres1.cognitiveservices.azure.com/face/v1.0", "2237e0c5a27c4dccb1881948767448a3");
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onStart() {
        super.onStart();
        mActivity = new LoginActivity();
        if (isWriteStoragePermissionGranted() && isReadStoragePermissionGranted() && isCameraPermissionGranted()) {
            Log.d("LoginPermission", "Success ");
        }
    }

    // Called when image selection is done.
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_TAKE_PHOTO) {
            if (resultCode == RESULT_OK) {
                String image = SharedPreferenceHelper.getInstance().getPreference(DetectionActivity.this, "imagePath");
                mImageUri = FileProvider.getUriForFile(getApplicationContext(), "com.wps.memberapp.fileprovider", new File(image));
                // Start a background task to detect facs in the image.
                Bitmap mBitmap = ImageHelper.loadSizeLimitedBitmapFromUri(Uri.fromFile(new File(image)), getContentResolver());
                if (mBitmap != null) {
                    // Show the image on screen.
                    mCapturedImage.setImageBitmap(mBitmap);
                    ByteArrayOutputStream output = new ByteArrayOutputStream();
                    mBitmap.compress(Bitmap.CompressFormat.JPEG, 100, output);
                    ByteArrayInputStream inputStream = new ByteArrayInputStream(output.toByteArray());
                    // Start a background task to detect facs in the image.
                    new DetectionTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, inputStream);
                }
            }
        } else if (resultCode == RESULT_CANCELED) {
            Toast.makeText(this, "Picture was not taken", Toast.LENGTH_SHORT);
        } else {
            Toast.makeText(this, "Picture was not taken", Toast.LENGTH_SHORT);
        }
    }

    // Called when the "Select Image" button is clicked.
    public void selectImage(View view) {
        try {
            if (isCameraPermissionGranted()) {
                takePhoto();
            }
        } catch (Exception e) {
            Logger.e("AddMedication2", e);
        }
    }

    private void takePhoto() {
        Log.d("LoginPermission", "Success ");
        // When the button of "Take a Photo with Camera" is pressed.
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) != null) {
            // Save the photo taken to a temporary file.
            File photoFile = null;
            Uri photoURI = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                // Error occurred while creating the File
                ex.getMessage();
            }
            if (photoFile != null) {
                photoURI = FileProvider.getUriForFile(this,
                        "com.wps.memberapp.fileprovider",
                        photoFile);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                intent.putExtra("android.intent.extras.CAMERA_FACING", 1);
                intent.putExtra("android.intent.extras.LENS_FACING_FRONT", 1);
                intent.putExtra("android.intent.extra.USE_FRONT_CAMERA", true);
                startActivityForResult(intent, REQUEST_TAKE_PHOTO);
            }
            // future
        }
    }

    private boolean isCameraPermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (getApplication().checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                Log.v("LoginActivityFitbit", "Permission is granted2");
                return true;
            } else {
                Log.v("LoginActivityFitbit", "Permission is revoked2");
                ActivityCompat.requestPermissions(DetectionActivity.this, new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_CODE);
                return false;
            }
        } else {
            Log.v("LoginActivityFitbit", "Permission is granted2");
            return true;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_CODE && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            takePhoto();
        }else{
            GeneralUtils.showAlertDialog(this,"Camera permission mandatory to register Face ID");
        }
    }

    private File createImageFile() throws IOException {
        String timeStamp =
                new SimpleDateFormat("yyyyMMdd_HHmmss",
                        Locale.getDefault()).format(new Date());
        String imageFileName = "IMG_" + timeStamp + "_";
        File storageDir =
                getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );
        imageFilePath = image.getPath();
        SharedPreferenceHelper.getInstance().setPreference(DetectionActivity.this, "imagePath", imageFilePath);
        return image;
    }

    // Background task of face detection.
    private class DetectionTask extends AsyncTask<InputStream, String, Face[]> {
        private boolean mSucceed = true;
        AlertDialog.Builder alertDialog;

        @Override
        protected Face[] doInBackground(InputStream... params) {
            // Get an instance of face service client to detect faces in image.
            try {
                publishProgress("Detecting...");

                // Start detection.

                return sFaceServiceClient.detect(
                        params[0],  /* Input stream of image to detect */
                        true,       /* Whether to return face ID */
                        true,       /* Whether to return face landmarks */
                        new FaceServiceClient.FaceAttributeType[]{
                                FaceServiceClient.FaceAttributeType.Age,
                                FaceServiceClient.FaceAttributeType.Gender,
                                FaceServiceClient.FaceAttributeType.Smile,
                                FaceServiceClient.FaceAttributeType.Glasses,
                                FaceServiceClient.FaceAttributeType.FacialHair,
                                FaceServiceClient.FaceAttributeType.Emotion,
                                FaceServiceClient.FaceAttributeType.HeadPose,
                                FaceServiceClient.FaceAttributeType.Accessories,
                                FaceServiceClient.FaceAttributeType.Blur,
                                FaceServiceClient.FaceAttributeType.Exposure,
                                FaceServiceClient.FaceAttributeType.Hair,
                                FaceServiceClient.FaceAttributeType.Makeup,
                                FaceServiceClient.FaceAttributeType.Noise,
                                FaceServiceClient.FaceAttributeType.Occlusion
                        });
            } catch (Exception e) {
                mSucceed = false;
                Log.i("Detection", "catch");
                //Hanlde session tiem out - socket exception
                publishProgress(e.getMessage());
                alertDialog.setTitle("Face Authentication");
                alertDialog.setCancelable(false);
                alertDialog.setMessage("Network Connectivity Error! Please try again!");
                alertDialog.setPositiveButton("OK",
                        (dialog, which) -> {
                            // Redirect to Dashboard Activity here as per realm
                            Intent A = new Intent(DetectionActivity.this, LoginActivity.class);
                            startActivity(A);
                            finish();
                        });
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        alertDialog.show();
                    }
                });
                LogHelper.addDetectionLog(e.getMessage());
                return null;
            }
        }

        @Override
        protected void onPreExecute() {
            try {
                mProgressDialog.show();
                alertDialog = new AlertDialog.Builder(DetectionActivity.this);
                LogHelper.addDetectionLog("Request: Detecting in image " + mImageUri);
            } catch (Exception e) {
                e.getLocalizedMessage();
            }
        }

        @Override
        protected void onProgressUpdate(String... progress) {
            mProgressDialog.setMessage(progress[0]);
        }

        @Override
        protected void onPostExecute(Face[] result) {
            try {
                if (mSucceed && result != null) {
                    List<Face> faces;
                    faces = Arrays.asList(result);
                    List<UUID> faceIds = new ArrayList<>();
                    for (Face face : faces) {
                        faceIds.add(face.faceId);
                    }
                    boolean mRegisteredUser = SharedPreferenceHelper.getInstance().getPrefBoolean(DetectionActivity.this, "RegisteredUser", false);
                    if (!mRegisteredUser) {
                        Log.i("Detection", "AddFaceTask");
                        new AddFaceTask(DetectionActivity.this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                    } else {
                        String uniqueId = SharedPreferenceHelper.getInstance().getPreference(DetectionActivity.this, "PersonGroupUniqueId");
                        new IdentificationTask(uniqueId, DetectionActivity.this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, faceIds.toArray(new UUID[faceIds.size()]));
                    }
                }
                // Show the result on screen when detection is done.
                setUiAfterDetection(result, mSucceed);
            } catch (Exception e) {
                e.getLocalizedMessage();
            }
        }
    }

    // Show the result on screen when detection is done.
    private void setUiAfterDetection(Face[] result, boolean succeed) {
        // Detection is done, hide the progress dialog.
        mProgressDialog.dismiss();
        // Disable button "detect" as the image has already been detected.
        if (succeed) {
            String detectionResult;
            if (result != null) {
                String image = SharedPreferenceHelper.getInstance().getPreference(DetectionActivity.this, "imagePath");
                // Start a background task to detect facs in the image.
                Bitmap mBitmap = ImageHelper.loadSizeLimitedBitmapFromUri(Uri.fromFile(new File(image)), getContentResolver());
                if (mBitmap != null) {
                    mCapturedImage.setImageBitmap(ImageHelper.drawFaceRectanglesOnBitmap(mBitmap, result, true));
                }
            } else {
                detectionResult = "0 face detected";
            }
        }
    }

    // Background task of adding a face to person.
    class AddFaceTask extends AsyncTask<Void, String, Boolean> {
        private Context mContext;
        String image;
        Bitmap bitmap;
        String uniqueId;

        public AddFaceTask(Context context) {
            this.mContext = context;
            image = SharedPreferenceHelper.getInstance().getPreference(mContext, "imagePath");
            bitmap = ImageHelper.loadSizeLimitedBitmapFromUri(Uri.fromFile(new File(image)), getContentResolver());
            uniqueId = SharedPreferenceHelper.getInstance().getPreference(mContext, "PersonGroupUniqueId");
            Log.i(" UniqueId", "abc");

        }

        @Override
        protected Boolean doInBackground(Void... params) {
            // Get an instance of face service client to detect faces in image.
            try {
                Log.i(" Adding face", "face task");
//                String mPersonId = SharedPreferenceHelper.getInstance().getPreference(mContext, "PersonId");
                Intent intent = getIntent();
                String mPersonId = intent.getExtras().getString("PersonId");
                if (mPersonId != null && bitmap != null && uniqueId != null) {
                    UUID personId = UUID.fromString(mPersonId);
                    Log.d(" Adding face to person", "PersonId");
                    Log.d(" Adding face to person", "bitmap");
                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
                    InputStream imageInputStream = new ByteArrayInputStream(stream.toByteArray());
                    // Start the request to add face.
                    Log.d(" calling face API", "faceapi");
                    sFaceServiceClient.addPersonFaceInLargePersonGroup(
                            uniqueId,
                            personId,
                            imageInputStream,
                            "User data",
                            null);
                    Log.e(" Adding face", "inside do in background");
                }
                return true;
            } catch (Exception e) {
                Log.i(" exception face", "face task");
                publishProgress(e.getMessage());
                return false;
            }
        }

        @Override
        protected void onPreExecute() {
            try {
                mProgressDialog.show();
            } catch (Exception e) {
                e.getLocalizedMessage();
            }
        }

        @Override
        protected void onProgressUpdate(String... progress) {
            mProgressDialog.setMessage(progress[0]);
        }

        @Override
        protected void onPostExecute(Boolean result) {
            try {
                mProgressDialog.dismiss();
                Log.d(" Added face to person", "PersonId");
                if (result != null) {
                    new TrainPersonGroupTask().execute(uniqueId);
                }
            } catch (Exception e) {
                e.getLocalizedMessage();
            }
        }
    }

    class TrainPersonGroupTask extends AsyncTask<String, String, String> {
        AlertDialog.Builder alertDialog;

        @Override
        protected String doInBackground(String... params) {
            Log.d("Request: Training group", "Training");

            // Get an instance of face service client.
            try {
                publishProgress("Training person group...");
                sFaceServiceClient.trainLargePersonGroup(params[0]);
                return params[0];
            } catch (Exception e) {
                publishProgress(e.getMessage());
                return null;
            }
        }

        @Override
        protected void onPreExecute() {
            try {
                mProgressDialog.show();
                alertDialog = new AlertDialog.Builder(DetectionActivity.this);
            } catch (Exception e) {
                e.getLocalizedMessage();
            }

        }

        @Override
        protected void onProgressUpdate(String... progress) {
            mProgressDialog.setMessage(progress[0]);
            Log.d("Training is in progress", "Training");
        }

        @Override
        protected void onPostExecute(String result) {
            try {
                mProgressDialog.dismiss();
                if (result != null) {
                    Log.d("Training Completed", "Training");

                    if (alertDialog != null) {
                        alertDialog.setTitle("Face Authentication");
                        alertDialog.setCancelable(false);
                        alertDialog.setMessage("Face Registration Successful!");
                        alertDialog.setPositiveButton("OK",
                                (dialog, which) -> {
                                    // Redirect to Dashboard Activity here as per realm
                                    mUserRegistered = true;
                                    LoginActivity.isFingerFlow = false;
                                    LoginActivity.isFaceFlow = false;
                                    SharedPreferenceHelper.getInstance().setPrefBoolean(getApplicationContext(), "isFacePrint", true);
                                    SharedPreferenceHelper.getInstance().setPrefBoolean(DetectionActivity.this, "RegisteredUser", mUserRegistered);
                                    Intent A = new Intent(DetectionActivity.this, LoginActivity.class);
                                    startActivity(A);
                                    finish();
                                });
                        alertDialog.show();
                    }
                }
            } catch (Exception e) {
                e.getLocalizedMessage();
            }
        }
    }

    // Background task of face identification.
    private class IdentificationTask extends AsyncTask<UUID, String, IdentifyResult[]> {
        private boolean mSucceed = true;
        AlertDialog.Builder alertDialog;
        String mPersonGroupId;
        private Context mContext;

        IdentificationTask(String personGroupId, Context context) {
            this.mPersonGroupId = personGroupId;
            this.mContext = context;
        }

        @Override
        protected IdentifyResult[] doInBackground(UUID... params) {
            String logString = "Request: Identifying faces ";
            for (UUID faceId : params) {
                logString += faceId.toString() + ", ";
            }
            logString += " in group " + mPersonGroupId;

            // Get an instance of face service client to detect faces in image.
            try {
                publishProgress("Getting person group status...");

                TrainingStatus trainingStatus = sFaceServiceClient.getLargePersonGroupTrainingStatus(
                        this.mPersonGroupId);     /* personGroupId */
                if (trainingStatus.status != TrainingStatus.Status.Succeeded) {
                    publishProgress("Person group training status is " + trainingStatus.status);
                    mSucceed = false;
                    return null;
                }
                publishProgress("Identifying...");
                String uniqueId = SharedPreferenceHelper.getInstance().getPreference(mContext, "PersonGroupUniqueId");
                // Start identification.
                return sFaceServiceClient.identityInLargePersonGroup(
                        uniqueId,   /* personGroupId */
                        params,                  /* faceIds */
                        1);  /* maxNumOfCandidatesReturned */
            } catch (Exception e) {
                mSucceed = false;
                publishProgress(e.getMessage());
                return null;
            }
        }

        @Override
        protected void onPreExecute() {
            try {
                mProgressDialog.show();
                alertDialog = new AlertDialog.Builder(DetectionActivity.this);
            } catch (Exception e) {
                e.getLocalizedMessage();
            }
        }

        @Override
        protected void onProgressUpdate(String... values) {
            // Show the status of background detection task on screen.a
            mProgressDialog.setMessage(values[0]);
        }

        @Override
        protected void onPostExecute(IdentifyResult[] result) {
            try {
                // Show the result on screen when Identification is completed.
                mProgressDialog.dismiss();
                if (result != null && result.length > 0) {
                    boolean foundFace = false;
                    for (IdentifyResult res : result) {
                        if (res.candidates.size() > 0) {
                            Log.d("Face Identified", "Identification Success");
                            try {
                                alertDialog.setTitle("Face Authentication");
                                alertDialog.setCancelable(false);
                                alertDialog.setMessage("Face Authentication Successful!");
                                alertDialog.setPositiveButton("OK",
                                        (dialog, which) -> {
                                            callSessionsAPIs();
                                            //   callLoginFacAuth();    // In this we have one issue -> Waiting for Progress bar to check in Login Activity
                                        });
                                alertDialog.show();
                                foundFace = true;
                                break;
                            } catch (Exception e) {
                                e.getLocalizedMessage();
                            }
                        } else
                            continue;
                    }
                    if (!foundFace) {
                        Log.d("Face not Identified", "Identification Failure");
                        try {
                            alertDialog.setTitle("Face Authentication");
                            alertDialog.setCancelable(false);
                            alertDialog.setMessage("Face Authentication Failure!");
                            alertDialog.setPositiveButton("OK",
                                    (dialog, which) -> {
                                        Intent A = new Intent(DetectionActivity.this, LoginActivity.class);
                                        startActivity(A);
                                        finish();
                                    });
                            alertDialog.show();
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    }
                } else {
                    Log.d("Face not Identified", "Identification Failure");
                    alertDialog.setTitle("Face Authentication");
                    alertDialog.setCancelable(false);
                    alertDialog.setMessage("Face Authentication Failure! Please try again or login with authorized credentials");

                    alertDialog.setPositiveButton("OK",
                            (dialog, which) -> {
                                // Redirect to Dashboard Activity here as per realm
                                Intent A = new Intent(DetectionActivity.this, LoginActivity.class);
                                startActivity(A);
                                finish();
                            });
                    alertDialog.show();
                }
            } catch (Exception e) {
                e.getLocalizedMessage();
            }
        }
    }

    private void callLoginFacAuth() {
//        GeneralUtils.showProgress(DetectionActivity.this);
        Intent intFacAuth = new Intent(DetectionActivity.this, LoginActivity.class);
        intFacAuth.putExtra("FaceAuth_Success", "FaceAuthSuccess");
        startActivity(intFacAuth);
    }

    private void callSessionsAPIs() {
        GeneralUtils.showProgress(this);
        VolleyService.issueSTCToken
                (DetectionActivity.this, AppConstants.LOGIN_STC_TOKEN, new VolleyResponseListener() {
                    @Override
                    public void onError(String error) {
                        ProfileDataCache.getInstance().clearCache();
                        hideProgress();
                        Log.d("LoginPresenterImp", "onError: " + error);
                    }

                    @Override
                    public void onResponse(String response) {
                        showLog(response);
                        if (response != null) {
                            VolleyService.issueSAMLFedAuth(DetectionActivity.this,
                                    AppConstants.LOGIN_FED_AUTH_TOKEN, new VolleyResponseListener() {
                                        @Override
                                        public void onError(String error) {
                                            hideProgress();
                                            showLog(error);
                                        }

                                        @Override
                                        public void onResponse(String response) {
                                            showLog(response);
                                            ProfileDataCache.getInstance().clearCache();
                                            VolleyService.getMemberGroupList(DetectionActivity.this, AppConstants.GET_MEMBER_GROUP_LIST, new VolleyResponseListener() {
                                                @Override
                                                public void onError(String error) {
                                                    hideProgress();
                                                }

                                                @Override
                                                public void onResponse(String message) {
                                                    parseMemberGroupResponse(message);
                                                }
                                            });
                                        }
                                    });
                        }
                    }
                });
    }

    private void parseMemberGroupResponse(String message) {
        if (message != null) {
            try {
                Gson gson = new Gson();
                JSONArray jsonArray = new JSONArray(message);
                List<MemberGroupDetails> detailsList = new ArrayList<>();
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    MemberGroupDetails details = gson.fromJson(jsonObject.toString(), MemberGroupDetails.class);
                    detailsList.add(details);
                }
                if (detailsList.size() == 1) {
                    callProfileAPIs();
                } else {
                    Intent intent = new Intent(DetectionActivity.this, DashboardActivity.class);
                    if (detailsList.size() > 1) {
                        ProfileDataCache.getInstance().setmMemberGroupDetails(detailsList);
                        intent = new Intent(DetectionActivity.this, GroupActivity.class);
                    }
                    startActivity(intent);
                    finish();
                }
            } catch (Exception e) {
                Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
            }
        }
    }

    public void callProfileAPIs() {
        VolleyService.getProfileData(this, AppConstants.GET_PROFILE_DETAILS, new VolleyResponseListener() {
            @Override
            public void onError(String error) {
                hideProgress();
                showLog(error);
            }

            @Override
            public void onResponse(String response) {
                showLog(response);
                if (response != null) {
                    ProfileDataCache.getInstance().clearCache();
                    DashboardData data = new Gson().fromJson(response, DashboardData.class);
                    ProfileDataCache.getInstance().setDashboardData(data);
                    SharedPreferenceHelper.getInstance().setPreference(DetectionActivity.this, "ProfileID", data.getProfileId());
                }
                VolleyService.getUserProfileData(DetectionActivity.this, AppConstants.GET_USER_PROFILE_DETAILS, new VolleyResponseListener() {
                    @Override
                    public void onError(String error) {
                        hideProgress();
                        showLog(error);
                    }

                    @Override
                    public void onResponse(String response) {
                        showLog(response);
                        parseUserProfileResponse(response);
                        VolleyService.getMemberEligInfo(DetectionActivity.this, AppConstants.GET_MEMBER_ELIGINFO, new VolleyResponseListener() {
                            @Override
                            public void onError(String error) {
                                hideProgress();
                                showLog(error);
                            }

                            @Override
                            public void onResponse(String response) {
                                showLog(response);
                                if (response != null) {
                                    MemberEligibleInfo data = new Gson().fromJson(response, MemberEligibleInfo.class);
                                    ProfileDataCache.getInstance().setMemberEligibleInfo(data);
                                }
                                VolleyService.getMemberDetails(DetectionActivity.this, AppConstants.GET_MEMBER_DETAILS, new VolleyResponseListener() {
                                    @Override
                                    public void onError(String error) {
                                        hideProgress();
                                        Log.i("Member Error", error);
                                    }

                                    @Override
                                    public void onResponse(String response) {
                                        parseMemberDetailsResponse(response);
                                        if (response != null) {
                                            Intent intent = new Intent(DetectionActivity.this, DashboardActivity.class);
                                            startActivity(intent);
                                            finish();
                                        }
                                    }
                                });
                            }
                        });
                    }
                });

            }
        });
    }

    /*
     * This method is used to parse Get UserProfile API response.
     */
    private void parseUserProfileResponse(String response) {
        if (response != null) {
            try {
                JSONObject obj = new JSONObject(response);
                String key = obj.getString("External_System_Key2");
                ProfileDataCache.getInstance().setExternalKey2(key);
            } catch (Exception e) {
                Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
            }
        }
    }

    /*
     * This method is used to parse Get MemberDetails API response.
     */
    private void parseMemberDetailsResponse(String response) {
        final ArrayList<MemberDetails> memberInfo = new ArrayList<>();
        if (response != null && response.length() > 0) {
            try {
                Gson gson = new GsonBuilder().create();
                JSONArray array = new JSONObject(response).getJSONArray("MemberDetails");
                for (int i = 0; i < array.length(); i++) {
                    MemberDetails feed = gson.fromJson(array.getString(i), MemberDetails.class);
                    if (feed.getPersonNumber() != null && feed.getSubscriberID() != null) {
                        memberInfo.add(feed);
                    }
                }
                ProfileDataCache.getInstance().setmMemberDetails(memberInfo);
            } catch (JSONException e) {
                Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
            }
        }
    }

    void showLog(String msg) {
        Log.i("info", msg);
    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @SuppressLint("LongLogTag")
    public boolean isWriteStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                Log.v("LoginActivity", "Permission is granted2");
                return true;
            } else {
                Log.v("LoginActivity", "Permission is revoked2");
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 2);
                return false;
            }
        } else if (getApplication().checkSelfPermission(android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            Log.v("LoginActivity", "Permission is granted2");
            return true;
        } else {
            Log.v("LoginActivity", "Permission is revoked2");
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 2);
            return false;
        }
    }

    @SuppressLint("LongLogTag")
    public boolean isReadStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (getApplication().checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                Log.v("LoginActivity", "Permission is granted1");
                return true;
            } else {
                Log.v("LoginActivity", "Permission is revoked1");
                ActivityCompat.requestPermissions(DetectionActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 3);
                return false;
            }
        } else {
            Log.v("LoginActivity", "Permission is granted1");
            return true;
        }
    }

}
