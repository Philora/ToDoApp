package com.wps.memberapp.presentation.login.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.fingerprint.FingerprintManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.telephony.TelephonyManager;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MemberGroupDetails;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.presentation.base.MainActivity;
import com.wps.memberapp.presentation.dashboard.activity.DashboardActivity;
import com.wps.memberapp.presentation.groupmanagement.activity.GroupActivity;
import com.wps.memberapp.presentation.login.LoginPresenter;
import com.wps.memberapp.presentation.login.LoginPresenterImpl;
import com.wps.memberapp.presentation.login.LoginView;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.StringConstants;

import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.cert.CertificateException;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * A login screen activity that offers login via mUsername and password via Authentication mechanism.
 */
public class LoginActivity extends MainActivity implements LoginView {

    //Member variables declaration
    @BindView(R.id.login_param2_et)
    EditText etUsername;

    @BindView(R.id.login_param1_et)
    EditText etPassword;

    @BindView(R.id.txt_sign_fingerprint)
    TextView tvSigninWith;

    @BindView(R.id.tvSigninWithTouch)
    TextView tvSigninWithTouch;


    private boolean isPwdVisible = false;
    private static final String KEY_NAME_NOT_INVALIDATED = "key_not_invalidated";
    public static final String DEFAULT_KEY_NAME = "default_key";
    private KeyStore mKeyStore;
    private KeyGenerator mKeyGenerator;
    private Cipher defaultCipher = null;
    // private Bundle bundle;
    private boolean isFingerPrint;
    private boolean isFacePrint;
    //private boolean isBiometricEnabled;
    private LoginPresenter mMvpPresenter;

    public static boolean isFingerFlow = false;
    public static boolean isFaceFlow = false;
    public static boolean isNormalLogin = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        mMvpPresenter = new LoginPresenterImpl();
        mMvpPresenter.onAttach(this);
        ButterKnife.bind(LoginActivity.this);
//        etUsername.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        etPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        isFingerPrint = SharedPreferenceHelper.getInstance().getPrefBoolean(getApplicationContext(), "isFingerPrint", false);
        isFacePrint = SharedPreferenceHelper.getInstance().getPrefBoolean(getApplicationContext(), "isFacePrint", false);
        //isBiometricEnabled = SharedPreferenceHelper.getInstance().getPrefBoolean(getApplicationContext(), "isBiometricEnabled", false);
        if (isFacePrint) {
            tvSigninWithTouch.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_green, 0, 0, 0);
        }

        if (isFingerPrint) {
            tvSigninWith.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_green, 0, 0, 0);
            tvSigninWith.setCompoundDrawablePadding(45);
        }

        /*
         * Creates a symmetric key in the Android Key Store which can only be used after the user has
         * authenticated with fingerprint
         */
        try {
            mKeyStore = KeyStore.getInstance("AndroidKeyStore");
        } catch (KeyStoreException e) {
            Log.d(DEFAULT_KEY_NAME, e.getMessage());
        }
        try {
            mKeyGenerator = KeyGenerator
                    .getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        } catch (NoSuchAlgorithmException | NoSuchProviderException e) {
            Log.d(DEFAULT_KEY_NAME, e.getMessage());
        }
        try {
            defaultCipher = Cipher.getInstance(KeyProperties.KEY_ALGORITHM_AES + "/"
                    + KeyProperties.BLOCK_MODE_CBC + "/"
                    + KeyProperties.ENCRYPTION_PADDING_PKCS7);
            Cipher.getInstance(KeyProperties.KEY_ALGORITHM_AES + "/"
                    + KeyProperties.BLOCK_MODE_CBC + "/"
                    + KeyProperties.ENCRYPTION_PADDING_PKCS7);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
            Log.d(DEFAULT_KEY_NAME, e.getMessage());
        }
    }

    /**
     * Creates a symmetric key in the Android Key Store which can only be used after the user has
     * authenticated with fingerprint.
     *
     * @param keyName                          the name of the key to be created
     * @param invalidatedByBiometricEnrollment if {@code false} is passed, the created key will not
     *                                         be invalidated even if a new fingerprint is enrolled.
     *                                         The default value is {@code true}, so passing
     *                                         {@code true} doesn't change the behavior
     *                                         (the key will be invalidated if a new fingerprint is
     *                                         enrolled.). Note that this parameter is only valid if
     *                                         the app works on Android N developer preview.
     */
    @RequiresApi(api = Build.VERSION_CODES.M)
    public void createKey(String keyName, boolean invalidatedByBiometricEnrollment) {
// The enrolling flow for fingerprint. This is where we ask the user to set up fingerprint
// for our flow. Use of keys is necessary if we need to know if the set of
// enrolled fingerprints has changed.
        try {
            mKeyStore.load(null);
// Set the alias of the entry in Android KeyStore where the key will appear
// and the constrains (purposes) in the constructor of the Builder

            KeyGenParameterSpec.Builder builder = new KeyGenParameterSpec.Builder(keyName,
                    KeyProperties.PURPOSE_ENCRYPT |
                            KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_CBC)
                    // Require the user to authenticate with a fingerprint to authorize every use
                    // of the key
                    .setUserAuthenticationRequired(true)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_PKCS7);

            // This is a workaround to avoid crashes on devices whose API level is < 24
            // because KeyGenParameterSpec.Builder#setInvalidatedByBiometricEnrollment is only
            // visible on API level +24.
            // Ideally there should be a compat library for KeyGenParameterSpec.Builder but
            // which isn't available yet.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                builder.setInvalidatedByBiometricEnrollment(invalidatedByBiometricEnrollment);
            }
            mKeyGenerator.init(builder.build());
            mKeyGenerator.generateKey();
        } catch (NoSuchAlgorithmException | InvalidAlgorithmParameterException
                | CertificateException | IOException e) {
            Log.d("Failed KeyGenerator", e.getMessage());
        }
    }

    @TargetApi(Build.VERSION_CODES.M)
    public void onPurchased(boolean withFingerprint, @Nullable FingerprintManager.CryptoObject cryptoObject) {
        if (withFingerprint) {
            // If the user has authenticated with fingerprint, verify that using cryptography and
            // then show the confirmation message.
            assert cryptoObject != null;
            GeneralUtils.showProgress(this);
            mMvpPresenter.onFingerPrintLogin();
        }

    }

    /**
     * This method is used to provide onClick EventListener on btnLogin
     * and login screen field validation
     */

    @OnClick({R.id.login_sign_in_btn, R.id.forgot_paswd, R.id.register, R.id.txt_sign_fingerprint, R.id.tvSigninWithTouch})
    public void onButtonClick(@NonNull View v) {
        switch (v.getId()) {
            case R.id.forgot_paswd:
                mMvpPresenter.onForgotPasswordClicked();
                break;
            case R.id.login_sign_in_btn:
                String mParam2 = etUsername.getText().toString().trim();
                String mParam1 = etPassword.getText().toString().trim();
                if (TextUtils.isEmpty(mParam2) || TextUtils.isEmpty(mParam1)) {
                    GeneralUtils.showAlertDialog(this, "Please enter both username and password");
                    return;
                }
                SharedPreferenceHelper.getInstance().setPreference(this, StringConstants.PARAM2, mParam2);
                SharedPreferenceHelper.getInstance().setPreference(this, StringConstants.PARAM1, mParam1);
                /*
                 if (isFingerFlow) {
                    SharedPreferenceHelper.getInstance().setPreference(this, StringConstants.PARAM2, mParam2);
                    SharedPreferenceHelper.getInstance().setPreference(this, StringConstants.PARAM1, mParam1);
                } else if (isFaceFlow) {
                    SharedPreferenceHelper.getInstance().setPreference(this, StringConstants.PARAM2, mParam2);
                    SharedPreferenceHelper.getInstance().setPreference(this, StringConstants.PARAM1, mParam1);
                } else {
                    SharedPreferenceHelper.getInstance().setPreference(this, StringConstants.PARAM2, mParam2);
                    SharedPreferenceHelper.getInstance().setPreference(this, StringConstants.PARAM1, mParam1);
                }*/
                showProgress();
                isNormalLogin = true;
                etUsername.setText("");
                etPassword.setText("");

                mMvpPresenter.onLoginClicked();
                break;
            case R.id.register:
                if (GeneralUtils.isOnline(getAppContext())) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(AppConstants.REGISTER_NEW_USER));
                    startActivity(intent);
                } else {
                    GeneralUtils.showAlertDialog(this, getAppContext().getString(R.string.login_no_internet));
                }
                break;
            case R.id.txt_sign_fingerprint:
//                isNormalLogin = true;
//                onBiometricClicked();
                mParam2 = etUsername.getText().toString().trim();
                mParam1 = etPassword.getText().toString().trim();
                String profileId = SharedPreferenceHelper.getInstance().getPreference(this, "ProfileID");
                if (mParam2.length() > 0 && mParam1.length() > 0 && profileId != null) {
                    etUsername.setText("");
                    etPassword.setText("");
                    GeneralUtils.showAlertDialog(this, "Please continue with fingerprint login");
                } else {
                    onBiometricClicked();
                }

                break;
            case R.id.tvSigninWithTouch:
                String ProfileID = SharedPreferenceHelper.getInstance().getPreference(this, "ProfileID");
                if (ProfileID != null) {
                    boolean mRegisteredUser = SharedPreferenceHelper.getInstance().getPrefBoolean(getApplicationContext(), "RegisteredUser", false);
                    if (!mRegisteredUser) {
                        Intent intent = new Intent(LoginActivity.this, ConfirmFacePrintActivity.class);
                        startActivity(intent);
                    } else {
                        Intent intent = new Intent(LoginActivity.this, DetectionActivity.class);
                        startActivity(intent);
                    }
                } else {
                    isFaceFlow = true;
                    GeneralUtils.showAlertDialog(this, "Please authenticate with credentials first");
                }
                break;
            default:
                break;
        }
    }

    private void onBiometricClicked() {
        // Check if we're running on Android 6.0 (M) or higher
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.USE_FINGERPRINT) == PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                //Fingerprint API only available on from Android 6.0 (M)
                FingerprintManager fingerprintManager = (FingerprintManager) getSystemService(Context.FINGERPRINT_SERVICE);
                if (fingerprintManager != null && !fingerprintManager.isHardwareDetected()) {
                    GeneralUtils.showAlertDialog(this, "Device doesn't support Finger Print");
                } else if (fingerprintManager != null && !fingerprintManager.hasEnrolledFingerprints()) {
                    // User hasn't enrolled any fingerprints to authenticate with
                    //GeneralUtils.showAlertDialog(this, "Go to 'Settings -> Security -> Fingerprint' and register at least one fingerprint");
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setCancelable(false)
                            .setMessage("Go to 'Settings -> Security -> Fingerprint' and register at least one fingerprint")
                            .setNegativeButton(getString(R.string.cancel), null)
                            .setPositiveButton("Settings", (dialogInterface, i) -> {
                                startActivity(new Intent(Settings.ACTION_SETTINGS));
                            }).create().show();
                } else {
                    // Everything is ready for fingerprint authentication
                    createKey(DEFAULT_KEY_NAME, true);
                    createKey(KEY_NAME_NOT_INVALIDATED, false);
                    String ProfileID = SharedPreferenceHelper.getInstance().getPreference(this, "ProfileID");
                    if (ProfileID != null) {
                        if (isFingerPrint) {
                            //SharedPreferenceHelper.getInstance().setPreference(this, StringConstants.PARAM2, "empuat30");
                            // SharedPreferenceHelper.getInstance().setPreference(this, StringConstants.PARAM1, "Password_1");
                            mMvpPresenter.onFingerPrintSelected(defaultCipher, DEFAULT_KEY_NAME);
                        } else {
                            isFingerFlow = true;
                            Intent intent = new Intent(LoginActivity.this, ConfirmFingerprintActivity.class);
                            startActivity(intent);
                        }
                    } else {
                        isFingerFlow = true;
                        GeneralUtils.showAlertDialog(this, "Please authenticate with credentials first");
                    }
                }
            }
        }
    }

    /*
    Call back for invalid credentials.
     */
    @Override
    public void onInvalidaCredentialsEntered(String error) {

            }

    // BCBSRI Code flow
    /*@Override
    public void onInvalidCredentialsEntered() {
        etUsername.setText("");
        etPassword.setText("");
    }*/

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onStart() {
        super.onStart();
        if (isWriteStoragePermissionGranted() && isReadStoragePermissionGranted()) {
            Log.d("LoginPermission", "Success ");
        }

    }

    /*
    Used to open Dashboard Activity if plans equal to 1. If plans greater than 1
    we will open Group Activity to manage plans.
    */
    @Override
    public void openDashboardActivity(@NonNull List<MemberGroupDetails> detailsList) {
        Intent intent = new Intent(LoginActivity.this, DashboardActivity.class);
        if (detailsList.size() > 1) {  // detailsList !=null always true
            ProfileDataCache.getInstance().setmMemberGroupDetails(detailsList);
            intent = new Intent(LoginActivity.this, GroupActivity.class);
        }
        startActivity(intent);
        finish();
    }

    /*
    Used to open ForgotPassword Activity if user click on forgot password link.
   */
    @Override
    public void openForgotPasswordActivity() {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(AppConstants.RESET_CREDENTIALS));
        startActivity(intent);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @SuppressLint("LongLogTag")
    public boolean isWriteStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                Log.v("LoginActivity", "Permission is granted2");
                return true;
            } else {
                Log.v("LoginActivity", "Permission is revoked2");
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 2);
                return false;
            }
        } else if (getApplication().checkSelfPermission(android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            Log.v("LoginActivity", "Permission is granted2");
            return true;
        } else {
            Log.v("LoginActivity", "Permission is revoked2");
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 2);
            return false;
        }
    }


    @SuppressLint("LongLogTag")
    public boolean isReadStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (getApplication().checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                Log.v("LoginActivity", "Permission is granted1");
                return true;
            } else {
                Log.v("LoginActivity", "Permission is revoked1");
                ActivityCompat.requestPermissions(LoginActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 3);
                return false;
            }
        } else {
            Log.v("LoginActivity", "Permission is granted1");
            return true;
        }
    }

}