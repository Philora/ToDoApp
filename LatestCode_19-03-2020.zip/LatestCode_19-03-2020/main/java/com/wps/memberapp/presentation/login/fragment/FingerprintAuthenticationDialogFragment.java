/*
 * Copyright (C) 2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License
 */

package com.wps.memberapp.presentation.login.fragment;

import android.app.DialogFragment;
import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.presentation.login.activity.ConfirmFingerprintActivity;
import com.wps.memberapp.presentation.login.activity.LoginActivity;

import androidx.annotation.RequiresApi;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

public class FingerprintAuthenticationDialogFragment extends DialogFragment
        implements TextView.OnEditorActionListener, FingerprintUiHelper.Callback {
    @BindView(R.id.cancel_button)
    Button mCancelButton;
    @BindView(R.id.second_dialog_button)
    Button mSecondDialogButton;
    @BindView(R.id.fingerprint_container)
    View mFingerprintContent;
    @BindView(R.id.backup_container)
    View mBackupContent;
    @BindView(R.id.password)
    EditText mPassword;
    @BindView(R.id.use_fingerprint_in_future_check)
    CheckBox mUseFingerprintFutureCheckBox;
    @BindView(R.id.password_description)
    TextView mPasswordDescriptionTextView;
    @BindView(R.id.new_fingerprint_enrolled_description)
    TextView mNewFingerprintEnrolledTextView;
    @BindView(R.id.fingerprint_icon)
    ImageView fingerPrintIcon;
    @BindView(R.id.fingerprint_status)
    TextView fingerPrintStatus;
    private Stage mStage = Stage.FINGERPRINT;
    private FingerprintManager.CryptoObject mCryptoObject;
    private FingerprintUiHelper mFingerprintUiHelper;
    private InputMethodManager mInputMethodManager;
    private SharedPreferences mSharedPreferences;
    private Unbinder unbinder;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
        setStyle(DialogFragment.STYLE_NORMAL, android.R.style.Theme_Material_Light_Dialog);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getDialog().setCanceledOnTouchOutside(false);
        getDialog().setTitle(getString(R.string.sign_in));
        getDialog().setCancelable(false);
        if (LoginActivity.isFingerFlow) {
            getDialog().setTitle("Please Register");
            getDialog().setCancelable(false);
        }
        View v = inflater.inflate(R.layout.fingerprint_dialog_container, container, false);
        unbinder = ButterKnife.bind(this, v);
        mCancelButton.setOnClickListener(view -> dismiss());
        mSecondDialogButton.setOnClickListener(view -> {
            if (mStage == Stage.FINGERPRINT) {
                goToBackup();
            } else {
                verifyPassword();
            }
        });
        mPassword.setOnEditorActionListener(this);
        mFingerprintUiHelper = new FingerprintUiHelper(
                getActivity().getSystemService(FingerprintManager.class),
                fingerPrintIcon,
                fingerPrintStatus, this, getContext());
        updateStage();
        if (!mFingerprintUiHelper.isFingerprintAuthAvailable()) {
            goToBackup();
        }
        return v;
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onResume() {
        super.onResume();
        if (mStage == Stage.FINGERPRINT) {
            mFingerprintUiHelper.startListening(mCryptoObject);
        }
    }

    public void setStage(Stage stage) {
        mStage = stage;
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onPause() {
        super.onPause();
        mFingerprintUiHelper.stopListening();
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mInputMethodManager = context.getSystemService(InputMethodManager.class);
        mSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
    }

    public void setCryptoObject(FingerprintManager.CryptoObject cryptoObject) {
        mCryptoObject = cryptoObject;
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void goToBackup() {
        mStage = Stage.PASSWORD;
        updateStage();
        if(mPassword!=null) {
            mPassword.requestFocus();
            mPassword.postDelayed(mShowKeyboardRunnable, 500);
        }
        mFingerprintUiHelper.stopListening();
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void verifyPassword() {
        if (!checkPassword(mPassword.getText().toString())) {
            return;
        }
        if (mStage == Stage.NEW_FINGERPRINT_ENROLLED) {
            SharedPreferences.Editor editor = mSharedPreferences.edit();
            editor.putBoolean(getString(R.string.use_fingerprint_to_authenticate_key),
                    mUseFingerprintFutureCheckBox.isChecked());
            editor.apply();

            if (mUseFingerprintFutureCheckBox.isChecked()) {
                if (getActivity() instanceof LoginActivity) {
                    ((LoginActivity) getActivity()).createKey(LoginActivity.DEFAULT_KEY_NAME, true);
                } else {
                    ((ConfirmFingerprintActivity) getActivity()).createKey(LoginActivity.DEFAULT_KEY_NAME, true);
                }
                //mActivity.createKey(LoginActivityFitbit.DEFAULT_KEY_NAME, true);
                mStage = Stage.FINGERPRINT;
            }
        }
        mPassword.setText("");
        // Without FingerPrintwala
        //mActivity.onPurchased(false, null);
        if (getActivity() instanceof LoginActivity) {
            ((LoginActivity) getActivity()).onPurchased(false, null);
        } else {
            ((ConfirmFingerprintActivity) getActivity()).onPurchased(false, null);
        }
        dismiss();
    }

    private boolean checkPassword(String password) {
        return password.length() > 0;
    }

    private final Runnable mShowKeyboardRunnable = new Runnable() {
        @Override
        public void run() {
            mInputMethodManager.showSoftInput(mPassword, 0);
        }
    };

    private void updateStage() {
        switch (mStage) {
            case FINGERPRINT:
                mCancelButton.setText(R.string.cancel);
                mSecondDialogButton.setText(R.string.use_password);
                mSecondDialogButton.setVisibility(View.GONE);
                mFingerprintContent.setVisibility(View.VISIBLE);
                mBackupContent.setVisibility(View.GONE);
                break;
            case NEW_FINGERPRINT_ENROLLED:

            case PASSWORD:
                if (mSecondDialogButton != null) {
                    mSecondDialogButton.setText(R.string.ok);
                    mSecondDialogButton.setOnClickListener(view -> dismiss());
                }
                if (mFingerprintContent != null) {
                    mFingerprintContent.setVisibility(View.GONE);
                }
                if (mStage == Stage.NEW_FINGERPRINT_ENROLLED) {
                    mPasswordDescriptionTextView.setVisibility(View.GONE);
                    mNewFingerprintEnrolledTextView.setVisibility(View.VISIBLE);
                    mUseFingerprintFutureCheckBox.setVisibility(View.VISIBLE);
                }
                break;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if (actionId == EditorInfo.IME_ACTION_GO) {
            verifyPassword();
            return true;
        }
        return false;
    }

    @Override
    public void onAuthenticated() {
        if (getActivity() != null) {
            // with fingerprint
            if (getActivity() instanceof LoginActivity) {
                ((LoginActivity) getActivity()).onPurchased(true, mCryptoObject);
            } else {
                ((ConfirmFingerprintActivity) getActivity()).onPurchased(true, mCryptoObject);
            }
        }
        dismiss();
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onError() {
        goToBackup();
    }

    public enum Stage {
        FINGERPRINT,
        NEW_FINGERPRINT_ENROLLED,
        PASSWORD
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }
}
