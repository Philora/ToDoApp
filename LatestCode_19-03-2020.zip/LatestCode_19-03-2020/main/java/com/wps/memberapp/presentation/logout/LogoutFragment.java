package com.wps.memberapp.presentation.logout;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.wps.memberapp.R;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.domain.fitbitauth.authentication.AuthenticationManager;
import com.wps.memberapp.presentation.base.BaseFragment;
import com.wps.memberapp.presentation.dashboard.activity.DashboardActivity;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.GeneralUtils;

import androidx.annotation.NonNull;

/**
 * This fragment is used to display logout dialog to the user and to clean all the resources.
 */
public class LogoutFragment extends BaseFragment {


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        return inflater.inflate(R.layout.fragment_logout, container, false);
    }

    /**
     * Clear all activities
     */
    private void logout() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setCancelable(false);
        builder.setMessage(R.string.do_you_want_logout);
        builder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                SharedPreferenceHelper.getInstance().clearPreference(getActivity(), AppConstants.AUTHORIZATION_TOKEN);
                SharedPreferenceHelper.getInstance().clearPreference(getActivity(),"FedAuth");
                SharedPreferenceHelper.getInstance().clearPreference(getActivity(),"FedAuth1");
                SharedPreferenceHelper.getInstance().clearPreference(getActivity(),"latitude");
                SharedPreferenceHelper.getInstance().clearPreference(getActivity(),"longitude");
                SharedPreferenceHelper.getInstance().clearPreference(getActivity(),"step_goal");

                GeneralUtils.logoutApp(getActivity());
            }
        });//                AuthenticationManager.logout(getActivity());

        builder.setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                dialog.cancel();
                Intent myIntent = new Intent(getActivity(), DashboardActivity.class);
                getActivity().startActivity(myIntent);
                getActivity().finish();
            }
        });

        AlertDialog alert = builder.create();
        alert.show();
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        logout();
    }
}
