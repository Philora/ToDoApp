package com.wps.memberapp.presentation.medication.adapter;

import android.app.Activity;
import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;


import com.wps.memberapp.R;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


public class MedicationAdapter extends RecyclerView.Adapter<MedicationAdapter.ProductViewHolder> {

    //This context will be used to inflate the layout
    private final Context mCtx;
    private final List<String> mList;
    private final List<String> quantities;


    //Getting the context and product list with constructor
    public MedicationAdapter(Context mCtx, Activity activity, List<String> mList, List<String> quantities) {
        this.mCtx = mCtx;
        this.mList = mList;
        this.quantities = quantities;
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.add_medication_list_item, parent, false);
        return new ProductViewHolder(view, new MyCustomEditTextListener());
    }

    @Override
    public void onBindViewHolder(@NonNull final ProductViewHolder holder, int position) {

        //Binding the data with the viewHolder views
        if (mList != null) {
            if (mList.get(position).equalsIgnoreCase("6 am") || mList.get(position).equalsIgnoreCase("7 am") || mList.get(position).equalsIgnoreCase("8 am") || mList.get(position).equalsIgnoreCase("9 am") || mList.get(position).equalsIgnoreCase("10 am") || mList.get(position).equalsIgnoreCase("11 am")) {
                holder.morningTime.setText(mList.get(position));
                holder.imageView.setBackgroundResource(R.drawable.ic_morning);
                holder.textView.setText(R.string.morning);
            } else if (mList.get(position).equalsIgnoreCase("12 pm") || mList.get(position).equals("1 pm") || mList.get(position).equalsIgnoreCase("2 pm") || mList.get(position).equalsIgnoreCase("3 pm") || mList.get(position).equalsIgnoreCase("4 pm") || mList.get(position).equalsIgnoreCase("5 pm")) {
                holder.morningTime.setText(mList.get(position));
                holder.imageView.setBackgroundResource(R.drawable.ic_noon);
                holder.textView.setText(R.string.afternoon);
            } else {
                holder.morningTime.setText(mList.get(position));
                holder.imageView.setBackgroundResource(R.drawable.ic_evening);
                holder.textView.setText(R.string.evening);
            }
            holder.myCustomEditTextListener.updatePosition(holder.getAdapterPosition());
            holder.medicineQuantity.setText("1"); // Add Medication quantity is "0" by default  but as per Member Portal it is "1"(Mandatory field)
        }
    }

    @Override
    public int getItemCount() {
        if (mList.isEmpty())
            return 0;
        else
            return mList.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    class ProductViewHolder extends RecyclerView.ViewHolder {

        final TextView morningTime;
        final EditText medicineQuantity;
        final ImageView imageView;
        final TextView textView;
        final MyCustomEditTextListener myCustomEditTextListener;


        ProductViewHolder(View itemView, MyCustomEditTextListener myCustomEditTextListener) {
            super(itemView);
            morningTime = itemView.findViewById(R.id.morningTime);
            imageView = itemView.findViewById(R.id.img_morning);
            textView = itemView.findViewById(R.id.txtMorning);
            medicineQuantity = itemView.findViewById(R.id.medicineQuantity);
            this.myCustomEditTextListener = myCustomEditTextListener;
            this.medicineQuantity.addTextChangedListener(myCustomEditTextListener);
        }
    }

    public List<String> getQuantities() {
        return this.quantities;
    }

    private class MyCustomEditTextListener implements TextWatcher {
        private int position;

        void updatePosition(int position) {
            this.position = position;
        }

        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            //Not used
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            String f = "";
            if (charSequence.length() > 0) {
                quantities.set(position, String.valueOf(String.valueOf(charSequence)));
            } else {
                quantities.set(position, f);
            }
        }

        @Override
        public void afterTextChanged(Editable editable) {
            //Not used
        }
    }

}
