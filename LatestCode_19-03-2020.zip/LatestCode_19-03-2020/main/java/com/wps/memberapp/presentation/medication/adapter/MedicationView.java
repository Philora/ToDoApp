package com.wps.memberapp.presentation.medication.adapter;

import com.wps.memberapp.data.model.Medication;
import java.util.List;

public interface MedicationView {

    void onMedicationList(List<Medication> medication);
}
