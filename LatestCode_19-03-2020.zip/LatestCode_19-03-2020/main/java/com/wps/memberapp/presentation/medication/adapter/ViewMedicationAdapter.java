package com.wps.memberapp.presentation.medication.adapter;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.wps.memberapp.R;
import com.wps.memberapp.data.model.Medication;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
//import com.wps.memberapp.presentation.medication.fragment.MedicationPresenter;
import com.wps.memberapp.presentation.medication.fragment.MedicationPresenterImp;
import com.wps.memberapp.utility.ReminderAlertDialog;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


public class ViewMedicationAdapter extends RecyclerView.Adapter<ViewMedicationAdapter.ProductViewHolder> {

    //This context will be used to inflate the layout

    private final Context mCtx;
    private final Activity activity;
    //We are storing all the product in a list
    private final List<Medication> medicationList;
//    MedicationPresenter medicationPresenter;

    //getting the context and product list with constructor
    public ViewMedicationAdapter(Context mCtx, Activity activity, List<Medication> medicationList) {
        this.mCtx = mCtx;
        this.medicationList = medicationList;
        this.activity = activity;
//        this.medicationPresenter = new MedicationPresenterImp();
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.fragment_view_med_detail, parent, false);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, final int position) {

        //getting the product of the specified position
        Medication medication = medicationList.get(position);
        String medicineList = medication.getMedicine_Day_Plan();
        String medicineQuantity = medication.getNumber_Of_Tablets();


//        if (medicineList.contains("6AM") || medicineList.contains("7AM") || medicineList.contains("8 AM") || medicineList.contains("9 AM") || medicineList.contains("10 AM") || medicineList.contains("11AM")) {
        if (medicineList.contains("AM")) {
            holder.txtMorning.setText(R.string.morning);
            holder.morningTime.setText(medicineList);
            holder.imgMorning.setBackgroundResource(R.drawable.ic_morning);
        } else if (medicineList.contains("12PM") || medicineList.contains("1PM") || medicineList.contains("2 PM") || medicineList.contains("3PM") || medicineList.contains("3 PM") || medicineList.contains("4PM") || medicineList.contains("4 PM")) {
            holder.txtMorning.setText(R.string.afternoon);
            holder.morningTime.setText(medicineList);
            holder.imgMorning.setBackgroundResource(R.drawable.ic_noon);
        } else {
            holder.txtMorning.setText(R.string.evening);
            holder.morningTime.setText(medicineList);
            holder.imgMorning.setBackgroundResource(R.drawable.ic_evening);
        }

        if (SharedPreferenceHelper.getInstance() != null) {
            String intakePlanSelectedValue = medication.getIntake_Plan();
            String doseValue = medication.getDosage();
            String medicineName = medication.getMedicine_Name();
            String imagePath = medication.getImage_Path();
            String text = medicineName + " " + doseValue + " " + "tablet";
            holder.medicationTextViewHeader.setText(text);
            if (imagePath != null) {
                Uri myUri = Uri.parse(imagePath);
                Glide.with(mCtx)
                        .load(myUri)
                        .error(R.drawable.medicationicon)
                        .diskCacheStrategy(DiskCacheStrategy.NONE)
                        .skipMemoryCache(true)
                        .into(holder.mMedication);
            } else {
                SharedPreferenceHelper.getInstance().setPreference(mCtx, "imagePath", null);
            }
            String medicine = medicineQuantity + " " + "Pill" + "  " + " + " + intakePlanSelectedValue;
            holder.medicineTxtView.setText(medicine);
        }

        //Binding the data with the viewHolder views
        holder.icReminder.setOnClickListener(view -> showDialog());
        holder.icRemClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        holder.icRemSeschedule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                medicationPresenter.getRescheduleReminder();
            }
        });
    }

    @Override
    public int getItemCount() {
        if (medicationList != null)
            return medicationList.size();
        else
            return 0;
    }

    class ProductViewHolder extends RecyclerView.ViewHolder {

        final TextView medicationTextViewHeader;
        final TextView medicineTxtView;
        final TextView txtMorning;
        final TextView morningTime;
        private final ImageView imgMorning;
        private final ImageView mMedication;
        private final ImageView icReminder;
        private final ImageView icRemClose;
        private final ImageView icRemSeschedule;


        ProductViewHolder(View itemView) {
            super(itemView);
            mMedication = itemView.findViewById(R.id.ic_medication);
            medicationTextViewHeader = itemView.findViewById(R.id.medicationTextViewHeader);
            medicineTxtView = itemView.findViewById(R.id.medicineTxtView);
            txtMorning = itemView.findViewById(R.id.txtMorning);
            morningTime = itemView.findViewById(R.id.morningTime);
            imgMorning = itemView.findViewById(R.id.img_morning);
            icReminder = itemView.findViewById(R.id.ic_reminder);
            icRemClose = itemView.findViewById(R.id.ic_rem_close);
            icRemSeschedule = itemView.findViewById(R.id.ic_rem_reschedule);
        }
    }

    private void showDialog() {
//        medicationPresenter.getReminder();
        ReminderAlertDialog newFragment = ReminderAlertDialog.newInstance();
        newFragment.show(activity.getFragmentManager(), "Title");
    }
}

