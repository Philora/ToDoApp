package com.wps.memberapp.presentation.medication.adapter;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.Medication;
import com.wps.memberapp.presentation.medication.fragment.AddMedicationView;
import com.wps.memberapp.utility.GeneralUtils;

import java.util.List;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

public class ViewPagerAdapter extends FragmentStatePagerAdapter {
    private int noOfItems;
    private List<String> mDay;
    private TextView txtMonth, txtDay, txtDate;
    Context mContext;

    public ViewPagerAdapter(FragmentManager fm, int noOfItems, List<String> day, Context context) {
        super(fm);
        this.noOfItems = noOfItems;
        this.mDay = day;
        this.mContext = context;
    }

    @Override
    public Fragment getItem(int position) {
        String mResDate = mDay.get(position);
        String[] dayParts = mResDate.split(" ");
        String day = dayParts[2].toUpperCase();
        return DynamicDaysFragment.checkDay(day);
//        return DynamicDayFragment.newInstance(position);
    }

    @Override
    public int getCount() {
        return noOfItems;
    }

    public View getTabView(int position) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.custom_tab, null);
        txtMonth = (TextView) v.findViewById(R.id.txt_Month);
        txtDate = (TextView) v.findViewById(R.id.txt_Date);
        txtDay = (TextView) v.findViewById(R.id.txt_Day);
        String mResDate = mDay.get(position);
        String[] dayParts = mResDate.split(" ");
        String month = dayParts[0].toUpperCase();
        String date = dayParts[1];
        String day = dayParts[2].toUpperCase();
        System.out.println(month + "\n" + date + "\n" + day);
        txtMonth.setText(month);
        txtDate.setText(date);
        txtDay.setText(day);
        return v;
    }

    @SuppressLint("ValidFragment")
    public static class DynamicDaysFragment extends Fragment { //implements MedicationView {

        @BindView(R.id.recyclerMedicationView)
        RecyclerView recyclerMedicationView;
        @BindView(R.id.no_medications)
        TextView noMedications;
        @BindView(R.id.add_Medication_Btn)
        FloatingActionButton fab1;
        private String valDay;
        private String imagePath;
        private ProgressDialog progressDialog;
        private Unbinder unbinder;
        Context mContext;
        List<Medication> medicationList;

        public DynamicDaysFragment() {
            this.mContext = getContext();
        }

        public static Fragment checkDay(String day) {
            DynamicDaysFragment fragment = new DynamicDaysFragment();
            Bundle args = new Bundle();
            args.putString("selectedDay", day);
            fragment.setArguments(args);
            return fragment;
        }

        @Override
        public void onCreate(@Nullable Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
        }

        @TargetApi(Build.VERSION_CODES.N)
        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
            GeneralUtils.setLanguage(getActivity());
            View rootView = inflater.inflate(R.layout.fragment_dynamic_day, container, false);
            unbinder = ButterKnife.bind(this, rootView);
            //    valDay = getArguments().getString("selectedDay");

            fab1.setOnClickListener(view -> {
                AddMedicationView medicationView = new AddMedicationView();
                FragmentManager manager = getFragmentManager();
                manager.beginTransaction().replace(R.id.frame_container, medicationView).addToBackStack(null).commit();
            });

            //getting list of medicines from previous screen
            if (getArguments() != null) {
                imagePath = getArguments().getString("imagePath");
            }

            medicationList = ProfileDataCache.getInstance().getMedicationList();
//            if (medicationList != null) {
                recyclerMedicationView.setHasFixedSize(true);
                recyclerMedicationView.setNestedScrollingEnabled(false);
                final LinearLayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
                mLayoutManager.setOrientation(RecyclerView.VERTICAL);
                recyclerMedicationView.setLayoutManager(mLayoutManager);
                ViewMedicationAdapter adapter = new ViewMedicationAdapter(getActivity(), getActivity(), medicationList);
                recyclerMedicationView.setAdapter(adapter);
                adapter.notifyDataSetChanged();
                noMedications.setVisibility(View.GONE);
            /*} else {
                noMedications.setVisibility(View.VISIBLE);
            }*/
            return rootView;
        }

        @Override
        public void onDestroyView() {
            super.onDestroyView();
            unbinder.unbind();
        }

        /*@Override
        public void onMedicationList(List<Medication> medicationList) {
            if (medicationList != null) {
                recyclerMedicationView.setHasFixedSize(true);
                recyclerMedicationView.setNestedScrollingEnabled(false);
                final LinearLayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
                mLayoutManager.setOrientation(RecyclerView.VERTICAL);
                recyclerMedicationView.setLayoutManager(mLayoutManager);
                ViewMedicationAdapter adapter = new ViewMedicationAdapter(getActivity(), getActivity(), medicationList);
                recyclerMedicationView.setAdapter(adapter);
                adapter.notifyDataSetChanged();
                noMedications.setVisibility(View.GONE);
            } else {
                noMedications.setVisibility(View.VISIBLE);
            }
        }*/

    }
}
