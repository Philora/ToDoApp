package com.wps.memberapp.presentation.medication.fragment;

import android.annotation.TargetApi;
import android.app.ProgressDialog;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.wps.memberapp.R;
import com.wps.memberapp.data.model.Medication;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.medication.adapter.ViewMedicationAdapter;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.LocaleHelper;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import devs.mulham.horizontalcalendar.HorizontalCalendar;
import devs.mulham.horizontalcalendar.HorizontalCalendarListener;

/**
 * A Details screen which will display list of added medicines and timings to take medicines
 */

public class AddMedicationDetailFragment extends Fragment {

    @BindView(R.id.recyclerMedicationView)
    RecyclerView recyclerMedicationView;
    @BindView(R.id.no_medications)
    TextView noMedications;
    @BindView(R.id.add_Medication_Btn)
    FloatingActionButton fab1;
    private String imagePath;
    private ProgressDialog progressDialog;
    private Unbinder unbinder;
    String mSelectDay;
//    MedicationPresenter medicationPresenter;

    @TargetApi(Build.VERSION_CODES.N)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        View rootView = inflater.inflate(R.layout.add_medication_list_frag, container, false);
        unbinder = ButterKnife.bind(this, rootView);

        //Setting title to fragment
        if (getActivity() != null) {
            TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
            fragmentTitle.setText(R.string.my_medication);
            ImageView imageViewSearch = getActivity().findViewById(R.id.imageViewSearch);
            imageViewSearch.setVisibility(View.GONE);
            TextView txtDownloadPDF = getActivity().findViewById(R.id.txt_Call);
            txtDownloadPDF.setVisibility(View.GONE);
        }

//        medicationPresenter = new MedicationPresenterImp();
        Calendar startDate = Calendar.getInstance();
        Calendar endDate = Calendar.getInstance();
        String lang = SharedPreferenceHelper.getInstance().getPreference(getActivity(), "Language");
        final Date mStartDate, mEndDate;
        if ("es".equalsIgnoreCase(lang)) {
            startDate.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
            endDate.set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY);
            startDate = Calendar.getInstance();
//            String dayLongName = startDate.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, Locale.getDefault());
            mStartDate = startDate.getTime();
            mEndDate = endDate.getTime();
        } else {
            startDate.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
            endDate.set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY);
        }

        getMedicationByMemberID();
        Log.d("AddMedicationDetails", "Start Day = " + startDate);
        Log.d("AddMedicationDetails", "End Day = " + endDate);
        HorizontalCalendar horizontalCalendar = new HorizontalCalendar.Builder(rootView, R.id.calendarView)
                .startDate(startDate.getTime())
                .endDate(endDate.getTime())
                .datesNumberOnScreen(5)
                .dayNameFormat("EEE")
                .dayNumberFormat("dd")
                .textSize(0f, 20f, 12f)
                .showDayName(true)
                .build();

        horizontalCalendar.setCalendarListener(new HorizontalCalendarListener() {
            @Override
            public void onDateSelected(Date date, int position) {
                DateFormat dateFormat1 = new SimpleDateFormat("MMM dd EEE", Locale.ENGLISH);
                mSelectDay = dateFormat1.format(date.getTime()); //  mSelectDay = dateFormat1.format(curToday.getTime());
                String[] dayParts = mSelectDay.split(" ");
                String mResDay = dayParts[2].toUpperCase();
                Log.i("mDaySelected", mResDay + " - Position = " + position);
                SharedPreferenceHelper.getInstance().setPreference(getContext(), StringConstants.SELECTED_DAY, mResDay);
                recyclerMedicationView.setHasFixedSize(true);
                final LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
                layoutManager.setOrientation(RecyclerView.VERTICAL);
                recyclerMedicationView.setLayoutManager(layoutManager);
            }
        });

        fab1.setOnClickListener(view -> {
            boolean isRegistered = SharedPreferenceHelper.getInstance().getPrefBoolean(getActivity(), "MedicationRegistration", false);
            if (!isRegistered) {
//                medicationPresenter.getRegisterDevice();
            }
            AddMedicationView medicationView = new AddMedicationView();
            FragmentManager manager = getFragmentManager();
            manager.beginTransaction().replace(R.id.frame_container, medicationView).addToBackStack(null).commit();

        });

        //getting list of medicines from previous screen
        if (getArguments() != null) {
            imagePath = getArguments().getString("imagePath");
        }

        //Setting dynamic layout manager to recycle view
      /*  recyclerMedicationView.setHasFixedSize(true);
        final LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        recyclerMedicationView.setLayoutManager(layoutManager);
        //Creating adapter object and setting to recycle view along with default animation
        getMedicationByMemberID();*/
        return rootView;
    }

    private void getMedicationByMemberID() {
        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setCancelable(false);
        progressDialog.setMessage(getString(R.string.loading_please_wait));
        progressDialog.show();
        VolleyService.getMedicationsByMemberID(getActivity(), AppConstants.GET_MEDICATIONS_BY_MEMBER_ID_URL, new VolleyResponseListener() {
            @Override
            public void onResponse(String message) {
                progressDialog.dismiss();
                showLog(message);
                try {
                    if (message != null && message.equals("[]")) {
                        noMedications.setVisibility(View.VISIBLE);
                    } else {
                        noMedications.setVisibility(View.GONE);
                        JSONArray response = new JSONArray(message);
                        ArrayList<Medication> medications = new ArrayList<>();
                        for (int i = 0; i < response.length(); i++) {
                            JSONObject obj = response.getJSONObject(i);
                            Medication medication = new Medication();
                            String medicineName = obj.getString("medicineName");
                            medication.setMedicine_Name(medicineName);
                            SharedPreferenceHelper.getInstance().setPreference(getActivity(), "medicine_name", medicineName);
                            String intakePlan = obj.getString("intakePlan");
                            medication.setIntake_Plan(intakePlan);
                            SharedPreferenceHelper.getInstance().setPreference(getActivity(), "intakePlanValue", intakePlan);
                            String dosage = obj.getString("dosage");
                            medication.setDosage(dosage);
                            String unit = obj.getString("unit");
                            medication.setUnit(unit);
                            SharedPreferenceHelper.getInstance().setPreference(getActivity(), "doseValueSelectedItem", dosage + " " + unit);
                            imagePath = obj.getString("imagePath");
                            medication.setImage_Path(imagePath);
                            SharedPreferenceHelper.getInstance().setPreference(getActivity(), "imagePath", imagePath);
                            String quantity = obj.getString("quantity");
                            medication.setNumber_Of_Tablets(quantity);
                            String time = obj.getString("time");
                            medication.setMedicine_Day_Plan(time);
                            medications.add(medication);
                        }
                        //Creating adapter object and setting to recycle view along with default animation
                        // Collections.reverse(medications);
                        ViewMedicationAdapter adapter = new ViewMedicationAdapter(getActivity(), getActivity(), medications);
                        recyclerMedicationView.setItemAnimator(new DefaultItemAnimator());
                        recyclerMedicationView.setAdapter(adapter);
                        adapter.notifyDataSetChanged();
                    }
                } catch (Exception e) {
                    Logger.e("Medication", e);
                }
            }

            @Override
            public void onError(String error) {
                progressDialog.dismiss();
                showLog(error);
                noMedications.setVisibility(View.VISIBLE);
            }
        });
    }

    private void showLog(String text) {
        Log.d("MedicationDetails", text);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }
}
