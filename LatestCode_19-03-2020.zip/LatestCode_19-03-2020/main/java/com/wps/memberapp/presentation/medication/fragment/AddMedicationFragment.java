package com.wps.memberapp.presentation.medication.fragment;


import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.wps.memberapp.R;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * A screen which will display welcome screen for add medication
 */

public class AddMedicationFragment extends Fragment {

    @BindView(R.id.add_medication_btn)
    TextView image;
    private Unbinder unbinder;

    @Override
    public View onCreateView(LayoutInflater inflater,ViewGroup container,Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        if (container != null) {
            container.removeAllViews();
            container.clearDisappearingChildren();
        }
        View rootView = inflater.inflate(R.layout.add_medication_fragment, container, false);
        unbinder = ButterKnife.bind(this, rootView);
        image.setClickable(true);
        ImageView imageViewSearch = getActivity().findViewById(R.id.imageViewSearch);
        imageViewSearch.setVisibility(View.VISIBLE);
        imageViewSearch.setOnClickListener(view -> {
            SharedPreferenceHelper.getInstance().setPreference(getActivity(), "SearchQuery", "");
            FragmentManager fragmentManager = getFragmentManager();
            //fragmentManager.beginTransaction().replace(R.id.frame_container, new PegaSearchFragment()).addToBackStack(null).commit();
        });
        //Setting title for tool bar
        TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
        fragmentTitle.setText(R.string.add_medication);

        //setting onclick listener to display the screen which will provide form to add medicine
        image.setOnClickListener(v -> {
            AddMedicationDetailFragment medicationDetailView = new AddMedicationDetailFragment();
            getFragmentManager().beginTransaction().replace(R.id.frame_container, medicationDetailView).addToBackStack(null).commit();
        });
        return rootView;
    }

    private void showLog(String text) {
        Log.d("AddMedication", text);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }
}
