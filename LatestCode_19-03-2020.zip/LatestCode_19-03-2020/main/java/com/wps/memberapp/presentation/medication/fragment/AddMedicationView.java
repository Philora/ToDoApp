package com.wps.memberapp.presentation.medication.fragment;

import android.Manifest;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.claims.adapter.NothingSelectedSpinnerAdapter;
import com.wps.memberapp.presentation.login.activity.DetectionActivity;
import com.wps.memberapp.presentation.logout.LogoutFragment;
import com.wps.memberapp.presentation.medication.adapter.CalendarDaysAdapter;
import com.wps.memberapp.presentation.medication.adapter.GridViewAdapter;
import com.wps.memberapp.presentation.medication.adapter.MedicationAdapter;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.CustomView;
import com.wps.memberapp.utility.DatePickerFragment;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.GridCustomView;
import com.wps.memberapp.utility.ImageHelper;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.PermissionUtils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import androidx.core.view.GravityCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

import static android.app.Activity.RESULT_CANCELED;
import static android.app.Activity.RESULT_OK;

/**
 * A screen which will display  form to add medicine and setting alarm to take medicine
 */
public class AddMedicationView extends Fragment implements View.OnClickListener {

    private static final int CAMERA_REQUEST = 1001;
    @BindView(R.id.intakePlan)
    Spinner intakePlan;
    @BindView(R.id.doseValue)
    Spinner doseValue;
    @BindView(R.id.reminderTime)
    Spinner reminderTime;
    @BindView(R.id.calendar1)
    ImageView calendar1;
    @BindView(R.id.calendar2)
    ImageView calendar2;
    @BindView(R.id.startDate)
    TextView mStartDate;
    @BindView(R.id.endDate)
    TextView mEndDate;
    @BindView(R.id.btnCamera)
    ImageView btnCamera;
    @BindView(R.id.medicationListView)
    RecyclerView mMedicationRecylcerView;
    @BindView(R.id.gridView)
    GridView gridView;
    @BindView(R.id.editText)
    EditText doseQuantity;
    @BindView(R.id.medicationName)
    EditText medicationName;
    @BindView(R.id.btnDetailView)
    Button btnDetailView;
    @BindView(R.id.alarmSwitch)
    Switch alarm;
    @BindView(R.id.daysGridView)
    GridView daysGridView;
    private TextView intakePlanTxt;
    private String startDate = "";
    private String endDate = "";
    private String intakePlanValue = "";
    private String doseUnits = "";
    private Uri imageUri;
    private ArrayList<String> mList;
    private ArrayList<String> daysList;
    private ProgressDialog progressDialog;
    private List<String> selectedQuantities;
    private static final String DOSE_VALUE_SELECTED_ITEM = "doseValueSelectedItem";
    private Unbinder unbinder;
    private Calendar calender = Calendar.getInstance();
    private String imageFilePath = "";

    //Creating date picker dialog to select end date and will store in shared preferences
    private final DatePickerDialog.OnDateSetListener ondateSecond = new DatePickerDialog.OnDateSetListener() {

        public void onDateSet(DatePicker datePicker, int year, int monthOfYear,
                              int dayOfMonth) {
            datePicker.setMinDate(System.currentTimeMillis());
            mEndDate.setError(null);
            String date = String.valueOf(monthOfYear + 1) + "/" + dayOfMonth + "/" + year;
            mEndDate.setText(date);
            endDate = String.valueOf(monthOfYear + 1) + "/" + dayOfMonth + "/" + year;
            SharedPreferenceHelper.getInstance().setPreference(getActivity(), "endDate",
                    String.valueOf(monthOfYear + 1) + "/" + dayOfMonth + "/" + year);
        }
    };

    //Creating date picker dialog to select start date and will store in shared preferences
    private final DatePickerDialog.OnDateSetListener ondate = new DatePickerDialog.OnDateSetListener() {

        public void onDateSet(DatePicker datePicker, int year, int monthOfYear,
                              int dayOfMonth) {
            datePicker.setMinDate(System.currentTimeMillis());
            mStartDate.setError(null);
            String date = String.valueOf(monthOfYear + 1) + "/" + dayOfMonth + "/" + year;
            mStartDate.setText(date);
            startDate = String.valueOf(monthOfYear + 1) + "/" + dayOfMonth + "/" + year;
            SharedPreferenceHelper.getInstance().setPreference(getActivity(), "startDate",
                    String.valueOf(monthOfYear + 1) + "/" + dayOfMonth + "/" + year);
        }
    };

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        View rootView = inflater.inflate(R.layout.fragment_add, container, false);
        unbinder = ButterKnife.bind(this, rootView);

        //Setting title to fragment
        if (getActivity() != null) {
            TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
            fragmentTitle.setText(R.string.my_medication);
            ImageView imageViewSearch = getActivity().findViewById(R.id.imageViewSearch);
            imageViewSearch.setVisibility(View.GONE);
            TextView txtDownloadPDF = getActivity().findViewById(R.id.txt_Call);
            txtDownloadPDF.setVisibility(View.GONE);
        }
        //Inflating view controls
        mMedicationRecylcerView.setHasFixedSize(true);
        final LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        mMedicationRecylcerView.setLayoutManager(layoutManager);
        btnCamera.setEnabled(true);
        calendar1.setEnabled(true);
        calendar2.setEnabled(true);
        daysList = new ArrayList<>();
        reminderTime.setEnabled(false);
        alarm.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                reminderTime.setEnabled(false);
                if (b) {
                    reminderTime.setEnabled(true);
                }
            }
        });

        //Setting adapter to gridview and providing onclick listener
        final CalendarDaysAdapter adapter = new CalendarDaysAdapter(getActivity(),
                getActivity().getResources().getStringArray(R.array.days));
        daysGridView.setAdapter(adapter);
        daysGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                int selectedIndex = adapter.selectedPositions.indexOf(position);
                String selectedItem = String.valueOf(parent.getItemAtPosition(position));
                if (selectedIndex > -1) {
                    adapter.selectedPositions.remove(selectedIndex);
                    daysList.remove(selectedItem);
                    ((CustomView) view).display(false);
                } else {
                    adapter.selectedPositions.add(position);
                    daysList.add(selectedItem);
                    ((CustomView) view).display(true);
                }
                ProfileDataCache.getInstance().setDaysList(daysList);
                adapter.notifyDataSetChanged();
            }
        });

        addItemsOnSpinner1();
        addItemsOnSpinner2();
        addReminderTime();
        btnDetailView.setOnClickListener(this);
        return rootView;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mList = new ArrayList<>();
        selectedQuantities = new ArrayList<>();
        final GridViewAdapter mAdapter = new GridViewAdapter(getActivity(),
                getActivity().getResources().getStringArray(R.array.medication_time));
        gridView.setAdapter(mAdapter);

        //Used to Set the  onitemclicklistener to get the selected item from grid view
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                int selectedIndex = mAdapter.selectedPositions.indexOf(position);
                String selectedItem = String.valueOf(parent.getItemAtPosition(position));
                selectedItem = selectedItem.toUpperCase().trim();
                if (selectedIndex > -1) {
                    mAdapter.selectedPositions.remove(selectedIndex);
                    mList.remove(selectedItem);
                    ((GridCustomView) view).display(false);
                } else {
                    mAdapter.selectedPositions.add(position);
                    mList.add(selectedItem);
                    ((GridCustomView) view).display(true);
                }
                ProfileDataCache.getInstance().setMedicineList(mList);
                mAdapter.notifyDataSetChanged();

                //maintaining the selected quantities based on the user selection
                if (selectedQuantities.isEmpty()) {
                    for (int i = 0; i < mList.size(); i++) {
                        selectedQuantities.add(String.valueOf(0));
                    }
                } else {
                    if (mList.size() > selectedQuantities.size()) {
                        for (int i = 0; i < mList.size() - selectedQuantities.size(); i++) {
                            selectedQuantities.add(String.valueOf(0));
                        }
                    } else if (mList.size() < selectedQuantities.size()) {
                        for (int i = 0; i < selectedQuantities.size() - mList.size(); i++) {
                            selectedQuantities.remove(selectedIndex);
                        }
                    }
                }

                //Used to display the selected quantities
                MedicationAdapter adapter = new MedicationAdapter(getActivity(), getActivity(), mList, selectedQuantities);
                selectedQuantities = adapter.getQuantities();
                ProfileDataCache.getInstance().setNoOfTablets(selectedQuantities);
                mMedicationRecylcerView.setItemAnimator(new DefaultItemAnimator());
                mMedicationRecylcerView.setAdapter(adapter);
                adapter.notifyDataSetChanged();
            }
        });
        calendar1.setOnClickListener(v -> showDatePickerforCalendar());
        calendar2.setOnClickListener(v -> showDatePickerforCalendarNew());

        btnCamera.setOnClickListener(view1 -> {
            try {
                boolean result = PermissionUtils.checkPermission(getActivity());
                if (result) {
                    openCamera();
                } /*else {
                    AlertDialog.Builder alertBuilder = new AlertDialog.Builder(getActivity());
                    alertBuilder.setCancelable(false);
                    alertBuilder.setTitle("Permission necessary");
                    alertBuilder.setMessage("Write calendar permission is necessary to write event!!!");
                    alertBuilder.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                        @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions(getActivity(), new String[]{android.Manifest.permission.CAMERA}, 123);
                        }
                    });
                    AlertDialog alert = alertBuilder.create();
                    alert.show();
                }*/
            } catch (Exception e) {
                Logger.e("AddMedication", e);
            }
        });
    }

    //Creating adapter with reminder time values and setting to spinner
    private void addReminderTime() {
        List<String> listt = Arrays.asList(getActivity().getResources().getStringArray(R.array.spinner_item_reminder));
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(getActivity(),
                android.R.layout.simple_spinner_item, listt);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        reminderTime.setAdapter(dataAdapter);
        reminderTime.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String remindTime = reminderTime.getSelectedItem().toString();
                SharedPreferenceHelper.getInstance().setPreference(getActivity(), "reminder_time", remindTime);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //Do something
            }
        });
    }

    //Creating adapter with intake plan values and setting to spinner
    private void addItemsOnSpinner1() {
        List<String> objects = Arrays.asList(getActivity().getResources().getStringArray(R.array.intake_plan));
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(),
                R.layout.intake_plan_spinner_item, objects) {

            @NonNull
            @Override
            public View getView(int position, View convertView, @NonNull ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                v.setPadding(0, v.getPaddingTop(), v.getPaddingRight(), v.getPaddingBottom());
                intakePlanTxt = v.findViewById(R.id.intakePlanTxt);
                if (position == getCount()) {
                    intakePlanTxt.setText(" ");
                    intakePlanTxt.setHint(getItem(getCount()));
                    intakePlanTxt.setHintTextColor(getResources().getColor(R.color.loginField_txtColor));//"Hint to be displayed"
                }
                return v;
            }

            @Override
            public int getCount() {
                return super.getCount() - 1;
            }
        };
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        intakePlan.setAdapter(new NothingSelectedSpinnerAdapter(
                dataAdapter,
                R.layout.medication_intakeplan_spinner_hint,
                // R.layout.contact_spinner_nothing_selected_dropdown, // Optional
                getActivity()));

        //Added Selected listener to get the selected intake value from spinner
        intakePlan.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                try {
                    if (intakePlan.getSelectedItem() != null) {
                        intakePlanValue = intakePlan.getSelectedItem().toString();
                        SharedPreferenceHelper.getInstance().setPreference(getActivity(), "intakePlanValue", intakePlanValue);
                    }
                } catch (Exception e) {
                    Logger.e("AddMedication3", e);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //Do something
            }
        });
    }

    //Creating adapter with dose values and setting to spinner
    private void addItemsOnSpinner2() {
        List<String> objects = Arrays.asList(getActivity().getResources().getStringArray(R.array.dose_types));
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(), R.layout.intake_plan_spinner_item, objects) {

            @NonNull
            @Override
            public View getView(int position, View convertView, @NonNull ViewGroup parent) {

                View v = super.getView(position, convertView, parent);
                v.setPadding(0, v.getPaddingTop(), v.getPaddingRight(), v.getPaddingBottom());

                if (position == getCount()) {
                    intakePlanTxt.setText("");
                    intakePlanTxt.setHint(getItem(getCount()));
                    intakePlanTxt.setHintTextColor(getResources()
                            .getColor(R.color.loginField_txtColor));//"Hint to be displayed"
                }
                return v;
            }

            @Override
            public int getCount() {
                return super.getCount() - 1;
            }
        };
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        doseValue.setAdapter(new NothingSelectedSpinnerAdapter(
                dataAdapter,
                R.layout.medication_units_spinner_hint,
                // R.layout.contact_spinner_nothing_selected_dropdown, // Optional
                getActivity()));

        //Added Selected listener to get the selected dose value from spinner
        doseValue.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                try {
                    if (doseValue.getSelectedItem() != null) {
                        doseUnits = doseValue.getSelectedItem().toString();
                        SharedPreferenceHelper.getInstance().setPreference(getActivity(),
                                DOSE_VALUE_SELECTED_ITEM, doseUnits);
                    }
                } catch (Exception e) {
                    Logger.e("AddMedication1", e);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //Do something
            }
        });
    }

    private void showDatePickerforCalendar() {
        DatePickerFragment date = new DatePickerFragment();
        /*
         * Set up Current Date into dialog
         */
        Calendar calender = Calendar.getInstance();
        Bundle args = new Bundle();
        args.putInt("year", calender.get(Calendar.YEAR));
        args.putInt("month", calender.get(Calendar.MONTH));
        args.putInt("day", calender.get(Calendar.DAY_OF_MONTH));
        args.putString("CustomDatePicker", "AddMedDatePicker");
        date.setArguments(args);
        /*
         * Set Call back to capture selected date
         */
        date.setCallBack(ondate);
        if (getFragmentManager() != null) {
            date.show(getFragmentManager(), "DatePicker");
        }
    }

    private void showDatePickerforCalendarNew() {
        DatePickerFragment date = new DatePickerFragment();
        /*
         * Set Up current Date into dialog
         */
        Calendar calender = Calendar.getInstance();
        Bundle args = new Bundle();
        args.putInt("year", calender.get(Calendar.YEAR));
        args.putInt("month", calender.get(Calendar.MONTH));
        args.putInt("day", calender.get(Calendar.DAY_OF_MONTH));
        args.putString("CustomDatePicker", "AddMedDatePicker");
        date.setArguments(args);
        /*
         * Set Call Back to capture selected date
         */
        date.setCallBack(ondateSecond);
        date.show(getFragmentManager(), "Date PickerNew");
    }

    //Launch Camera to capture image
    private void openCamera() {
        try {
            if (isWriteStoragePermissionGranted() && isReadStoragePermissionGranted() && isCameraPermissionGranted()) {
                dispatchTakePictureIntent();
            }
        } catch (Exception e) {
            Logger.e("AddMedication2", e);
        }
    }

    private boolean isWriteStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (getActivity().checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                Log.v("LoginActivityFitbit", "Permission is granted2");
                return true;
            } else {
                Log.v("LoginActivityFitbit", "Permission is revoked2");
                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 2);
                return false;
            }
        } else {
            Log.v("LoginActivityFitbit", "Permission is granted2");
            return true;
        }
    }

    @SuppressLint("LongLogTag")
    public boolean isReadStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (getActivity().checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                Log.v("LoginActivityFitbit", "Permission is granted1");
                return true;
            } else {
                Log.v("LoginActivityFitbit", "Permission is revoked1");
                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 3);
                return false;
            }
        } else {
            Log.v("LoginActivityFitbit", "Permission is granted1");
            return true;
        }
    }

    private boolean isCameraPermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (getActivity().checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                Log.v("LoginActivityFitbit", "Permission is granted2");
                return true;
            } else {
                Log.v("LoginActivityFitbit", "Permission is revoked2");
                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.CAMERA}, 2);
                return false;
            }
        } else {
            Log.v("LoginActivityFitbit", "Permission is granted2");
            return true;
        }
    }

    //Used to process the received image from camera
    /*@Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK) {
            Log.e("Image Name", imageUri.getPath());
            Bitmap myBitmap = BitmapFactory.decodeFile(imageUri.getPath());
//            btnCamera.setBackgroundResource(0);
            btnCamera.setImageBitmap(myBitmap);
        }
    }*/
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAMERA_REQUEST) {
            if (resultCode == RESULT_OK) {
                String image = SharedPreferenceHelper.getInstance().getPreference(getActivity(), "imagePath");
                imageUri = FileProvider.getUriForFile(getActivity(), "com.wps.memberapp.fileprovider", new File(image));
                // Start a background task to detect facs in the image.
                Bitmap myBitmap = ImageHelper.loadSizeLimitedBitmapFromUri(Uri.fromFile(new File(image)), getActivity().getContentResolver());
//                Bitmap myBitmap = BitmapFactory.decodeFile(imageUri.getPath());
                if (myBitmap != null) {
                    btnCamera.setImageBitmap(myBitmap);
                    /*btnCamera.getLayoutParams().height = 65;
                    btnCamera.getLayoutParams().width = 65;*/
                }
            } else {
                Toast.makeText(getActivity(), "Picture not setting from IMAGE path", Toast.LENGTH_SHORT);
            }
        } else if (resultCode == RESULT_CANCELED) {
            Toast.makeText(getActivity(), "Picture was not taken", Toast.LENGTH_SHORT);
        } else {
            Toast.makeText(getActivity(), "Picture was not taken", Toast.LENGTH_SHORT);
        }
    }

    //Used to launch default camrera to take photo
    private void dispatchTakePictureIntent() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getActivity().getPackageManager()) != null) {
            // Save the photo taken to a temporary file.
            File photoFile = null;
            Uri photoURI = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                // Error occurred while creating the File
                ex.getMessage();
            }
            if (photoFile != null) {
                photoURI = FileProvider.getUriForFile(getContext(), "com.wps.memberapp.fileprovider", photoFile);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                intent.putExtra("android.intent.extras.CAMERA_FACING", 1);
                intent.putExtra("android.intent.extras.LENS_FACING_FRONT", 1);
                intent.putExtra("android.intent.extra.USE_FRONT_CAMERA", true);
                startActivityForResult(intent, CAMERA_REQUEST);
            }
        }
    }

    //Used to create image file from camera
    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String imageFileName = "IMG_" + timeStamp + "_";
        File storageDir = getActivity().getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );
        imageFilePath = image.getPath();
        SharedPreferenceHelper.getInstance().setPreference(getActivity(), "imagePath", imageFilePath);
        return image;
    }

    @Override
    public void onClick(View view) {

        Bundle args = new Bundle();

        //Used to store the intake plan and dose value in shared preferences
        String intakePlanSelectedValue = SharedPreferenceHelper.getInstance().getPreference(getActivity(), "intakePlanValue");
        args.putString("intakePlan", intakePlanSelectedValue);
        String doseValuee = SharedPreferenceHelper.getInstance().getPreference(getActivity(), DOSE_VALUE_SELECTED_ITEM);
        args.putString("doseValue", doseValuee);
        args.putStringArrayList("medication_list", mList);
        String medicationNameValue = medicationName.getText().toString();

        //Used to validate the data is entered or not
        if (medicationNameValue.length() == 0) {
            medicationName.requestFocus();
            medicationName.setError(getString(R.string.enter_medicine_name));
            return;
        }
        if (intakePlanValue.length() == 0) {
            TextView errorText = (TextView) intakePlan.getSelectedView();
            errorText.setError("");
            errorText.setTextColor(Color.RED);//just to highlight that this is an error
            errorText.setText(R.string.select_intake_plan);
            return;
        }

        String doseQuantityValue = doseQuantity.getText().toString();
        if (doseQuantityValue.length() == 0) {
            doseQuantity.requestFocus();
            doseQuantity.setError(getString(R.string.please_enter_dose));
            return;
        }

        if (doseUnits.length() == 0) {
            TextView errorText = (TextView) (this.doseValue).getSelectedView();
            errorText.setError("");
            Toast.makeText(getActivity(), R.string.select_dose_units, Toast.LENGTH_SHORT).show();
            return;
        }

        SharedPreferenceHelper.getInstance().setPreference(getActivity(), DOSE_VALUE_SELECTED_ITEM, doseQuantityValue);
        SharedPreferenceHelper.getInstance().setPreference(getActivity(), "doseUnitValueSelectedItem", doseUnits);

        if (startDate.length() == 0) {
            mStartDate.requestFocus();
            mStartDate.setError(getString(R.string.select_start_date));
            return;
        }
        if (endDate.length() == 0) {
            mEndDate.requestFocus();
            mEndDate.setError(getString(R.string.select_end_date));
            return;
        }

        if (daysList.isEmpty()) {
            Toast.makeText(getActivity(), R.string.select_day, Toast.LENGTH_SHORT).show();
            return;
        }

        if (selectedQuantities.isEmpty()) {
            Toast.makeText(getActivity(), R.string.select_time_quantity, Toast.LENGTH_SHORT).show();
            return;
        }

        //Used to display medicine details fragment
        args.putString("medicine_name", medicationName.getText().toString());
        if (imageUri != null && imageUri.toString() != null) {
            args.putString("imagePath", imageUri.toString());
            String image = imageUri.toString();
            if (SharedPreferenceHelper.getInstance() != null) {
                SharedPreferenceHelper.getInstance().setPreference(getActivity(), "imagePath", image);
            }
            imageUri = null;
        }
        SharedPreferenceHelper.getInstance().setPreference(getActivity(), "medicine_name", medicationNameValue);
        addMedicationData();
    }

    /**
     * Used to call web service for Add Medication Summary and get response as JSON
     * using post method
     */

    private void addMedicationData() {
        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage("Please Wait ...");
        progressDialog.setCancelable(false);
        progressDialog.show();
        VolleyService.addMedicationData(getActivity(), AppConstants.ADD_MEDICATION_DETAILS, new VolleyResponseListener() {
            @Override
            public void onError(String message) {
                progressDialog.dismiss();
                Log.i("ERROR_ADD_MEDICATION", message);
            }

            @Override
            public void onResponse(String response) {
                try {
                    progressDialog.dismiss();
                    Toast.makeText(getActivity(), "Medication added successfully", Toast.LENGTH_SHORT).show();
                    getActivity().getFragmentManager().popBackStack();
                    ((AppCompatActivity) getActivity()).getSupportFragmentManager().popBackStack();
                    medicationName.setText("");
                    doseQuantity.setText("");
                    Log.i("SUCCESS_ADD_MEDICATION", response);
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }
}