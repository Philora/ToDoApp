package com.wps.memberapp.presentation.medication.fragment;

import android.annotation.TargetApi;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.Medication;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.base.BaseFragment;
import com.wps.memberapp.presentation.medication.adapter.ViewMedicationAdapter;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

public class CustomAddMedicationView extends BaseFragment {

    @BindView(R.id.custom_rv_addmedication)
    RecyclerView customRvaddmedication;
    @BindView(R.id.no_medications)
    TextView noMedications;
    @BindView(R.id.add_Medication_Btn)
    FloatingActionButton fab1;
    private String imagePath;
    private Unbinder unbinder;
    String mResDay;

    @TargetApi(Build.VERSION_CODES.N)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        View rootView = inflater.inflate(R.layout.custom_addmedicaldetail, container, false);
        unbinder = ButterKnife.bind(this, rootView);

        if (getActivity() != null) {
            TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
            fragmentTitle.setText(R.string.my_medication);
            ImageView imageViewSearch = getActivity().findViewById(R.id.imageViewSearch);
            imageViewSearch.setVisibility(View.GONE);
            TextView txtDownloadPDF = getActivity().findViewById(R.id.txt_Call);
            txtDownloadPDF.setVisibility(View.GONE);
        }

        DateFormat format = new SimpleDateFormat("MMM" + "\n" + "dd" + "\n" + "EEE", Locale.ENGLISH);
        Calendar calendar = Calendar.getInstance();
        calendar.setFirstDayOfWeek(Calendar.SUNDAY);
        calendar.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(5, 0, 5, 0);
        // For comparing Today's Day with Calendar List
        DateFormat dateFormat1 = new SimpleDateFormat("MMM" + "\n" + "dd" + "\n" + "EEE", Locale.ENGLISH);
        Date curToday = new Date();
        String mCurrentDay = dateFormat1.format(curToday.getTime());
        String[] arrDays = new String[7];
        final TextView[] dynamicText = new TextView[7];
        LinearLayout lLayout = (LinearLayout) rootView.findViewById(R.id.layout); // Root ViewGroup in which you want to add textviews
        for (int i = 0; i < 7; i++) {
            dynamicText[i] = new TextView(getActivity());
            arrDays[i] = format.format(calendar.getTime());
            calendar.add(Calendar.DAY_OF_WEEK, 1);
            dynamicText[i].setGravity(Gravity.CENTER);
            dynamicText[i].setTextSize(18);
            dynamicText[i].setLayoutParams(params);
            dynamicText[i].setPadding(21, 8, 21, 8);
            dynamicText[i].setBackground(ContextCompat.getDrawable(getActivity(), R.drawable.bg_selector));
            dynamicText[i].setPadding(20, 5, 20, 5);
            dynamicText[i].setTextColor(Color.WHITE);
            dynamicText[i].setText(arrDays[i]);
            lLayout.addView(dynamicText[i]);
            final int I = i;
            if (mCurrentDay.equalsIgnoreCase(arrDays[I])) {
                dynamicText[i].setPadding(21, 8, 21, 8);
                dynamicText[i].setBackground(ContextCompat.getDrawable(getActivity(), R.drawable.bg_selected));
                dynamicText[i].setTextSize(18);
                ProfileDataCache.getInstance().setSelectedPostion(i);
                mResDay = arrDays[I];
                String[] arrSplit = mResDay.split("\\n");
                mResDay = arrSplit[2].toUpperCase();
                SharedPreferenceHelper.getInstance().setPreference(getContext(), StringConstants.SELECTED_DAY, mResDay);
//                Toast.makeText(getActivity(), mResDay, Toast.LENGTH_SHORT).show();
                getMedicationByMemberID();
            }
            dynamicText[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                        mResDay = arrDays[I];
                        String[] arrSplit = mResDay.split("\\n");
                        mResDay = arrSplit[2].toUpperCase();
                        int mSelPosition = ProfileDataCache.getInstance().getSelectedPostion();
                        if (I != mSelPosition) {
                            dynamicText[I].setBackground(ContextCompat.getDrawable(getActivity(), R.drawable.bg_selected));
                            ProfileDataCache.getInstance().setSelectedPostion(I);
                            dynamicText[mSelPosition].setBackground(ContextCompat.getDrawable(getActivity(), R.drawable.bg_unselected));
                            SharedPreferenceHelper.getInstance().setPreference(getContext(), StringConstants.SELECTED_DAY, mResDay);
                            getMedicationByMemberID();
                        }
//                        Toast.makeText(getActivity(), mResDay, Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        e.getLocalizedMessage();
                    }
                }
            });
        }

        fab1.setOnClickListener(view -> {
            boolean isRegistered = SharedPreferenceHelper.getInstance().getPrefBoolean(getActivity(), "MedicationRegistration", false);
            if (!isRegistered) {
//                medicationPresenter.getRegisterDevice();
            }
            AddMedicationView medicationView = new AddMedicationView();
            FragmentManager manager = getFragmentManager();
            manager.beginTransaction().replace(R.id.frame_container, medicationView).addToBackStack(null).commit();
        });

        return rootView;
    }

    private void getMedicationByMemberID() {
        VolleyService.getMedicationsByMemberID(getActivity(), AppConstants.GET_MEDICATIONS_BY_MEMBER_ID_URL, new VolleyResponseListener() {
            @Override
            public void onResponse(String message) {
                showLog(message);
                try {
                    if (message != null && message.equals("[]")) {
                        noMedications.setVisibility(View.VISIBLE);
                    } else {
                        noMedications.setVisibility(View.GONE);
                        JSONArray response = new JSONArray(message);
                        ArrayList<Medication> medications = new ArrayList<>();
                        for (int i = 0; i < response.length(); i++) {
                            JSONObject obj = response.getJSONObject(i);
                            Medication medication = new Medication();
                            String medicineName = obj.getString("medicineName");
                            medication.setMedicine_Name(medicineName);
                            SharedPreferenceHelper.getInstance().setPreference(getActivity(), "medicine_name", medicineName);
                            String intakePlan = obj.getString("intakePlan");
                            medication.setIntake_Plan(intakePlan);
                            SharedPreferenceHelper.getInstance().setPreference(getActivity(), "intakePlanValue", intakePlan);
                            String dosage = obj.getString("dosage");
                            medication.setDosage(dosage);
                            String unit = obj.getString("unit");
                            medication.setUnit(unit);
                            SharedPreferenceHelper.getInstance().setPreference(getActivity(), "doseValueSelectedItem", dosage + " " + unit);
                            imagePath = obj.getString("imagePath");
                            medication.setImage_Path(imagePath);
                            SharedPreferenceHelper.getInstance().setPreference(getActivity(), "imagePath", imagePath);
                            String quantity = obj.getString("quantity");
                            medication.setNumber_Of_Tablets(quantity);
                            String time = obj.getString("time");
                            medication.setMedicine_Day_Plan(time);
                            medications.add(medication);
                        }
                        //Creating adapter object and setting to recycle view along with default animation
                        // Collections.reverse(medications);
                        ViewMedicationAdapter adapter = new ViewMedicationAdapter(getActivity(), getActivity(), medications);
                        customRvaddmedication.setItemAnimator(new DefaultItemAnimator());
                        customRvaddmedication.setHasFixedSize(true);
                        final LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
                        layoutManager.setOrientation(RecyclerView.VERTICAL);
                        customRvaddmedication.setLayoutManager(layoutManager);
                        customRvaddmedication.setAdapter(adapter);
                        adapter.notifyDataSetChanged();
                    }
                } catch (Exception e) {
                    Logger.e("Medication", e);
                }
            }

            @Override
            public void onError(String error) {
                showLog(error);
                noMedications.setVisibility(View.VISIBLE);
            }
        });
    }
}
