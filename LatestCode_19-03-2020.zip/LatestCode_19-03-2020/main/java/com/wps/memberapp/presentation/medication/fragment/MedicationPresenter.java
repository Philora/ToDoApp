package com.wps.memberapp.presentation.medication.fragment;

import com.wps.memberapp.presentation.base.MvpPresenter;

interface MedicationPresenter extends MvpPresenter {

    void getMedicationByMemberID();


//    void getRegisterDevice();
//
//    void getReminder();
//
//    void getRescheduleReminder();

}
