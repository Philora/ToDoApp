package com.wps.memberapp.presentation.medication.fragment;

import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.Medication;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.base.MvpView;
import com.wps.memberapp.presentation.medication.adapter.MedicationView;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.Logger;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class MedicationPresenterImp implements MedicationPresenter {

    private MvpView mView;

    @Override
    public void onAttach(MvpView mView) {
        this.mView = mView;
    }


 /* @Override
    public void getRegisterDevice() {
        mView.showProgress();
        VolleyService.registerDevice(mView.getAppContext(),
                AppConstants.REGISTER_DEVICE_URL, new VolleyResponseListener() {
                    @Override
                    public void onError(String error) {
                        mView.hideProgress();
                        Log.d("Medication Error",error);
                    }

                    @Override
                    public void onResponse(String response) {
                        mView.hideProgress();
                        try {
                            if ("200".equalsIgnoreCase(response)) {
                                SharedPreferenceHelper.getInstance().setPrefBoolean(mView.getAppContext(), "MedicationRegistration", true);
                            }
                        } catch (Exception e) {
                            Logger.e("Exception", e);
                        }
                        Log.d("Medication Response",response);
                    }
                });
    }

    @Override
    public void getReminder() {
        mView.showProgress();
        VolleyService.reminderApiRequest(mView.getAppContext(),
                AppConstants.GET_REMINDER, new VolleyResponseListener() {
                    @Override
                    public void onError(String error) {
                        mView.hideProgress();
                        Log.d("Medication Error",error);
                    }

                    @Override
                    public void onResponse(String response) {
                        mView.hideProgress();
                        try {

                        } catch (Exception e) {
                            Logger.e("Exception", e);
                        }
                        Log.d("Medication Response",response);
                    }
                });

    }

    @Override
    public void getRescheduleReminder() {
        mView.showProgress();
        VolleyService.rescheduleReminderApiRequest(mView.getAppContext(),
                AppConstants.GET_RESCHEDULE_REMINDER, new VolleyResponseListener() {
                    @Override
                    public void onError(String error) {
                        mView.hideProgress();
                        Log.d("Medication Error",error);
                    }

                    @Override
                    public void onResponse(String response) {
                        mView.hideProgress();
                        try {

                        } catch (Exception e) {
                            Logger.e("Exception", e);
                        }
                        Log.d("Medication Response",response);
                    }
                });

    }*/


    @Override
    public void getMedicationByMemberID() {
        VolleyService.getMedicationsByMemberID(mView.getAppContext(), AppConstants.GET_MEDICATIONS_BY_MEMBER_ID_URL, new VolleyResponseListener() {
            @Override
            public void onResponse(String message) {
                try {
                    JSONArray response = new JSONArray(message);
                    ArrayList<Medication> medicationList = new ArrayList<>();
                    for (int i = 0; i < response.length(); i++) {
                        JSONObject obj = response.getJSONObject(i);
                        Medication medication = new Medication();
                        String medicineName = obj.getString("medicineName");
                        medication.setMedicine_Name(medicineName);
                        SharedPreferenceHelper.getInstance().setPreference(mView.getAppContext(), "medicine_name", medicineName);
                        String intakePlan = obj.getString("intakePlan");
                        medication.setIntake_Plan(intakePlan);
                        SharedPreferenceHelper.getInstance().setPreference(mView.getAppContext(), "intakePlanValue", intakePlan);
                        String dosage = obj.getString("dosage");
                        medication.setDosage(dosage);
                        String unit = obj.getString("unit");
                        medication.setUnit(unit);
                        SharedPreferenceHelper.getInstance().setPreference(mView.getAppContext(), "doseValueSelectedItem", dosage + " " + unit);
                        String imagePath = obj.getString("imagePath");
                        medication.setImage_Path(imagePath);
                        SharedPreferenceHelper.getInstance().setPreference(mView.getAppContext(), "imagePath", imagePath);
                        String quantity = obj.getString("quantity");
                        medication.setNumber_Of_Tablets(quantity);
                        String time = obj.getString("time");
                        medication.setMedicine_Day_Plan(time);
                        medicationList.add(medication);
                    }
                    ((MedicationView) mView).onMedicationList(medicationList);
                    ProfileDataCache.getInstance().setMedicationList(medicationList);
                } catch (Exception e) {
                    Logger.e("Medication", e);
                }
            }

            @Override
            public void onError(String error) {
                mView.hideProgress();
                Logger.e("Medication_Error", error);
            }
        });
    }

    @Override
    public void onDetach() {
        mView = null;
    }
}

