package com.wps.memberapp.presentation.profilemanagement;

import com.wps.memberapp.data.model.DemographicHistory;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.presentation.base.MvpView;

import java.util.List;

/**
 * This interface contain UI functions of demographic history screen
 */
public interface DemographicView extends MvpView {
    void onUserDetailsLoadingCompleted(List<MemberDetails> details);

    void onUpdateDemographicHistoryLoaded(List<DemographicHistory> historyList);
}
