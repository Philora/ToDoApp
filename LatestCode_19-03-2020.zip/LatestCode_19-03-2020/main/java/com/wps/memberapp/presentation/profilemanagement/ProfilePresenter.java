package com.wps.memberapp.presentation.profilemanagement;

import com.wps.memberapp.presentation.base.MvpPresenter;

import java.util.List;

/**
 * This interface contain all the profile management functionality declarations.
 */
public interface ProfilePresenter extends MvpPresenter {
    void updatePassword();

    void getUpdateDemographicHistory();

    void verifyPassword(String currentPwd);

    void getSecurityQuestions();

    void getUserSecurityQuestions();

    void updateSecurityQuestions(List<String> idList, List<String> ansList);

    void getBenefitUserDetails(int pos);

    void getCountriesData(String pinCode);

    void updateDemographicHistory();
}
