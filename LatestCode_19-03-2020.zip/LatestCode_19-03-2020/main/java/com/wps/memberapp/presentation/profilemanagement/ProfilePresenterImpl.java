package com.wps.memberapp.presentation.profilemanagement;

import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.DemographicHistory;
import com.wps.memberapp.data.model.DemographyData;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.model.SecurityQuestion;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.base.MvpView;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import androidx.annotation.NonNull;

/**
 * This class is used to implement all the profile management functions
 * which are declared in ProfilePresenter.
 */
public class ProfilePresenterImpl implements ProfilePresenter {
    private MvpView view;

    @Override
    public void onAttach(MvpView view) {
        this.view = view;
    }

    /*
This method is used to send the API request to update the password
 */
    @Override
    public void updatePassword() {
        view.showProgress();
        VolleyService.updatePassword(view.getAppContext(), AppConstants.CHANGE_PARAM, new VolleyResponseListener() {
            @Override
            public void onResponse(String response) {
                String msg = "";
                int statusCode = -1;
                if (response != null) {
                    try {
                        JSONObject obj = new JSONObject(response);
                        statusCode = obj.getInt("StatusCode");
                        if (statusCode == 0) {
                            msg = view.getAppContext().getString(R.string.param1_updated);
                        } else {
                            msg = obj.getString("ErrorMessage");
                        }
                    } catch (Exception e) {
                        Logger.e(StringConstants.EXCEPTION, e);
                    }
                }
                view.hideProgress();
                ((ProfileView) view).onPasswordUpdated(statusCode, msg);
            }

            @Override
            public void onError(String error) {
                view.hideProgress();
            }
        });
    }

    /*
This method is used to send the API request to get the updated demographic history
 */
    @Override
    public void getUpdateDemographicHistory() {
        view.showProgress();
        VolleyService.getDemographicHistory(view.getAppContext(), AppConstants.GET_DEMOGRAPHY_UPDATE_HISTORY, new VolleyResponseListener() {
            @Override
            public void onResponse(String response) {
                if (response != null) {
                    List<DemographicHistory> historyList = new ArrayList<>();
                    try {
                        Gson gson = new GsonBuilder().create();
                        JSONArray array = new JSONArray(response);
                        for (int i = 0; i < array.length(); i++) {
                            DemographicHistory history = gson.fromJson(array.getString(i), DemographicHistory.class);
                            historyList.add(history);
                        }
                    } catch (Exception e) {
                        Logger.e(StringConstants.EXCEPTION, e);
                    }
                    view.hideProgress();
                    ((DemographicView) view).onUpdateDemographicHistoryLoaded(historyList);
                }
            }

            @Override
            public void onError(String error) {
                Log.i("Update error", error);
            }
        });
    }

    /*
This method is used to send the API request to validate the password entered by user
 */
    @Override
    public void verifyPassword(@NonNull String currentPwd) {
        String param2 = SharedPreferenceHelper.getInstance().getPreference(view.getAppContext(), StringConstants.PARAM2);
        String url = "";
        if (param2 != null) {
            String mUsername = GeneralUtils.getBase64ChangePasswordString(param2);
            String mCurrentPassword = GeneralUtils.getBase64ChangePasswordString(currentPwd);
            mUsername = mUsername.replace("\n", "");
            mCurrentPassword = mCurrentPassword.replace("\n", "");
//            url = AppConstants.VERIFY_PARAM + "Username=" + mUsername + "&Password=" + mCurrentPassword;
//            url = AppConstants.VERIFY_PARAM +"Username=REVNT01FTUJFUg%3D%3D&Password=UGFzc3dvcmRfMQ%3D%3D";
            ProfileDataCache.getInstance().setConvUsername(mUsername);
            ProfileDataCache.getInstance().setConvPassword(mCurrentPassword);
        }
        view.showProgress();
        VolleyService.verifyPwd(view.getAppContext(), AppConstants.VERIFY_PARAM, new VolleyResponseListener() {
            @Override
            public void onResponse(String message) {
                try {
                    if (message != null) {
                        ((QuestionsView) view).onPasswordVerified(message);
                    }
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
                view.hideProgress();
            }

            @Override
            public void onError(String error) {
                ((QuestionsView) view).onPasswordVerified("false");
                view.hideProgress();
            }
        });
    }

    /*
This method is used to send the API request to get list of all security questions
 */
    @Override
    public void getSecurityQuestions() {
        VolleyService.getSecurityQuestions(view.getAppContext(), AppConstants.GET_SECURITY_QUESTIONS, new VolleyResponseListener() {
            @Override
            public void onResponse(String message) {
                try {
                    ((QuestionsView) view).onQuestionsLoaded(processQuestionsList(message));
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
            }

            @Override
            public void onError(String error) {
                Log.i("Questions error", error);
            }
        });
    }

    /*
This method is used to send the API request to get list of security questions based on the user
 */
    @Override
    public void getUserSecurityQuestions() {
        view.showProgress();
        String url = AppConstants.GET_USER_SECURITY_QUESTIONS;
        VolleyService.getUserSecurityQuestions(view.getAppContext(), url, new VolleyResponseListener() {
            @Override
            public void onResponse(String message) {
                try {
                    ((QuestionsView) view).onUserQuestionsLoaded(processQuestionsList(message));
                    view.hideProgress();
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
            }

            @Override
            public void onError(String error) {
                //Show error message
                view.hideProgress();
            }
        });
    }

    /*
This method is used to parse the security questions response and will store
all questions in a array list.
 */
    @NonNull
    private List<SecurityQuestion> processQuestionsList(String message) {
        List<SecurityQuestion> data = new ArrayList<>();
        if (message != null) {
            Gson gson = new GsonBuilder().create();
            try {
                JSONArray array = new JSONArray(message);
                for (int i = 0; i < array.length(); i++) {
                    SecurityQuestion question = gson.fromJson(array.getString(i), SecurityQuestion.class);
                    data.add(question);
                }
            } catch (Exception e) {
                Logger.e(StringConstants.EXCEPTION, e);
            }
        }
        return data;
    }

    /*
This method is used to send the API request to update the security questions along with answers
 */
    @Override
    public void updateSecurityQuestions(@NonNull List<String> idList, @NonNull List<String> ansList) {
        view.showProgress();
        String idsString = "";
        for (String id : idList) {
            idsString = idsString.concat(id + "$");
        }
        idsString = idsString.substring(0, idsString.length() - 1);

        String ansString = "";
        for (String id : ansList) {
            ansString = ansString.concat(id + "$");
        }
        ansString = ansString.substring(0, ansString.length() - 1);


        ProfileDataCache.getInstance().setQuestionList(idsString);
        ProfileDataCache.getInstance().setAnswerList(ansString);

        // Old Code
        /*HashMap<String, String> body = new HashMap<>();
        body.put("Email_ID", param2);
        body.put("QuestionList", idsString);
        body.put("AnswerList", ansString);
        String params = GeneralUtils.convertToBody(body);*/


        VolleyService.updateSecurityQuestions(view.getAppContext(), AppConstants.UPDATE_SECURITY_QUESTIONS, new VolleyResponseListener() {
            @Override
            public void onResponse(String message) {
                try {
                    view.hideProgress();
                    ((QuestionsView) view).onQuestionsUpdated(message);
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
            }

            @Override
            public void onError(String error) {
                view.hideProgress();
            }
        });
    }

    /*
This method is used to send the API request to get the details of the user benefits
 */
    @Override
    public void getBenefitUserDetails(int pos) {
        //Used to display infinite progress dilog
        VolleyService.getBenefitUser(view.getAppContext(), AppConstants.GET_BENEFIT_USER_DETAILS, new VolleyResponseListener() {
            @Override
            public void onResponse(String response) {
                List<MemberDetails> detailsList = new ArrayList<>();
                //Processing the response
                if (response != null) {
                    try {
                        Gson gson = new Gson();
                        JSONArray jsonArray = new JSONArray(response);
                        for (int i = 0; i < jsonArray.length(); i++) {
                            MemberDetails details = gson.fromJson(jsonArray.getString(i), MemberDetails.class);
                            detailsList.add(details);

                        }
                        if (view instanceof DemographicView) {
                            ((DemographicView) view).onUserDetailsLoadingCompleted(detailsList);
                        } else {
                            ((UpdateView) view).onUserDetailsLoadingCompleted(detailsList.get(pos));
                        }
                    } catch (Exception e) {
                        Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
                    }
                }
            }

            @Override
            public void onError(String error) {
                Log.i("User error", error);
            }
        });
    }

    /*
This method is used to send the API request to get the list of countries along with states
 */
    @Override
    public void getCountriesData(String pinCode) {
        DemographyData data = new DemographyData();
        data.setZipCode(pinCode);
        ProfileDataCache.getInstance().setDemographyData(data);
        view.showProgress();
        VolleyService.getCountries(view.getAppContext(), AppConstants.GET_COUNTRY_DATA, new VolleyResponseListener() {
            @Override
            public void onResponse(String message) {
                try {
                    if (message != null) {
                        List<String> statesList = new ArrayList<>();
                        List<String> countryList = new ArrayList<>();
                        statesList.add(view.getAppContext().getString(R.string.select_state));
                        countryList.add(view.getAppContext().getString(R.string.select_county));
                        parseStateData(message, statesList, countryList);
                    }
                    view.hideProgress();
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
            }

            @Override
            public void onError(String error) {
                view.hideProgress();
            }
        });
    }

    /*
This method is used to parse the countries and to store in a list
 */
    private void parseStateData(String message, List<String> statesList, List<String> countryList) {
        try {
            JSONArray data = new JSONObject(message).getJSONArray("CountyStates");
            if (data != null) {
                for (int i = 0; i < data.length(); i++) {
                    JSONObject object = data.getJSONObject(i);
                    String state = object.getString("StateValue");
                    if (!statesList.contains(state)) {
                        statesList.add(state);
                    }
                    countryList.add(object.getString("County"));
                }
            }
        } catch (Exception e) {
            Logger.e(StringConstants.EXCEPTION, e);
        }
        ((UpdateView) view).onCountriesLoaded(countryList);
        ((UpdateView) view).onStatesLoaded(statesList);
    }

    /*
This method is used to send the API request to update the demographic informations
 */
    @Override
    public void updateDemographicHistory() {
        view.showProgress();
        VolleyService.updateDemography(view.getAppContext(), AppConstants.UPDATE_DEMOGRAPHY, new VolleyResponseListener() {
            @Override
            public void onResponse(String message) {
                try {
                    view.hideProgress();
                    ((UpdateView) view).onDemographyUpdated(message);
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
            }

            @Override
            public void onError(String error) {
                view.hideProgress();
            }
        });
    }

    @Override
    public void onDetach() {
        view = null;
    }
}
