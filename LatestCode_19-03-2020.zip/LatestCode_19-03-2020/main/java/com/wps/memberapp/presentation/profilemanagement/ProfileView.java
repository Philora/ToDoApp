package com.wps.memberapp.presentation.profilemanagement;

import com.wps.memberapp.presentation.base.MvpView;

/**
 * This interface contain UI functions of updating password screen
 */
public interface ProfileView extends MvpView {
    void onPasswordUpdated(int statusCode, String msg);
}
