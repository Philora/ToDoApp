package com.wps.memberapp.presentation.profilemanagement;

import com.wps.memberapp.data.model.SecurityQuestion;
import com.wps.memberapp.presentation.base.MvpView;

import java.util.List;

/**
 * This interface contain UI functions of updating questions screen
 */
public interface QuestionsView extends MvpView {
    void onPasswordVerified(String status);
    void onQuestionsLoaded(List<SecurityQuestion> questionsList);
    void onUserQuestionsLoaded(List<SecurityQuestion> questionsList);
    void onQuestionsUpdated(String result);
}
