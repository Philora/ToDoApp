package com.wps.memberapp.presentation.profilemanagement;

import com.wps.memberapp.data.model.MemberDetails;

import java.util.List;

/**
 * This interface contain UI functions of update demographic history screen
 */
public interface UpdateView {
    void onUserDetailsLoadingCompleted(MemberDetails details);

    void onStatesLoaded(List<String> statesList);

    void onCountriesLoaded(List<String> countriesList);

    void onDemographyUpdated(String result);
}
