package com.wps.memberapp.presentation.profilemanagement.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.wps.memberapp.R;
import com.wps.memberapp.data.model.Address;
import com.wps.memberapp.data.model.DemographicHistory;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.domain.listener.DialogCallbackContract;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

/**
 * This adapter is used to display the list of demographic history of the user
 * as a list view.
 */
public class DemographicHistoryAdapter extends RecyclerView.Adapter<DemographicHistoryAdapter.ProductViewHolder>
        implements DialogCallbackContract {

    //this context  will be used to inflate the layout
    private final Context mCtx;
    //We are storing all the demographic history in a list
    private final List<DemographicHistory> mHistoryList;

    //getting the context and demographic list with constructor
    public DemographicHistoryAdapter(Context mCtx, List<DemographicHistory> mHistoryList) {
        this.mCtx = mCtx;
        this.mHistoryList = mHistoryList;
    }

    /*
   Creating ViewHolder based on the layout to bind the data to adapter.
    */
    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //inflating and returning our view holder
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.row_fragment_demographic_history, parent, false);
        return new ProductViewHolder(view);
    }

    /*
   Binding data to ViewHolder class object based on the position.
   */
    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, final int position) {
        if (mHistoryList != null && !mHistoryList.isEmpty()) {
            //getting the product of the specified position
            final DemographicHistory history = mHistoryList.get(position);
            //Binding the data  with the viewHolder views
            holder.tvUpdatedDate.setText(history.getSubmitDate());
            MemberDetails details = history.getMemberInfo();
            if (details.getFirstName() != null) {
                holder.tvFirstName.setText(details.getFirstName());
            }
            if (details.getLastName() != null) {
                holder.tvLastName.setText(details.getLastName());
            }
            holder.tvPhone.setText(details.getPhoneNumber());
            holder.tvDob.setText(details.getDateOfBirth());
            holder.tvGender.setText(details.getGender());
            if (!details.getAddressList().isEmpty()) {
                Address address = details.getAddressList().get(0);
                String primaryAddress = address.getAddress1() + "," + address.getCity() + "," + address.getState() + "," + address.getCounty() + "," + address.getZipCode();
                holder.tvPrimaryAddress.setText(primaryAddress);
                if (details.getAddressList().size() > 1) {
                    address = details.getAddressList().get(1);
                    String mailingAddress = address.getAddress1() + "," + address.getCity() + "," + address.getState() + "," + address.getCounty() + "," + address.getZipCode();
                    holder.tvMailingAddress.setText(mailingAddress);
                }
            }
        } else {
            Toast.makeText(mCtx, "No Records Found", Toast.LENGTH_SHORT).show();
        }
    }

    /*
This method is used to get the items size in array list
*/
    @Override
    public int getItemCount() {
        if (mHistoryList != null) {
            return mHistoryList.size();
        } else {
            return 0;
        }
    }

    /**
     * This class is used to bind the demographic history in the adapter
     */
    class ProductViewHolder extends RecyclerView.ViewHolder {

        //Member variables
        final TextView tvFirstName;
        final TextView tvLastName;
        final TextView tvUpdatedDate;
        final TextView tvPhone;
        final TextView tvDob;
        final TextView tvGender;
        final TextView tvPrimaryAddress;
        final TextView tvMailingAddress;

        private ProductViewHolder(@NonNull View itemView) {
            super(itemView);

            //Initializing views
            tvFirstName = itemView.findViewById(R.id.firstName);
            tvLastName = itemView.findViewById(R.id.lastName);
            tvFirstName.setSelected(true);
            tvLastName.setSelected(true);
            tvUpdatedDate = itemView.findViewById(R.id.updatedDate);
            tvPhone = itemView.findViewById(R.id.phoneNo);
            tvDob = itemView.findViewById(R.id.dob);
            tvGender = itemView.findViewById(R.id.gender);
            tvPrimaryAddress = itemView.findViewById(R.id.primaryAddress);
            tvMailingAddress = itemView.findViewById(R.id.mailingAddress);
        }
    }
}
