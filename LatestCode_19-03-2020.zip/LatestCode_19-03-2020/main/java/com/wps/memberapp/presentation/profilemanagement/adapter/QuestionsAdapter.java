package com.wps.memberapp.presentation.profilemanagement.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.model.SecurityQuestion;

import java.util.List;

import androidx.annotation.NonNull;

/**
 * This adapter used to populate list of questions to the user.
 */
public class QuestionsAdapter extends ArrayAdapter<SecurityQuestion> {
    //We are storing all the questions in a list
    @NonNull
    private final List<SecurityQuestion> questionList;
    //this inflater  will be used to inflate the layout
    private final LayoutInflater inflater;

    public QuestionsAdapter(@NonNull Context context, @NonNull List<SecurityQuestion> questionList) {
        super(context, R.layout.row_question_adapter, R.id.question, questionList);
        inflater = LayoutInflater.from(context);
        this.questionList = questionList;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        return getRowView(position, convertView, parent);
    }

    @NonNull
    @Override
    public View getDropDownView(int position, View convertView, @NonNull ViewGroup parent) {
        return getRowView(position, convertView, parent);
    }

    /*
    This method is used to populate the questions from the list
     */
    private View getRowView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.row_question_adapter, parent, false);
        }
        if (!questionList.isEmpty()) {
            //Appending data to the UI
            SecurityQuestion question = questionList.get(position);
            TextView tv = convertView.findViewById(R.id.question);
            tv.setSelected(true);
            tv.setText(question.getQuestion());
        }
        return convertView;
    }

    /*
This method is used to get the items size in array list
*/
    @Override
    public int getCount() {
        return questionList.size();
    }
}
