package com.wps.memberapp.presentation.profilemanagement.adapter;

import android.content.Context;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.Address;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.domain.listener.DialogCallbackContract;
import com.wps.memberapp.presentation.profilemanagement.fragment.UpdateFragment;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

public class UpdateDemographicMemAdapter extends RecyclerView.Adapter<UpdateDemographicMemAdapter.DemographicMemViewHolder> implements DialogCallbackContract {

    private final Context mCtx;
    private final AppCompatActivity mActivity;
    private final List<MemberDetails> mDetailList;

    public UpdateDemographicMemAdapter(Context context, AppCompatActivity mActivity, List<MemberDetails> detailList) {
        this.mCtx = context;
        this.mActivity = mActivity;
        this.mDetailList = detailList;
    }

    @NonNull
    @Override
    public DemographicMemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.fragment_update_demographic_header, parent, false);
        return new DemographicMemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DemographicMemViewHolder holder, int position) {

        if(mDetailList!=null){
//            View view = LayoutInflater.from(getAppContext()).inflate(R.layout.fragment_update_demographic_header, null);
//            llCustomLayout.addView(view);
            List<String> mListDetails = new ArrayList<>();
            String name = mDetailList.get(position).getFirstName() + " " + mDetailList.get(position).getLastName();
            MemberDetails memberDetails = ProfileDataCache.getInstance().getmMemberDetails().get(position);
            if (memberDetails != null) {
                holder.tvPhoneNo.setText(memberDetails.getPhoneNumber());
            }
            holder.tvName.setText(name);
            holder.tvDob.setText(mDetailList.get(position).getDateOfBirth());
            holder.tvGender.setText(mDetailList.get(position).getGender());
            if (mDetailList.get(position).getAddressList() != null && !mDetailList.get(0).getAddressList().isEmpty()) {
                Address address = mDetailList.get(position).getAddressList().get(0);
                holder.tvAddress.setText(address.getAddress1()); //holder.tvAddress.setText(address.getAddress1()+address.getAddress2());
                holder.tvCity.setText(address.getCity());
                holder.tvState.setText(address.getState());
                holder.tvZipCode.setText(address.getZipCode());
            }

            /*
             if (mDetailList.get(position).getAddressList() != null && !mDetailList.get(0).getAddressList().isEmpty()) {
                for (int i = 0; i < mDetailList.size(); i++) {
                    mListDetails.addAll(mDetailList.get(i).getAddressList());
                    Address address = mListDetails.get(position);
                    holder.tvAddress.setText(address.getAddress1());
                    holder.tvCity.setText(address.getCity());
                    holder.tvState.setText(address.getState());
                    holder.tvZipCode.setText(address.getZipCode());
                }
            }*/

            holder.tvUpdate.setPaintFlags(holder.tvUpdate.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
            holder.tvUpdate.setOnClickListener(view -> {
                if (mCtx != null) {
                    UpdateFragment upDatefragment = new UpdateFragment();
                    Bundle args = new Bundle();
                    if (mDetailList.get(position)!= null) {
                        int pos = holder.getPosition();
                        args.putInt("memberPosition", pos);
                    }
                    upDatefragment.setArguments(args);
                    mActivity.getSupportFragmentManager().beginTransaction().replace(R.id.frame_container, upDatefragment).addToBackStack(null).commit();
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        if (mDetailList != null) {
            return mDetailList.size();
        } else {
            return 0;
        }
    }

    public class DemographicMemViewHolder extends RecyclerView.ViewHolder {

        TextView tvName;
        TextView tvPhoneNo;
        TextView tvDob;
        TextView tvGender;
        TextView tvAddress;
        TextView tvCity;
        TextView tvState;
        TextView tvZipCode;
        TextView tvUpdate;

        public DemographicMemViewHolder(@NonNull View itemView) {
            super(itemView);

            tvName = itemView.findViewById(R.id.nameTv);
            tvPhoneNo = itemView.findViewById(R.id.phoneNumberTv);
            tvDob = itemView.findViewById(R.id.dobValue);
            tvGender = itemView.findViewById(R.id.genderTv);
            tvAddress = itemView.findViewById(R.id.addressValue);
            tvCity = itemView.findViewById(R.id.cityValue);
            tvState = itemView.findViewById(R.id.stateValue);
            tvZipCode = itemView.findViewById(R.id.zipCodeValue);
            tvUpdate = itemView.findViewById(R.id.update);
        }
    }
}

