package com.wps.memberapp.presentation.profilemanagement.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.appdynamics.eumagent.runtime.Instrumentation;
import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.UpdatePasswordData;
import com.wps.memberapp.presentation.base.BaseFragment;
import com.wps.memberapp.presentation.dashboard.fragment.DashboardFragment;
import com.wps.memberapp.presentation.profilemanagement.ProfilePresenter;
import com.wps.memberapp.presentation.profilemanagement.ProfilePresenterImpl;
import com.wps.memberapp.presentation.profilemanagement.ProfileView;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.StringConstants;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * This class is used to change the current password of the user.
 */
public class ChangePasswordFragment extends BaseFragment implements ProfileView {

    //Member variables
    @BindView(R.id.oldPwd)
    EditText etCurrentPwd;

    @BindView(R.id.newPwd)
    EditText etNewPwd;

    @BindView(R.id.confirmPwd)
    EditText etConfirmPwd;

    @BindView(R.id.update)
    Button btUpdatePwd;

    @BindView(R.id.cancel)
    Button btCancel;

    private Unbinder mUnbinder;
    private ProfilePresenter presenter;


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (getActivity() != null) {
            Instrumentation.start(StringConstants.APP_DYNAMICS_KEY, getActivity().getApplicationContext());
        }
        View rootView = inflater.inflate(R.layout.fragment_changepassword, container, false);
        mUnbinder = ButterKnife.bind(this, rootView);
        presenter = new ProfilePresenterImpl();
        presenter.onAttach(this);
        if (getActivity() != null) {
            ImageView imageViewSearch = getActivity().findViewById(R.id.imageViewSearch);
            imageViewSearch.setVisibility(View.GONE);
            TextView txtDownloadPDF = getActivity().findViewById(R.id.txt_Call);
            txtDownloadPDF.setVisibility(View.GONE);
            TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
            fragmentTitle.setText(getString(R.string.change_param1));
        }

        //Handling click action for submit button
        btUpdatePwd.setOnClickListener(view -> {
            if (getActivity() != null) {
                if (GeneralUtils.isOnline(getActivity())) {
                    updatePassword();
                } else {
                    GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.login_no_internet));
                }
            }
        });

        //Handling click action for cancel button
        btCancel.setOnClickListener(v -> {
            if (getFragmentManager() != null) {
                getFragmentManager().popBackStack();
                DashboardFragment firstFragment = new DashboardFragment();
                getFragmentManager().beginTransaction().replace(R.id.frame_container,
                        firstFragment, "home").addToBackStack(null).commit();
            }
        });
        return rootView;
    }

    /*
     This method is used to validate the data entered by user and call the APIs to update the password.
     */
    private void updatePassword() {
        String oldPassword = etCurrentPwd.getText().toString();
        String newPassword = etNewPwd.getText().toString();
        String confirmPassword = etConfirmPwd.getText().toString();
        if (oldPassword.length() == 0 || newPassword.length() == 0 || confirmPassword.length() == 0) {
            Toast.makeText(getActivity(), getString(R.string.fill_all_details), Toast.LENGTH_LONG).show();
            return;
        } else if (!newPassword.equalsIgnoreCase(confirmPassword)) {
            Toast.makeText(getActivity(), getString(R.string.both_should_match), Toast.LENGTH_LONG).show();
            return;
        } else if (!GeneralUtils.isPasswordValid(confirmPassword)) {
            Toast.makeText(getActivity(), getString(R.string.follow_param2_rules), Toast.LENGTH_LONG).show();
            return;
        }
        UpdatePasswordData data = new UpdatePasswordData();
        data.setOldPwd(oldPassword);
        data.setNewPwd(newPassword);
        ProfileDataCache.getInstance().setPasswordData(data);
        presenter.updatePassword();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mUnbinder.unbind();
    }

    /*
      This method will call after user successfully changed his password.
     */
    @Override
    public void onPasswordUpdated(int statusCode, String msg) {
        if (getActivity() == null) {
            return;
        }
        etCurrentPwd.setText("");
        etNewPwd.setText("");
        etConfirmPwd.setText("");
        if (statusCode == 0) {
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setCancelable(false)
                    .setMessage(msg)
                    .setPositiveButton(getActivity().getString(R.string.ok), (dialogInterface, i) -> GeneralUtils.logoutApp(getActivity())).create().show();

        } else {
            GeneralUtils.showAlertDialog(getActivity(), msg);
        }
    }
}
