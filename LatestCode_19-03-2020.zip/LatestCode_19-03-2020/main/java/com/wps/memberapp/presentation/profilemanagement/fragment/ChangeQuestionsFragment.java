package com.wps.memberapp.presentation.profilemanagement.fragment;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.appdynamics.eumagent.runtime.Instrumentation;
import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.SecurityQuestion;
import com.wps.memberapp.presentation.base.BaseFragment;
import com.wps.memberapp.presentation.dashboard.fragment.DashboardFragment;
import com.wps.memberapp.presentation.profilemanagement.ProfilePresenter;
import com.wps.memberapp.presentation.profilemanagement.ProfilePresenterImpl;
import com.wps.memberapp.presentation.profilemanagement.QuestionsView;
import com.wps.memberapp.presentation.profilemanagement.adapter.QuestionsAdapter;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * This class is used to change the user security questions
 */
public class ChangeQuestionsFragment extends BaseFragment implements QuestionsView {

    //Member variables declaration
    @BindView(R.id.question1)
    Spinner spQuestion1;

    @BindView(R.id.question2)
    Spinner spQuestion2;

    @BindView(R.id.question3)
    Spinner spQuestion3;

    @BindView(R.id.answer1)
    EditText etAnswer1;

    @BindView(R.id.answer2)
    EditText etAnswer2;

    @BindView(R.id.answer3)
    EditText etAnswer3;

    @BindView(R.id.update)
    Button btSave;

    @BindView(R.id.cancel)
    Button btCancel;
    private Unbinder mUnbinder;
    private ProfilePresenter mPresenter;
    private List<SecurityQuestion> mTotalQuestionsList;
    private int mStrQuest1;
    private int mStrQuest2;
    private int mStrQuest3;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (getActivity() != null) {
            Instrumentation.start(StringConstants.APP_DYNAMICS_KEY, getActivity().getApplicationContext());
        }
        View rootView = inflater.inflate(R.layout.fragment_change_questions, container, false);
        mUnbinder = ButterKnife.bind(this, rootView);
        mPresenter = new ProfilePresenterImpl();
        mPresenter.onAttach(this);

        if (getActivity() != null) {
            ImageView imageViewSearch = getActivity().findViewById(R.id.imageViewSearch);
            imageViewSearch.setVisibility(View.GONE);
            TextView txtDownloadPDF = getActivity().findViewById(R.id.txt_Call);
            txtDownloadPDF.setVisibility(View.GONE);
            TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
            fragmentTitle.setText(getString(R.string.change_questions));
        }
        if (GeneralUtils.isOnline(getActivity())) {
            mPresenter.getSecurityQuestions();
        }
        spQuestion1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                try {
                    if (spQuestion1.getSelectedItem() != null) {
                        Toast.makeText(getContext(), "1Quest Position " + position, Toast.LENGTH_SHORT).show();
                        mTotalQuestionsList.remove(position);
                    }
                } catch (Exception e) {
                    Logger.e(StringConstants.EXCEPTION, e);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        spQuestion2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                try {
                    if (spQuestion2.getSelectedItem() != null) {
                        Toast.makeText(getContext(), "2Quest Position " + position, Toast.LENGTH_SHORT).show();
                        mTotalQuestionsList.remove(position);
                    }
                } catch (Exception e) {
                    Logger.e(StringConstants.EXCEPTION, e);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        spQuestion3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                try {
                    if (spQuestion3.getSelectedItem() != null) {
                        Toast.makeText(getContext(), "3Quest Position " + position, Toast.LENGTH_SHORT).show();
                        mTotalQuestionsList.remove(position);
                    }
                } catch (Exception e) {
                    Logger.e(StringConstants.EXCEPTION, e);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        showPwdDialog();
        List<String> idList = new ArrayList<>();
        List<String> ansList = new ArrayList<>();
        btSave.setOnClickListener(view -> {

            // Getting user selected questions and sending API request to save the questions
            try {
                String id1 = mTotalQuestionsList.get(spQuestion1.getSelectedItemPosition()).getQuestionID();
                String id2 = mTotalQuestionsList.get(spQuestion2.getSelectedItemPosition()).getQuestionID();
                String id3 = mTotalQuestionsList.get(spQuestion3.getSelectedItemPosition()).getQuestionID();
                idList.add(id1);
                idList.add(id2);
                idList.add(id3);
                String ans1 = etAnswer1.getText().toString().trim();
                String ans2 = etAnswer2.getText().toString().trim();
                String ans3 = etAnswer3.getText().toString().trim();
                if (ans1.length() == 0 || ans2.length() == 0 || ans3.length() == 0) {
                    Toast.makeText(getActivity(), getString(R.string.enter_all_answers), Toast.LENGTH_LONG).show();
                    return;
                }
                ansList.add(ans1);
                ansList.add(ans2);
                ansList.add(ans3);
            } catch (Exception e) {
                Logger.e(StringConstants.EXCEPTION, e);
            }

            //Checking internet connection to send API request
            if (getActivity() != null) {
                if (GeneralUtils.isOnline(getActivity())) {
                    mPresenter.updateSecurityQuestions(idList, ansList);
                } else {
                    GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.login_no_internet));
                }
            }
        });

        //Handling click action for cancel button
        btCancel.setOnClickListener(view -> {
            if (getFragmentManager() != null) {
                getFragmentManager().popBackStack();
                DashboardFragment firstFragment = new DashboardFragment();
                getFragmentManager().beginTransaction().replace(R.id.frame_container,
                        firstFragment, "home").addToBackStack(null).commit();
            }
        });
        return rootView;
    }

    /*
    This dialog is used to ask the user to enter password
     */
    private void showPwdDialog() {
        if (getActivity() == null) {
            return;
        }
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View view = View.inflate(getActivity(), R.layout.dialog_verify_pwd, null);
        final EditText currentPwd = view.findViewById(R.id.currentPwd);
        builder.setView(view)
                .setPositiveButton(getString(R.string.validate), (dialogInterface, i) -> {

                }).setNegativeButton(getString(R.string.cancel), (dialogInterface, i) -> {
            if (getActivity() != null) {
                //getActivity().getSupportFragmentManager().popBackStack();
                if (getFragmentManager() != null) {
                    getFragmentManager().popBackStack();
                    DashboardFragment firstFragment = new DashboardFragment();
                    getFragmentManager().beginTransaction().replace(R.id.frame_container,
                            firstFragment, "home").addToBackStack(null).commit();
                }
            }
        })
                .setCancelable(false);
        AlertDialog dialog = builder.create();
        dialog.show();

        //Setting positive button to handle user click action
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view1 -> {
            String pwd = currentPwd.getText().toString();
            if (pwd.length() == 0) {
                Toast.makeText(getActivity(), getString(R.string.enter_current_pwd), Toast.LENGTH_LONG).show();
            } else {
                dialog.dismiss();
                if (getActivity() != null) {
                    if (GeneralUtils.isOnline(getActivity())) {
                        mPresenter.verifyPassword(pwd);
                    } else {
                        GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.login_no_internet));
                    }
                }
            }
        });
    }

    /*
    Call back for password verification
     */
    @Override
    public void onPasswordVerified(@NonNull String status) {
        if (status.equalsIgnoreCase("false")) {
            Toast.makeText(getActivity(), getString(R.string.param1_incorrect), Toast.LENGTH_LONG).show();
            showPwdDialog();
        } else {
            mPresenter.getUserSecurityQuestions();
        }
    }

    /*
    Call back for questions loading
     */
    @Override
    public void onQuestionsLoaded(@NonNull List<SecurityQuestion> questionsList) {
        mTotalQuestionsList = questionsList;
    }

    /*    Appending questions to spinners
     */
    private void updateData(@NonNull List<SecurityQuestion> questionsList) {
        if (getActivity() != null) {
            QuestionsAdapter adapter = new QuestionsAdapter(getActivity(), questionsList);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spQuestion1.setAdapter(adapter);
            spQuestion2.setAdapter(adapter);
            spQuestion3.setAdapter(adapter);
        }
    }

    /*
     * call back for user specific questions loading
     */
    @Override
    public void onUserQuestionsLoaded(@NonNull List<SecurityQuestion> questionsList) {
        if (mTotalQuestionsList != null && !mTotalQuestionsList.isEmpty()) {
            updateData(mTotalQuestionsList);
            try {
                spQuestion1.setSelection(getQuestionPosition(questionsList.get(0).getQuestion()));
//                if (spQuestion1.setSelection(getQuestionPosition(questionsList.get()));)
                spQuestion2.setSelection(getQuestionPosition(questionsList.get(1).getQuestion()));
                spQuestion3.setSelection(getQuestionPosition(questionsList.get(2).getQuestion()));
            } catch (Exception e) {
                Logger.e(StringConstants.EXCEPTION, e);
            }
        }
    }

    /*
    call back for after questions updated through API
     */
    @Override
    public void onQuestionsUpdated(@NonNull String result) {
        if (getActivity() == null) {
            return;
        }
        if (result.equalsIgnoreCase("true")) {
            etAnswer1.setText("");
            etAnswer2.setText("");
            etAnswer3.setText("");
            showAlert(getActivity(), getString(R.string.questions_updated));
        } else {
            GeneralUtils.showAlertDialog(getActivity(), getString(R.string.questions_not_updated));
        }
    }

    /*
      Getting question position from questions list based on the question
     */
    private int getQuestionPosition(@NonNull String question) {
        for (int i = 0; i < mTotalQuestionsList.size(); i++) {
            if (question.equalsIgnoreCase(mTotalQuestionsList.get(i).getQuestion())) {
                return i;
            }
        }
        return 0;
    }

    /*
    This dialog is used to show information to user
     */
    private void showAlert(@NonNull Activity activity, String msg) {
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(activity);
        builder.setCancelable(false)
                .setMessage(msg)
                .setPositiveButton(activity.getString(R.string.ok), (dialogInterface, i) -> {
                    if (getFragmentManager() != null) {
                        getFragmentManager().popBackStack();
                        DashboardFragment firstFragment = new DashboardFragment();
                        getFragmentManager().beginTransaction().replace(R.id.frame_container,
                                firstFragment, "home").addToBackStack(null).commit();
                    }
                }).create().show();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mUnbinder.unbind();
    }
}
