package com.wps.memberapp.presentation.profilemanagement.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.appdynamics.eumagent.runtime.Instrumentation;
import com.wps.memberapp.R;
import com.wps.memberapp.data.model.DemographicHistory;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.presentation.base.BaseFragment;
import com.wps.memberapp.presentation.profilemanagement.DemographicView;
import com.wps.memberapp.presentation.profilemanagement.ProfilePresenter;
import com.wps.memberapp.presentation.profilemanagement.ProfilePresenterImpl;
import com.wps.memberapp.presentation.profilemanagement.adapter.DemographicHistoryAdapter;
import com.wps.memberapp.presentation.profilemanagement.adapter.UpdateDemographicMemAdapter;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.StringConstants;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

import static org.webrtc.ContextUtils.getApplicationContext;

/**
 * This class is used to show the user details and updated demographic history
 */
public class UpdateDemographicsFragment extends BaseFragment implements DemographicView {

    //Declaring member variables
    @BindView(R.id.rv_member_demographics)
    RecyclerView rvMemberDemographics;

    @BindView(R.id.demographicHistoryList)
    RecyclerView rvDemographicHistory;

    @BindView(R.id.noUpdates)
    TextView tvNoUpdates;

    private Unbinder mUnbinder;

    private ProgressBar mProgressBar;


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        if (getActivity() != null) {
            Instrumentation.start(StringConstants.APP_DYNAMICS_KEY, getActivity().getApplicationContext());
        }
        View rootView = inflater.inflate(R.layout.fragment_update_demographics, container, false);
        if (getActivity() != null) {
            ImageView imageViewSearch = getActivity().findViewById(R.id.imageViewSearch);
            imageViewSearch.setVisibility(View.GONE);
            TextView txtDownloadPDF = getActivity().findViewById(R.id.txt_Call);
            txtDownloadPDF.setVisibility(View.GONE);
            TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
            fragmentTitle.setText(getString(R.string.update_demographics));
        }
        mUnbinder = ButterKnife.bind(this, rootView);

        final LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        rvMemberDemographics.setLayoutManager(layoutManager);

        final LinearLayoutManager memlayoutManager = new LinearLayoutManager(getActivity());
        memlayoutManager.setOrientation(RecyclerView.VERTICAL);
        rvDemographicHistory.setLayoutManager(memlayoutManager);

        mProgressBar = rootView.findViewById(R.id.progressBar);
        ProfilePresenter presenter = new ProfilePresenterImpl();
        presenter.onAttach(this);

        //Checking internet connection to send API request
        if (getActivity() != null) {
            if (GeneralUtils.isOnline(getActivity())) {
                presenter.getBenefitUserDetails(0);
                presenter.getUpdateDemographicHistory();
            } else {
                GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.login_no_internet));
            }
        }
        return rootView;
    }

    /*
    This method will call after we successfully loaded the user details with API call.
     */
    @Override
    public void onUserDetailsLoadingCompleted(@NonNull List<MemberDetails> detailList) {
        /*for (int i = 0; i < details.size(); i++) {
//            View view = LayoutInflater.from(getAppContext()).inflate(R.layout.fragment_update_demographic_header, null);
//            llCustomLayout.addView(view);
            String name = details.get(i).getFirstName() + " " + details.get(i).getLastName();
            tvPhoneNo.setText(details.get(i).getPhoneNumber());
            tvName.setText(name);
            tvDob.setText(details.get(i).getDateOfBirth());
            tvGender.setText(details.get(i).getGender());
            if (details.get(i).getAddressList() != null && !details.get(i).getAddressList().isEmpty()) {
                Address address = details.get(i).getAddressList().get(0);
                tvAddress.setText(address.getAddress1());
                tvCity.setText(address.getCity());
                tvState.setText(address.getState());
                tvZipCode.setText(address.getZipCode());
            }
        }*/

        UpdateDemographicMemAdapter mDemoAdapter = new UpdateDemographicMemAdapter(getActivity(),(AppCompatActivity) getActivity(), detailList);
        rvMemberDemographics.setItemAnimator(new DefaultItemAnimator());
        mProgressBar.setVisibility(View.GONE);
        rvMemberDemographics.setAdapter(mDemoAdapter);
        mDemoAdapter.notifyDataSetChanged();

    }

    /*
    This method will call after we successfully loaded the user details with API call.
     */


    /*
    java.lang.NullPointerException: Attempt to invoke virtual method 'void androidx.recyclerview.widget.RecyclerView.setItemAnimator(androidx.recyclerview.widget.RecyclerView$ItemAnimator)' on a null object reference
        at com.wps.memberapp.presentation.profilemanagement.fragment.UpdateDemographicsFragment.onUpdateDemographicHistoryLoaded(UpdateDemographicsFragment.java:131)
        at com.wps.memberapp.presentation.profilemanagement.ProfilePresenterImpl$2.onResponse(ProfilePresenterImpl.java:99)
        at com.wps.memberapp.domain.dataservice.VolleyService.lambda$getDemographicHistory$68(VolleyService.java:1505)
        // For historyList Randomly
     */
    @Override
    public void onUpdateDemographicHistoryLoaded(@NonNull List<DemographicHistory> historyList) {
        DemographicHistoryAdapter adapter = new DemographicHistoryAdapter(getActivity(), historyList);
        rvDemographicHistory.setItemAnimator(new DefaultItemAnimator());
        mProgressBar.setVisibility(View.GONE);
        rvDemographicHistory.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        if (historyList.isEmpty()) {
            tvNoUpdates.setVisibility(View.VISIBLE);
        } else {
            tvNoUpdates.setVisibility(View.GONE);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mUnbinder.unbind();
    }
}
