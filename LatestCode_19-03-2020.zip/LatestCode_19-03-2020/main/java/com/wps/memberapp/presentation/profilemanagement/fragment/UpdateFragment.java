package com.wps.memberapp.presentation.profilemanagement.fragment;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.appdynamics.eumagent.runtime.Instrumentation;
import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.Address;
import com.wps.memberapp.data.model.DemographyData;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.presentation.base.BaseFragment;
import com.wps.memberapp.presentation.profilemanagement.ProfilePresenter;
import com.wps.memberapp.presentation.profilemanagement.ProfilePresenterImpl;
import com.wps.memberapp.presentation.profilemanagement.UpdateView;
import com.wps.memberapp.utility.CustomEditText;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.StringConstants;

import java.util.Calendar;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

import static org.webrtc.ContextUtils.getApplicationContext;

/**
 * This class is used to update the demographics of the user.
 */
public class UpdateFragment extends BaseFragment implements UpdateView {

    // Member variables declaration
    @BindView(R.id.firstName)
    EditText etFirstName;

    @BindView(R.id.lastName)
    EditText etLastName;

    @BindView(R.id.pincode)
    EditText etPinCode;

    @BindView(R.id.dob)
    CustomEditText etDob;

    @BindView(R.id.phone)
    EditText etPhone;

    @BindView(R.id.city)
    EditText etCity;

    @BindView(R.id.adress)
    EditText etAddress1;

    @BindView(R.id.genderSpinner)
    Spinner spGender;

    @BindView(R.id.stateSpinner)
    Spinner spState;

    @BindView(R.id.countrySpinner)
    Spinner spCountry;

    @BindView(R.id.update)
    Button btUpdate;

    private Unbinder mUnbinder;

    private List<String> mStatesList;

    private List<String> mCountyList;

    private ProfilePresenter mPresenter;

    private MemberDetails mMemberDetails;
    private static final String[] genders = {"Male", "Female", "Unknown"};
    private int position;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        if (getActivity() != null) {
            Instrumentation.start(StringConstants.APP_DYNAMICS_KEY, getActivity().getApplicationContext());
        }
        View rootView = inflater.inflate(R.layout.fragment_update_demo, container, false);
        mUnbinder = ButterKnife.bind(this, rootView);
        mPresenter = new ProfilePresenterImpl();
        mPresenter.onAttach(this);
        if (getActivity() != null) {
            ImageView imageViewSearch = getActivity().findViewById(R.id.imageViewSearch);
            imageViewSearch.setVisibility(View.GONE);
            TextView txtDownloadPDF = getActivity().findViewById(R.id.txt_Call);
            txtDownloadPDF.setVisibility(View.GONE);
            TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
            fragmentTitle.setText(getString(R.string.update_demographics));
        }
        position = getArguments().getInt("memberPosition");
        if (getActivity() != null) {
            if (GeneralUtils.isOnline(getActivity())) {
                mPresenter.getBenefitUserDetails(position);
            } else {
                GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.login_no_internet));
            }
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_dropdown_item, genders);
        spGender.setAdapter(adapter);

        //Handling click action for submit button
        btUpdate.setOnClickListener(view -> {
            if (getActivity() != null) {
                if (GeneralUtils.isOnline(getActivity())) {
                    updateHistory();
                } else {
                    GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.login_no_internet));
                }
            }
        });

        //Text change listener to monitor zip code lenght entered by user
        etPinCode.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                //write your code here
            }

            @Override
            public void onTextChanged(@NonNull CharSequence charSequence, int i, int i1, int i2) {
                if (getActivity() != null && (charSequence.length() >= 5 && charSequence.length() <= 9)) {
                    if (GeneralUtils.isOnline(getActivity())) {
                        mPresenter.getCountriesData(charSequence.toString());
                    } else {
                        GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.login_no_internet));
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
                //write your code here
            }
        });

        //Setting on touch listener for right drawable of edit text to show calendar to user
        etDob.setOnTouchListener((v, event) -> {
            final int DRAWABLE_RIGHT = 2;
            if ((event.getAction() == MotionEvent.ACTION_UP) && event.getRawX() >= (etDob.getRight() -
                    etDob.getCompoundDrawables()[DRAWABLE_RIGHT].getBounds().width())) {
                showDateDialog();
                etDob.performClick();
                return true;
            }
            return false;
        });
        return rootView;
    }

    /*
    This dialog is used show date dialog to user to select date
     */
    private void showDateDialog() {
        if (getActivity() != null) {
            Calendar calender = Calendar.getInstance();
            DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(),
                    (view, year, monthOfYear, dayOfMonth) ->
                    {
                        String dob = year + "-" + (monthOfYear + 1) + "-" + dayOfMonth;
                        etDob.setText(dob);
                    }, calender.get(Calendar.YEAR), calender.get(Calendar.MONTH), calender.get(Calendar.DAY_OF_MONTH));
            datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
            datePickerDialog.show();
        }
    }

    /*
    Call back for user details loading completed
     */
    @Override
    public void onUserDetailsLoadingCompleted(@NonNull MemberDetails details) {
        this.mMemberDetails = details;
        etFirstName.setText(details.getFirstName());
        etLastName.setText(details.getLastName());
        etDob.setText(details.getDateOfBirth());
        if (details.getGender().equalsIgnoreCase("M")) {
            spGender.setSelection(0);
        } else { //if (details.getGender().equalsIgnoreCase("F")){{
            spGender.setSelection(1);
        }
        MemberDetails data = ProfileDataCache.getInstance().getmMemberDetails().get(position);
        if (data.getPhoneNumber() != null) {
            etPhone.setText(data.getPhoneNumber());
        } else {
            etPhone.setText(data.getPhoneNumber());
        }

        if (details.getAddressList() != null && !details.getAddressList().isEmpty()) {
            Address address = details.getAddressList().get(0);
            etPinCode.setText(address.getZipCode());
            mPresenter.getCountriesData(address.getZipCode());
            etCity.setText(address.getCity());
            etAddress1.setText(address.getAddress1());
        }
    }

    /*
   Call back for states loading completed
    */
    @Override
    public void onStatesLoaded(@NonNull List<String> statesList) {
        if (getActivity() != null) {
            if (statesList.isEmpty()) {
                GeneralUtils.showAlertDialog(getActivity(), getString(R.string.enter_valid_zipcode));
            }
            this.mStatesList = statesList;
            ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_dropdown_item, statesList);
            spState.setAdapter(adapter);
        }
    }

    /*
 Call back for countries loading completed
  */
    @Override
    public void onCountriesLoaded(@NonNull List<String> countriesList) {
        if (getActivity() != null) {
            this.mCountyList = countriesList;
            ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_dropdown_item, countriesList);
            spCountry.setAdapter(adapter);
        }
    }

    /*
     This method is used to validate the data entered by user and call the APIs to update the history.
     */
    private void updateHistory() {
        String fName = etFirstName.getText().toString().trim();
        String lName = etLastName.getText().toString().trim();
        String dob = "";
        if (etDob.getText() != null) {
            dob = etDob.getText().toString().trim();
        }
        String address1 = etAddress1.getText().toString().trim();
        String city = etCity.getText().toString().trim();
        String zipCode = etPinCode.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();

        //Validating the details entered by user
        if (getActivity() != null && (fName.length() == 0 || lName.length() == 0 ||
                dob.length() == 0 || phone.length() == 0 || address1.length() == 0 || city.length() == 0 || zipCode.length() == 0)) {
            GeneralUtils.showAlertDialog(getActivity(), getString(R.string.fill_all_details));
            return;
        } else if (getActivity() != null && (zipCode.length() < 5 || zipCode.length() > 9)) {
            GeneralUtils.showAlertDialog(getActivity(), getString(R.string.enter_valid_zipcode));
            return;
        }
        String gender = genders[spGender.getSelectedItemPosition()];
        if (gender == null) {
            gender = mMemberDetails.getGender();
        }
        String state = "";
        if (mStatesList != null && !mStatesList.isEmpty() && spState.getSelectedItemPosition() > 0) {
            state = mStatesList.get(spState.getSelectedItemPosition());
        } else {
            if (getActivity() != null) {
                GeneralUtils.showAlertDialog(getActivity(), getString(R.string.select_state));
                return;
            }
        }
        String county = "";
        if (mCountyList != null && !mCountyList.isEmpty() && spCountry.getSelectedItemPosition() > 0) {
            county = mCountyList.get(spCountry.getSelectedItemPosition());
        } else {
            if (getActivity() != null) {
                GeneralUtils.showAlertDialog(getActivity(), getString(R.string.select_county));
                return;
            }
        }

        //Setting user entered data in DemographyData object to send in API request
        DemographyData data = new DemographyData();
        data.setGender(gender);
        data.setFirstName(fName);
        data.setLastName(lName);
        data.setPhone(phone);
        data.setDateOfBirth(dob);
        data.setAddress1(address1);
        data.setCity(city);
        data.setState(state);
        data.setCounty(county);
        data.setZipCode(zipCode);
        data.setProductCode(mMemberDetails.getProductCode());
        ProfileDataCache.getInstance().setDemographyData(data);
        mPresenter.updateDemographicHistory();
    }

    /*
    Call back for whether demographic info updated or not
     */
    @Override
    public void onDemographyUpdated(String result) {
        if (result != null && result.equalsIgnoreCase("true")) {
            showAlert(result, getString(R.string.details_updated));
        } else {
            showAlert(result, getString(R.string.details_not_updated));
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mUnbinder.unbind();
    }

    /*
    Showing alert to user if demographic info is updated or not
     */
    private void showAlert(String result, String message) {
        if (getActivity() != null) {
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setCancelable(false)
                    .setMessage(message)
                    .setPositiveButton(getActivity().getString(R.string.ok), (dialogInterface, i) -> {
                        builder.create().dismiss();
                        if (result.equalsIgnoreCase("true")) {
                            getActivity().getSupportFragmentManager().popBackStack();
                        }
                    }).create().show();
        }
    }
}
