package com.wps.memberapp.presentation.providersearch.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;
import com.android.volley.VolleyError;
import com.github.barteksc.pdfviewer.PDFView;
import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.domain.dataservice.VolleyByteResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.LocaleHelper;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Map;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * This activity is used to display ID Card as PDF to the respective user.
 */
public class ExportsAsPDFActivity extends AppCompatActivity {

    //Member variables declaration
    @BindView(R.id.pdfView)
    PDFView pdfView;
    String mDownloadProPDF;
    private String FILE_NAME;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getApplicationContext());
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view_pdf);
        ButterKnife.bind(this);
        Intent intent = getIntent();
        if(ProfileDataCache.getInstance().getProviderResults()!=null) {
            FILE_NAME = ProfileDataCache.getInstance().getProviderResults();
        }
        mDownloadProPDF = intent.getExtras().getString("downloadProviderPDF");
        GeneralUtils.showProgress(this);

        VolleyService.getExportAsPDF(getApplicationContext(), mDownloadProPDF, new VolleyByteResponseListener() {
            @Override
            public void onResponse(byte[] response) {
                Log.i("PDF Response", String.valueOf(response));
                    convertBytesToPDF(response);
                    GeneralUtils.hideProgress();
                    File pdfFile = new File(Environment.getExternalStorageDirectory() + "/ProviderSearchResults/" + FILE_NAME);
                    try {
                        pdfView.fromFile(pdfFile).enableDoubletap(true).load();
                    } catch (Exception e) {
                        Logger.e("Exc1", e);
                    }
            }
            @Override
            public void onError(VolleyError error) {
                GeneralUtils.hideProgress();
                try {
                    JSONObject obj = new JSONObject(String.valueOf(error));
//                    Toast.makeText(getApplicationContext(), "Download failed", Toast.LENGTH_LONG).show();
                    GeneralUtils.showAlertDialog(ExportsAsPDFActivity.this, getString(R.string.download_failed));
                } catch (Exception e) {
//                    Toast.makeText(getApplicationContext(), "Download failed", Toast.LENGTH_LONG).show();
                    Logger.e(StringConstants.EXCEPTION, e);
                }
            }
        });
    }

    private void convertBytesToPDF(byte[] response) {
        try {
            File folder = new File(Environment.getExternalStorageDirectory() + "/ProviderSearchResults/");
            folder.mkdir();
            File pdfFile = new File(folder, FILE_NAME);
            FileOutputStream fos = new FileOutputStream(pdfFile);
            fos.write(response);
            if (!pdfFile.exists()) {
                pdfFile.createNewFile();
            }
            fos.close();
//            Toast.makeText(getApplicationContext(), "Converted from byte to PDF", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            System.out.println("Exception: " + e);
        }
    }
}
