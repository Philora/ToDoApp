package com.wps.memberapp.presentation.providersearch.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import androidx.fragment.app.FragmentActivity;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMapOptions;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.wps.memberapp.presentation.providersearch.fragment.ProviderSearchFragment;

public class MapActivity extends FragmentActivity implements OnMapReadyCallback {
    private GoogleMap mMap;
    private double latitudeSource;
    private double longitudeSource;
    private double latitudeDestination;
    private double longitudeDestination;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        String mLatValue = ProfileDataCache.getInstance().getGeoLat();
        String mLongValue = ProfileDataCache.getInstance().getGeoLong();
        if (SharedPreferenceHelper.getInstance() != null) {
            latitudeSource = Double.parseDouble(mLatValue);
            longitudeSource = Double.parseDouble(mLongValue);
            if (getIntent().getExtras() != null) {
                Bundle extras = getIntent().getExtras();
                String value1 = extras.getString("latitude");
                String value2 = extras.getString("longitude");

                latitudeDestination = Double.parseDouble(value1);
                longitudeDestination = Double.parseDouble(value2);
            }
        }
        // Initializing array List
        MapFragment mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        String urlTopass = makeURL();
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(urlTopass));
        intent.setClassName("com.google.android.apps.maps", "com.google.android.maps.MapsActivity");
        startActivity(intent);
        finish();
    }


    @Override
    protected void onResume() {
        super.onResume();
        setUpMapIfNeeded();
    }

    private void setUpMapIfNeeded() {
        if (mMap != null) {
            return;
        }
        MapFragment mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        if (mMap == null) {
            return;
        }
        // Initialize map options. For example:
        GoogleMapOptions options = new GoogleMapOptions();
        options.mapType(GoogleMap.MAP_TYPE_NORMAL)
                .compassEnabled(false)
                .rotateGesturesEnabled(false)
                .tiltGesturesEnabled(false);
    }

    private String makeURL() {
        return "http://maps.google.com/maps" +
                "?saddr=" +// from
                Double.toString(latitudeSource) +
                "," +
                Double.toString(longitudeSource) +
                "&daddr=" +// to
                Double.toString(latitudeDestination) +
                "," +
                Double.toString(longitudeDestination);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        setUpMapIfNeeded();
    }

    @Override
    public void onBackPressed() {
        Intent i = new Intent(MapActivity.this, ProviderSearchFragment.class);
        startActivity(i);
    }
}
