package com.wps.memberapp.presentation.providersearch.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.model.Provider;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ProviderListAdapter extends RecyclerView.Adapter<ProviderListAdapter.ProviderListViewHolder> {

    private final Context mCtx;
    List<Provider> mSearchResultList;

    public ProviderListAdapter(Activity mCtx, List<Provider> mSearchResultList) {
        this.mCtx = mCtx;
        this.mSearchResultList = mSearchResultList;
    }

    @NonNull
    @Override
    public ProviderListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.provider_list_item, parent, false);
        return new ProviderListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProviderListViewHolder holder, final int position) {
        final Provider pcpSearchResult = mSearchResultList.get(position);
        String mFirstName = "";
        String mLastName = "";
        if (pcpSearchResult != null) {
            //Binding the data with the viewHolder views
            if (pcpSearchResult.getLastName() != null && !pcpSearchResult.getLastName().isEmpty() && !pcpSearchResult.getLastName().equalsIgnoreCase("null")) {
                mLastName = pcpSearchResult.getLastName();
            }
            if (pcpSearchResult.getFirstName() != null && !pcpSearchResult.getFirstName().isEmpty() && !pcpSearchResult.getFirstName().equalsIgnoreCase("null")) {
                mFirstName = pcpSearchResult.getFirstName();
            }
            holder.txtProvFLName.setText(mFirstName + " " + mLastName);
//            holder.txtProvAddress.setText(pcpSearchResult.getAddress1() + ", " + pcpSearchResult.getCity() + ", " + pcpSearchResult.getState() + ", " + pcpSearchResult.getZipCode());
            if (pcpSearchResult.getGender() != null) {
                if (pcpSearchResult.getGender().equalsIgnoreCase("M")) {
                    holder.txtProvGender.setText(R.string.txt_male);
                } else {
                    holder.txtProvGender.setText(R.string.txt_female);
                }
            }
            if (pcpSearchResult.getSpecialty() != null && !pcpSearchResult.getSpecialty().isEmpty() && !pcpSearchResult.getSpecialty().equalsIgnoreCase("null")) {
                holder.txtProvSpeciality.setText(pcpSearchResult.getSpecialty());
            } else {
                holder.txtProvSpeciality.setText("");
            }
            if (pcpSearchResult.getClinicalStafLanguage() != null && !pcpSearchResult.getClinicalStafLanguage().isEmpty() && !pcpSearchResult.getClinicalStafLanguage().equalsIgnoreCase("null")) {
                holder.txtProvLanguage.setText(pcpSearchResult.getClinicalStafLanguage());
            } else {
                holder.txtProvLanguage.setText("N/A");
            }
            if (pcpSearchResult.getPCPFlag() != null) {
                if (pcpSearchResult.getPCPFlag().toString().equalsIgnoreCase("true")) {
                    holder.txtProvPCPResult.setText("Yes");
                } else {
                    holder.txtProvPCPResult.setText("No");
                }
            }
            if (pcpSearchResult.getBoardCertifications() != null && !pcpSearchResult.getBoardCertifications().isEmpty() && !pcpSearchResult.getBoardCertifications().equalsIgnoreCase("null")) {
                holder.txtProvBoard.setText(pcpSearchResult.getBoardCertifications());
            } else {
                holder.txtProvBoard.setText("N/A");
            }
            if (pcpSearchResult.getADAAccessibility() != null && !pcpSearchResult.getADAAccessibility().isEmpty() && !pcpSearchResult.getADAAccessibility().equalsIgnoreCase("null")) {
                if (pcpSearchResult.getADAAccessibility().equalsIgnoreCase("Y")) {
                    holder.txtProvADAAccessibility.setText("Yes");
                } else {
                    holder.txtProvADAAccessibility.setText("No");
                }
            } else {
                holder.txtProvADAAccessibility.setText("N/A");
            }
        }
    }

    @Override
    public int getItemCount() {
        if (mSearchResultList != null) {
            return mSearchResultList.size();
        } else {
            return 0;
        }
    }

    class ProviderListViewHolder extends RecyclerView.ViewHolder {

        final TextView txtProvFLName;
        //        final TextView txtProvAddress;
        final TextView txtProvGender;
        final TextView txtProvSpeciality;
        final TextView txtProvLanguage;
        final TextView txtProvPCPResult;
        final TextView txtProvBoard;
        final TextView txtProvADAAccessibility;


        private ProviderListViewHolder(@NonNull View itemView) {
            super(itemView);
            txtProvFLName = itemView.findViewById(R.id.txt_ProvFLName);
//            txtProvAddress = itemView.findViewById(R.id.txt_ProvAddress);
            txtProvGender = itemView.findViewById(R.id.txt_ProvGender);
            txtProvSpeciality = itemView.findViewById(R.id.txt_ProvSpeciality);
            txtProvLanguage = itemView.findViewById(R.id.txt_ProvLanguage);
            txtProvPCPResult = itemView.findViewById(R.id.txt_ProvPCPResult);
            txtProvBoard = itemView.findViewById(R.id.txt_ProvBoard);
            txtProvADAAccessibility = itemView.findViewById(R.id.txt_ProvADAAccessibility);

        }

    }
}