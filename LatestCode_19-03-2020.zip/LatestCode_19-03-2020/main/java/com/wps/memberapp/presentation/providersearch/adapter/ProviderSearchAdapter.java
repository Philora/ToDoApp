package com.wps.memberapp.presentation.providersearch.adapter;
/*

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.wps.memberapp.R;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.presentation.providersearch.activity.MapActivity;
import androidx.recyclerview.widget.RecyclerView;

public class ProviderSearchAdapter extends RecyclerView.Adapter<ProviderSearchAdapter.ProviderViewHolder> {

    private final Context mCtx;
    private final Activity activity;
    List<Specialities> list;
    private final List<ProviderSearch> providerSearch;

    public ProviderSearchAdapter(Context applicationContext, Activity activity, List<ProviderSearch> providerSearch) {
        this.mCtx = applicationContext;
        this.providerSearch = providerSearch;
        this.activity = activity;
    }

    @Override
    public ProviderSearchAdapter.ProviderViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.fragment_provider_detail_view, parent, false);
        return new ProviderSearchAdapter.ProviderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ProviderSearchAdapter.ProviderViewHolder holder, final int position) {

        //Binding the data with the viewHolder views
        final ProviderSearch providerDetails = providerSearch.get(position);

        if (providerDetails != null) {

            String latitude = providerDetails.getGeographicalInfo().getLatitude();
            String longitude = providerDetails.getGeographicalInfo().getLongitude();
            SharedPreferenceHelper.getInstance().setPreference(mCtx, "origin", latitude);
            SharedPreferenceHelper.getInstance().setPreference(mCtx, "destination", longitude);

            if (providerDetails.getFirstName() != null && providerDetails.getLastName() != null) {
                String name = providerDetails.getFirstName() + "  " + providerDetails.getLastName();
                holder.textViewTitle.setText(name);
            }

            if (providerDetails.getGeographicalInfo().getGeoDistanceer() != null) {
                String info = providerDetails.getGeographicalInfo().getGeoDistanceer() + " " + "miles";
                holder.directionLabelTxt.setText(info);
            }
            if (providerDetails.getAddress() != null && providerDetails.getAddress().getAddress1() != null &&
                    !providerDetails.getAddress().getAddress1().equals("null")
                    && providerDetails.getAddress().getZipCode() != null
                    && providerDetails.getAddress().getZipCode().length() == 9 &&
                    providerDetails.getAddress().getCity() != null
                    && providerDetails.getAddress().getState() != null) {
                String zipCode = providerDetails.getAddress().getZipCode();
                String formattedZipCode = zipCode.substring(0, 5) + "-" + zipCode.substring(6, 8);
                String address = providerDetails.getAddress().getAddress1() + "," + " " +
                        providerDetails.getAddress().getCity()
                        + " " + providerDetails.getAddress().getState() + " " +
                        formattedZipCode;
                holder.txtAddressValue.setText(address);
            } else {
                String zipCode = providerDetails.getAddress().getZipCode();
                String address = providerDetails.getAddress().getAddress1() + "," + " " +
                        providerDetails.getAddress().getCity()
                        + " " + providerDetails.getAddress().getState() + " " + zipCode;
                holder.txtAddressValue.setText(address);
            }
            if (providerDetails.getPhoneNumber() != null && !providerDetails.getPhoneNumber().equals("null") &&
                    !providerDetails.getPhoneNumber().equals(" ") &&
                    !providerDetails.getPhoneNumber().isEmpty()) {
                String phoneNumber = providerDetails.getPhoneNumber();
                phoneNumber = "( " + phoneNumber.substring(0, 3) + " ) " + " " + phoneNumber.substring(3, 6)
                        + "-" + phoneNumber.substring(6, 10);
                holder.txtPhoneValue.setText(phoneNumber);
            } else {
                holder.txtPhoneValue.setText(" ");
            }
            if (providerDetails.getLanguages() != null && !providerDetails.getLanguages().isEmpty()) {
                for (int i = 0; i < providerDetails.getLanguages().size(); i++) {
                    if (providerDetails.getLanguages().get(i) != null &&
                            providerDetails.getLanguages().get(i).getDescription() != null) {
                        holder.txtLanguageValue.setText(providerDetails.getLanguages().get(i).getDescription());
                    }
                }
            }

            if (providerDetails.getRestrictions() != null && !providerDetails.getRestrictions().getRestrictionSummary().isEmpty()) {
                for (int i = 0; i < providerDetails.getRestrictions().getRestrictionSummary().size(); i++) {
                    if (providerDetails.getRestrictions().getRestrictionSummary().get(i) != null) {

                        String minAge = providerDetails.getRestrictions().getRestrictionSummary().get(i).getMinAge();
                        String maxAge = providerDetails.getRestrictions().getRestrictionSummary().get(i).getMaxAge();
                        String gender = providerDetails.getRestrictions().getRestrictionSummary().get(i).getRestrictionGender();

                        if (gender.equals("B")) {
                            String msg="Both Male and Female Patients Age Range " + minAge + " yrs to " + maxAge + "yrs";
                            holder.restrictionValue.setText(msg);
                        }

                    }
                }
            }

            if (providerDetails.getSpecialities() != null && !providerDetails.getSpecialities().isEmpty()) {
                for (int i = 0; i < providerDetails.getSpecialities().size(); i++) {
                    if (providerDetails.getSpecialities().get(i) != null &&
                            providerDetails.getSpecialities().get(i).getSpeciality() != null) {
                        holder.specialityValue.setText(providerDetails.getSpecialities().get(i).getSpeciality());
                    }
                }
            }
            if (providerSearch.get(position).getGender() != null && providerSearch.get(position).getGender().equals("M")) {
                holder.genderValue.setText(activity.getString(R.string.male));
            } else {
                holder.genderValue.setText(activity.getString(R.string.female));
            }
        }
        holder.directionImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mCtx, MapActivity.class);
                if(providerDetails!=null) {
                    intent.putExtra("origin", providerDetails.getGeographicalInfo().getLatitude());
                    intent.putExtra("destination", providerDetails.getGeographicalInfo().getLongitude());
                }
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                activity.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return providerSearch.size();
    }

    class ProviderViewHolder extends RecyclerView.ViewHolder {

        final TextView textViewTitle;
        final TextView textViewHospitalValue;
        final TextView timeTxtValue;
        final TextView txtAddressValue;
        final TextView txtPhoneValue;
        final TextView txtLanguageValue;
        final TextView specialityValue;
        final TextView genderValue;
        final TextView restrictionValue;
        final TextView directionLabelTxt;
        final ImageView directionImage;

        ProviderViewHolder(View itemView) {
            super(itemView);
            textViewTitle = itemView.findViewById(R.id.memberNameLabel);
            textViewHospitalValue = itemView.findViewById(R.id.txtViewHospitalLabel);
            timeTxtValue = itemView.findViewById(R.id.timeTxt);
            directionLabelTxt = itemView.findViewById(R.id.directionLabelTxt);
            txtAddressValue = itemView.findViewById(R.id.txtAddress);
            txtPhoneValue = itemView.findViewById(R.id.txtPhone);
            txtLanguageValue = itemView.findViewById(R.id.txtLanguage);
            specialityValue = itemView.findViewById(R.id.specialityValue);
            genderValue = itemView.findViewById(R.id.genderValue);
            restrictionValue = itemView.findViewById(R.id.restrictionValue);
            directionImage = itemView.findViewById(R.id.directionImage);
        }
    }
}
*/
