package com.wps.memberapp.presentation.providersearch.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.model.PlanList;

import java.util.List;

import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;

public class SearchProviderListAdapter extends RecyclerView.Adapter<SearchProviderListAdapter.ViewHolder> {
    private final Activity activity;
    View v;
    OnItemClickListener onItemClickListner;

    private List<PlanList> cityList;

    public SearchProviderListAdapter(Activity appContext, List<PlanList> planList, OnItemClickListener onItemClickListner) {
        //,SearchView mSearchView) {
        this.activity = appContext;
        this.cityList = planList;
        this.onItemClickListner = onItemClickListner;
    }

    @Override
    public SearchProviderListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        v = inflater.inflate(R.layout.search_item_text, parent, false);
        return new SearchProviderListAdapter.ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(SearchProviderListAdapter.ViewHolder holder, final int position) {
        if (cityList != null && !cityList.isEmpty()) {
            PlanList mPlanList = cityList.get(position);
            if (mPlanList.getValue() != null && !mPlanList.getValue().isEmpty() && !mPlanList.getValue().equalsIgnoreCase("null")) {
                holder.txtName.setText(mPlanList.getValue());
            }
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
//                    SharedPreferenceHelper.getInstance().setPreference(activity,"PlanListItem",mPlanList.getValue());
                    onItemClickListner.onItemClicked(position, mPlanList.getValue());
                }
            });
        }
    }


    @Override
    public int getItemCount() {
        if (cityList != null) {
            return cityList.size();
        } else {
            return 0;
        }
    }

    public interface OnItemClickListener {
        void onItemClicked(int position, String mPlanList);
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.txt_name)
        TextView txtName;

        public ViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
