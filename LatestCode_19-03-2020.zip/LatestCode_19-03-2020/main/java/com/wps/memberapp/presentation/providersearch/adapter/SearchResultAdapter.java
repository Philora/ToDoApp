package com.wps.memberapp.presentation.providersearch.adapter;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.PCPSearchResult;
import com.wps.memberapp.presentation.providersearch.activity.MapActivity;
import com.wps.memberapp.presentation.providersearch.fragment.ProviderSearchList;
import com.wps.memberapp.utility.GeneralUtils;

import java.net.URL;
import java.util.List;

public class SearchResultAdapter extends RecyclerView.Adapter<SearchResultAdapter.SearchViewHolder> {

    private final AppCompatActivity mCtx;
    List<PCPSearchResult> mSearchResultList;

    public SearchResultAdapter(AppCompatActivity mCtx, List<PCPSearchResult> mSearchResultList) {
        this.mCtx = mCtx;
        this.mSearchResultList = mSearchResultList;
    }

    @NonNull
    @Override
    public SearchViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.search_result_item, parent, false);
        return new SearchViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SearchViewHolder holder, final int position) {
        final PCPSearchResult pcpSearchResult = mSearchResultList.get(position);
        String mClinicAddress = "";
        String mClinicCity = "";
        if (pcpSearchResult != null) {
            //Binding the data with the viewHolder views
            if (pcpSearchResult.getClinicName() != null && !pcpSearchResult.getClinicName().isEmpty() && !pcpSearchResult.getClinicName().equalsIgnoreCase("null")) {
                holder.txtClinicName.setText(pcpSearchResult.getClinicName());
            }
            if (pcpSearchResult.getAddress1() != null && !pcpSearchResult.getAddress1().isEmpty() && !pcpSearchResult.getAddress1().equalsIgnoreCase("null")) {
                mClinicAddress = pcpSearchResult.getAddress1();
            }
            if (pcpSearchResult.getCity() != null && !pcpSearchResult.getCity().isEmpty() && !pcpSearchResult.getCity().equalsIgnoreCase("null")) {
                mClinicCity = pcpSearchResult.getCity();
            }
            holder.txtProvAddress.setText(mClinicAddress + ", " + mClinicCity);
            if (pcpSearchResult.getZipCode() != null) {
                String mZipLength = pcpSearchResult.getZipCode();
                String mZipCode = mZipLength.substring(0, 5);
                holder.txtProvState.setText(pcpSearchResult.getState() + ", " + mZipCode);
            }
            if (pcpSearchResult.getDISTANCE() != null && !pcpSearchResult.getDISTANCE().isEmpty() && !pcpSearchResult.getDISTANCE().equalsIgnoreCase("null")) {
                String mDistance = pcpSearchResult.getDISTANCE();
                if (!mDistance.equalsIgnoreCase("0")) {
                    holder.txtProvClinicMap.setText(mCtx.getString(R.string.view_on_map) + " (" + mDistance + mCtx.getString(R.string.miles) + ")");
                } else {
                    holder.txtProvClinicMap.setText(mCtx.getString(R.string.view_on_map) + " (" + mDistance + mCtx.getString(R.string.mile) + ")");
                }
            }
            holder.txtProvClinicWebsite.setOnClickListener(view -> {
                String mClinicURL = pcpSearchResult.getClinicWebsite();
                if (mClinicURL != null && !mClinicURL.equalsIgnoreCase("") && !mClinicURL.isEmpty()) {

                    if (!mClinicURL.startsWith("https://") && (mClinicURL.contains(".com")|| mClinicURL.contains(".in") || mClinicURL.contains(".org"))) {
                        mClinicURL = "http://"+mClinicURL;
                    }
                    if (mClinicURL.startsWith("http://")) {
                        mClinicURL = mClinicURL.replace("http://", "https://");
                        Toast.makeText(mCtx, "UnSecure URL! " + mClinicURL, Toast.LENGTH_SHORT).show();
                    }
                    if (!mClinicURL.startsWith("https://") && mClinicURL.contains("www.")) {
                        mClinicURL = "https://" + mClinicURL;
                        // System.out.println("Result: " +mClinicURL);
                        Toast.makeText(mCtx, "Formatted URL: " + mClinicURL, Toast.LENGTH_SHORT).show();
                    }
                    if (isValid(mClinicURL)) {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(mClinicURL));
                        mCtx.startActivity(intent);
                    } else {
                        GeneralUtils.showAlertDialog(mCtx, "Invalid URL");
                    }
                }
            });
            holder.txtProvClinicMap.setOnClickListener(view -> {
                Intent intent = new Intent(mCtx, MapActivity.class);
                if (pcpSearchResult != null) {
                    if (pcpSearchResult.getLatitude() != null) {
                        intent.putExtra("latitude", pcpSearchResult.getLatitude());
                    }
                    if (pcpSearchResult.getLongitude() != null) {
                        intent.putExtra("longitude", pcpSearchResult.getLongitude());
                    }
                }
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                mCtx.startActivity(intent);
            });
            holder.itemView.setOnClickListener(view -> {
                Fragment providerSearchList = new ProviderSearchList();
                Bundle args = new Bundle();
                if (mSearchResultList.get(position) != null) {
                    int pos = holder.getPosition();
                    args.putInt("providerPosition", pos);
                    ProfileDataCache.getInstance().setPcpProviderList(mSearchResultList.get(position).getProviders());
                }
                providerSearchList.setArguments(args);
                mCtx.getSupportFragmentManager().beginTransaction().replace(R.id.frame_container, providerSearchList).addToBackStack(null).commit();
            });
        }
    }

    private boolean isValid(String mClinicURL) {
        try {
            new URL(mClinicURL).toURI();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public int getItemCount() {
        if (mSearchResultList != null) {
            return mSearchResultList.size();
        } else {
            return 0;
        }
    }

    class SearchViewHolder extends RecyclerView.ViewHolder {

        final TextView txtClinicName;
        final TextView txtProvAddress;
        final TextView txtProvState;
        final TextView txtProvClinicWebsite;
        final TextView txtProvClinicMap;

        private SearchViewHolder(@NonNull View itemView) {
            super(itemView);
            txtClinicName = itemView.findViewById(R.id.txt_ProvClinicName);
            txtProvAddress = itemView.findViewById(R.id.txt_ProvAddress);
            txtProvState = itemView.findViewById(R.id.txt_ProvState);
            txtProvClinicWebsite = itemView.findViewById(R.id.txt_ProvClinicWebsite);
            txtProvClinicMap = itemView.findViewById(R.id.txt_ProvClinicMap);
        }

    }
}