package com.wps.memberapp.presentation.providersearch.fragment;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
//import android.widget.Toast;

import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.model.PCPSearchResult;
import com.wps.memberapp.data.model.PlanList;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.presentation.base.BaseFragment;
import com.wps.memberapp.presentation.claims.adapter.NothingSelectedSpinnerAdapter;
import com.wps.memberapp.presentation.providersearch.adapter.SearchProviderListAdapter;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

public class ProviderSearchFragment extends BaseFragment implements SearchProviderView {

    @BindView(R.id.ll_AdVanceOverlay)
    LinearLayout ll_AdVanceOverlay;
    @BindView(R.id.ll_advance_search)
    LinearLayout llAdvanceSearch;
    @BindView(R.id.rv_search_result)
    RecyclerView rvSearchCity;
    @BindView(R.id.spin_PlanName)
    Spinner spinPlanName;
    @BindView(R.id.spin_Language)
    Spinner spinLanguage;
    @BindView(R.id.search_view_city)
    SearchView svCity;

   /* @BindView(R.id.search_view_groupname)
    SearchView searchGroupName;
    @BindView(R.id.rv_search_result_groupname)
    RecyclerView rvSearchGroupName;*/

    @BindView(R.id.search_view_speciality)
    SearchView svSpeciality;
    @BindView(R.id.rv_search_result_speciality)
    RecyclerView rvSearchSpeciality;
    @BindView(R.id.search_view_hospital_affiliation)
    SearchView svHospitalAffiliation;
    @BindView(R.id.rv_search_result_hospital_affiliation)
    RecyclerView rvSearchHospitalAffiliation;


    //
    @BindView(R.id.search_view_ClinicName)
    SearchView svClinicName;
    @BindView(R.id.rv_search_result_clinicName)
    RecyclerView rvSearchClinicName;
    @BindView(R.id.search_view_AreaOfExpertise)
    SearchView svAreaOfExpertise;
    @BindView(R.id.rv_search_result_area_expertise)
    RecyclerView rvSearchAreaOfExpertise;


    @BindView(R.id.spin_provider_type)
    Spinner spinProviderType;
    @BindView(R.id.spin_ProviderGender)
    Spinner spinProviderGender;
    @BindView(R.id.spin_ProviderMiles)
    Spinner spinProviderMiles;
    @BindView(R.id.check_PCP)
    CheckBox checkPCP;
    @BindView(R.id.check_AcceptingNewPatients)
    CheckBox chkAcceptingNewPatients;

    // Enhancement 16-01-2020
    @BindView(R.id.check_BoardCertification)
    CheckBox chkBoardCertification;
    @BindView(R.id.check_UrgentCareFacility)
    CheckBox chkUrgentCareFacility;
    @BindView(R.id.check_ExtendedHours)
    CheckBox chkExtendedHours;

    // Enhancement 12-02-2020
    @BindView(R.id.check_Accredited)
    CheckBox chkAccredited;
    @BindView(R.id.check_Telemedicine)
    CheckBox chkTelemedicine;
    @BindView(R.id.check_ADAAccessibility)
    CheckBox chkADAAccessibility;

    @BindView(R.id.edt_GroupName)
    EditText edtGroupName;
    @BindView(R.id.edt_FirstName)
    EditText edtFirstName;
    @BindView(R.id.edt_LastName)
    EditText edtLastName;
    @BindView(R.id.txt_SearchByAddress)
    TextView txtSearchByAddress;
    @BindView(R.id.btn_AdvanceSearch)
    Button btnAdvanceSearch;
    @BindView(R.id.btn_provider_clear)
    Button btnProviderClear;
    @BindView(R.id.btn_provider_search)
    Button btnProviderSearch;
    private Unbinder mUnbinder;
    boolean isBtnSelected = true;
    SearchProviderPresenter searchProviderPresenter;
    String svCityQuery = "";
    String search_groupName_query = "";
    String search_speciality_query = "";
    String search_hospital_affiliation = "";
    private String providerLanguage = "";
    private String providerType = "";
    private String providerGender = "";
    private String providerMiles = "";
    Dialog dialog;
    private int pageID = 1;
    List<String> languageList;
    ArrayAdapter<String> langDataAdapter;
    @BindView(R.id.lL_SpinnerCheck)
    LinearLayout lLSpinnerCheck;
    @BindView(R.id.lL_Name)
    LinearLayout lLName;
    @BindView(R.id.ll_Behavioral)
    LinearLayout lLBehavioral;
    @BindView(R.id.lL_Lang)
    LinearLayout lLLang;
    @BindView(R.id.edt_Name)
    EditText edtName;

    // Enhancement 12-02
    String svClinicNameQuery = "";
    String svAreaOfExpertiseQuery = "";
    @BindView(R.id.lL_SearchByAddress)
    LinearLayout lLSearchByAddress;
    String mAddress1, mAddress2, mCity, mState, mZipCode;

    @SuppressLint("WrongConstant")
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        View rootView = inflater.inflate(R.layout.provider_search_fragment, container, false);
        mUnbinder = ButterKnife.bind(this, rootView);
        if (getActivity() != null) {
            ImageView imageViewSearch = getActivity().findViewById(R.id.imageViewSearch);
            imageViewSearch.setVisibility(View.GONE);
            TextView txtDownloadPDF = getActivity().findViewById(R.id.txt_Call);
            txtDownloadPDF.setVisibility(View.GONE);
            TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
            fragmentTitle.setText(R.string.provider_search);
        }

        searchProviderPresenter = new SearchProviderPresenterImp();
        searchProviderPresenter.onAttach(this);
        String mPlanName = ProfileDataCache.getInstance().getmMemberDetails().get(0).getPlanName();
        List<String> list = Arrays.asList(mPlanName);
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinPlanName.setAdapter(dataAdapter);
        if (mPlanName != null) {
            int spinnerPosition = dataAdapter.getPosition(mPlanName);
            spinPlanName.setSelection(spinnerPosition);
        }
        if (ProfileDataCache.getInstance().getLanguageSpokenList() == null) {
            searchProviderPresenter.getLanguage();
        } else {
            addItemsOnSpinner1();
        }
        if (ProfileDataCache.getInstance().getGeoLat() == null && ProfileDataCache.getInstance().getGeoLong() == null) {
            searchProviderPresenter.getApplicantsGeoLocation();
        }
        svCity.setOnQueryTextListener(new androidx.appcompat.widget.SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                svCityQuery = newText;
                if (newText.length() > 2) {
                    if (svCityQuery.matches(".*\\d.*")) {
                        ProfileDataCache.getInstance().setSearchCityItemValue(svCityQuery);
                    } else {
                        svCity.clearFocus();
                        rvSearchCity.setVisibility(View.VISIBLE);
                        ProfileDataCache.getInstance().setSearchCityQueryKeyword(svCityQuery);
                        searchProviderPresenter.getSearchCityText();
                    }
                } else {
                    rvSearchCity.setVisibility(View.GONE);
                }
                return false;
            }
        });

        //Added selected listener to get the selected data
        spinProviderType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                try {
                    if (spinProviderType.getSelectedItem() != null) {
                        providerType = spinProviderType.getSelectedItem().toString();
                        if (providerType != null && providerType.equalsIgnoreCase("Doctors/Medical Professionals")) {
                            providerType = providerType.replace("Doctors/Medical Professionals", "DOC");
                            lLSpinnerCheck.setVisibility(View.VISIBLE);
                            lLLang.setVisibility(View.VISIBLE);
                            lLName.setVisibility(View.GONE);
                            lLBehavioral.setVisibility(View.GONE);
                            chkAcceptingNewPatients.setVisibility(View.VISIBLE);
                            chkBoardCertification.setVisibility(View.VISIBLE);
                            chkUrgentCareFacility.setVisibility(View.VISIBLE);
                            chkExtendedHours.setVisibility(View.VISIBLE);
                            chkTelemedicine.setVisibility(View.GONE);
                            chkAccredited.setVisibility(View.GONE);
                            chkADAAccessibility.setVisibility(View.GONE);
                            clearDataByProviderType();
                        } else if (providerType != null && providerType.equalsIgnoreCase("Facility")) {
                            providerType = providerType.replace("Facility", "FAC");
                            lLSpinnerCheck.setVisibility(View.GONE);
                            lLBehavioral.setVisibility(View.GONE);
                            lLLang.setVisibility(View.VISIBLE);
                            lLName.setVisibility(View.VISIBLE);
                            chkAcceptingNewPatients.setVisibility(View.VISIBLE);
                            chkUrgentCareFacility.setVisibility(View.VISIBLE);
                            chkExtendedHours.setVisibility(View.VISIBLE);
                            chkAccredited.setVisibility(View.VISIBLE);
                            chkTelemedicine.setVisibility(View.GONE);
                            chkADAAccessibility.setVisibility(View.GONE);
                            chkBoardCertification.setVisibility(View.GONE);
                            clearDataByProviderType();
                        } else if (providerType != null && providerType.equalsIgnoreCase("Pharmacy")) {
                            providerType = providerType.replace("Pharmacy", "PHA");
                            lLSpinnerCheck.setVisibility(View.GONE);
                            lLBehavioral.setVisibility(View.GONE);
                            lLLang.setVisibility(View.INVISIBLE);
                            lLName.setVisibility(View.GONE);
                            chkAcceptingNewPatients.setVisibility(View.VISIBLE);
                            chkTelemedicine.setVisibility(View.VISIBLE);
                            chkUrgentCareFacility.setVisibility(View.VISIBLE);
                            chkExtendedHours.setVisibility(View.VISIBLE);
                            chkAccredited.setVisibility(View.GONE);
                            chkADAAccessibility.setVisibility(View.GONE);
                            chkBoardCertification.setVisibility(View.GONE);
                            clearDataByProviderType();
                        } else if (providerType != null && providerType.equalsIgnoreCase("Hospital")) {
                            providerType = providerType.replace("Hospital", "HOSP");
                            lLSpinnerCheck.setVisibility(View.GONE);
                            lLBehavioral.setVisibility(View.GONE);
                            lLName.setVisibility(View.VISIBLE);
                            lLLang.setVisibility(View.VISIBLE);
                            chkAcceptingNewPatients.setVisibility(View.VISIBLE);
                            chkUrgentCareFacility.setVisibility(View.VISIBLE);
                            chkExtendedHours.setVisibility(View.VISIBLE);
                            chkAccredited.setVisibility(View.VISIBLE);
                            chkTelemedicine.setVisibility(View.GONE);
                            chkADAAccessibility.setVisibility(View.GONE);
                            chkBoardCertification.setVisibility(View.GONE);
                            clearDataByProviderType();
                        } else if (providerType != null && providerType.equalsIgnoreCase("Behavioral Health")) {
                            providerType = providerType.replace("Behavioral Health", "BHE");
                            lLSpinnerCheck.setVisibility(View.VISIBLE);
                            lLName.setVisibility(View.GONE);
                            lLBehavioral.setVisibility(View.VISIBLE);
                            lLLang.setVisibility(View.VISIBLE);
                            chkAcceptingNewPatients.setVisibility(View.VISIBLE);
                            chkUrgentCareFacility.setVisibility(View.VISIBLE);
                            chkExtendedHours.setVisibility(View.VISIBLE);
                            chkAccredited.setVisibility(View.VISIBLE);
                            chkTelemedicine.setVisibility(View.VISIBLE);
                            chkADAAccessibility.setVisibility(View.VISIBLE);
                            chkBoardCertification.setVisibility(View.VISIBLE);
                            clearDataByProviderType();
                        } else if (providerType != null && providerType.equalsIgnoreCase("Durable Medical Equipment")) {
                            providerType = providerType.replace("Durable Medical Equipment", "DME");
                            lLSpinnerCheck.setVisibility(View.GONE);
                            lLBehavioral.setVisibility(View.GONE);
                            lLName.setVisibility(View.VISIBLE);
                            lLLang.setVisibility(View.VISIBLE);
                            chkExtendedHours.setVisibility(View.VISIBLE);
                            chkAcceptingNewPatients.setVisibility(View.GONE);
                            chkUrgentCareFacility.setVisibility(View.GONE);
                            chkAccredited.setVisibility(View.GONE);
                            chkTelemedicine.setVisibility(View.GONE);
                            chkADAAccessibility.setVisibility(View.GONE);
                            chkBoardCertification.setVisibility(View.GONE);
                            clearDataByProviderType();
                        }
                        ProfileDataCache.getInstance().setProviderType(providerType);
                    }
                } catch (Exception e) {
                    Logger.e(StringConstants.EXCEPTION, e);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //Do something
            }
        });

        //Added selected listener to get the selected data
        spinProviderGender.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                try {
                    if (spinProviderGender.getSelectedItem() != null) {
                        providerGender = spinProviderGender.getSelectedItem().toString();
                        if (providerGender != null && providerGender.equalsIgnoreCase("No Preference")) {
                            providerGender = providerGender.replace("No Preference", "");
                        } else if (providerGender != null && providerGender.equalsIgnoreCase("Male")) {
                            providerGender = providerGender.replace("Male", "M");
                        } else if (providerGender != null && providerGender.equalsIgnoreCase("Female")) {
                            providerGender = providerGender.replace("Female", "F");
                        }
                        ProfileDataCache.getInstance().setProviderGender(providerGender);
                    }
                } catch (Exception e) {
                    Logger.e(StringConstants.EXCEPTION, e);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //Do something
            }
        });

        spinProviderMiles.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                try {
                    if (spinProviderMiles.getSelectedItem() != null) {
                        providerMiles = spinProviderMiles.getSelectedItem().toString();
                        if (providerMiles != null && providerMiles.equalsIgnoreCase("5 Miles")) {
                            providerMiles = providerMiles.replace("5 Miles", "5");
                        } else if (providerMiles != null && providerMiles.equalsIgnoreCase("10 Miles")) {
                            providerMiles = providerMiles.replace("10 Miles", "10");
                        } else if (providerMiles != null && providerMiles.equalsIgnoreCase("20 Miles")) {
                            providerMiles = providerMiles.replace("20 Miles", "20");
                        } else if (providerMiles != null && providerMiles.equalsIgnoreCase("30 Miles")) {
                            providerMiles = providerMiles.replace("30 Miles", "30");
                        } else if (providerMiles != null && providerMiles.equalsIgnoreCase("50 Miles")) {
                            providerMiles = providerMiles.replace("50 Miles", "50");
                        } else if (providerMiles != null && providerMiles.equalsIgnoreCase("99 Miles")) {
                            providerMiles = providerMiles.replace("99 Miles", "99");
                        } else if (providerMiles != null && providerMiles.equalsIgnoreCase("All")) {
                            providerMiles = providerMiles.replace("All", "");
                        }
                        ProfileDataCache.getInstance().setProvMiles(providerMiles);
                    }
                } catch (Exception e) {
                    Logger.e(StringConstants.EXCEPTION, e);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //Do something
            }
        });

        btnAdvanceSearch.setOnClickListener(view -> {
            if (isBtnSelected) {
                Drawable iconMinus = getActivity().getResources().getDrawable(R.drawable.minus_w);
                ll_AdVanceOverlay.setBackground(ContextCompat.getDrawable(getActivity(), R.drawable.rounded_corners_blue_bg));
                btnAdvanceSearch.setTextColor(Color.WHITE);
                btnAdvanceSearch.setCompoundDrawablesWithIntrinsicBounds(null, null, iconMinus, null);
                llAdvanceSearch.setVisibility(View.VISIBLE);
                btnAdvanceSearch.setPadding(20, 0, 20, 0);
                getSearchByAddress();
                isBtnSelected = false;
            } else {
                Drawable iconPlus = getActivity().getResources().getDrawable(R.drawable.add_color_app);
                ll_AdVanceOverlay.setBackground(ContextCompat.getDrawable(getActivity(), R.drawable.rounded_corners_w_blue_bg));
                btnAdvanceSearch.setTextColor(ResourcesCompat.getColor(getResources(), R.color.colorPrimary, null));
                btnAdvanceSearch.setCompoundDrawablesWithIntrinsicBounds(null, null, iconPlus, null);
                clearDataOnClick();
                llAdvanceSearch.setVisibility(View.GONE);
                btnAdvanceSearch.setVisibility(View.VISIBLE);
                btnAdvanceSearch.setPadding(20, 0, 20, 0);
                isBtnSelected = true;
            }
        });

        lLSearchByAddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                showDialog(mAddress1, mAddress2, mCity, mState, mZipCode);
            }
        });
        lLSearchByAddress.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                //showDialog(mAddress1, mAddress2, mCity, mState, mZipCode);
                return true;
            }
        });

        /*searchGroupName.setOnQueryTextListener(new androidx.appcompat.widget.SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                search_groupName_query = newText;
                if (newText.length() > 2) {
                    rvSearchGroupName.setVisibility(View.VISIBLE);
                    ProfileDataCache.getInstance().setSearchGroupNameQueryKeyword(search_groupName_query);
                    searchProviderPresenter.getSearchGroupName(search_groupName_query);
                    searchGroupName.clearFocus();

                } else {
                    rvSearchGroupName.setVisibility(View.GONE);
                }
                return false;
            }
        });*/

        svSpeciality.setOnQueryTextListener(new androidx.appcompat.widget.SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                search_speciality_query = newText;
                if (newText.length() > 2) {
                    rvSearchSpeciality.setVisibility(View.VISIBLE);
                    ProfileDataCache.getInstance().setSearchSpecialityQueryKeyword(search_speciality_query);
                    searchProviderPresenter.getSearchSpeciality();
                    svSpeciality.clearFocus();
                } else {
                    rvSearchSpeciality.setVisibility(View.GONE);
                }
                return false;
            }
        });

        svHospitalAffiliation.setOnQueryTextListener(new androidx.appcompat.widget.SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                search_hospital_affiliation = newText;
                if (newText.length() > 2) {
                    rvSearchHospitalAffiliation.setVisibility(View.VISIBLE);
                    ProfileDataCache.getInstance().setSearchHospitalAffiliationQueryKeyword(search_hospital_affiliation);
                    searchProviderPresenter.getSearchHospitalAffiliation();
                    svHospitalAffiliation.clearFocus();
                } else {
                    rvSearchHospitalAffiliation.setVisibility(View.GONE);
                }
                return false;
            }
        });

        svClinicName.setOnQueryTextListener(new androidx.appcompat.widget.SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                svClinicNameQuery = newText;
                if (newText.length() > 2) {
                    rvSearchClinicName.setVisibility(View.VISIBLE);
                    ProfileDataCache.getInstance().setSearchClinicQueryKeyword(svClinicNameQuery);
                    searchProviderPresenter.getSearchClinicName();
                } else {
                    rvSearchClinicName.setVisibility(View.GONE);
                }
                return false;
            }
        });

        svAreaOfExpertise.setOnQueryTextListener(new androidx.appcompat.widget.SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                svAreaOfExpertiseQuery = newText;
                if (newText.length() > 2) {
                    rvSearchAreaOfExpertise.setVisibility(View.VISIBLE);
                    ProfileDataCache.getInstance().setSearchAreaExpertiseQueryKeyword(svAreaOfExpertiseQuery);
                    searchProviderPresenter.getSearchAreaExpertise();
                } else {
                    rvSearchAreaOfExpertise.setVisibility(View.GONE);
                }
                return false;
            }
        });

        btnProviderSearch.setOnClickListener(view ->

        {
            if (checkPCP.isChecked()) {
                ProfileDataCache.getInstance().setPCPCheck(true);
            } else {
                ProfileDataCache.getInstance().setPCPCheck(false);
            }
            if (chkAcceptingNewPatients.isChecked()) {
                ProfileDataCache.getInstance().setAcceptNewPatients(true);
            } else {
                ProfileDataCache.getInstance().setAcceptNewPatients(false);
            }

            // Enhancement 16-01-2020
            if (chkBoardCertification.isChecked()) {
                ProfileDataCache.getInstance().setBoardCertification(true);
            } else {
                ProfileDataCache.getInstance().setBoardCertification(false);
            }
            if (chkUrgentCareFacility.isChecked()) {
                ProfileDataCache.getInstance().setUrgentCareFacility(true);
            } else {
                ProfileDataCache.getInstance().setUrgentCareFacility(false);
            }
            if (chkExtendedHours.isChecked()) {
                ProfileDataCache.getInstance().setExtendedHours(true);
            } else {
                ProfileDataCache.getInstance().setExtendedHours(false);
            }
            if (chkAccredited.isChecked()) {
                ProfileDataCache.getInstance().setAccredited(true);
            } else {
                ProfileDataCache.getInstance().setAccredited(false);
            }
            if (chkTelemedicine.isChecked()) {
                ProfileDataCache.getInstance().setTelemedicine(true);
            } else {
                ProfileDataCache.getInstance().setTelemedicine(false);
            }
            if (chkADAAccessibility.isChecked()) {
                ProfileDataCache.getInstance().setADAAccessibility(true);
            } else {
                ProfileDataCache.getInstance().setADAAccessibility(false);
            }

            String mCityCode = svCity.getQuery().toString().trim();
            ProfileDataCache.getInstance().setSearchCityItemValue(mCityCode);

            String mSpeciality = svSpeciality.getQuery().toString().trim();
            ProfileDataCache.getInstance().setSearchSpecialityItemValue(mSpeciality);

            String mHospitalAffiliation = svHospitalAffiliation.getQuery().toString().trim();
            ProfileDataCache.getInstance().setSearchHospitalAffiliationItemValue(mHospitalAffiliation);

            String mFirstName = edtFirstName.getText().toString().trim();
            String mLastName = edtLastName.getText().toString().trim();
            String mGroupName = edtGroupName.getText().toString().trim();
            String mName = edtName.getText().toString().trim();
            ProfileDataCache.getInstance().setProvFirstName(mFirstName);
            ProfileDataCache.getInstance().setProvLastName(mLastName);
//            ProfileDataCache.getInstance().setProvGroupName(mGroupName);
            ProfileDataCache.getInstance().setProvName(mName);
            if (isBtnSelected && providerMiles != null) { // && !spinProviderMiles.isSelected()
                ProfileDataCache.getInstance().setProvMiles(String.valueOf(5));
            }
            ProfileDataCache.getInstance().setPageID(pageID);

            String mSearchCityItem = ProfileDataCache.getInstance().getSearchCityItemValue();
            String mSearchSpecialityItem = ProfileDataCache.getInstance().getSearchSpecialityItemValue();
            String mSearchHospitalAffiliationItem = ProfileDataCache.getInstance().getSearchHospitalAffiliationItemValue();
            if (mCityCode.equalsIgnoreCase(mSearchCityItem) && mSearchSpecialityItem.equalsIgnoreCase(mSpeciality) && mSearchHospitalAffiliationItem.equalsIgnoreCase(mHospitalAffiliation)) {
                searchProviderPresenter.getPCPSearch();
            } else {
                GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.data_mismatching));
            }
        });

        btnProviderClear.setOnClickListener(view -> {
            cleanUpData();
        });
        return rootView;
    }

    private void clearDataOnClick() {
        svSpeciality.setQuery("", true);
        svHospitalAffiliation.setQuery("", true);
        svClinicName.setQuery("", true);
        svAreaOfExpertise.setQuery("", true);
        svCity.clearFocus();
        edtFirstName.setText("");
        edtLastName.setText("");
        edtGroupName.setText("");
        edtName.setText("");
        spinProviderGender.setSelection(0);
        spinProviderMiles.setSelection(0);
        spinLanguage.setSelection(0);
        chkAcceptingNewPatients.setChecked(false);
        chkBoardCertification.setChecked(false);
        chkUrgentCareFacility.setChecked(false);
        chkExtendedHours.setChecked(false);
        chkAccredited.setChecked(false);
        chkTelemedicine.setChecked(false);
        chkADAAccessibility.setChecked(false);
        ProfileDataCache.getInstance().setProviderLanguage("");
        ProfileDataCache.getInstance().setProvName("");
    }

    @Override
    public void onResume() {
        super.onResume();
        isBtnSelected = true;
    }

    private void showDialog(String mDAddress1, String mDAddress2, String mDCity, String mDState, String mDZipCode) {
        if (getActivity() != null) {
            dialog = new Dialog(getActivity());
            dialog.setContentView(R.layout.search_by_address_popup);
            dialog.setCancelable(false);
            EditText edtAddress1 = (EditText) dialog.findViewById(R.id.edt_Address1);
            EditText edtAddress2 = (EditText) dialog.findViewById(R.id.edt_Address2);
            EditText edtCity = (EditText) dialog.findViewById(R.id.edt_City);
            EditText edtZipcode = (EditText) dialog.findViewById(R.id.edt_Zipcode);
            Button btnUpdateAddress = (Button) dialog.findViewById(R.id.btn_UpdateAddress);
            Button btnSearchClear = (Button) dialog.findViewById(R.id.btn_SearchClear);

            edtAddress1.setText(mDAddress1);
            edtAddress2.setText(mDAddress2);
            edtCity.setText(mDCity);
            edtZipcode.setText(mDZipCode);

            btnUpdateAddress.setOnClickListener(view1 -> {
                if (getActivity() != null) {
                    if (GeneralUtils.isOnline(getActivity())) {
                        mAddress1 = edtAddress1.getText().toString();
                        mAddress2 = edtAddress2.getText().toString();
                        mCity = edtCity.getText().toString();
                        mZipCode = edtZipcode.getText().toString();
                        updateAddressData(mAddress1, mAddress2, mCity, mState, mZipCode);
                        dialog.dismiss();
                    }
                }
            });
            btnSearchClear.setOnClickListener(view12 -> dialog.dismiss());
            dialog.show();
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        isBtnSelected = false;
    }

    private void clearDataByProviderType() {

        svSpeciality.setQuery("", true);
        svHospitalAffiliation.setQuery("", true);
        svClinicName.setQuery("", true);
        svAreaOfExpertise.setQuery("", true);
        svCity.clearFocus();
        edtFirstName.setText("");
        edtLastName.setText("");
        edtGroupName.setText("");
        edtName.setText("");
        checkPCP.setChecked(false);
        spinProviderGender.setSelection(0);
        spinProviderMiles.setSelection(0);
        spinLanguage.setSelection(0);
        chkAcceptingNewPatients.setChecked(false);
        chkBoardCertification.setChecked(false);
        chkUrgentCareFacility.setChecked(false);
        chkExtendedHours.setChecked(false);
        chkAccredited.setChecked(false);
        chkTelemedicine.setChecked(false);
        chkADAAccessibility.setChecked(false);
        ProfileDataCache.getInstance().setSearchCityItemValue("");
        ProfileDataCache.getInstance().setSearchSpecialityItemValue("");
        ProfileDataCache.getInstance().setSearchHospitalAffiliationItemValue("");
        ProfileDataCache.getInstance().setSearchClinicItemValue("");
        ProfileDataCache.getInstance().setSearchExpertiseItemValue("");
        ProfileDataCache.getInstance().setProviderLanguage("");
        ProfileDataCache.getInstance().setProvName("");
    }

    private void getSearchByAddress() {
        MemberDetails details = ProfileDataCache.getInstance().getmMemberDetails().get(0);
        if (details != null) {
            for (int i = 0; i < details.getAddressList().size(); i++) {
                if (details.getAddressList().get(i).getAddressType().equalsIgnoreCase("R1")) {

                    mAddress1 = details.getAddressList().get(i).getAddress1();
                    mAddress2 = details.getAddressList().get(i).getAddress2();
                    mCity = details.getAddressList().get(i).getCity();
                    mState = details.getAddressList().get(i).getState();
                    mZipCode = details.getAddressList().get(i).getZipCode();
                    updateAddressData(mAddress1, mAddress2, mCity, mState, mZipCode);
                }
            }
        }
    }

    private void updateAddressData(String mAddress1, String mAddress2, String mCity, String mState, String mZipCode) {
        String mAddressBySearch = mAddress1 + ", " + mAddress2 + ", " + mCity + ", " + mState + ", " + mZipCode;
        txtSearchByAddress.setText(mAddressBySearch);
    }

    @Override
    public void onLanguageResponse(List<PlanList> mGetLanguageSpoken) {
        languageList = new ArrayList<>();
        languageList.add(getActivity().getString(R.string.any_language));
        if (mGetLanguageSpoken != null) {
            try {
                for (int i = 0; i < mGetLanguageSpoken.size(); i++) {
                    languageList.add(mGetLanguageSpoken.get(i).getValue());
                }
            } catch (Exception e) {
                Logger.e(StringConstants.EXCEPTION, e);
            }
        }
        ProfileDataCache.getInstance().setLanguageSpokenList(languageList);
        addItemsOnSpinner1();
    }

    @Override
    public void onApplicantLocationResponse(String mAppGeoLocation) {
//        Toast.makeText(getContext(), "App Geo Location: " + mAppGeoLocation, Toast.LENGTH_SHORT).show();
//        showDialogError("App Geo Location: " + mAppGeoLocation);
    }

    /*@Override
    public void onGroupNameResponse(List<PlanList> mGetGroupName) {
        try {
            if (mGetGroupName!= null && mGetGroupName.size() > 0) {
                rvSearchGroupName.setHasFixedSize(true);
                rvSearchGroupName.setNestedScrollingEnabled(false);
                final LinearLayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
                mLayoutManager.setOrientation(RecyclerView.VERTICAL);
                rvSearchGroupName.setLayoutManager(mLayoutManager);

                SearchProviderListAdapter searchAdapter = new SearchProviderListAdapter(getAppContext(), mGetGroupName, new SearchProviderListAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClicked(int position, String mCityList) {
                        // Handle Object of list item here
                        searchGroupName.setQuery(mCityList, true);
                        searchGroupName.clearFocus();
                        rvSearchGroupName.setVisibility(View.GONE);
                        if (mCityList!=null) {
                            ProfileDataCache.getInstance().setSearchGroupNameItemValue(mCityList);
                        }else {
                            ProfileDataCache.getInstance().setSearchGroupNameItemValue("");
                        }
                    }
                });
                rvSearchGroupName.setAdapter(searchAdapter);
                searchAdapter.notifyDataSetChanged();
                searchGroupName.clearFocus();
            } else {
                rvSearchGroupName.setVisibility(View.GONE);
                Toast.makeText(getContext(), getString(R.string.no_data_found), Toast.LENGTH_SHORT).show();
                searchGroupName.clearFocus();
                getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }*/

    @Override
    public void onCityResponse(List<PlanList> mGetCityCountry) {
        try {
            if (mGetCityCountry != null && mGetCityCountry.size() > 0) {
                rvSearchCity.setHasFixedSize(true);
                rvSearchCity.setNestedScrollingEnabled(false);
                final LinearLayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
                mLayoutManager.setOrientation(RecyclerView.VERTICAL);
                rvSearchCity.setLayoutManager(mLayoutManager);

                SearchProviderListAdapter searchAdapter = new SearchProviderListAdapter(getAppContext(), mGetCityCountry, new SearchProviderListAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClicked(int position, String mCityList) {
                        // Handle Object of list item here
                        if (mCityList != null) {
                            svCity.setQuery(mCityList, true);
                            svCity.clearFocus();
                            rvSearchCity.setVisibility(View.GONE);
                            ProfileDataCache.getInstance().setSearchCityItemValue(mCityList);
                        } else {
                            ProfileDataCache.getInstance().setSearchCityItemValue("");
                        }
                    }
                });
                svCity.clearFocus();
                rvSearchCity.setAdapter(searchAdapter);
                searchAdapter.notifyDataSetChanged();
            } else {
                svCity.clearFocus();
                rvSearchCity.setVisibility(View.GONE);
//                Toast.makeText(getContext(), getString(R.string.no_data_found), Toast.LENGTH_SHORT).show();
                GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.no_provider_found));
                svCity.setQuery("", true);
                ProfileDataCache.getInstance().setSearchCityItemValue("");
                getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onSpecialityResponse(List<PlanList> mGetSpeciality) {
        try {
            if (mGetSpeciality != null && mGetSpeciality.size() > 0) {
                rvSearchSpeciality.setHasFixedSize(true);
                rvSearchSpeciality.setNestedScrollingEnabled(false);
                final LinearLayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
                mLayoutManager.setOrientation(RecyclerView.VERTICAL);
                rvSearchSpeciality.setLayoutManager(mLayoutManager);

                SearchProviderListAdapter searchAdapter = new SearchProviderListAdapter(getAppContext(), mGetSpeciality, new SearchProviderListAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClicked(int position, String mSpecialityList) {
                        // Handle Object of list item here
                        svSpeciality.setQuery(mSpecialityList, true);
                        svSpeciality.clearFocus();
                        rvSearchSpeciality.setVisibility(View.GONE);
                        if (mSpecialityList != null) {
                            ProfileDataCache.getInstance().setSearchSpecialityItemValue(mSpecialityList);
                        } else {
                            ProfileDataCache.getInstance().setSearchSpecialityItemValue("");
                        }
                    }
                });
                svSpeciality.clearFocus();
                rvSearchSpeciality.setAdapter(searchAdapter);
                searchAdapter.notifyDataSetChanged();
            } else {
                svSpeciality.clearFocus();
                rvSearchSpeciality.setVisibility(View.GONE);
//                Toast.makeText(getContext(), getString(R.string.no_data_found), Toast.LENGTH_SHORT).show();
                GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.no_search_results));
                svSpeciality.setQuery("", true);
                ProfileDataCache.getInstance().setSearchSpecialityItemValue("");
                getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onHospitalAffiliationResponse(List<PlanList> mGetHospitalAffiliation) {
        try {
            if (mGetHospitalAffiliation != null && mGetHospitalAffiliation.size() > 0) {
                rvSearchHospitalAffiliation.setHasFixedSize(true);
                rvSearchHospitalAffiliation.setNestedScrollingEnabled(false);
                final LinearLayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
                mLayoutManager.setOrientation(RecyclerView.VERTICAL);
                rvSearchHospitalAffiliation.setLayoutManager(mLayoutManager);

                SearchProviderListAdapter searchAdapter = new SearchProviderListAdapter(getAppContext(), mGetHospitalAffiliation, new SearchProviderListAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClicked(int position, String mHospitalityList) {
                        // Handle Object of list item here
                        svHospitalAffiliation.setQuery(mHospitalityList, true);
                        svHospitalAffiliation.clearFocus();
                        rvSearchHospitalAffiliation.setVisibility(View.GONE);
                        if (mHospitalityList != null) {
                            ProfileDataCache.getInstance().setSearchHospitalAffiliationItemValue(mHospitalityList);
                        } else {
                            ProfileDataCache.getInstance().setSearchHospitalAffiliationItemValue("");
                        }
                    }
                });
                svHospitalAffiliation.clearFocus();
                rvSearchHospitalAffiliation.setAdapter(searchAdapter);
                searchAdapter.notifyDataSetChanged();
            } else {
                svHospitalAffiliation.clearFocus();
                rvSearchHospitalAffiliation.setVisibility(View.GONE);
//                Toast.makeText(getContext(), getString(R.string.no_data_found), Toast.LENGTH_SHORT).show();
                GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.no_search_results));
                svHospitalAffiliation.setQuery("", true);
                ProfileDataCache.getInstance().setSearchHospitalAffiliationItemValue("");
                getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onClinicNameResponse(List<PlanList> mGetClinicName) {
        try {
            if (mGetClinicName != null && mGetClinicName.size() > 0) {
                rvSearchClinicName.setHasFixedSize(true);
                rvSearchClinicName.setNestedScrollingEnabled(false);
                final LinearLayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
                mLayoutManager.setOrientation(RecyclerView.VERTICAL);
                rvSearchClinicName.setLayoutManager(mLayoutManager);

                SearchProviderListAdapter searchAdapter = new SearchProviderListAdapter(getAppContext(), mGetClinicName, new SearchProviderListAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClicked(int position, String mClinicList) {
                        // Handle Object of list item here
                        if (mClinicList != null) {
                            svClinicName.setQuery(mClinicList, true);
                            svClinicName.clearFocus();
                            rvSearchClinicName.setVisibility(View.GONE);
                            ProfileDataCache.getInstance().setSearchClinicItemValue(mClinicList);
                        } else {
                            ProfileDataCache.getInstance().setSearchClinicItemValue("");
                        }
                    }
                });
                svClinicName.clearFocus();
                rvSearchClinicName.setAdapter(searchAdapter);
                searchAdapter.notifyDataSetChanged();
            } else {
                svClinicName.clearFocus();
                rvSearchClinicName.setVisibility(View.GONE);
//                Toast.makeText(getContext(), getString(R.string.no_data_found), Toast.LENGTH_SHORT).show();
                GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.no_clinic_name_found));
                svClinicName.setQuery("", true);
                ProfileDataCache.getInstance().setSearchClinicItemValue("");
                getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onAreaExpertiseResponse(List<PlanList> mGetAreaExpertise) {
        try {
            if (mGetAreaExpertise != null && mGetAreaExpertise.size() > 0) {
                rvSearchAreaOfExpertise.setHasFixedSize(true);
                rvSearchAreaOfExpertise.setNestedScrollingEnabled(false);
                final LinearLayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
                mLayoutManager.setOrientation(RecyclerView.VERTICAL);
                rvSearchAreaOfExpertise.setLayoutManager(mLayoutManager);

                SearchProviderListAdapter searchAdapter = new SearchProviderListAdapter(getAppContext(), mGetAreaExpertise, new SearchProviderListAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClicked(int position, String mAreaExpertiseList) {
                        // Handle Object of list item here
                        if (mAreaExpertiseList != null) {
                            svAreaOfExpertise.setQuery(mAreaExpertiseList, true);
                            svAreaOfExpertise.clearFocus();
                            rvSearchAreaOfExpertise.setVisibility(View.GONE);
                            ProfileDataCache.getInstance().setSearchExpertiseItemValue(mAreaExpertiseList);
                        } else {
                            ProfileDataCache.getInstance().setSearchExpertiseItemValue("");
                        }
                    }
                });
                svAreaOfExpertise.clearFocus();
                rvSearchAreaOfExpertise.setAdapter(searchAdapter);
                searchAdapter.notifyDataSetChanged();
            } else {
                svAreaOfExpertise.clearFocus();
                rvSearchAreaOfExpertise.setVisibility(View.GONE);
//                Toast.makeText(getContext(), getString(R.string.no_data_found), Toast.LENGTH_SHORT).show();
                GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.no_area_expertise_found));
                svAreaOfExpertise.setQuery("", true);
                ProfileDataCache.getInstance().setSearchExpertiseItemValue("");
                getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void addItemsOnSpinner1() {
        if (getActivity() == null) {
            return;
        }
        //Creating adapter with member name values and setting to spinner
        List<String> list = ProfileDataCache.getInstance().getLanguageSpokenList();
        if (list == null) {
            list = new ArrayList<>();
        }
        langDataAdapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, list);
        langDataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinLanguage.setAdapter(new NothingSelectedSpinnerAdapter(langDataAdapter, R.layout.language_spoken_spinner_hint, getActivity()));

        //Added selected listener to get the selected data
        spinLanguage.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                try {
                    if (spinLanguage.getSelectedItem() != null) {
                        providerLanguage = spinLanguage.getSelectedItem().toString();
                        if (providerLanguage.equalsIgnoreCase(getActivity().getString(R.string.any_language))) {
                            spinLanguage.setSelection(0);
                            ProfileDataCache.getInstance().setProviderLanguage("");
                        } else {
                            ProfileDataCache.getInstance().setProviderLanguage(providerLanguage);
                        }
                    }
                } catch (Exception e) {
                    Logger.e(StringConstants.EXCEPTION, e);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //Do something
            }
        });
    }

    @Override
    public void onPCPSearchResponse(List<PCPSearchResult> searchResultList) {
        if (searchResultList != null && searchResultList.size() > 0) {
            ProfileDataCache.getInstance().setProvSearchResults(searchResultList.get(0).getRecordCount());
//                Toast.makeText(getContext(), "PCP Search Results: " + searchResultList.get(0).getRecordCount(), Toast.LENGTH_SHORT).show();
            Fragment fragment = new ProviderSearchResults();
            FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
            fragmentManager.beginTransaction().replace(R.id.frame_container, fragment).addToBackStack(null).commit();
            // getActivity().getFragmentManager().popBackStack();
        } else {
            GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.no_search_results));
        }
        cleanUpData();
    }

    private void cleanUpData() {

        svCity.setQuery("", true);
        svSpeciality.setQuery("", true);
        svHospitalAffiliation.setQuery("", true);
        svClinicName.setQuery("", true);
        svAreaOfExpertise.setQuery("", true);
        svCity.clearFocus();
        spinProviderType.setSelection(0);
        edtFirstName.setText("");
        edtLastName.setText("");
        edtGroupName.setText("");
        edtName.setText("");
        checkPCP.setChecked(false);
        spinProviderGender.setSelection(0);
        spinProviderMiles.setSelection(0);
        spinLanguage.setSelection(0);
        chkAcceptingNewPatients.setChecked(false);
        chkBoardCertification.setChecked(false);
        chkUrgentCareFacility.setChecked(false);
        chkExtendedHours.setChecked(false);
        chkAccredited.setChecked(false);
        chkTelemedicine.setChecked(false);
        chkADAAccessibility.setChecked(false);
        ProfileDataCache.getInstance().setProviderLanguage("");
        ProfileDataCache.getInstance().setProvName("");

        /*ProfileDataCache.getInstance().setSearchCityItemValue("");
        ProfileDataCache.getInstance().setSearchSpecialityItemValue("");
        ProfileDataCache.getInstance().setSearchHospitalAffiliationItemValue("");
        ProfileDataCache.getInstance().setSearchClinicItemValue("");
        ProfileDataCache.getInstance().setSearchExpertiseItemValue("");*/

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUnbinder.unbind();
    }
}
