package com.wps.memberapp.presentation.providersearch.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.PCPSearchResult;
import com.wps.memberapp.data.model.Provider;
import com.wps.memberapp.presentation.base.BaseFragment;
import com.wps.memberapp.presentation.providersearch.adapter.ProviderListAdapter;
import com.wps.memberapp.utility.GeneralUtils;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

public class ProviderSearchList extends BaseFragment {

    @BindView(R.id.rv_ProviderSearchList)
    RecyclerView rvProviderSearchList;
    @BindView(R.id.txt_prov_list_results)
    TextView txtProvListResults;
    private Unbinder mUnbinder;
    int position;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        View rootView = inflater.inflate(R.layout.provider_list_fragment, container, false);
        mUnbinder = ButterKnife.bind(this, rootView);
        if (getActivity() != null) {
            ImageView imageViewSearch = getActivity().findViewById(R.id.imageViewSearch);
            imageViewSearch.setVisibility(View.GONE);
            TextView txtDownloadPDF = getActivity().findViewById(R.id.txt_Call);
            txtDownloadPDF.setVisibility(View.GONE);
            TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
            fragmentTitle.setText(R.string.provider_search);
        }
        List<Provider> mSearResult = ProfileDataCache.getInstance().getPcpProviderList();
//        txtProvListResults.setText(String.valueOf(mSearResult.size())+" Provider List");

        position = getArguments().getInt("providerPosition");
        rvProviderSearchList.setHasFixedSize(true);
        final LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        rvProviderSearchList.setLayoutManager(layoutManager);
        if (mSearResult != null) {
            ProviderListAdapter adapter = new ProviderListAdapter(getActivity(), mSearResult);
            rvProviderSearchList.setItemAnimator(new DefaultItemAnimator());
            rvProviderSearchList.setAdapter(adapter);
            adapter.notifyDataSetChanged();
        }
        return rootView;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUnbinder.unbind();
    }
}
