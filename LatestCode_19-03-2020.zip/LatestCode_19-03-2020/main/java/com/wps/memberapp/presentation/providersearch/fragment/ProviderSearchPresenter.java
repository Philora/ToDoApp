package com.wps.memberapp.presentation.providersearch.fragment;

import com.wps.memberapp.presentation.base.MvpPresenter;

interface ProviderSearchPresenter extends MvpPresenter {

    void getExpertPDF();

//    void getPCPSearch();
}

