package com.wps.memberapp.presentation.providersearch.fragment;

import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.base.MvpView;
import com.wps.memberapp.utility.AppConstants;

public class ProviderSearchPresenterImp implements ProviderSearchPresenter{

    private MvpView mView;

    @Override
    public void onAttach(MvpView mView) {
        this.mView = mView;
    }

    @Override
    public void getExpertPDF() {
        mView.showProgress();
        VolleyService.getExpertPDFRequest(mView.getAppContext(), AppConstants.GET_EXPERT_PROVIDER_PDF, new VolleyResponseListener() {
            @Override
            public void onResponse(String response) {
                mView.hideProgress();
                if (response != null) {
                    response = response.replace('"', '@');
                    response = response.replace("@", "");
                    ProfileDataCache.getInstance().setProviderResults(response);
                    String pdfURL = AppConstants.EXPORT_AS_PDF + response;
                    ((ProviderSearchView) mView).onExpertPDFResponse(pdfURL);

                }
            }
            @Override
            public void onError(String error) {
                mView.hideProgress();
            }
        });
    }

    /*@Override
    public void getPCPSearch() {
        mView.showProgress();
        VolleyService.getPCPSearch(mView.getAppContext(), AppConstants.GET_PCP_SEARCH, new VolleyResponseListener() {
            @Override
            public void onResponse(String response) {
                List<PCPSearchResult> searchResultList = new ArrayList<>();
                mView.hideProgress();
                //Processing the response
                if (response != null) {
                    try {
                        Gson gson = new Gson();
                        JSONArray jsonArray = new JSONArray(response);
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            PCPSearchResult mSearchResult = gson.fromJson(jsonObject.toString(), PCPSearchResult.class);

                            mSearchResult.setClinicName(jsonObject.getString("ClinicName"));
                            mSearchResult.setAddress1(jsonObject.getString("Address1"));
                            mSearchResult.setCity(jsonObject.getString("City"));
                            mSearchResult.setState(jsonObject.getString("State"));
                            mSearchResult.setZipCode(jsonObject.getString("ZipCode"));
                            mSearchResult.setClinicWebsite(jsonObject.getString("ClinicWebsite"));
                            mSearchResult.setLatitude(jsonObject.getString("Latitude"));
                            mSearchResult.setLongitude(jsonObject.getString("Longitude"));
                            searchResultList.add(mSearchResult);
                        }
                        ((ProviderSearchView) mView).onPCPSearchResponse(searchResultList);
                    } catch (Exception e) {
                        Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
                    }
                }
            }

            @Override
            public void onError(String error) {
                mView.hideProgress();
            }
        });
    }*/

    @Override
    public void onDetach() {
        mView = null;
    }
}
