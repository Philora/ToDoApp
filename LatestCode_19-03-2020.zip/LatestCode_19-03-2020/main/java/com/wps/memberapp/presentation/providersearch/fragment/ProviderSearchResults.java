package com.wps.memberapp.presentation.providersearch.fragment;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.PCPSearchResult;
import com.wps.memberapp.presentation.base.BaseFragment;
import com.wps.memberapp.presentation.providersearch.activity.ExportsAsPDFActivity;
import com.wps.memberapp.presentation.providersearch.adapter.SearchResultAdapter;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

public class ProviderSearchResults extends BaseFragment implements ProviderSearchView {

    @BindView(R.id.rv_ProviderSearchResults)
    RecyclerView rvProviderSearchResults;
    @BindView(R.id.txt_prov_search_results)
    TextView txtProvSearchResults;
    @BindView(R.id.txt_expert_as_pdf)
    TextView txtExpertAsPdf;
    @BindView(R.id.txt_LastUpdate)
    TextView txtLastUpdate;
    private Unbinder mUnbinder;
    ProviderSearchPresenter providerSearchPresenter;
    private boolean isLoading;
    private int pageID = 1;
    private int scrollPosition = 0;
    private ProgressBar mProgressBar;
    List<PCPSearchResult> mSearResultList;
    private AlertDialog dialog;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        View rootView = inflater.inflate(R.layout.provider_search_results_fragment, container, false);
        mUnbinder = ButterKnife.bind(this, rootView);
        if (getActivity() != null) {
            ImageView imageViewSearch = getActivity().findViewById(R.id.imageViewSearch);
            imageViewSearch.setVisibility(View.GONE);
            TextView txtDownloadPDF = getActivity().findViewById(R.id.txt_Call);
            txtDownloadPDF.setVisibility(View.GONE);
        }
        providerSearchPresenter = new ProviderSearchPresenterImp();
        providerSearchPresenter.onAttach(this);
        mSearResultList = ProfileDataCache.getInstance().getPcpSearchResult();
        txtProvSearchResults.setText(String.valueOf(ProfileDataCache.getInstance().getProvSearchResults()) + " Provider Found");
        mProgressBar = rootView.findViewById(R.id.progressBar);
        rvProviderSearchResults.setHasFixedSize(true);
        final LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        rvProviderSearchResults.setLayoutManager(layoutManager);
        updateSearchResult(mSearResultList);
        String s = "<b>Last Updated:</b> 07/20/2019";
        txtLastUpdate.setText(Html.fromHtml(s));

        txtExpertAsPdf.setOnClickListener(view ->
                providerSearchPresenter.getExpertPDF());

        /*rvProviderSearchResults.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                if (mSearResultList.size() > 9) {
                    int visibleItemCount = layoutManager.getChildCount();
                    int totalItemCount = layoutManager.getItemCount();
                    int pastVisibleItems = layoutManager.findFirstVisibleItemPosition();
                    if (pastVisibleItems + visibleItemCount >= totalItemCount && !isLoading) {
                        isLoading = true;
                        pageID = pageID + 1;
                        scrollPosition = scrollPosition + 10;
                        ProfileDataCache.getInstance().setPageID(pageID);
                        if (getActivity() != null) {
                            if (GeneralUtils.isOnline(getActivity())) {
                                providerSearchPresenter.getPCPSearch();
                            } else {
                                GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.login_no_internet));
                            }
                        } else {
                            mProgressBar.setVisibility(View.GONE);
                            Toast.makeText(getActivity(), "No Data Found", Toast.LENGTH_LONG).show();
                        }
                    }
                }
            }
        });*/

        return rootView;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUnbinder.unbind();
    }

    @Override
    public void onExpertPDFResponse(String response) {
        try {
            if (response != null) {
                //GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.pdf_downloaded_successfully));
                android.app.AlertDialog.Builder alret = new android.app.AlertDialog.Builder(getActivity())
                        .setCancelable(false)
                        .setMessage(getActivity().getString(R.string.pdf_downloaded_successfully))
                        .setPositiveButton(getActivity().getString(R.string.ok), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Intent mIntCustom = new Intent(getActivity(), ExportsAsPDFActivity.class);
                                mIntCustom.putExtra("downloadProviderPDF", response);
                                getActivity().startActivity(mIntCustom);
                            }
                        });
                dialog = alret.create();
                dialog.show();
            }
        } catch (Exception e) {
            e.getLocalizedMessage();
        }

    }

   /* @Override
    public void onPCPSearchResponse(List<PCPSearchResult> searchResultList) {
        if (searchResultList != null && searchResultList.size() > 0) {
            mSearResultList = new ArrayList<>();
            this.mSearResultList.clear();
            this.mSearResultList.addAll(searchResultList);
            updateSearchResult(this.mSearResultList);
        } else {
            showDialogError("", getActivity().getString(R.string.no_records_found));
        }
    }*/

    private void updateSearchResult(@NonNull List<PCPSearchResult> mSearchList) {
        if (mSearchList != null) {
            SearchResultAdapter adapter = new SearchResultAdapter((AppCompatActivity) getActivity(), mSearchList);
            rvProviderSearchResults.setItemAnimator(new DefaultItemAnimator());
            rvProviderSearchResults.setAdapter(adapter);
            adapter.notifyDataSetChanged();
            mProgressBar.setVisibility(View.GONE);
            if (scrollPosition > 0) {
                rvProviderSearchResults.scrollToPosition(scrollPosition - 3);
            }
            isLoading = false;
        }
    }

    private void showDialogError(String title, String string) {
        try {
            AlertDialog.Builder alret = new AlertDialog.Builder(getActivity())
                    .setTitle(title)
                    .setCancelable(false)
                    .setMessage(string)
                    .setPositiveButton(getActivity().getString(R.string.ok), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            /*Fragment fragment = new ProviderSearchFragment();
                            FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                            fragmentManager.beginTransaction().replace(R.id.frame_container, fragment).addToBackStack(null).commit();*/
                            dialog.dismiss();

                        }
                    });
            dialog = alret.create();
            dialog.show();
        } catch (Exception e) {
            Logger.e("ProviderSearch", e);
        }
    }
}
