package com.wps.memberapp.presentation.providersearch.fragment;

import com.wps.memberapp.data.model.PCPSearchResult;

import java.util.List;

interface ProviderSearchView {

   void onExpertPDFResponse(String response);

//    void onPCPSearchResponse(List<PCPSearchResult> searchResultList);
}
