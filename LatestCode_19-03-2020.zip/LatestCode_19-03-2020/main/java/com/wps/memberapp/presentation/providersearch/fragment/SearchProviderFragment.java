package com.wps.memberapp.presentation.providersearch.fragment;

/*import android.app.Activity;
import android.app.FragmentManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.presentation.base.BaseFragment;
import com.wps.memberapp.utility.GeneralUtils;

import java.util.ArrayList;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class SearchProviderFragment extends BaseFragment implements View.OnClickListener,
        AdvanceSearchFragment.DialogCallbackContract, SearchProviderView {

    private RecyclerView rv;
    private String address;
    private String city;
    private String state;
    private String zipCode;
    private static final int FRAGMENT = 1;
    private TextView noData;
    private SearchProviderPresenterImpl searchProviderPresenter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        GeneralUtils.setLanguage(getActivity());

        if (container != null) {
            container.removeAllViews();
            container.clearDisappearingChildren();
        }
        View rootView = inflater.inflate(R.layout.fragment_provider, container, false);
        searchProviderPresenter = new SearchProviderPresenterImpl();
        searchProviderPresenter.onAttach(this);
        TextView addressLabel = rootView.findViewById(R.id.addressLabel);
        TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
        fragmentTitle.setText(R.string.search_physician);
        noData = rootView.findViewById(R.id.nodata);
        if (ProfileDataCache.getInstance().getmMemberDetails() != null) {
            ArrayList<MemberDetails> memberDetail = (ArrayList<MemberDetails>) ProfileDataCache.getInstance().getmMemberDetails();
            if (!memberDetail.isEmpty()) {
                address = memberDetail.get(0).getAddressList().get(0).getAddress1();
                city = memberDetail.get(0).getAddressList().get(0).getCity();
                state = memberDetail.get(0).getAddressList().get(0).getState();
                zipCode = memberDetail.get(0).getAddressList().get(0).getZipCode();
            }
        }
        if (address != null && !address.equals("null")) {
            String addressValue = address + "," + System.getProperty("line.separator") + " " + city + " " + state + " " + zipCode;
            addressLabel.setText(addressValue);
        }
        SharedPreferenceHelper.getInstance().setPreference(getActivity(), "address", address);
        SharedPreferenceHelper.getInstance().setPreference(getActivity(), "state", state);
        SharedPreferenceHelper.getInstance().setPreference(getActivity(), "zipcode", zipCode);
        SharedPreferenceHelper.getInstance().setPreference(getActivity(), "city", city);
        rv = rootView.findViewById(R.id.recyclerProviderView);
        rv.setHasFixedSize(true);
        final LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rv.setLayoutManager(layoutManager);
        View view = getActivity().findViewById(R.id.imageViewSearch);
        view.setVisibility(View.VISIBLE);
        view.setClickable(true);
        view.setOnClickListener(this);
        searchProviderPresenter.getGeolocationDetails();
        return rootView;
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.imageViewSearch) {
            showDialog();
        }
    }

    private void showDialog() {
        FragmentManager fm = getActivity().getFragmentManager();
        AdvanceSearchFragment addDialog = new AdvanceSearchFragment();
        addDialog.setTargetFragment(this, 0);
        addDialog.setListener(this);
        addDialog.show(fm, "dialog");
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FRAGMENT && resultCode == Activity.RESULT_OK) {
            super.onActivityResult(requestCode, resultCode, data);
            // Here the part where we get my selected date from the saved variable in the intent and then displaying it.
            ArrayList<ProviderSearch> providerList = getActivity().getIntent().
                    getParcelableArrayListExtra("ClaimList");
            if (providerList != null && !providerList.isEmpty()) {
                ProviderSearchAdapter adapter = new ProviderSearchAdapter(getActivity(), getActivity(), providerList);
                rv.setItemAnimator(new DefaultItemAnimator());
                rv.setAdapter(adapter);
                adapter.notifyDataSetChanged();
            }
        }
    }

    @Override
    public void returnData(List<ProviderSearch> providerList) {
        updateData(providerList);
    }

    @Override
    public void onGeoLocationCompleted() {
        searchProviderPresenter.getProviderSearchDetails();
    }

    @Override
    public void onProviderSearchCompleted(List<ProviderSearch> providerList) {
        updateData(providerList);
    }

    private void updateData(List<ProviderSearch> providerList) {
        if (providerList != null && !providerList.isEmpty()) {
            ProviderSearchAdapter adapter = new ProviderSearchAdapter
                    (getActivity(), getActivity(), providerList);
            rv.setItemAnimator(new DefaultItemAnimator());
            rv.setAdapter(adapter);
            adapter.notifyDataSetChanged();
        }
        if (providerList != null && providerList.isEmpty()) {
            noData.setVisibility(View.VISIBLE);
        } else {
            noData.setVisibility(View.GONE);
        }
    }
}*/
