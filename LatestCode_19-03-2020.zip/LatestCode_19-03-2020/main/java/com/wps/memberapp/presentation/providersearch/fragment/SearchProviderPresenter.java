package com.wps.memberapp.presentation.providersearch.fragment;

import com.wps.memberapp.presentation.base.MvpPresenter;

interface SearchProviderPresenter extends MvpPresenter {

    void getLanguage();

    void getApplicantsGeoLocation();

    void getSearchCityText();

    void getPCPSearch();

//    void getSearchGroupName(String search_groupName_query);

    void getSearchSpeciality();

    void getSearchHospitalAffiliation();

    void getSearchClinicName();

    void getSearchAreaExpertise();
}
