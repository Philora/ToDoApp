package com.wps.memberapp.presentation.providersearch.fragment;

import android.util.Log;

import com.google.gson.Gson;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.ApplicantGeoLocation;
import com.wps.memberapp.data.model.GetCityCountry;
import com.wps.memberapp.data.model.PCPSearchResult;
import com.wps.memberapp.data.model.PlanList;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.base.MvpView;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class SearchProviderPresenterImp implements SearchProviderPresenter {

    private MvpView mView;

    @Override
    public void onAttach(MvpView mView) {
        this.mView = mView;
    }

    @Override
    public void getLanguage() {
        mView.showProgress();
        VolleyService.getLanguageSpoken(mView.getAppContext(), AppConstants.GET_LANGUAGE_SPOKEN, new VolleyResponseListener() {
            @Override
            public void onResponse(String response) {
                try {
                mView.hideProgress();
                    //Processing the response
                    if (response != null) {
                        try {
                            Gson gson = new Gson();
                            List<PlanList> planList = new ArrayList<>();
                            JSONArray jsonArray = new JSONObject(response).getJSONArray("PlanList");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                PlanList details = gson.fromJson(jsonObject.toString(), PlanList.class);
                                planList.add(details);
                            }
                            ((SearchProviderView) mView).onLanguageResponse(planList);
                        } catch (Exception e) {
                            Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
                        }
                    }
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
            }

            @Override
            public void onError(String error) {
                mView.hideProgress();
            }
        });
    }

    @Override
    public void getApplicantsGeoLocation() {
        VolleyService.getApplicantsLocation(mView.getAppContext(), AppConstants.APPLICANTS_GEO_LOCATION, new VolleyResponseListener() {
            @Override
            public void onResponse(String response) {
                try {
                    //Processing the response
                    Log.i("Claim response", StringConstants.RESPONSE);
                    if (response != null && response.length() > 0) {
                        ApplicantGeoLocation model = new Gson().fromJson(response, ApplicantGeoLocation.class);
                        ProfileDataCache.getInstance().setGeoLat(model.getLatitude());
                        ProfileDataCache.getInstance().setGeoLong(model.getLongitude());
                        ((SearchProviderView) mView).onApplicantLocationResponse(model.getLatitude() + " " + model.getLongitude());
                    }
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
            }

            @Override
            public void onError(String error) {
                mView.hideProgress();
            }
        });
    }

    @Override
    public void getSearchCityText() {
        mView.showProgress();
        VolleyService.getCityCountry(mView.getAppContext(), AppConstants.GET_CITY_COUNTRY, new VolleyResponseListener() {
            @Override
            public void onResponse(String response) {
                mView.hideProgress();
                //Processing the response
                if (response != null) {
                    try {
                        Gson gson = new Gson();
                        List<PlanList> planList = new ArrayList<>();
                        JSONArray jsonArray = new JSONObject(response).getJSONArray("PlanList");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            PlanList details = gson.fromJson(jsonObject.toString(), PlanList.class);
                            planList.add(details);
                        }
                        ((SearchProviderView) mView).onCityResponse(planList);
                    } catch (Exception e) {
                        Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
                    }
                }
            }

            @Override
            public void onError(String error) {
                mView.hideProgress();
            }
        });
    }

    /*@Override
    public void getSearchGroupName(String keyText) {
        mView.showProgress();
        VolleyService.getGroupName(mView.getAppContext(), AppConstants.GET_PRACTICE_GROUP, new VolleyResponseListener() {
            @Override
            public void onResponse(String response) {
                mView.hideProgress();
                //Processing the response
                if (response != null) {
                    try {
                        Gson gson = new Gson();
                        List<PlanList> planList = new ArrayList<>();
                        JSONArray jsonArray = new JSONObject(response).getJSONArray("PlanList");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            PlanList details = gson.fromJson(jsonObject.toString(), PlanList.class);
                            planList.add(details);
                        }
                        ((SearchProviderView) mView).onGroupNameResponse(planList);
                    } catch (Exception e) {
                        Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
                    }
                }
            }

            @Override
            public void onError(String error) {
                mView.hideProgress();
            }
        });
    }*/

    @Override
    public void getSearchSpeciality() {
        mView.showProgress();
        VolleyService.getSpeciality(mView.getAppContext(), AppConstants.GET_SPECIALITY, new VolleyResponseListener() {
            @Override
            public void onResponse(String response) {
                mView.hideProgress();
                //Processing the response
                if (response != null) {
                    try {
                        Gson gson = new Gson();
                        List<PlanList> planList = new ArrayList<>();
                        JSONArray jsonArray = new JSONObject(response).getJSONArray("PlanList");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            PlanList details = gson.fromJson(jsonObject.toString(), PlanList.class);
                            planList.add(details);
                        }
                        ((SearchProviderView) mView).onSpecialityResponse(planList);
                    } catch (Exception e) {
                        Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
                    }
                }
            }

            @Override
            public void onError(String error) {
                mView.hideProgress();
            }
        });
    }

    @Override
    public void getSearchHospitalAffiliation() {
        mView.showProgress();
        VolleyService.getHospitalAffiliation(mView.getAppContext(), AppConstants.GET_HOSPITAL_AFFILIATION, new VolleyResponseListener() {
            @Override
            public void onResponse(String response) {
                mView.hideProgress();
                //Processing the response
                if (response != null) {
                    try {
                        Gson gson = new Gson();
                        List<PlanList> planList = new ArrayList<>();
                        JSONArray jsonArray = new JSONObject(response).getJSONArray("PlanList");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            PlanList details = gson.fromJson(jsonObject.toString(), PlanList.class);
                            planList.add(details);
                        }
                        ((SearchProviderView) mView).onHospitalAffiliationResponse(planList);
                    } catch (Exception e) {
                        Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
                    }
                }
            }

            @Override
            public void onError(String error) {
                mView.hideProgress();
            }
        });
    }

    @Override
    public void getSearchClinicName() {
        mView.showProgress();
        VolleyService.getClinicName(mView.getAppContext(), AppConstants.GET_CLINIC_NAME, new VolleyResponseListener() {
            @Override
            public void onResponse(String response) {
                mView.hideProgress();
                //Processing the response
                if (response != null) {
                    try {
                        Gson gson = new Gson();
                        List<PlanList> planList = new ArrayList<>();
                        JSONArray jsonArray = new JSONObject(response).getJSONArray("PlanList");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            PlanList details = gson.fromJson(jsonObject.toString(), PlanList.class);
                            planList.add(details);
                        }
                        ((SearchProviderView) mView).onClinicNameResponse(planList);
                    } catch (Exception e) {
                        Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
                    }
                }
            }

            @Override
            public void onError(String error) {
                mView.hideProgress();
            }
        });
    }

    @Override
    public void getSearchAreaExpertise() {
        mView.showProgress();
        VolleyService.getAreaExpertise(mView.getAppContext(), AppConstants.GET_AREA_OF_EXPERTISE, new VolleyResponseListener() {
            @Override
            public void onResponse(String response) {
                mView.hideProgress();
                //Processing the response
                if (response != null) {
                    try {
                        Gson gson = new Gson();
                        List<PlanList> planList = new ArrayList<>();
                        JSONArray jsonArray = new JSONObject(response).getJSONArray("PlanList");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            PlanList details = gson.fromJson(jsonObject.toString(), PlanList.class);
                            planList.add(details);
                        }
                        ((SearchProviderView) mView).onAreaExpertiseResponse(planList);
                    } catch (Exception e) {
                        Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
                    }
                }
            }

            @Override
            public void onError(String error) {
                mView.hideProgress();
            }
        });
    }

    @Override
    public void getPCPSearch() {
        mView.showProgress();
        VolleyService.getPCPSearch(mView.getAppContext(), AppConstants.GET_PCP_SEARCH, new VolleyResponseListener() {
            @Override
            public void onResponse(String response) {
                List<PCPSearchResult> searchResultList = new ArrayList<>();
                mView.hideProgress();
                //Processing the response
                if (response != null) {
                    try {
                        Gson gson = new Gson();
                        JSONArray jsonArray = new JSONArray(response);
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            PCPSearchResult mSearchResult = gson.fromJson(jsonObject.toString(), PCPSearchResult.class);
                            searchResultList.add(mSearchResult);
                        }
                        ProfileDataCache.getInstance().setPcpSearchResult(searchResultList);
                        ((SearchProviderView) mView).onPCPSearchResponse(searchResultList);
                    } catch (Exception e) {
                        Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
                    }
                }
            }

            @Override
            public void onError(String error) {
                mView.hideProgress();
            }
        });
    }


    @Override
    public void onDetach() {
        mView = null;
    }
}
