package com.wps.memberapp.presentation.providersearch.fragment;

import com.wps.memberapp.data.model.PCPSearchResult;
import com.wps.memberapp.data.model.PlanList;
import com.wps.memberapp.presentation.base.MvpView;

import java.util.List;

interface SearchProviderView extends MvpView {

    void onCityResponse(List<PlanList> mGetCityCountry);

    void onLanguageResponse(List<PlanList> mGetLanguage);

    void onSpecialityResponse(List<PlanList> mGetSpeciality);

    void onHospitalAffiliationResponse(List<PlanList> mGetHospitalAffiliation);

    void onPCPSearchResponse(List<PCPSearchResult> searchResultList);

    void onApplicantLocationResponse(String s);

    void onClinicNameResponse(List<PlanList> planList);

    void onAreaExpertiseResponse(List<PlanList> planList);

    //  void onGroupNameResponse(List<PlanList> planList);
}