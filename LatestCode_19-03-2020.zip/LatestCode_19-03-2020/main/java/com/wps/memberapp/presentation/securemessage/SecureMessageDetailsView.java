package com.wps.memberapp.presentation.securemessage;


import com.wps.memberapp.presentation.base.MvpView;

import org.json.JSONObject;

/**
 * This interface contain UI functions of secure message details screen
 */
public interface SecureMessageDetailsView extends MvpView {

    void onDetailsLoadingCompleted(JSONObject jsonObject);
}
