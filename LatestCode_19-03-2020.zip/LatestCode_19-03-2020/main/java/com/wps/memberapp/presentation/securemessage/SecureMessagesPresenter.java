package com.wps.memberapp.presentation.securemessage;


import com.wps.memberapp.presentation.base.MvpPresenter;

/**
 * This interface contain all the Secure Messages functionality declarations.
 */
public interface SecureMessagesPresenter extends MvpPresenter {
    void getSecureMessages();

    void getSecureMessageDetails();

    void getSecureMessageProvider();

    void getSecureMessageProviderPCP();

    void getMessageSubject();
}
