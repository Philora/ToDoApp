package com.wps.memberapp.presentation.securemessage;

import android.annotation.TargetApi;
import android.os.Build;
import android.util.Log;

import com.google.gson.Gson;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.GetSecureMessagesProvider;
import com.wps.memberapp.data.model.MasterData;
import com.wps.memberapp.data.model.SecureMessage;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.base.MvpView;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used to implement all the Secure Messages functions
 * which are declared in SecureMessagesPresenter.
 */
public class SecureMessagesPresenterImpl implements SecureMessagesPresenter {

    private MvpView view;

    /*
     * Used to call web service for SecureMessages and get response as JSON
     * using post method and to plot the horizontal bar chart
     */
    @Override
    public void getSecureMessages() {
        //Used to display infinite progress dilog
        //Used to send the API request to get all the secure messages
        VolleyService.getSecureMessages(view.getAppContext(),
                AppConstants.GET_SECURE_MESSAGES, new VolleyResponseListener() {
                    @Override
                    public void onError(String error) {
                        view.hideProgress();
//                        Log.i("Error_SecureMessage", error);
                    }

                    @TargetApi(Build.VERSION_CODES.KITKAT)
                    @Override
                    public void onResponse(String response) {
//                        Log.i("Success_SecureMessage", response);
                        //Processing the response
                        view.hideProgress();
                        if (response != null) {
                            try {
                                Gson gson = new Gson();
                                List<SecureMessage> listObjects = new ArrayList<>();

                                JSONArray jsonArray = new JSONArray(response);
                                for (int i = 0; i < jsonArray.length(); i++) {

                                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                                    SecureMessage feed = gson.fromJson(jsonObject.toString(), SecureMessage.class);
                                    if (feed != null) {
                                        listObjects.add(feed);
                                    }
                                }
                                ((SecureMessagesView) view).onSecureMessagesLoadingCompleted(listObjects);
                            } catch (Exception e) {
                                Logger.e(StringConstants.EXCEPTION, e);
                            }
                        }
                    }
                });
    }

    /*
    This method is used to send the API request to get the details of secure message
     */
    @Override
    public void getSecureMessageDetails() {
        //Used to display the progress dialog
        view.showProgress();
        //Sending the API request to get the details of secure message
        VolleyService.getSecureMessageDetail(view.getAppContext(),
                AppConstants.GET_SECURE_MESSAGE_DETAILS, new VolleyResponseListener() {
                    @Override
                    public void onError(String error) {
                        try {
                            view.hideProgress();
//                            Log.i("Error_SecureMsgDetail", error);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    }

                    @TargetApi(Build.VERSION_CODES.KITKAT)
                    @Override
                    public void onResponse(String response) {
//                        Log.i("Success_SecureMsgDetail", response);
                        view.hideProgress();
                        //Processing the received response
                        if (response != null) {
                            try {
                                JSONObject jsonObject = new JSONObject(response);
                                ((SecureMessageDetailsView) view).onDetailsLoadingCompleted(jsonObject);
                            } catch (Exception e) {
                                Logger.e("Exception", e);
                            }
                        }
                    }
                });

    }

    @Override
    public void getMessageSubject() {
        VolleyService.getSecureMessageSubjects(view.getAppContext(), AppConstants.GET_SECURE_MESSAGE_SUBJECTS, new VolleyResponseListener() {
            @Override
            public void onResponse(String response) {
                try {
                    //Processing the response
                    if (response != null) {
                        try {
                            JSONArray array = new JSONArray(response);
                            List<MasterData> mSecMsgList = new ArrayList<>();
                            for (int j = 0; j < array.length(); j++) {
                                JSONObject jsonObject = array.getJSONObject(j);
                                JSONArray arrayVaccine = jsonObject.getJSONArray("MasterData");
                                for (int i = 0; i < arrayVaccine.length(); i++) {
                                    MasterData mCodeVal = new MasterData();
                                    JSONObject jsonVaccine = arrayVaccine.getJSONObject(i);
                                    String prov = jsonVaccine.getString("Description");
                                    mCodeVal.setCode(prov);
                                    mSecMsgList.add(mCodeVal);
                                }
                                ((SecureMessagesView) view).onSubjectResponse(mSecMsgList);
                            }

                        } catch (Exception e) {
                            Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
                        }
                    }
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
            }

            @Override
            public void onError(String error) {
                view.hideProgress();
            }
        });
    }

    @Override
    public void getSecureMessageProvider() {
        //Sending the API request to get the details of secure message
        VolleyService.getSecureMessageProvider(view.getAppContext(),
                AppConstants.SECURE_MESSAGE_PROVIDER, new VolleyResponseListener() {
                    @Override
                    public void onError(String error) {
                        try {
                            view.hideProgress();
//                            Log.i("Error_SecureMsgProvErr", error);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    }

                    @TargetApi(Build.VERSION_CODES.KITKAT)
                    @Override
                    public void onResponse(String response) {
//                        Log.i("Success_SecureMsgProv", response);
                        view.hideProgress();
                        //Processing the received response
                        if (response != null && response.length() > 0) {
                            try {
                                Gson gson = new Gson();
                                JSONArray jsonArray = new JSONArray(response);
                                List<GetSecureMessagesProvider> msgProviderList = new ArrayList<>();
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                                    GetSecureMessagesProvider messagesProvider = gson.fromJson(jsonObject.toString(), GetSecureMessagesProvider.class);
                                    msgProviderList.add(messagesProvider);
                                }
                                ((SecureMessagesView) view).onSecureMessageProvider(msgProviderList);
                            } catch (Exception e) {
                                Logger.e("Exception", e);
                            }
                        }
                    }
                });
    }

    @Override
    public void getSecureMessageProviderPCP() {
        //Sending the API request to get the details of secure message
        VolleyService.getSecureMessageProviderPCP(view.getAppContext(),
                AppConstants.SECURE_MESSAGE_PROV_PCP, new VolleyResponseListener() {
                    @Override
                    public void onError(String error) {
                        try {
                            view.hideProgress();
//                            Log.i("Error_SecureMsgError", error);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    }

                    @TargetApi(Build.VERSION_CODES.KITKAT)
                    @Override
                    public void onResponse(String response) {
//                        Log.i("Success_SecureMsgRes", response);
                        view.hideProgress();
                        //Processing the received response
                        if (response != null && response.length() > 0) {
                            try {
                                Gson gson = new Gson();
                                JSONArray jsonArray = new JSONArray(response);
                                List<GetSecureMessagesProvider> msgProviderList = new ArrayList<>();
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                                    GetSecureMessagesProvider messagesProvider = gson.fromJson(jsonObject.toString(), GetSecureMessagesProvider.class);
                                    msgProviderList.add(messagesProvider);
                                }
                                ((SecureMessagesView) view).onSecureMessageProviderPCP(msgProviderList);
                            } catch (Exception e) {
                                Logger.e("Exception", e);
                            }
                        }
                    }
                });
    }

    @Override
    public void onAttach(MvpView view) {
        this.view = view;
    }

    @Override
    public void onDetach() {
        view = null;
    }
}
