package com.wps.memberapp.presentation.securemessage;

import com.wps.memberapp.data.model.GetSecureMessagesProvider;
import com.wps.memberapp.data.model.MasterData;
import com.wps.memberapp.data.model.SecureMessage;
import com.wps.memberapp.presentation.base.MvpView;

import org.json.JSONObject;

import java.util.List;

/**
 * This interface contain UI functions of Secure Messages screen
 */
public interface SecureMessagesView extends MvpView {
    void onSecureMessagesLoadingCompleted(List<SecureMessage> secureMessageList);

    void onSecureMessageProvider(List<GetSecureMessagesProvider> messagesProvider);

    void onSecureMessageProviderPCP(List<GetSecureMessagesProvider> messagesProvider);

    void onSubjectResponse(List<MasterData> messageSubject);

}
