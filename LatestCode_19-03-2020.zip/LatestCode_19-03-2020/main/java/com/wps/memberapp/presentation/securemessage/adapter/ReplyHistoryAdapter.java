package com.wps.memberapp.presentation.securemessage.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.model.MessageResponseList;
import com.wps.memberapp.utility.ReminderAlertDialog;
import com.wps.memberapp.utility.StringConstants;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


public class ReplyHistoryAdapter extends RecyclerView.Adapter<ReplyHistoryAdapter.ProductViewHolder> {

    //This context will be used to inflate the layout

    private final Context mCtx;
    String submittedDate;
    private final Activity activity;
    //We are storing all the product in a list
    private final List<MessageResponseList> replyHistList;
//    MedicationPresenter replyHistPresenter;

    //getting the context and product list with constructor
    public ReplyHistoryAdapter(Context mCtx, Activity activity, List<MessageResponseList> replyHistList, String submittedDate) {
        this.mCtx = mCtx;
        this.replyHistList = replyHistList;
        this.activity = activity;
        this.submittedDate = submittedDate;
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.fragment_reply_history, parent, false);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, final int position) {
        try {
            if (replyHistList != null && !replyHistList.isEmpty() && !replyHistList.equals("")) {
                MessageResponseList mReplyHistList = replyHistList.get(position);
                String mFirstName = mReplyHistList.getResponseUser().getFNAME();
                String mLastName = mReplyHistList.getResponseUser().getLNAME();
                if (mFirstName != null && !mFirstName.equalsIgnoreCase("") && !mFirstName.isEmpty() && (mLastName != null && !mLastName.equalsIgnoreCase("") && !mLastName.isEmpty())) {
                    holder.txtReplyBy.setText(mFirstName + StringConstants.SPACE_SINGLE + mLastName);
                }
                if (submittedDate != null && !submittedDate.equalsIgnoreCase("") && !submittedDate.isEmpty()) {
                    String[] submitDate = submittedDate.split(" ", 2);
                    String mSubmitDate = submitDate[0];
                    holder.txtSubmissionDate.setText(mSubmitDate);
                } else {
                    holder.txtSubmissionDate.setText("");
                }
                if (mReplyHistList.getResponseDate() != null && !mReplyHistList.getResponseDate().equalsIgnoreCase("") && !mReplyHistList.getResponseDate().isEmpty()) {
                    String[] lastActivityDate = mReplyHistList.getResponseDate().split(" ", 2);
                    String mlastActivityDate = lastActivityDate[0];
                    holder.txtLastActivityDate.setText(mlastActivityDate);
                }
                if (mReplyHistList.getSEQ() != null && !mReplyHistList.getSEQ().equalsIgnoreCase("") && !mReplyHistList.getSEQ().isEmpty()) {
                    holder.txtSeq.setText(mReplyHistList.getSEQ());
                }
                if (mReplyHistList.getResponseText() != null && !mReplyHistList.getResponseText().equalsIgnoreCase("") && !mReplyHistList.getResponseText().isEmpty()) {
                    holder.txtReplyHistory.setText(mReplyHistList.getResponseText());
                }
            }
        } catch (Exception e) {
            e.getLocalizedMessage();
        }

        /*
        int position = 0;
                if (!responseMessageList.isEmpty() && responseMessageList.get(position).getResponseText() != null && responseMessageList.get(position)
                        .getResponseDate() != null) {
                    replyMessageSubjectViewDetails.setText(responseMessageList.get(position).getResponseText());

                    if (submittedDate != null) {
                        String[] s = submittedDate.split(" ", 2);
                        String date = s[0];
                        txt_SubmissionDate.setText(date);
                    }
                    if (lastActivityDate != null) {
                        String[] s = lastActivityDate.split(" ", 2);
                        String date = s[0];
                        txtLastActivityDate.setText(date);
                    }
                }
         */
    }

    @Override
    public int getItemCount() {
        if (replyHistList != null)
            return replyHistList.size();
        else
            return 0;
    }

    class ProductViewHolder extends RecyclerView.ViewHolder {

        TextView txtReplyBy;
        TextView txtSeq;
        TextView txtSubmissionDate;
        TextView txtLastActivityDate;
        TextView txtReplyHistory;


        ProductViewHolder(View itemView) {
            super(itemView);
            txtReplyBy = itemView.findViewById(R.id.txt_ReplyBy);
            txtSeq = itemView.findViewById(R.id.txt_Seq);
            txtSubmissionDate = itemView.findViewById(R.id.txt_SubmissionDate);
            txtLastActivityDate = itemView.findViewById(R.id.txt_LastActivityDate);
            txtReplyHistory = itemView.findViewById(R.id.txt_ReplyHistory);
        }
    }

    private void showDialog() {
//        replyHistPresenter.getReminder();
        ReminderAlertDialog newFragment = ReminderAlertDialog.newInstance();
        newFragment.show(activity.getFragmentManager(), "Title");
    }
}


