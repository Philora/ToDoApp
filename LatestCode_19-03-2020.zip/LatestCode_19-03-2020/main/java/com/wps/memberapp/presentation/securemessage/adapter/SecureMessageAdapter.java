package com.wps.memberapp.presentation.securemessage.adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.VolleyError;
import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.SecureMessage;
import com.wps.memberapp.domain.dataservice.VolleyByteResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.providersearch.activity.ExportsAsPDFActivity;
import com.wps.memberapp.presentation.securemessage.fragment.SecureMessageDetailViewFragment;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import static com.wps.memberapp.utility.GeneralUtils.hideProgress;
import static com.wps.memberapp.utility.GeneralUtils.showProgress;
import static org.webrtc.ContextUtils.getApplicationContext;

/**
 * This class is used to create adapter to show secure messages list in recycle view
 */
public class SecureMessageAdapter extends RecyclerView.Adapter<SecureMessageAdapter.ProviderViewHolder> {

    //Member variables
    private final Context mCtx;
    private final AppCompatActivity activity;
    //We are storing all the product in a list
    private final List<SecureMessage> secureMessageList;
    private static String mFileAttachment;
    private AlertDialog dialog;

    public SecureMessageAdapter(Context applicationContext, AppCompatActivity activity, List<SecureMessage> providerSearch) {
        this.mCtx = applicationContext;
        this.secureMessageList = providerSearch;
        this.activity = activity;
    }

    /*
    This method is used to create the view holder by using layout
     */
    @NonNull
    @Override
    public ProviderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.fragment_secure_message_list_view, parent, false);
        return new ProviderViewHolder(view);
    }

    /*
   Binding data to ViewHolder class object based on the position.
   */
    @Override
    public void onBindViewHolder(@NonNull ProviderViewHolder holder, final int position) {
        if (secureMessageList != null && !secureMessageList.isEmpty()) {

            //Binding the data with the viewHolder views
            final SecureMessage secureDetails = secureMessageList.get(position);
           /* if (secureDetails.getSenderFirstName() != null && secureDetails.getSenderFirstName().length() > 0 && !secureDetails.getSenderFirstName().equals("null")
                    && secureDetails.getSenderLastName() != null && secureDetails.getSenderLastName().length() > 0 && !secureDetails.getSenderLastName().equals("null")) {
                String name = secureDetails.getSenderFirstName() + " " + secureDetails.getSenderLastName() + " " + "to" + " ";
                holder.textViewTitle.setText(name);
            }*/

            if (secureDetails.getLastActivityDate() != null && !secureDetails.getLastActivityDate().equalsIgnoreCase("null") && !secureDetails.getLastActivityDate().isEmpty() && secureDetails.getLastActivityDate().length() > 0) {
                String mainDateString = secureDetails.getLastActivityDate();
                String[] s = mainDateString.split(" ", 2);
                String date = s[0];
                holder.lastActivityValue.setText(date);
            }
            if (secureDetails.getSent_ReceiveDate() != null && !secureDetails.getSent_ReceiveDate().equalsIgnoreCase("null") && !secureDetails.getSent_ReceiveDate().isEmpty() && secureDetails.getSent_ReceiveDate().length() > 0) {
                String submittedDateString = secureDetails.getSent_ReceiveDate();
                String[] s1 = submittedDateString.split(" ", 2);
                String submittedDate = s1[0];
                holder.submissionDateValue.setText(submittedDate);
            }
            if (secureDetails.getStatus() != null && !secureDetails.getStatus().equalsIgnoreCase("null") && !secureDetails.getStatus().isEmpty() && secureDetails.getStatus().length() > 0) {
                holder.statusTextView.setText(secureDetails.getStatus());
            }

            if (secureDetails.getMsgType() != null && !secureDetails.getMsgType().equalsIgnoreCase("null") && !secureDetails.getMsgType().isEmpty() && secureDetails.getMsgType().length() > 0) {
                holder.messageTypeValue.setText(secureDetails.getMsgType());
            }

            if (secureDetails.getSubject() != null && !secureDetails.getSubject().equalsIgnoreCase("null") && !secureDetails.getSubject().isEmpty() && secureDetails.getSubject().length() > 0) {
                holder.subjectLabel.setText(secureDetails.getSubject());
            }

            if (secureDetails.getMessageID() != null && !secureDetails.getMessageID().equalsIgnoreCase("null") && !secureDetails.getMessageID().isEmpty() && secureDetails.getMessageID().length() > 0) {
                holder.referenceTextView.setText(secureDetails.getMessageID());
            }
            if (secureDetails.getGeneratedfileName() != null && !secureDetails.getGeneratedfileName().equalsIgnoreCase("null") && !secureDetails.getGeneratedfileName().isEmpty() && secureDetails.getGeneratedfileName().length() > 0) {
                holder.imgAttachment.setVisibility(View.VISIBLE);
            } else {
                holder.imgAttachment.setVisibility(View.GONE);
            }
            holder.cardView.setOnClickListener(view -> openDetails(secureDetails));
            holder.imgAttachment.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                        showProgress(mCtx);
                        mFileAttachment = secureDetails.getGeneratedfileName();
                        downloadAttachMentDocs(mFileAttachment);
                    } catch (Exception e) {
                        e.getLocalizedMessage();
                    }
                }
            });
        }
    }

    private void downloadAttachMentDocs(String mDownloadAttachment) {
        String mReqURL = AppConstants.DOWNLOAD_SECURE_MESSAGE_ATTACHMENT + mDownloadAttachment; // application/vnd.openxmlformats-officedocument.spreadsheetml.sheet
//        Toast.makeText(mCtx, "Request URL! " + mReqURL, Toast.LENGTH_SHORT).show();
        VolleyService.getSecureMessageAttachment(mCtx, AppConstants.DOWNLOAD_SECURE_MESSAGE_ATTACHMENT + mDownloadAttachment, new VolleyByteResponseListener() {
            @Override
            public void onResponse(byte[] response) {
                try {
                    Log.i("PDF Response", String.valueOf(response));
                    convertBytesToPDF(response);
                    hideProgress();
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
            }

            @Override
            public void onError(VolleyError error) {
                hideProgress();
                try {
//                    Toast.makeText(getApplicationContext(), "Download failed", Toast.LENGTH_LONG).show();
                    GeneralUtils.showAlertDialog(activity, activity.getString(R.string.download_failed));
                } catch (Exception e) {
                    Toast.makeText(activity, "Exception - Download failed", Toast.LENGTH_LONG).show();
                    Logger.e(StringConstants.EXCEPTION, e);
                }
            }
        });
    }

    private void convertBytesToPDF(byte[] response) {
        try {
            File folder = new File(Environment.getExternalStorageDirectory() + "/SecureMessage/");
            folder.mkdir();
            File pdfFile = new File(folder, mFileAttachment);
            FileOutputStream fos = new FileOutputStream(pdfFile);
            fos.write(response);
            if (!pdfFile.exists()) {
                pdfFile.createNewFile();
            }
            fos.close();
            android.app.AlertDialog.Builder alret = new android.app.AlertDialog.Builder(mCtx)
                    .setCancelable(false)
                    .setTitle(mCtx.getString(R.string.download_completed))
                    .setMessage("Path:/InternalStorage/SecureMessage/" + mFileAttachment)
                    .setPositiveButton(mCtx.getString(R.string.ok), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialog.dismiss();
                        }
                    });
            dialog = alret.create();
            dialog.show();
        } catch (Exception e) {
            System.out.println("Exception: " + e);
            e.getLocalizedMessage();
        }
    }

    /*
    This method is used to get the items size in array list
    */
    @Override
    public int getItemCount() {
        if (secureMessageList != null) {
            return secureMessageList.size();
        } else {
            return 0;
        }
    }

    /*
      View Holder class to bind the data to views and will improve the performance.
    */
    class ProviderViewHolder extends RecyclerView.ViewHolder {

        final TextView textViewTitle;
        final TextView messageTypeValue;
        final TextView lastActivityValue;
        final TextView submissionDateValue;
        final TextView statusTextView;
        final TextView subjectLabel;
        final TextView referenceTextView;
        final ImageView imgAttachment;
        final CardView cardView;


        private ProviderViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.secureMessageCardView);
            textViewTitle = itemView.findViewById(R.id.nameLabel);
            messageTypeValue = itemView.findViewById(R.id.messageTypeValue);
            lastActivityValue = itemView.findViewById(R.id.lastActivityValue);
            submissionDateValue = itemView.findViewById(R.id.submissionDateValue);
            statusTextView = itemView.findViewById(R.id.statusTextView);
            subjectLabel = itemView.findViewById(R.id.subjectLabel);
            subjectLabel.setSelected(true);
            referenceTextView = itemView.findViewById(R.id.referenceTextView);
            imgAttachment = itemView.findViewById(R.id.img_Attachment);
        }
    }

    /*
    This method is used to update the view with secure message details
     */
    private void openDetails(SecureMessage secureDetails) {
        SecureMessageDetailViewFragment secureMessageDetailView = new SecureMessageDetailViewFragment();
        Bundle args = new Bundle();
        ProfileDataCache.getInstance().setHashCode(secureDetails.getHashCode());
        if (secureDetails.getStatus() != null && !secureDetails.getStatus().equalsIgnoreCase("null") && !secureDetails.getStatus().isEmpty() && secureDetails.getStatus().length() > 0) {
            args.putString("status", secureDetails.getStatus());
        }
        if (secureDetails.getEncryptMsgId() != null && !secureDetails.getEncryptMsgId().equalsIgnoreCase("null") && !secureDetails.getEncryptMsgId().isEmpty() && secureDetails.getEncryptMsgId().length() > 0) {
            args.putString("encryptMsgId", secureDetails.getEncryptMsgId());
            ProfileDataCache.getInstance().setMsgID(secureDetails.getEncryptMsgId());
        }
        if (secureDetails.getMessageID() != null && !secureDetails.getMessageID().equalsIgnoreCase("null") && !secureDetails.getMessageID().isEmpty() && secureDetails.getMessageID().length() > 0) {
            args.putString("messageId", secureDetails.getMessageID());
        }
        if (secureDetails.getLastActivityDate() != null && !secureDetails.getLastActivityDate().equalsIgnoreCase("null") && !secureDetails.getLastActivityDate().isEmpty() && secureDetails.getLastActivityDate().length() > 0) {
            args.putString("lastActivityDate", secureDetails.getLastActivityDate());
        }
        if (secureDetails.getSent_ReceiveDate() != null && !secureDetails.getSent_ReceiveDate().equalsIgnoreCase("null") && !secureDetails.getSent_ReceiveDate().isEmpty() && secureDetails.getSent_ReceiveDate().length() > 0) {
            args.putString("submittedDate", secureDetails.getSent_ReceiveDate());
        }
        if (secureDetails.getSubject() != null && !secureDetails.getSubject().equalsIgnoreCase("null") && !secureDetails.getSubject().isEmpty() && secureDetails.getSubject().length() > 0) {
            args.putString("subject", secureDetails.getSubject());
        }
        if (secureDetails.getSubscriberId() != null && !secureDetails.getSubscriberId().equalsIgnoreCase("null") && !secureDetails.getSubscriberId().isEmpty() && secureDetails.getSubscriberId().length() > 0) {
            args.putString("subscriberId", secureDetails.getSubscriberId());
        }
        if (secureDetails.getMsgType() != null && !secureDetails.getMsgType().equalsIgnoreCase("null") && !secureDetails.getMsgType().isEmpty() && secureDetails.getMsgType().length() > 0) {
            args.putString("MsgType", secureDetails.getMsgType());
        }
        secureMessageDetailView.setArguments(args);
        activity.getSupportFragmentManager().beginTransaction().
                replace(R.id.frame_container, secureMessageDetailView).addToBackStack(null).commit();
    }
}
