package com.wps.memberapp.presentation.securemessage.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MemberEligibleInfo;
import com.wps.memberapp.data.model.MessageData;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.claims.adapter.NothingSelectedSpinnerAdapter;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import java.util.Arrays;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * This class is used to compose new message to respected user
 */

public class ComposeFragment extends Fragment {

    //Declaring member variables
    @BindView(R.id.spinner)
    Spinner spinner;

    @BindView(R.id.spin_MessageType)
    Spinner spinMessageType;

    @BindView(R.id.spin_Providername)
    Spinner spinProvidername;

    @BindView(R.id.txt_ProvPCPName)
    TextView txtProvPCPName;

    @BindView(R.id.editText)
    EditText editText;

    @BindView(R.id.icon_send)
    ImageView imageView;

    @BindView(R.id.icon_upload)
    ImageView uploadIV;

    @BindView(R.id.fromLabel)
    TextView fromLabel;

    @BindView(R.id.toLabel)
    TextView toLabel;

    @BindView(R.id.subId)
    TextView subId;
    private String editTxtValue;
    @NonNull
    private String subject = "";
    private static final String DEFAULT_SUBJECT = "Subject";
    private Unbinder unbinder;
    private MemberEligibleInfo info;
    private String messageType = "";
    private String providerName = "";

    /**
     * This override method is used to inflate the layout for Dashboard fragment
     *
     * @return rootView
     */
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        View rootView = inflater.inflate(R.layout.fragment_compose_message, container, false);
        unbinder = ButterKnife.bind(this, rootView);
        //Inflating views from XML layout
        if (getActivity() != null) {
            ImageView imageViewSearch = getActivity().findViewById(R.id.imageViewSearch);
            imageViewSearch.setVisibility(View.GONE);
            TextView txtDownloadPDF = getActivity().findViewById(R.id.txt_Call);
            txtDownloadPDF.setVisibility(View.GONE);
            TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
            fragmentTitle.setText(R.string.compose_message);
        }
        info = ProfileDataCache.getInstance().getMemberEligibleInfo();
        if (info != null) {
            String id = getString(R.string.subid_colon) + StringConstants.SPACE_SINGLE + info.getSubscriberID();
            subId.setText(id);
        }
        spinner.setPadding(0, spinner.getPaddingTop(), spinner.getPaddingRight(), spinner.getPaddingBottom());
//        String name = ProfileDataCache.getInstance().getMessageBy();
        String name = ProfileDataCache.getInstance().getFirstName() + StringConstants.SPACE_SINGLE + ProfileDataCache.getInstance().getLastName();
        name = getString(R.string.msg_by) + StringConstants.SPACE_SINGLE + name;
        fromLabel.setText(name);
        toLabel.setText(getString(R.string.message_type_csr));
        addItemsOnSpinner1();
        uploadIV.setOnClickListener(view -> {
            Intent intentPDF = new Intent(Intent.ACTION_GET_CONTENT);
            intentPDF.setType("application/*");
            intentPDF.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(Intent.createChooser(intentPDF, "ChooseFile"), 1);
        });
        List<String> list = Arrays.asList(getActivity().getResources().getStringArray(R.array.message_type));
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(getActivity(),
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinMessageType.setAdapter(new NothingSelectedSpinnerAdapter(
                dataAdapter,
                R.layout.message_type_spinner_hint,
                // R.layout.contact_spinner_nothing_selected_dropdown, // Optional
                getActivity()));

        spinMessageType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                try {
                    if (spinMessageType.getSelectedItem() != null) {
                        messageType = spinMessageType.getSelectedItem().toString();
                        if (messageType.equalsIgnoreCase("CSR Message")) {
                            messageType = "1";
                            spinProvidername.setVisibility(View.GONE);
                            txtProvPCPName.setVisibility(View.GONE);
                        } else if (messageType.equalsIgnoreCase("Disease Mgmt Enrollment Request")) {
                            messageType = "2";
                            spinProvidername.setVisibility(View.GONE);
                            txtProvPCPName.setVisibility(View.GONE);
                        } else if (messageType.equalsIgnoreCase("PCP Message")) {
                            messageType = "3";
                            spinProvidername.setVisibility(View.GONE);
                            txtProvPCPName.setVisibility(View.VISIBLE);
                            String mProviderName = ProfileDataCache.getInstance().getSecMessagesProviderPCP().get(0);
                            String mProId = ProfileDataCache.getInstance().getSecMessagesProviderId().get(0);
                            txtProvPCPName.setText(getActivity().getString(R.string.provider_name_colon) + mProviderName);
                            if(mProId!=null){
                                ProfileDataCache.getInstance().setProvId(mProId);
                            }
                        } else if (messageType.equalsIgnoreCase("Provider Message")) {
                            messageType = "4";
                            txtProvPCPName.setVisibility(View.GONE);
                            spinProvidername.setVisibility(View.VISIBLE);
                        }
                        spinMessageType.setSelected(true);
                        ProfileDataCache.getInstance().setTypeID(messageType);
                    }
                } catch (Exception e) {
                    Logger.e(StringConstants.EXCEPTION, e);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //Do something
            }
        });

        List<String> listProvider = ProfileDataCache.getInstance().getSecMessagesProvider();
        if (listProvider != null && list.size() > 0) {
            ArrayAdapter<String> dataProvAdapter = new ArrayAdapter<>(getActivity(),
                    android.R.layout.simple_spinner_item, listProvider);
            dataProvAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinProvidername.setAdapter(new NothingSelectedSpinnerAdapter(
                    dataProvAdapter,
                    R.layout.providername_spinner_hint,
                    // R.layout.contact_spinner_nothing_selected_dropdown, // Optional
                    getActivity()));
        }
        spinProvidername.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int pos, long l) {
                try {
                    if (spinProvidername.getSelectedItem() != null) {
                        providerName = spinProvidername.getSelectedItem().toString();
                        for (int i = 0; i < listProvider.size(); i++) {
                            if (spinProvidername.getSelectedItem() == listProvider.get(i)) {
                                String mProId = ProfileDataCache.getInstance().getSecMessagesProviderId().get(i);
                                ProfileDataCache.getInstance().setProvId(mProId);
                            }
                        }
                        spinProvidername.setSelected(true);
                    }

                } catch (Exception e) {
                    Logger.e(StringConstants.EXCEPTION, e);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        //Setting on click listener to send button to send the msg when user clicked
        imageView.setOnClickListener(view -> {
            editTxtValue = editText.getText().toString().trim();
            if (!spinMessageType.isSelected()) {
                GeneralUtils.showAlertDialog(getActivity(), getString(R.string.select_messageType));
            } else if (subject.equals(DEFAULT_SUBJECT)) {
                GeneralUtils.showAlertDialog(getActivity(), getString(R.string.select_subject));
            } else if (messageType.equals("4") && !spinProvidername.isSelected()) {
                GeneralUtils.showAlertDialog(getActivity(), getString(R.string.select_provider_name));
            } else if (editTxtValue.length() == 0) {
                GeneralUtils.showAlertDialog(getActivity(), getString(R.string.enter_message));
            } else {
                imageView.setClickable(true);
                MessageData data = new MessageData();
                data.setMessage(editTxtValue);
                data.setSubject(subject);
                ProfileDataCache.getInstance().setMessageData(data);

                //Sending API request to send new message if internet is available
                if (getActivity() != null) {
                    if (GeneralUtils.isOnline(getActivity())) {
                        VolleyService.composeMessage((AppCompatActivity) getActivity(), true);
                    } else {
                        GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.login_no_internet));
                    }
                }
            }
        });
        return rootView;
    }

    private void addItemsOnSpinner1() {
        if (getActivity() == null) {
            return;
        }
        //Creating adapter with subject values and setting to adapter
        List<String> objects = Arrays.asList("Address Change", "Authorizations", "Authorization to Disclose Health Information", DEFAULT_SUBJECT);
        final ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(),
                R.layout.spinner_compose_item, objects) {

            @NonNull
            @Override
            public View getView(int position, View convertView, @NonNull ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                v.setPadding(0, v.getPaddingTop(), v.getPaddingRight(), v.getPaddingBottom());
                if (convertView != null && position == getCount()) {
                    TextView textView = convertView.findViewById(R.id.text1);
                    textView.setText("");
                    textView.setHint(getItem(getCount()));
                    textView.setHintTextColor(GeneralUtils.getColor(getContext(), R.color.grey_color));
                }
                return v;
            }

            @Override
            public int getCount() {
                return super.getCount() - 1;
            }

        };
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(dataAdapter);
        spinner.setSelection(dataAdapter.getCount());

        //Setting onSelected listener to get the selected data from spinner
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if (getActivity() == null) {
                    return;
                }
                subject = spinner.getSelectedItem().toString();
                if (("Enrollment".equalsIgnoreCase(subject)) && (info != null && (StringConstants.ENTITY_ID_EMPLYRSOL.equalsIgnoreCase(info.getCurrentRelEntityID()) ||
                        StringConstants.ENTITY_ID_COMMSOLGR.equalsIgnoreCase(info.getCurrentRelEntityID())))) {
                    spinner.setSelection(dataAdapter.getCount());
                    GeneralUtils.showAlertDialog(getActivity(), getString(R.string.secure_message_enrollment_dialog));
                    return;
                }
                if (("Claims".equalsIgnoreCase(subject) || "Authorizations".equalsIgnoreCase(subject) || "PCP Change".equalsIgnoreCase(subject)) &&
                        (info != null && (StringConstants.ENTITY_ID_MEDMARSOL.equalsIgnoreCase(info.getCurrentRelEntityID())))) {
                    spinner.setSelection(dataAdapter.getCount());
                    GeneralUtils.showAlertDialog(getActivity(), getString(R.string.secure_message_normal_dialog));
                    return;
                }
                SharedPreferenceHelper.getInstance().setPreference(getActivity(), "spinnerValue", subject);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //Do something
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }
}


