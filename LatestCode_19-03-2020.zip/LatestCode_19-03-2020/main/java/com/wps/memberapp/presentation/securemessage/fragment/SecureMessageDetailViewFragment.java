package com.wps.memberapp.presentation.securemessage.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.gson.Gson;
import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MessageResponseList;
import com.wps.memberapp.presentation.base.BaseFragment;
import com.wps.memberapp.presentation.medication.adapter.ViewMedicationAdapter;
import com.wps.memberapp.presentation.securemessage.SecureMessageDetailsView;
import com.wps.memberapp.presentation.securemessage.SecureMessagesPresenter;
import com.wps.memberapp.presentation.securemessage.SecureMessagesPresenterImpl;
import com.wps.memberapp.presentation.securemessage.adapter.ReplyHistoryAdapter;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/**
 * This screen is used to display the detail view of individual secure message
 */

public class SecureMessageDetailViewFragment extends BaseFragment implements SecureMessageDetailsView {

    private TextView subjectDetailView;

    private static final String SUBJECT = "subject";
    private String lastActivityDate, submittedDate;
    LinearLayout llProviderName;
    String msgType;
    TextView txtProviderName;
    RecyclerView rvReplyHistory;

    /**
     * This override method is used to inflate the layout for SecureMessageDetailView fragment
     *
     * @return rootView
     */
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        View itemView = inflater.inflate(R.layout.frag_secure_message_detail_list_view, container, false);

        //Inflating the views from XML layout
        Button replyBtn = itemView.findViewById(R.id.replyBtn);
        //Member variables declaration
        TextView secureTitle = itemView.findViewById(R.id.secureMessageDetailViewNameLabel);
        TextView lastActivityValue = itemView.findViewById(R.id.lastActivityDetailViewValue);
        TextView submissionDateValue = itemView.findViewById(R.id.submissionDateDetailViewValue);
        TextView statusTextView = itemView.findViewById(R.id.statusDetailTextView);
        TextView subjectLabel = itemView.findViewById(R.id.subjectDetailViewLabel);
        subjectDetailView = itemView.findViewById(R.id.subjectDetailViewDetails);
        llProviderName = itemView.findViewById(R.id.ll_ProviderName);
        rvReplyHistory = itemView.findViewById(R.id.rv_ReplyHistory);
        submissionDateValue.setSelected(true);
        subjectLabel.setSelected(true);
        TextView messageIDValue = itemView.findViewById(R.id.messageIDValue);
        TextView subscriberIDValue = itemView.findViewById(R.id.subscriberIDValue);
        TextView txtMessageType = itemView.findViewById(R.id.txt_MessageType);
        txtProviderName = itemView.findViewById(R.id.txt_ProviderName);

        if (getActivity() != null) {
            ImageView imageViewSearch = getActivity().findViewById(R.id.imageViewSearch);
            imageViewSearch.setVisibility(View.GONE);
            TextView txtDownloadPDF = getActivity().findViewById(R.id.txt_Call);
            txtDownloadPDF.setVisibility(View.GONE);
            //Setting title for action bar
            TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
            fragmentTitle.setText(R.string.txt_message);
        }

        String mFLName = StringConstants.SPACE_SINGLE + ProfileDataCache.getInstance().getFirstName() + StringConstants.SPACE_SINGLE + ProfileDataCache.getInstance().getLastName();
        mFLName = getString(R.string.msg_by) + mFLName;
        secureTitle.setText(mFLName);

        //Getting data for individual secure message from previous fragment
        if (getArguments() != null) {
            submittedDate = getArguments().getString("submittedDate");
            String status = getArguments().getString("status");
            lastActivityDate = getArguments().getString("lastActivityDate");
            String messageId = getArguments().getString("messageId");
            String subscriberId = getArguments().getString("subscriberId");
            msgType = getArguments().getString("MsgType");

            String subject = getArguments().getString(SUBJECT);
            statusTextView.setText(status);
            if (status.equalsIgnoreCase("Closed")) {
                replyBtn.setVisibility(View.GONE);
            } else {
                replyBtn.setVisibility(View.VISIBLE);
            }
            subscriberIDValue.setText(subscriberId);
            txtMessageType.setText(msgType);

            messageIDValue.setText(messageId);
            if (lastActivityDate != null) {
                String[] s = lastActivityDate.split(" ", 2);
                String date = s[0];
                lastActivityValue.setText(date);
            }

            if (submittedDate != null) {
                String[] s = submittedDate.split(" ", 2);
                String date = s[0];
                submissionDateValue.setText(date);
            }
            if (subject != null && !subject.isEmpty() && !subject.equals("null")) {
                subjectLabel.setText(subject);
            } else {
                subjectLabel.setText("");
            }
        }
        SecureMessagesPresenter messagesPresenter = new SecureMessagesPresenterImpl();
        messagesPresenter.onAttach(this);
        if (getActivity() != null) {
            if (GeneralUtils.isOnline(getActivity())) {
                messagesPresenter.getSecureMessageDetails();
            } else {
                GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.login_no_internet));
            }
        }

        //This code is used to launch the SendReplyFragment
        replyBtn.setOnClickListener(view -> {
            SendReplyFragment sendReply = new SendReplyFragment();
            Bundle args = new Bundle();
            args.putString(SUBJECT, getArguments().getString(SUBJECT));
            args.putString("id", getArguments().getString("id"));
            sendReply.setArguments(args);
            getActivity().getSupportFragmentManager().beginTransaction().add(R.id.frame_container, sendReply)
                    .addToBackStack("null").commit();
        });
        return itemView;
    }

    @Override
    public void onDetailsLoadingCompleted(JSONObject jsonObject) {
        //Processing the received response
        if (jsonObject != null) {
            try {
                String message = jsonObject.getString("MessageBody");
                String mProvName = jsonObject.getString("PROVIDER_NAME");
                subjectDetailView.setText(message);
                if (msgType.equalsIgnoreCase("PCP Message") || msgType.equalsIgnoreCase("Provider Message")) {
                    llProviderName.setVisibility(View.VISIBLE);
                    txtProviderName.setText(mProvName);
                } else {
                    llProviderName.setVisibility(View.GONE);
                    txtProviderName.setText("");
                }
                List<MessageResponseList> responseMessageList = new ArrayList<>();
                JSONArray jsonArrayString;
                jsonArrayString = jsonObject.getJSONArray("MessageResponseList");
                if (jsonArrayString != null) {
                    for (int i = 0; i < jsonArrayString.length(); i++) {
                        MessageResponseList responseMessage = new Gson().fromJson(jsonArrayString.getString(i), MessageResponseList.class);
                        responseMessageList.add(responseMessage);
                    }
                }
                if (responseMessageList != null && responseMessageList.size() > 0) {
                    ReplyHistoryAdapter adapter = new ReplyHistoryAdapter(getActivity(), getActivity(), responseMessageList, submittedDate);
                    rvReplyHistory.setItemAnimator(new DefaultItemAnimator());
                    rvReplyHistory.setHasFixedSize(true);
                    final LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
                    layoutManager.setOrientation(RecyclerView.VERTICAL);
                    rvReplyHistory.setLayoutManager(layoutManager);
                    rvReplyHistory.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                } else {
                    rvReplyHistory.setVisibility(View.GONE);
                }

            } catch (Exception e) {
                Logger.e(StringConstants.EXCEPTION, e);
            }
        }
    }
}


