package com.wps.memberapp.presentation.securemessage.fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.gson.Gson;
import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.SecureMessage;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.claims.adapter.NothingSelectedSpinnerAdapter;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * A Screen which will display dialog to search claim based on start and end date
 */

public class SecureMessageSearchFragment extends DialogFragment {

    //Declaring member variables

    @BindView(R.id.subject)
    Spinner subjectSpinner;

    @BindView(R.id.status)
    Spinner statusSpinner;

    @BindView(R.id.refId)
    EditText refIdEt;

    @BindView(R.id.noOfDays)
    Spinner daysSpinner;

    @BindView(R.id.spin_messageType)
    Spinner spinMessageType;

    @BindView(R.id.btnSecureMsgSearch)
    Button btnSearch;

    @BindView(R.id.btnSecureMsgCancel)
    Button btnCancel;

    @BindView(R.id.close)
    ImageView close;
    private DialogCallbackContract mListener;
    private Unbinder unbinder;
    @NonNull
    private String subject = "";
    private String messageType = "";
    @NonNull
    private String status = "";
    @NonNull
    private String days = "";

    //required constructor
    public void setListener(DialogCallbackContract listener) {
        mListener = listener;
    }

    //Callback interface
    interface DialogCallbackContract {
        void returnData(List<SecureMessage> messageList);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NORMAL, R.style.DialogFragmentTheme);

    }


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.frag_secure_message_search, container, false);
        unbinder = ButterKnife.bind(this, rootView);
        close.setOnClickListener(view -> dismiss());
        addItemsOnSpinner2();
        addItemsOnSpinner1();
        addItemsOnSpinner3();
        addItemsOnSpinner4();
        return rootView;
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        btnSearch.setOnClickListener(view1 -> {
            if (getActivity() != null) {
                if (GeneralUtils.isOnline(getActivity())) {
                    getAdvanceSearchDetails();
                } else {
                    GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.login_no_internet));
                }
            }
        });
        btnCancel.setOnClickListener(view12 -> dismiss());
    }

    private void addItemsOnSpinner2() {
        if (getActivity() == null) {
            return;
        }
        //Creating adapter with claim status values and setting to spinner
        List<String> list = Arrays.asList(getActivity().getResources().getStringArray(R.array.secure_message_status));
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(getActivity(),
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        statusSpinner.setAdapter(new NothingSelectedSpinnerAdapter(
                dataAdapter,
                R.layout.secure_msg_status_spinner_hint,
                // R.layout.contact_spinner_nothing_selected_dropdown, // Optional
                getActivity()));

        //Added selected listener to get the selected data
        statusSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                try {
                    if (statusSpinner.getSelectedItem() != null) {
                        status = statusSpinner.getSelectedItem().toString();
                    }
                } catch (Exception e) {
                    Logger.e(StringConstants.EXCEPTION, e);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //Do something
            }
        });

    }

    private void addItemsOnSpinner1() {
        if (getActivity() == null) {
            return;
        }
        //Creating adapter with member name values and setting to spinner
//        List<String> list = Arrays.asList("Address Change", "Authorizations", "Authorization to Disclose Health Information");
        List<String> list = ProfileDataCache.getInstance().getSecMsgSubject();

        if (list == null) {
            list = new ArrayList<>();
        }
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(getActivity(),
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        subjectSpinner.setAdapter(new NothingSelectedSpinnerAdapter(
                dataAdapter,
                R.layout.secure_msg_subject_spinner_hint,
                // R.layout.contact_spinner_nothing_selected_dropdown, // Optional
                getActivity()));

        //Added selected listener to get the selected data
        subjectSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                try {
                    if (subjectSpinner.getSelectedItem() != null) {
                        subject = subjectSpinner.getSelectedItem().toString();
                        if (subject.equalsIgnoreCase("All")){
                            subject = "";
                        }
                    }
                } catch (Exception e) {
                    Logger.e(StringConstants.EXCEPTION, e);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //Do something
            }
        });
    }

    private void addItemsOnSpinner3() {
        if (getActivity() == null) {
            return;
        }
        //Creating adapter with member name values and setting to spinner
        List<String> list = Arrays.asList(getActivity().getResources().getStringArray(R.array.secure_message_days));
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(getActivity(),
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        daysSpinner.setAdapter(new NothingSelectedSpinnerAdapter(
                dataAdapter,
                R.layout.secure_msg_activityin_spinner_hint,
                // R.layout.contact_spinner_nothing_selected_dropdown, // Optional
                getActivity()));
        daysSpinner.setSelection(4);

        //Added selected listener to get the selected data
        daysSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                try {
                    if (i > -1) {
                        int j = getDays(i);
                        if (j > 0) {
                            days = "" + getDays(i);
                        } else {
                            days = "";
                        }
                    }
                } catch (Exception e) {
                    Logger.e(StringConstants.EXCEPTION, e);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //Do something
            }
        });
    }

    private void addItemsOnSpinner4() {
        if (getActivity() == null) {
            return;
        }
        //Creating adapter with member name values and setting to spinner
        List<String> list = Arrays.asList(getActivity().getResources().getStringArray(R.array.message_type));
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(getActivity(),
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinMessageType.setAdapter(new NothingSelectedSpinnerAdapter(
                dataAdapter,
                R.layout.message_type_spinner_hint,
                // R.layout.contact_spinner_nothing_selected_dropdown, // Optional
                getActivity()));

        //Added selected listener to get the selected data
        spinMessageType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                try {
                    if (spinMessageType.getSelectedItem() != null) {
                        messageType = String.valueOf(spinMessageType.getItemAtPosition(position));
//                        spinMessageType.getSelectedItemPosition();
//                        Toast.makeText(getContext(), "Position " + position, Toast.LENGTH_SHORT).show();
//                        Toast.makeText(getContext(), "PositionSelected " + spinMessageType.getSelectedItemPosition(), Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Logger.e(StringConstants.EXCEPTION, e);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //Do something
            }
        });
    }

    private int getDays(int i) {
        int day;
        switch (i) {
            case 1:
                day = 0;
                break;
            case 2:
                day = 7;
                break;
            case 3:
                day = 15;
                break;
            case 4:
                day = 30;
                break;
            case 5:
                day = 60;
                break;
            default:
                day = 0;
                break;
        }
        return day;
    }

    /**
     * This method is used to fetch detailedView authorization referral data
     */

    private void getAdvanceSearchDetails() {
        if (getActivity() == null) {
            return;
        }
        //Validating the fields data is entered or not
        String refId = refIdEt.getText().toString().trim();
        if (status.equalsIgnoreCase("All")) {
            status = "";
        } else if (status.equalsIgnoreCase("open")) {
            status = "1";
        } else if (status.equalsIgnoreCase("closed")) {
            status = "2";
        } else if (status.equalsIgnoreCase("New")) {
            status = "0";
        }

        // Change the selection of spinner(Message Type) values to number
        if (messageType.equalsIgnoreCase("All")) {
            messageType = "";
        } else if (messageType.equalsIgnoreCase("CSR Message")) {
            messageType = "1";
        } else if (messageType.equalsIgnoreCase("Disease Mgmt Enrollment Request")) {
            messageType = "2";
        } else if (messageType.equalsIgnoreCase("PCP Message")) {
            messageType = "3";
        } else if (messageType.equalsIgnoreCase("Provider Message")) {
            messageType = "4";
        }

        dismiss();
        String[] params = new String[5];
        params[0] = subject;
        params[1] = status;
        params[2] = refId;
        params[3] = days;
        params[4] = messageType;
        ProfileDataCache.getInstance().setSecureMessagesSearchData(params);
        //Used to display the progress dialog
        GeneralUtils.showProgress(getActivity());
        //Used to send API request to get the claim details based on search critiria
        VolleyService.getAdvanceSearchSecureMessages(getActivity(),
                AppConstants.GET_SECURE_MESSAGES, new VolleyResponseListener() {
                    @Override
                    public void onError(String error) {
                        GeneralUtils.hideProgress();
                        Log.i("Error_Auth_Referral", error);
                    }

                    @Override
                    public void onResponse(String response) {
                        try {
                            Log.i("Secure_Search", response);
                            GeneralUtils.hideProgress();
                            //Processing the response
                            parseSecureMessages(response);
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    }
                });
    }

    /*
    This method is used to parse the secure message API response
     */
    private void parseSecureMessages(String response) {
        if (response != null) {
            try {
                Gson gson = new Gson();
                List<SecureMessage> listObjects = new ArrayList<>();

                JSONArray jsonArray = new JSONArray(response);
                for (int i = 0; i < jsonArray.length(); i++) {

                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    SecureMessage feed = gson.fromJson(jsonObject.toString(), SecureMessage.class);
                    if (feed != null) {
                        listObjects.add(feed);
                    }
                }
                mListener.returnData(listObjects);
            } catch (Exception e) {
                Logger.e(StringConstants.EXCEPTION, e);
            }
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }
}
