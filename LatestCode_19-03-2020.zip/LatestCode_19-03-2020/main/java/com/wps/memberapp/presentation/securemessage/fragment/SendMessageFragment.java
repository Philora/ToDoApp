package com.wps.memberapp.presentation.securemessage.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
//import android.widget.Toast;

import com.appdynamics.eumagent.runtime.Instrumentation;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.GetSecureMessagesProvider;
import com.wps.memberapp.data.model.MasterData;
import com.wps.memberapp.data.model.SecureMessage;
import com.wps.memberapp.presentation.base.BaseFragment;
import com.wps.memberapp.presentation.securemessage.SecureMessagesPresenter;
import com.wps.memberapp.presentation.securemessage.SecureMessagesPresenterImpl;
import com.wps.memberapp.presentation.securemessage.SecureMessagesView;
import com.wps.memberapp.presentation.securemessage.adapter.SecureMessageAdapter;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/**
 * This screen is used to display the list of messages from API.
 */

public class SendMessageFragment extends BaseFragment implements View.OnClickListener, SecureMessagesView, SecureMessageSearchFragment.DialogCallbackContract {

    private RecyclerView recyclerSecureMessageView;
    private TextView noMessages;
    private ProgressBar mProgressBar;
    List<String> msgProviderList;
    List<String> msgProviderListId;
    List<String> mMsgSubj;

    List<String> msgProviderPCPList;
    List<String> msgProviderPCPListId;
    FloatingActionButton floatingActionButton;
    SecureMessagesPresenter messagesPresenter;
    /**
     * This override method is used to inflate the layout for Dashboard fragment
     *
     * @return rootView
     */
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        if (getActivity() != null) {
            Instrumentation.start(StringConstants.APP_DYNAMICS_KEY, getActivity().getApplicationContext());
        }
        if (container != null) {
            container.removeAllViews();
            container.clearDisappearingChildren();
        }
        View rootView = inflater.inflate(R.layout.fragment_send_message, container, false);
        //Inflating views from XML layout
        messagesPresenter = new SecureMessagesPresenterImpl();
        messagesPresenter.onAttach(this);
        recyclerSecureMessageView = rootView.findViewById(R.id.recycler_view);
        recyclerSecureMessageView.setHasFixedSize(true);
        noMessages = rootView.findViewById(R.id.no_messages);
        final LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        recyclerSecureMessageView.setLayoutManager(layoutManager);
        ImageView imageViewSearch = getActivity().findViewById(R.id.imageViewSearch);
        imageViewSearch.setVisibility(View.VISIBLE);
        mProgressBar = rootView.findViewById(R.id.progressBar);
        //Setting title to actionbar
        if (getActivity() != null) {
            TextView txtDownloadPDF = getActivity().findViewById(R.id.txt_Call);
            txtDownloadPDF.setVisibility(View.GONE);
            TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
            fragmentTitle.setText(R.string.secure_messages);
        }
        floatingActionButton = rootView.findViewById(R.id.floating_action_button);
        floatingActionButton.setOnClickListener(this);
        imageViewSearch.setOnClickListener(view -> showDialog());
        if (getActivity() != null) {
            if (GeneralUtils.isOnline(getActivity())) {
                messagesPresenter.getSecureMessages();
            } else {
                mProgressBar.setVisibility(View.GONE);
                GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.login_no_internet));
            }
        }
        return rootView;
    }

    @Override
    public void onClick(View view) {
        if (getActivity() == null) {
            return;
        }
        //Used to display compose message fragment
        ComposeFragment claimDetailView = new ComposeFragment();
        getActivity().getSupportFragmentManager().beginTransaction().
                replace(R.id.frame_container, claimDetailView).addToBackStack(null).commit();
    }

    /*Used to show the search dialog */
    private void showDialog() {
        if (getActivity() == null) {
            return;
        }
        FragmentManager fm = getActivity().getSupportFragmentManager();
        SecureMessageSearchFragment addDialog = new SecureMessageSearchFragment();
        addDialog.setTargetFragment(this, 0);
        addDialog.setListener(this);
        addDialog.show(fm, "dialog");
    }

    @Override
    public void onSecureMessagesLoadingCompleted(@NonNull List<SecureMessage> secureMessageList) {
        loadData(secureMessageList);
        if (ProfileDataCache.getInstance().getSecMessagesProvider() == null) {
            messagesPresenter.getSecureMessageProvider();
        }

    }


    @Override
    public void onSecureMessageProvider(List<GetSecureMessagesProvider> messagesProvider) {
//        Toast.makeText(getActivity(), "SecureMessageProvider " + messagesProvider.get(0).getPROVIDERNAME(), Toast.LENGTH_SHORT).show();

        msgProviderList = new ArrayList<>();
        msgProviderListId = new ArrayList<>();
        if (messagesProvider != null) {
            try {
                for (int i = 0; i < messagesProvider.size(); i++) {
                    msgProviderList.add(messagesProvider.get(i).getPROVIDERNAME());
                    msgProviderListId.add(messagesProvider.get(i).getSEQPROVID());
                }
            } catch (Exception e) {
                Logger.e(StringConstants.EXCEPTION, e);
            }
        }
        ProfileDataCache.getInstance().setSecMessagesProvider(msgProviderList);
        ProfileDataCache.getInstance().setSecMessagesProviderId(msgProviderListId);
        if (ProfileDataCache.getInstance().getSecMessagesProviderPCP() == null) {
            messagesPresenter.getSecureMessageProviderPCP();
        }
    }

    @Override
    public void onSecureMessageProviderPCP(List<GetSecureMessagesProvider> messagesProvider) {
//        Toast.makeText(getActivity(), "SecureMessageProviderPCP " + messagesProvider.get(0).getPROVIDERNAME(), Toast.LENGTH_SHORT).show();
        msgProviderPCPList = new ArrayList<>();
        msgProviderPCPListId = new ArrayList<>();
        if (messagesProvider != null && messagesProvider.size() > 0) {
            try {
                for (int i = 0; i < messagesProvider.size(); i++) {
                    msgProviderPCPList.add(messagesProvider.get(i).getPROVIDERNAME());
                    msgProviderPCPListId.add(messagesProvider.get(i).getSEQPROVID());
                }
            } catch (Exception e) {
                Logger.e(StringConstants.EXCEPTION, e);
            }
        }
        ProfileDataCache.getInstance().setSecMessagesProviderPCP(msgProviderPCPList);
        ProfileDataCache.getInstance().setSecMessagesProviderPCPId(msgProviderPCPListId);

        if (ProfileDataCache.getInstance().getSecMsgSubject() == null) {
            messagesPresenter.getMessageSubject();
        }
    }

    @Override
    public void returnData(@NonNull List<SecureMessage> secureMessageList) {
        loadData(secureMessageList);
    }

    private void loadData(List<SecureMessage> secureMessageList) {
        //If data is there we will create adapter and set to recycle view
        if (!secureMessageList.isEmpty()) {
            noMessages.setVisibility(View.GONE);
        } else {
            noMessages.setVisibility(View.VISIBLE);
        }
        SecureMessageAdapter adapter = new SecureMessageAdapter(getActivity(), (AppCompatActivity) getActivity(), secureMessageList);
        recyclerSecureMessageView.setItemAnimator(new DefaultItemAnimator());
        mProgressBar.setVisibility(View.GONE);
        recyclerSecureMessageView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onSubjectResponse(List<MasterData> messageSubject) {
        mMsgSubj = new ArrayList<>();
        mMsgSubj.add("All");
        if (messageSubject != null) {
            try {
                for (int i = 0; i < messageSubject.size(); i++) {
                    mMsgSubj.add(messageSubject.get(i).getCode());
                }
                mMsgSubj.remove("Select");
                ProfileDataCache.getInstance().setSecMsgSubject(mMsgSubj);
            } catch (Exception e) {
                Logger.e(StringConstants.EXCEPTION, e);
            }
        }

    }
}
