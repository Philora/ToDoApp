package com.wps.memberapp.presentation.securemessage.fragment;

import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MessageData;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.base.BaseFragment;
import com.wps.memberapp.presentation.dashboard.activity.DashboardActivity;
import com.wps.memberapp.presentation.dashboard.fragment.DashboardFragment;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.GeneralUtils;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

/**
 * This screen is used to give reply to the respected message
 */

public class SendReplyFragment extends BaseFragment implements View.OnClickListener {

    //Declaring member variables
    private EditText editText;
    @NonNull
    private String editTxtValue = "";

    private String mEncryptMsgId;

    /**
     * This override method is used to inflate the layout for Send reply fragment
     *
     * @return rootView
     */
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        View rootView = inflater.inflate(R.layout.send_reply_fragment, container, false);

        //Inflating the views from XML layout
        ImageView imageView = rootView.findViewById(R.id.icon_send_reply);
        TextView subjectValue = rootView.findViewById(R.id.subjectValue);

        //Setting title to actionbar
        if (getActivity() != null) {
            TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
//            fragmentTitle.setText(R.string.send_message_title);
            fragmentTitle.setText(R.string.txt_message);
        }
        imageView.setOnClickListener(this);
        editText = rootView.findViewById(R.id.replyEditText);
        //Getting data from the previous fragment
        if (getArguments() != null) {
            String subject = getArguments().getString("subject");
            mEncryptMsgId = getArguments().getString("encryptMsgId");
            subjectValue.setText(subject);
        }
        editText.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
            }

            @Override
            public void beforeTextChanged(CharSequence s, int arg1, int arg2, int arg3) {
            }

            @Override
            public void afterTextChanged(Editable arg0) {
                if (editText.getText().toString().contains(" ")) {
                    editText.setText(editText.getText().toString().replaceAll(" ", ""));
                    editText.setSelection(editText.getText().length());
                }
            }
        });
        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        editTxtValue = editText.getText().toString();
    }

    @Override
    public void onClick(View view) {
        //Saving the data in shared preferences
        editTxtValue = editText.getText().toString();
        if (editTxtValue.length() == 0) {
            editText.requestFocus();
            if (getActivity() != null) {
                GeneralUtils.showAlertDialog(getActivity(), getString(R.string.enter_message));
            }
        } else {
            MessageData data = new MessageData();
            data.setMessage(editTxtValue);
            data.setSubject(ProfileDataCache.getInstance().getMsgID());
            ProfileDataCache.getInstance().setMessageData(data);
            if (getActivity() != null) {
                if (GeneralUtils.isOnline(getActivity())) {
                    sendMessageData();
                } else {
                    GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.login_no_internet));
                }
            }
        }
    }

    /**
     * Used to call web service for claimSummary and get response as JSON
     * using post method and to plot the horizontal bar chart
     */

    private void sendMessageData() {
        if (getActivity() == null) {
            return;
        }
        //Display progress dialog
        GeneralUtils.showProgress(getActivity());
        VolleyService.sendMessageData(getActivity(),
                AppConstants.SEND_REPLY, new VolleyResponseListener() {
                    @Override
                    public void onError(String error) {
                        GeneralUtils.hideProgress();
                        Log.i("Error_Send_Reply", error);
                    }

                    @TargetApi(Build.VERSION_CODES.KITKAT)
                    @Override
                    public void onResponse(String response) {
                        try {
                            Log.i("Success_Send_Reply", response);  // response comes out in null ("") only
                            GeneralUtils.hideProgress();
                            //Displaying successfull message dialog based on the response
                            AlertDialog.Builder alertDialog = new AlertDialog.Builder(getActivity());
                            alertDialog.setTitle(R.string.message_sent);
                            // alertDialog.setMessage(getString(R.string.reference_id_colon) + response);
                            // Setting Positive "Yes" Button
                            alertDialog.setCancelable(false);
                            alertDialog.setPositiveButton(getString(R.string.ok), (dialog, which) -> {
                               /* Fragment fragment = new SecureMessageDetailViewFragment();
                                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                                fragmentManager.beginTransaction().replace(R.id.frame_container, fragment).addToBackStack(null).commit();*/
                                getActivity().getSupportFragmentManager().popBackStack();


                                /*if (getFragmentManager() != null) {
                                    getFragmentManager().popBackStack();
                                    Fragment firstFragment = new SecureMessageDetailViewFragment();
                                    getFragmentManager().beginTransaction().replace(R.id.frame_container, firstFragment, "home").addToBackStack(null).commit();
                                }*/
                            });
                            //Showing Alert Message
                            alertDialog.show();
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    }

                });
    }
}
