package com.wps.memberapp.presentation.splash.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.wps.memberapp.R;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.presentation.login.activity.LoginActivity;
//import com.wps.memberapp.presentation.splash.activity.SampleActivity;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Objects;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import butterknife.ButterKnife;
import butterknife.OnClick;

import static com.wps.memberapp.utility.GeneralUtils.showAlertDialog;

public class LanguageActivity extends AppCompatActivity {
    private static final String APP_SIGNATURE = "6406AC95CEA9BC817F04E70D78E581489A1A058A";
    private static final int CODE_AUTHENTICATION_VERIFICATION = 100;
    private static final int REQUEST_CODE_UNINSTALL_FREE_APP = 100;
    private AlertDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language);
        try {
            if (!validateAppSignature(LanguageActivity.this)) {
                showDialogPermission(LanguageActivity.this, getString(R.string.invalid_signature));
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        try {
            isDeviceRooted();
//            checkEmulator();
        } catch (Exception e) {
            e.printStackTrace();
        }

        ButterKnife.bind(this);
        if (!isTaskRoot()) {
            finish();
            return;
        }
    }

    @OnClick({R.id.english, R.id.spanish})
    public void onButonClick(View view) {
        if (view.getId() == R.id.english) {
            SharedPreferenceHelper.getInstance().setPreference(getApplicationContext(), "Language", "en");
        } else {
             SharedPreferenceHelper.getInstance().setPreference(getApplicationContext(), "Language", "es");
            //            GeneralUtils.uninstallApp(LanguageActivity.this);

           /* Uri uri = Uri.parse("package:com.wps.memberapp");
            Intent intent = new Intent("android.intent.action.DELETE", uri);
            startActivityForResult(intent, REQUEST_CODE_UNINSTALL_FREE_APP);*/
        }
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == CODE_AUTHENTICATION_VERIFICATION) {
            Toast.makeText(LanguageActivity.this, "Uninstalled App", Toast.LENGTH_SHORT).show();
        } else if (resultCode == RESULT_CANCELED && requestCode == CODE_AUTHENTICATION_VERIFICATION) {
            finish();
        } else {
            Toast.makeText(LanguageActivity.this, "Failure:", Toast.LENGTH_SHORT).show();
        }
    }

    public boolean isDeviceRooted() {
        try {
            if (checkRootMethod1() || checkRootMethod2() || checkRootMethod3()) {
                showDialogPermission(LanguageActivity.this, getString(R.string.app_root_installation));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    private boolean findBinary(String binaryName) {
        boolean found = false;
        if (!found) {
            String[] places = {"/sbin/", "/system/bin/", "/system/xbin/",
                    "/data/local/xbin/", "/data/local/bin/",
                    "/system/sd/xbin/", "/system/bin/failsafe/", "/data/local/",
                    "/system/app/Superuser.apk", "/sbin/su", "/sbin/su/", "/system/bin/su", "/system/bin/su/",
                    "/system/xbin/su", "/system/xbin/su/", "/data/local/xbin/su", "/data/local/bin/su", "/system/sd/xbin/su",
                    "/system/bin/failsafe/su", "/data/local/su", "/su/bin/su", "/su/",
                    "/data/local/xbin/",
                    "/system/bin/.ext/",
                    "/system/bin/failsafe/",
                    "/system/sd/xbin/",
                    "/su/xbin/",
                    "/su/bin/",
                    "/magisk/.core/bin/",
                    "/system/usr/we-need-root/",
                    "/system/xbin/",
                    "/system/su", "/system/bin/.ext/.su", "/system/usr/we-need-root/su-backup",
                    "/system/xbin/mu",
                    "/system/su/", "/system/bin/.ext/.su/", "/system/usr/we-need-root/su-backup/",
                    "/system/xbin/mu/"};
            for (String where : places) {
                if (new File(where + binaryName).exists()) {
                    found = true;
                    break;
                }
            }
        }
        return found;
    }

    private void showDialogPermission(@NonNull Activity activity, String string) {
        try {
            android.app.AlertDialog.Builder alret = new android.app.AlertDialog.Builder(activity)
                    .setCancelable(false)
                    .setMessage(string)
                    .setPositiveButton(activity.getString(R.string.close), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            String appPackage = "com.wps.memberapp";

                            Uri uri = Uri.parse("package:com.wps.memberapp");
                            Intent intent = new Intent("android.intent.action.DELETE", uri);
                            startActivityForResult(intent, REQUEST_CODE_UNINSTALL_FREE_APP);

                         /*   Intent intent = new Intent(Intent.ACTION_DELETE);   // ACTION_UNINSTALL_PACKAGE
                            intent.setData(Uri.parse("package:com.wps.memberapp"));
                            activity.startActivity(intent);*/

                         /* String appPackage = "com.wps.memberapp";
                            Intent intent = new Intent(activity, activity.getClass()); //getActivity() is undefined!
                            PendingIntent sender = PendingIntent.getActivity(activity, 0, intent, 0);
                            PackageInstaller mPackageInstaller = activity.getPackageManager().getPackageInstaller();
                            mPackageInstaller.uninstall(appPackage, sender.getIntentSender());*/

                            /*Intent intent = new Intent(activity, activity.getClass());
                            PendingIntent sender = PendingIntent.getActivity(activity, 0, intent, 0);
                            PackageInstaller mPackageInstaller = activity.getPackageManager().getPackageInstaller();
                            mPackageInstaller.uninstall(appPackage, sender.getIntentSender());*/

                            /*int UNINSTALL_REQUEST_CODE = 1;
                            Intent intent = new Intent(Intent.ACTION_UNINSTALL_PACKAGE);
                            intent.setData(Uri.parse("package:" + appPackage));
                            intent.putExtra(Intent.EXTRA_RETURN_RESULT, true);
                            activity.startActivityForResult(intent, UNINSTALL_REQUEST_CODE);*/
                        }
                    });
            dialog = alret.create();
            dialog.show();
        } catch (Exception e) {
            Logger.e("ProviderSearch", e);
        }
    }

    public boolean checkEmulator() {
        try {
            boolean goldfish = getSystemProperty("ro.hardware").contains("goldfish");
            boolean emu = getSystemProperty("ro.kernel.qemu").length() > 0;
            boolean sdk = getSystemProperty("ro.product.model").equals("sdk");
            if (emu || goldfish || sdk) {
                showDialogPermission(LanguageActivity.this, getString(R.string.app_installation));
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    private static boolean checkRootMethod1() {
        String buildTags = android.os.Build.TAGS;
        return buildTags != null && buildTags.contains("test-keys");
    }

    private static boolean checkRootMethod2() {
        String[] paths = {"/system/app/Superuser.apk", "/sbin/su", "/system/bin/su", "/system/xbin/su", "/data/local/xbin/su", "/data/local/bin/su", "/system/sd/xbin/su",
                "/system/bin/failsafe/su", "/data/local/su", "/su/bin/su"};
        for (String path : paths) {
            if (new File(path).exists()) return true;
        }
        return false;
    }

    private static boolean checkRootMethod3() {
        Process process = null;
        try {
            process = Runtime.getRuntime().exec(new String[]{"/system/xbin/which", "su"});
            BufferedReader in = new BufferedReader(new InputStreamReader(process.getInputStream()));
            if (in.readLine() != null) return true;
            return false;
        } catch (Throwable t) {
            return false;
        } finally {
            if (process != null) process.destroy();
        }
    }

    private static String getSystemProperty(String name) throws Exception {
        Class systemPropertyClazz = Class.forName("android.os.SystemProperties");
        return (String) systemPropertyClazz.getMethod("get", new Class[]{String.class}).invoke(systemPropertyClazz, new Object[]{name});
    }

    public boolean validateAppSignature(Context context) throws PackageManager.NameNotFoundException {

        PackageInfo packageInfo = context.getPackageManager().getPackageInfo(
                getPackageName(), PackageManager.GET_SIGNATURES);
        //note sample just checks the first signature
        for (Signature signature : packageInfo.signatures) {
            // SHA1 the signature
            String sha1 = getSHA1(signature.toByteArray());
            // check is matches hardcoded value
            return APP_SIGNATURE.equals(sha1);
        }
        return false;
    }

    //computed the sha1 hash of the signature
    public static String getSHA1(byte[] sig) {
        MessageDigest digest = null;
        try {
            digest = MessageDigest.getInstance("SHA1");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        digest.update(sig);
        byte[] hashtext = digest.digest();
        return bytesToHex(hashtext);
    }

    //util method to convert byte array to hex string
    public static String bytesToHex(byte[] bytes) {
        final char[] hexArray = {'0', '1', '2', '3', '4', '5', '6', '7', '8',
                '9', 'A', 'B', 'C', 'D', 'E', 'F'};
        char[] hexChars = new char[bytes.length * 2];
        int v;
        for (int j = 0; j < bytes.length; j++) {
            v = bytes[j] & 0xFF;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[j * 2 + 1] = hexArray[v & 0x0F];
        }
        return new String(hexChars);
    }
}
