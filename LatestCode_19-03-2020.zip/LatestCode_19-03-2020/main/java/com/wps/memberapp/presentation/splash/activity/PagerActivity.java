package com.wps.memberapp.presentation.splash.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import androidx.viewpager.widget.ViewPager;

import android.widget.ImageView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.presentation.splash.adapter.SplashPagerAdapter;

/**
 * This activity is used to display welcome pages to the user.
 */
public class PagerActivity extends Activity {

    private ImageView ivIndicator1;
    private ImageView ivIndicator2;
    private ImageView ivIndicator3;
    private int mCounterPageScroll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
      //  GeneralUtils.setLanguage(getApplicationContext());
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pager);
        boolean isFirstRun = SharedPreferenceHelper.getInstance().getPrefBoolean(this, "isFirstRun", false);

        //Checking if it first run or not
        if (isFirstRun) {
            Intent intent = new Intent(getApplicationContext(), LanguageActivity.class);
            startActivity(intent);
            finish();
        }
        SharedPreferenceHelper.getInstance().setPrefBoolean(this, "isFirstRun", true);
        ViewPager pager = findViewById(R.id.splashPager);
        ivIndicator1 = findViewById(R.id.indicator1);
        ivIndicator2 = findViewById(R.id.indicator2);
        ivIndicator3 = findViewById(R.id.indicator3);
        SplashPagerAdapter adapter = new SplashPagerAdapter(this);
        pager.setAdapter(adapter);

        //Adding page change listener to handle the user scroll interactions
        pager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                if (position == 2 && positionOffset == 0) {
                    if (mCounterPageScroll == 1) {
                        Intent intent = new Intent(getApplicationContext(), LanguageActivity.class);
                        startActivity(intent);
                        finish();
                    }
                    mCounterPageScroll++;
                } else {
                    mCounterPageScroll = 0;
                }

                //Changing page indicators based on the user selection
                switch (position) {
                    case 0:
                        ivIndicator1.setImageResource(R.drawable.pager_dot_blue);
                        ivIndicator2.setImageResource(R.drawable.pager_dot_white);
                        ivIndicator3.setImageResource(R.drawable.pager_dot_white);
                        break;
                    case 1:
                        ivIndicator1.setImageResource(R.drawable.pager_dot_white);
                        ivIndicator2.setImageResource(R.drawable.pager_dot_blue);
                        ivIndicator3.setImageResource(R.drawable.pager_dot_white);
                        break;
                    case 2:
                        ivIndicator1.setImageResource(R.drawable.pager_dot_white);
                        ivIndicator2.setImageResource(R.drawable.pager_dot_white);
                        ivIndicator3.setImageResource(R.drawable.pager_dot_blue);
                        break;
                    default:
                }
            }

            @Override
            public void onPageSelected(int position) {
                //Need to implement
            }

            @Override
            public void onPageScrollStateChanged(int state) {
                //Need to implement
            }
        });
    }
}
