package com.wps.memberapp.presentation.splash.activity;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.wps.memberapp.R;
import com.wps.memberapp.presentation.login.activity.LoginActivity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import butterknife.BindView;
import butterknife.ButterKnife;

public class SampleActivity extends Activity {

    /*@BindView(R.id.edtMessage)
    EditText edtMessage;
    @BindView(R.id.btnClick)
    Button btnClick;*/
    private static final int HELLO_ID = 1;
    CharSequence tickerText = "Hello";
    NotificationManager notificationManager;
    int notifyID = 1;
    String CHANNEL_ID = "my_channel_01";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sample);
        ButterKnife.bind(SampleActivity.this);
        notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        /*btnClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String message = edtMessage.getText().toString().trim();
                sendNotification(message);
            }
        });*/
    }

    private void sendNotification(String messageBody) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Intent intent = new Intent(SampleActivity.this, SampleActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pendingIntent = PendingIntent.getActivity(SampleActivity.this, 0 , intent,
                    PendingIntent.FLAG_ONE_SHOT);

            Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(SampleActivity.this)
                    .setSmallIcon(R.drawable.ic_search)
                    .setContentTitle("Member App")
                    .setContentText(messageBody)
                    .setAutoCancel(true)
                    .setSound(defaultSoundUri)
                    .setContentIntent(pendingIntent);

            NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.notify(0 , notificationBuilder.build());
        }

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            int notifyID = 1;
            String CHANNEL_ID = "my_channel_01";
            CharSequence name = "MemberAPP";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel mChannel = new NotificationChannel(CHANNEL_ID, name, importance);
            Notification notification =
                    new NotificationCompat.Builder(this)
                            .setSmallIcon(R.drawable.ic_search)
                            .setContentTitle("Member App")
                            .setContentText(messageBody)
                            .setChannelId(CHANNEL_ID).build();

            NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            mNotificationManager.createNotificationChannel(mChannel);
            mNotificationManager.notify(notifyID, notification);
        }

        /*String ns = Context.NOTIFICATION_SERVICE;
        NotificationManager mNotificationManager = (NotificationManager) getSystemService(ns);
        int icon = R.drawable.ic_search;
        long when = System.currentTimeMillis();

        Notification notification = new Notification(icon, tickerText, when);
        CharSequence contentTitle = "Member App";
        Intent notificationIntent = new Intent(this, SampleActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(SampleActivity.this)
                .setSmallIcon(R.drawable.ic_search)
                .setContentTitle(contentTitle)
                .setContentText(messageBody)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent);

        mNotificationManager.notify(HELLO_ID, notificationBuilder.build());*/

        /*int notificationID = 101;
        String channelID = "com.wps.memberapp";
        Notification notification = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            notification = new Notification.Builder(SampleActivity.this,
                    channelID)
                    .setContentTitle("New Message")
                    .setContentText(messageBody)
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setChannelId(channelID)
                    .build();
        }
        notificationManager.notify(notificationID, notification);*/
    }
}
