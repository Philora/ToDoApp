package com.wps.memberapp.presentation.splash.activity;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

//import com.ibm.mobilefirstplatform.clientsdk.android.logger.api.Logger;
import com.wps.memberapp.R;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;


public class SplashScreenActivity extends Activity {

    /**
     * To send and process Message and Runnable objects associated
     * with a thread's MessageQueue.
     */

    private final Handler mHandler = new Handler();
    private final Runnable mRunnable = new Runnable() {
        @Override
        public void run() {
            SharedPreferenceHelper.getInstance().setPrefBoolean(SplashScreenActivity.this, getString(R.string.firstRun), false);
            Intent intent = new Intent(SplashScreenActivity.this, LanguageActivity.class);
            startActivity(intent);
            finish();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        startSplash();
    }

    /**
     * This functions is used to start the splash screen
     */
    private void startSplash() {
    /*
    time duration for splash screen..
   */
        int timeOut = 2000;
        try {
            mHandler.postDelayed(mRunnable, timeOut);
        } catch (Exception e) {
//            Logger.getLogLevel();
        }
    }
}
