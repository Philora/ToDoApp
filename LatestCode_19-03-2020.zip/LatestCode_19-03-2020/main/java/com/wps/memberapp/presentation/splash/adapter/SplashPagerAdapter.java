package com.wps.memberapp.presentation.splash.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.presentation.login.activity.LoginActivity;

/**
 * This adapter is used to display welcome pages in PagerActivity.
 */
public class SplashPagerAdapter extends PagerAdapter {
    private final LayoutInflater mInflater;
    private final Context mContext;

    public SplashPagerAdapter(Context context) {
        mContext = context;
        mInflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup view, int position) {
        View imageLayout;
        switch (position) {
            case 0:
                imageLayout = mInflater.inflate(R.layout.splash_pager_item1, view, false);
                break;
            case 1:
                imageLayout = mInflater.inflate(R.layout.splash_pager_item2, view, false);
                break;
            case 2:
                imageLayout = mInflater.inflate(R.layout.splash_pager_item3, view, false);
                break;
            default:
                imageLayout = mInflater.inflate(R.layout.splash_pager_item1, view, false);
                break;
        }
        TextView login = imageLayout.findViewById(R.id.login);
        assert login != null;
        login.setPaintFlags(login.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        login.setOnClickListener(view1 -> {
            mContext.startActivity(new Intent(mContext, LoginActivity.class));
            ((Activity) mContext).finish();
        });
        view.addView(imageLayout, 0);
        return imageLayout;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((View) object);
    }

    @Override
    public int getCount() {
        return 3;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view.equals(object);
    }
}
