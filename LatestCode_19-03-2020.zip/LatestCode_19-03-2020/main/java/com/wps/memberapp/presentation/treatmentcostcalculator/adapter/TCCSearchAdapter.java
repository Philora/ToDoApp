package com.wps.memberapp.presentation.treatmentcostcalculator.adapter;


import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.TextView;
import android.widget.Toast;

import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.GetProcedureCode;
import com.wps.memberapp.data.model.PlanList;

import java.util.ArrayList;
import java.util.List;

import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;

public class TCCSearchAdapter extends RecyclerView.Adapter<TCCSearchAdapter.ViewHolder> {
    private final Activity activity;
    View v;
    OnItemClickListener onItemClickListner;

    private List<GetProcedureCode> tccSearchList;
    private List<GetProcedureCode> tccSearchListFilter;

    public TCCSearchAdapter(Activity appContext, List<GetProcedureCode> tccSearchList, OnItemClickListener onItemClickListner) {
        this.activity = appContext;
        this.tccSearchList = tccSearchList;
        this.tccSearchListFilter = tccSearchList;
        this.onItemClickListner = onItemClickListner;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        v = inflater.inflate(R.layout.search_item_text, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        try {
            if (tccSearchListFilter != null && !tccSearchListFilter.isEmpty()) {
                GetProcedureCode mTccSearchList = tccSearchListFilter.get(position);
                if (mTccSearchList.getLabel() != null) {
                    holder.txtName.setText(mTccSearchList.getLabel());
                }
                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        onItemClickListner.onItemClicked(position, tccSearchListFilter.get(position).getLabel());
                        String mProExtraInfo = tccSearchListFilter.get(position).getProcCodeExtraInfo();
                        String mProcCode = tccSearchListFilter.get(position).getProcCode();
                        ProfileDataCache.getInstance().setProcCodeExtraInfo(mProExtraInfo);
//                        Toast.makeText(activity, mProcCode, Toast.LENGTH_LONG).show();
                        ProfileDataCache.getInstance().setProcCode(mProcCode);
                    }
                });
            }
        } catch(Exception e){
            e.getLocalizedMessage();
        }
    }

    @Override
    public int getItemCount() {
        if (tccSearchListFilter != null) {
            return tccSearchListFilter.size();
        } else {
            return 0;
        }
    }

    public interface OnItemClickListener {
        void onItemClicked(int position, String mTccSearchList);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.txt_name)
        TextView txtName;

        public ViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}

