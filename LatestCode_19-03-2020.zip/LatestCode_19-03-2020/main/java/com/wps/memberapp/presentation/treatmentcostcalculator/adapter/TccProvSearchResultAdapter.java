package com.wps.memberapp.presentation.treatmentcostcalculator.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.model.TCCData;
import com.wps.memberapp.presentation.providersearch.activity.MapActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Pattern;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

public class TccProvSearchResultAdapter extends RecyclerView.Adapter<TccProvSearchResultAdapter.SearchViewHolder> {

    private final Context mCtx;
    List<TCCData> mTccProvList;

    public TccProvSearchResultAdapter(Activity mCtx, List<TCCData> mTccProvList) {
        this.mCtx = mCtx;
        this.mTccProvList = mTccProvList;
    }

    @NonNull
    @Override
    public SearchViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.found_provider_search_data_item, parent, false);
        return new SearchViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SearchViewHolder holder, final int position) {
        final TCCData tccResult = mTccProvList.get(position);
        String mZipCode = "";
        String mFirstName = "";
        String mLastName = "";
        if (tccResult != null) {
            //Binding the data with the viewHolder views
            if (tccResult.getFirstName() != null && !tccResult.getFirstName().isEmpty() && !tccResult.getFirstName().equalsIgnoreCase("null")) {
                mFirstName = tccResult.getFirstName();
            }
            if (tccResult.getLastName() != null && !tccResult.getLastName().isEmpty() && !tccResult.getLastName().equalsIgnoreCase("null")) {
                mLastName = tccResult.getLastName();
            }
            holder.txtTccName.setText(mFirstName + " " + mLastName);

            if (tccResult.getAvgAmount() != null) {
                holder.txtTccProvAvgCost.setText("$" + tccResult.getAvgAmount());
            }
            if (tccResult.getTccProvAddress().getAddress1() != null && !tccResult.getTccProvAddress().getAddress1().isEmpty() && !tccResult.getTccProvAddress().getAddress1().equalsIgnoreCase("null")) {
                holder.txtTccProvAddress.setText(tccResult.getTccProvAddress().getAddress1());
            }
            if (tccResult.getTccProvAddress().getZipCode() != null && !tccResult.getTccProvAddress().getZipCode().isEmpty() && !tccResult.getTccProvAddress().getZipCode().equalsIgnoreCase("null")) {
                mZipCode = tccResult.getTccProvAddress().getZipCode();
            }
            if (tccResult.getTccProvAddress().getState() != null && !tccResult.getTccProvAddress().getState().isEmpty() && !tccResult.getTccProvAddress().getState().equalsIgnoreCase("null")) {
                holder.txtTccProvState.setText(tccResult.getTccProvAddress().getState() + ", " + mZipCode);
            }
            if (tccResult.getGeoDistance() != null) {
                holder.txtTccProvMiles.setText(tccResult.getGeoDistance() + " Miles");
            }

            holder.txtTccProvClinicMap.setOnClickListener(view -> {
                Intent intent = new Intent(mCtx, MapActivity.class);
                if (tccResult != null) {
                    if (tccResult.getLatitude() != null) {
                        intent.putExtra("latitude", tccResult.getLatitude());
                    }
                    if (tccResult.getLongitude() != null) {
                        intent.putExtra("longitude", tccResult.getLongitude());
                    }
                }
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                mCtx.startActivity(intent);
            });


            // TCC Enhancement - 17-03-2020
            if (tccResult.getDrugName() != null && !tccResult.getDrugName().isEmpty() && !tccResult.getDrugName().equalsIgnoreCase("null")) {
                holder.crdviewPharm.setVisibility(View.VISIBLE);
                holder.crdviewMedDent.setVisibility(View.GONE);
                holder.txtTccDrugName.setText(tccResult.getDrugName());
            } else {
                holder.crdviewMedDent.setVisibility(View.VISIBLE);
                holder.crdviewPharm.setVisibility(View.GONE);
            }
            if (tccResult.getStrength() != null && !tccResult.getStrength().isEmpty() && !tccResult.getStrength().equalsIgnoreCase("null")) {
                holder.txtTccDrugStrength.setText(tccResult.getStrength());
            }
            if (tccResult.getQuantity() != null && !tccResult.getQuantity().isEmpty() && !tccResult.getQuantity().equalsIgnoreCase("null")) {
                String[] parts = tccResult.getQuantity().split(Pattern.quote("("));
                String mStr1 = parts[0];
                holder.txtTccQtyDesc.setText(mStr1); // Split the values and show qty / desc
            }
            if (tccResult.getAvgAmount() != null) {
                holder.txtTccDrugEstCost.setText("$" + tccResult.getAvgAmount());
            }
        }
    }

    @Override
    public int getItemCount() {
        if (mTccProvList != null) {
            return mTccProvList.size();
        } else {
            return 0;
        }
    }

    class SearchViewHolder extends RecyclerView.ViewHolder {

        final TextView txtTccName;
        final TextView txtTccProvAvgCost;
        final TextView txtTccProvAddress;
        final TextView txtTccProvState;
        final TextView txtTccProvClinicMap;
        final TextView txtTccProvMiles;
        CardView crdviewMedDent;
        CardView crdviewPharm;
        final TextView txtTccDrugName;
        final TextView txtTccDrugStrength;
        final TextView txtTccQtyDesc;
        final TextView txtTccDrugEstCost;


        private SearchViewHolder(@NonNull View itemView) {
            super(itemView);
            txtTccName = itemView.findViewById(R.id.txt_TccProvName);
            txtTccProvAvgCost = itemView.findViewById(R.id.txt_TccProvAvgCost);
            txtTccProvAddress = itemView.findViewById(R.id.txt_TccProvAddress);
            txtTccProvState = itemView.findViewById(R.id.txt_TccProvState);
            txtTccProvClinicMap = itemView.findViewById(R.id.txt_TccProvMap);
            txtTccProvMiles = itemView.findViewById(R.id.txt_TccProvMiles);
            crdviewMedDent = itemView.findViewById(R.id.crdview_MedDent);
            crdviewPharm = itemView.findViewById(R.id.crdview_Pharm);
            txtTccDrugName = itemView.findViewById(R.id.txt_TccDrugName);
            txtTccDrugStrength = itemView.findViewById(R.id.txt_TccDrugStrength);
            txtTccQtyDesc = itemView.findViewById(R.id.txt_TccQtyDesc);
            txtTccDrugEstCost = itemView.findViewById(R.id.txt_TccDrugEstCost);
        }
    }
}