package com.wps.memberapp.presentation.treatmentcostcalculator.fragment;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.AccountBalance;
import com.wps.memberapp.data.model.GetMemberOOPReponse;
import com.wps.memberapp.data.model.GetProcedureCode;
import com.wps.memberapp.data.model.GetTreatmentCost;
import com.wps.memberapp.presentation.base.BaseFragment;
import com.wps.memberapp.presentation.treatmentcostcalculator.adapter.TCCSearchAdapter;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

public class TCCFragment extends BaseFragment implements TCCSearchView {

    @BindView(R.id.btn_tcc_search)
    Button btnTccSearch;
    private Unbinder mUnbinder;
    TCCSearchPresenter tccSearchPresenter;
    @BindView(R.id.search_view_medical)
    SearchView svMedical;
    @BindView(R.id.rv_search_result_medical)
    RecyclerView rvSearchMedical;
    @BindView(R.id.spin_TCCMiles)
    Spinner spinTCCMiles;
    private String mTCCMiles = "";
    private String searchMedicalQuery;
    private AlertDialog dialog;
    @BindView(R.id.btn_tcc_clear)
    Button btnTccClear;
    private boolean isMedicProcedure;

    @BindView(R.id.rdGrp_Procedure)
    RadioGroup rdGrpProcedure;
    private RadioButton rdButton;

    @BindView(R.id.ll_Pharmacy)
    LinearLayout llPharmacy;
    @BindView(R.id.ll_MedDent)
    LinearLayout llMedDent;
    @BindView(R.id.edt_Strength)
    EditText edtStrength;

    String mRdBtnSelected;
    int selectedId;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.treatment_cost_fragment, container, false);
        mUnbinder = ButterKnife.bind(this, rootView);

        if (getActivity() != null) {
            ImageView imageViewSearch = getActivity().findViewById(R.id.imageViewSearch);
            imageViewSearch.setVisibility(View.GONE);
            TextView txtDownloadPDF = getActivity().findViewById(R.id.txt_Call);
            txtDownloadPDF.setVisibility(View.GONE);
            TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
            fragmentTitle.setText(R.string.treatment_cost_calculator);
        }

        tccSearchPresenter = new TCCSearchPresenterImp();
        tccSearchPresenter.onAttach(this);
        isMedicProcedure = false;

        if (ProfileDataCache.getInstance().getAccountBalance() == null) {
            tccSearchPresenter.getTCCMemberDeductible();
        }
        if (ProfileDataCache.getInstance().getMemberOOPReponse() == null) {
            tccSearchPresenter.getTCCOOPRequest();
        }
        if (ProfileDataCache.getInstance().getGeoLat() == null && ProfileDataCache.getInstance().getGeoLong() == null) {
            tccSearchPresenter.getApplicantsGeoLocation();
        }


        selectedId = rdGrpProcedure.getCheckedRadioButtonId();
        rdButton = (RadioButton) rootView.findViewById(selectedId);
        rdButton.setChecked(true);
        try {
            if (rdButton.isChecked() == true) {
                mRdBtnSelected = rdButton.getText().toString();
                mRdBtnSelected = "Medical";
//                Toast.makeText(getActivity(), mRdBtnSelected, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.getLocalizedMessage();
        }
        rdGrpProcedure.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {
                try {
                    if (checkedId == R.id.rdBtn_Medical) {
                        mRdBtnSelected = rdButton.getText().toString();
                        mRdBtnSelected = "Medical";
                        svMedical.setQuery("", true);
                        svMedical.clearFocus();
                        edtStrength.setText("");
                        ProfileDataCache.getInstance().setSearchCityItemValue("");
                        ProfileDataCache.getInstance().setStrength("");
                        llMedDent.setVisibility(View.VISIBLE);
                        spinTCCMiles.setSelection(0);
                        llPharmacy.setVisibility(View.GONE);
//                        Toast.makeText(getActivity(), mRdBtnSelected, Toast.LENGTH_SHORT).show();
                    } else if (checkedId == R.id.rdBtn_Dental) {
                        mRdBtnSelected = rdButton.getText().toString();
                        mRdBtnSelected = "Dental";
                        svMedical.setQuery("", true);
                        svMedical.clearFocus();
                        edtStrength.setText("");
                        spinTCCMiles.setSelection(0);
                        llMedDent.setVisibility(View.VISIBLE);
                        llPharmacy.setVisibility(View.GONE);
                        ProfileDataCache.getInstance().setSearchCityItemValue("");
                        ProfileDataCache.getInstance().setStrength("");
//                        Toast.makeText(getActivity(), mRdBtnSelected, Toast.LENGTH_SHORT).show();
                    } else if (checkedId == R.id.rdBtn_Pharmacy) {
                        mRdBtnSelected = rdButton.getText().toString();
                        mRdBtnSelected = "Pharmacy";
                        svMedical.setQuery("", true);
                        svMedical.clearFocus();
                        ProfileDataCache.getInstance().setSearchCityItemValue("");
                        llPharmacy.setVisibility(View.VISIBLE);
                        llMedDent.setVisibility(View.GONE);
//                        Toast.makeText(getActivity(), mRdBtnSelected, Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
            }
        });

        svMedical.setOnQueryTextListener(new androidx.appcompat.widget.SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                try {
                    searchMedicalQuery = newText;
                    if (newText.length() > 2) {
//                    svMedical.clearFocus();
                        rvSearchMedical.setVisibility(View.VISIBLE);
                        ProfileDataCache.getInstance().setSelectedPlan(mRdBtnSelected);
                        ProfileDataCache.getInstance().setSearchMedicalQuery(searchMedicalQuery);
                        tccSearchPresenter.getProcedureCode();
                    } else {
                        rvSearchMedical.setVisibility(View.GONE);
                    }
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
                return true;
            }
        });

        spinTCCMiles.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                try {
                    if (spinTCCMiles.getSelectedItem() != null) {
                        mTCCMiles = spinTCCMiles.getSelectedItem().toString();
                        if (mTCCMiles != null && mTCCMiles.equalsIgnoreCase("10 Miles")) {
                            mTCCMiles = mTCCMiles.replace("10 Miles", "10");
                        } else if (mTCCMiles != null && mTCCMiles.equalsIgnoreCase("20 Miles")) {
                            mTCCMiles = mTCCMiles.replace("20 Miles", "20");
                        } else if (mTCCMiles != null && mTCCMiles.equalsIgnoreCase("30 Miles")) {
                            mTCCMiles = mTCCMiles.replace("30 Miles", "30");
                        } else if (mTCCMiles != null && mTCCMiles.equalsIgnoreCase("50 Miles")) {
                            mTCCMiles = mTCCMiles.replace("50 Miles", "50");
                        } else if (mTCCMiles != null && mTCCMiles.equalsIgnoreCase("99 Miles")) {
                            mTCCMiles = mTCCMiles.replace("99 Miles", "99");
                        }
                        ProfileDataCache.getInstance().setTccMiles(mTCCMiles);
                    }
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //Do something
            }
        });

        btnTccSearch.setOnClickListener((View view) -> {
            try {
                if (searchMedicalQuery != null && !searchMedicalQuery.equalsIgnoreCase("")) {
                    if (isMedicProcedure && searchMedicalQuery.length() > 3) {
                        ProfileDataCache.getInstance().setTCCProcSelected(true);
                        ProfileDataCache.getInstance().setStrength(edtStrength.getText().toString().trim());
                        tccSearchPresenter.getTreatmentCost();
                    } else {
                        showDialogError("", getActivity().getString(R.string.please_enter_valid_procedure_code));
                    }
                } else {
                    showDialogError("", getActivity().getString(R.string.please_select_procedure_code));
                }
            } catch (Exception e) {
                e.getLocalizedMessage();
            }
        });

        btnTccClear.setOnClickListener(view -> {
            svMedical.setQuery("", true);
            spinTCCMiles.setSelection(0);
            edtStrength.setText("");
            ProfileDataCache.getInstance().setStrength("");
            ProfileDataCache.getInstance().setTCCProcSelected(false);
        });
        return rootView;
    }

    private void showDialogError(String title, String string) {
        try {
            AlertDialog.Builder alret = new AlertDialog.Builder(getActivity())
                    .setTitle(title)
                    .setCancelable(false)
                    .setMessage(string)
                    .setPositiveButton(getActivity().getString(R.string.ok), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialog.dismiss();
                            svMedical.setQuery("", true);
                            svMedical.clearFocus();
                            //getActivity().getFragmentManager().popBackStack();
                        }
                    });
            dialog = alret.create();
            dialog.show();
        } catch (Exception e) {
            e.getLocalizedMessage();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUnbinder.unbind();
    }

    // Todo TCC - Deploy
    @Override
    public void onTCCSearchResponse(List<GetProcedureCode> procedureCodes) {
        try {
            if (procedureCodes != null) {
                rvSearchMedical.setHasFixedSize(true);
                rvSearchMedical.setNestedScrollingEnabled(false);
                final LinearLayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
                mLayoutManager.setOrientation(RecyclerView.VERTICAL);
                rvSearchMedical.setLayoutManager(mLayoutManager);

                TCCSearchAdapter mAdapter = new TCCSearchAdapter(getAppContext(), procedureCodes, new TCCSearchAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClicked(int position, String mMedicalList) {
                        // Handle Object of list item here
                        if (mMedicalList != null) {
                            svMedical.setQuery(mMedicalList, true);
                            svMedical.clearFocus();
                            rvSearchMedical.setVisibility(View.GONE);
                            ProfileDataCache.getInstance().setTccMedicalItem(mMedicalList);
                            isMedicProcedure = true;
                            ProfileDataCache.getInstance().setTCCProcSelected(true);
                        } else {
                            ProfileDataCache.getInstance().setTccMedicalItem("");
                            isMedicProcedure = false;
                            ProfileDataCache.getInstance().setTCCProcSelected(false);
                        }
                    }
                });
                if (isMedicProcedure) {
                    svMedical.clearFocus();
                } else {
                    getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
                }
                rvSearchMedical.setAdapter(mAdapter);
                mAdapter.notifyDataSetChanged();
            } else {
                rvSearchMedical.setVisibility(View.GONE);
//                Toast.makeText(getContext(), getString(R.string.no_data_found), Toast.LENGTH_SHORT).show();
                GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.no_data_found));
                svMedical.setQuery("", true);
                svMedical.clearFocus();
                ProfileDataCache.getInstance().setSearchCityItemValue("");
                getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

 /*   private boolean validateKeyBoard() {
        if (isMedicProcedure && ){

        }
        return true;
    }*/

    @Override
    public void onTCCMemDeductibleResponse(AccountBalance mAccountModel) {
        float inNetworkIndDeductible = Float.parseFloat(mAccountModel.getInNetworkIndDeductible());
        float inNetworkIndDeductibleSpent = Float.parseFloat(mAccountModel.getInNetworkIndDeductibleSpent());
        float deductibleInNetworkInd = inNetworkIndDeductible - inNetworkIndDeductibleSpent;

        float inNetworkFamilyDeductible = Float.parseFloat(mAccountModel.getInNetworkFamilyDeductible());
        float inNetworkFamilyDeductibleSpent = Float.parseFloat(mAccountModel.getInNetworkFamilyDeductibleSpent());
        float deductibleInNetworkFamily = inNetworkFamilyDeductible - inNetworkFamilyDeductibleSpent;

        if (deductibleInNetworkInd < deductibleInNetworkFamily) {
//            Toast.makeText(getActivity(), "DedInNetInd = " + deductibleInNetworkInd, Toast.LENGTH_SHORT).show();
            ProfileDataCache.getInstance().setDedInNetwork(String.valueOf(deductibleInNetworkInd));
        } else {
//            Toast.makeText(getActivity(), "DedInNetFamily = " + deductibleInNetworkFamily, Toast.LENGTH_SHORT).show();
            ProfileDataCache.getInstance().setDedInNetwork(String.valueOf(deductibleInNetworkFamily));
        }

        float outNetworkIndDeductible = Float.parseFloat(mAccountModel.getOutNetworkIndDeductible());
        float outNetworkIndDeductibleSpent = Float.parseFloat(mAccountModel.getOutNetworkIndDeductibleSpent());
        float dedIndOutNetworkInd = outNetworkIndDeductible - outNetworkIndDeductibleSpent;

        float outNetworkFamilyDeductible = Float.parseFloat(mAccountModel.getOutNetworkFamilyDeductible());
        float outNetworkFamilyDeductibleSpent = Float.parseFloat(mAccountModel.getOutNetworkFamilyDeductibleSpent());
        float dedIndOutNetworkFamily = outNetworkFamilyDeductible - outNetworkFamilyDeductibleSpent;

        if (dedIndOutNetworkInd < dedIndOutNetworkFamily) {
//            Toast.makeText(getActivity(), "DedOutNet OP Ind = " + dedIndOutNetworkInd, Toast.LENGTH_LONG).show();
            ProfileDataCache.getInstance().setDedOutNetwork(String.valueOf(dedIndOutNetworkInd));
        } else {
//            Toast.makeText(getActivity(), "DedOOP Family = " + dedIndOutNetworkFamily, Toast.LENGTH_LONG).show();
            ProfileDataCache.getInstance().setDedOutNetwork(String.valueOf(dedIndOutNetworkFamily));
        }
    }

    @Override
    public void onTCCOOPResponse(GetMemberOOPReponse memberOOPReponse) {
        float inNetworkIndOOP = Float.parseFloat(memberOOPReponse.getBenfAccumulators().getInNetworkIndOOP());
        float inNetworkIndOOPSpent = Float.parseFloat(memberOOPReponse.getBenfAccumulators().getInNetworkIndOOPSpent());
        float InNetworkInd = inNetworkIndOOP - inNetworkIndOOPSpent;

        float inNetworkFamilyOOP = Float.parseFloat(memberOOPReponse.getBenfAccumulators().getInNetworkFamilyOOP());
        float inNetworkFamilyOOPSpent = Float.parseFloat(memberOOPReponse.getBenfAccumulators().getInNetworkFamilyOOPSpent());
        float InNetworkFamily = inNetworkFamilyOOP - inNetworkFamilyOOPSpent;

        if (InNetworkInd < InNetworkFamily) {
//            Toast.makeText(getActivity(), "InNetInd = " + InNetworkInd, Toast.LENGTH_SHORT).show();
            ProfileDataCache.getInstance().setOopInNetwork(String.valueOf(InNetworkInd));
        } else {
//            Toast.makeText(getActivity(), "InNetFamily = " + InNetworkFamily, Toast.LENGTH_SHORT).show();
            ProfileDataCache.getInstance().setOopInNetwork(String.valueOf(InNetworkFamily));
        }

        float outNetworkIndOOP = Float.parseFloat(memberOOPReponse.getBenfAccumulators().getOutNetworkIndOOP());
        float outNetworkIndOOPSpent = Float.parseFloat(memberOOPReponse.getBenfAccumulators().getOutNetworkIndOOPSpent());
        float oopNetworkInd = outNetworkIndOOP - outNetworkIndOOPSpent;

        float outNetworkFamilyOOP = Float.parseFloat(memberOOPReponse.getBenfAccumulators().getOutNetworkFamilyOOP());
        float outNetworkFamilyOOPSpent = Float.parseFloat(memberOOPReponse.getBenfAccumulators().getOutNetworkFamilyOOPSpent());
        float oopNetworkFamily = outNetworkFamilyOOP - outNetworkFamilyOOPSpent;

        if (oopNetworkInd < oopNetworkFamily) {
//            Toast.makeText(getActivity(), "OutNet OP Ind = " + oopNetworkInd, Toast.LENGTH_LONG).show();
            ProfileDataCache.getInstance().setOopOutNetwork(String.valueOf(oopNetworkInd));
        } else {
//            Toast.makeText(getActivity(), "OOP Family = " + oopNetworkFamily, Toast.LENGTH_LONG).show();
            ProfileDataCache.getInstance().setOopOutNetwork(String.valueOf(oopNetworkFamily));
        }
    }

    @Override
    public void onTreatmentCostResponse(GetTreatmentCost mTreatmentCost) {
        try {
            String mResTCCAvg = String.valueOf(mTreatmentCost.getTotalAvgCost());
            if (mTreatmentCost.getTCCDatas() != null && mTreatmentCost.getTCCDatas().size() > 0) {
                svMedical.setQuery("", true);
                svMedical.clearFocus();
                spinTCCMiles.setSelection(0);
                ProfileDataCache.getInstance().setTCCProcSelected(false);
                ProfileDataCache.getInstance().setStrength("");
                TCCSearchDetail fragment2 = new TCCSearchDetail();
                edtStrength.setText("");
                FragmentManager manager = getFragmentManager();
                manager.beginTransaction().replace(R.id.frame_container, fragment2).addToBackStack(null).commit();
            } else if (mResTCCAvg != null && !mResTCCAvg.isEmpty() && !mResTCCAvg.equalsIgnoreCase("0.0")) {
                svMedical.setQuery("", true);
                svMedical.clearFocus();
                spinTCCMiles.setSelection(0);
                ProfileDataCache.getInstance().setTCCProcSelected(false);
                ProfileDataCache.getInstance().setStrength("");
                TCCSearchDetail fragment2 = new TCCSearchDetail();
                edtStrength.setText("");
                FragmentManager manager = getFragmentManager();
                manager.beginTransaction().replace(R.id.frame_container, fragment2).addToBackStack(null).commit();
            } else {
                GeneralUtils.showAlertDialog(getActivity(), getActivity().getString(R.string.no_search_results));
                svMedical.setQuery("", true);
                edtStrength.setText("");
            }
        } catch (Exception e) {
            e.getLocalizedMessage();
        }
    }
}
