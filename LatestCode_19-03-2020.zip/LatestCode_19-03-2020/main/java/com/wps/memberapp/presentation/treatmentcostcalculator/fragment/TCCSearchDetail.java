package com.wps.memberapp.presentation.treatmentcostcalculator.fragment;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.GetProcedureCode;
import com.wps.memberapp.data.model.GetTreatmentCost;
import com.wps.memberapp.presentation.base.BaseFragment;
import com.wps.memberapp.presentation.treatmentcostcalculator.adapter.TccProvSearchResultAdapter;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

public class TCCSearchDetail extends BaseFragment {
    private Unbinder mUnbinder;
    GetTreatmentCost getTreatmentCost;
    @BindView(R.id.ll_Data_Found)
    LinearLayout llDataFound;
    @BindView(R.id.txt_FoundData)
    TextView txtFoundData;
    @BindView(R.id.txt_Tcc_Medical_Item)
    TextView txtMedicalItem;
    @BindView(R.id.txt_TotalAvgCost)
    TextView txtTotalAvgCost;
    @BindView(R.id.txt_InNetworkTotalAvgCostAdjust)
    TextView txtInNetworkTotalAvgCostAdjust;
    @BindView(R.id.txt_OutOfNetworkTotalAvgCostAdjust)
    TextView txtOutOfNetworkTotalAvgCostAdjust;

    @BindView(R.id.txt_InNetwork)
    TextView txtInNetwork;
    @BindView(R.id.txt_OutOfNetwork)
    TextView txtOutOfNetwork;

    @BindView(R.id.ll_InNetwork)
    LinearLayout lLInNetwork;
    @BindView(R.id.ll_OutOfNetwork)
    LinearLayout lLOutOfNetwork;

    @BindView(R.id.txt_remain_deductible_InNetwork)
    TextView txtDeductibleInNetwork;
    @BindView(R.id.txt_remain_deductible_OutOfNetwork)
    TextView txtDeductibleOutNetwork;

    @BindView(R.id.txt_OOP_InNetwork)
    TextView txtOOPInNetwork;
    @BindView(R.id.txt_OOP_OutOfNetwork)
    TextView txtOOPOutOfNetwork;

    @BindView(R.id.rv_tccSearchResults)
    RecyclerView rvTccSearchResults;

    @BindView(R.id.crdview_treatmentCost)
    CardView crdviewTreatmentCost;

    private boolean isInNetWorkSelected = true;
    private boolean isOutNetWorkSelected = true;
    String mProcExtraInfo;
    List<GetProcedureCode> mProcedureCode;
    int mTotalAvgCostInt;
    private AlertDialog dialog;
    Double mTotalAvgCost;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.treatment_cost_search_detail, container, false);
        mUnbinder = ButterKnife.bind(this, rootView);
        if (getActivity() != null) {
            ImageView imageViewSearch = getActivity().findViewById(R.id.imageViewSearch);
            imageViewSearch.setVisibility(View.GONE);
            TextView txtDownloadPDF = getActivity().findViewById(R.id.txt_Call);
            txtDownloadPDF.setVisibility(View.GONE);
            TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
            fragmentTitle.setText(R.string.treatment_cost_calculator);
        }

        getTreatmentCost = ProfileDataCache.getInstance().getTCCResponse();

        mProcExtraInfo = ProfileDataCache.getInstance().getProcCodeExtraInfo();
        if (mProcExtraInfo != null && !mProcExtraInfo.equalsIgnoreCase("")) {
            showDialogError(getActivity().getString(R.string.did_you_know), mProcExtraInfo);
        }

        try {
            String mTctMedicalItem = ProfileDataCache.getInstance().getTccMedicalItem();
            if (mTctMedicalItem != null) {
                String sLower = mTctMedicalItem.toLowerCase();
                String sTapCapSentence = sLower.substring(0, 9).toUpperCase();
                String mResCapSentence = sTapCapSentence + sLower.substring(9);
                txtMedicalItem.setText(mResCapSentence);
            }
        } catch (Exception e) {
            e.getLocalizedMessage();
        }

        // Old Code
        try {
            Double mTotalAvgCost = getTreatmentCost.getTotalAvgCost();

            String mSelectedPlan = ProfileDataCache.getInstance().getSelectedPlan();
            if (mSelectedPlan.equalsIgnoreCase("Pharmacy")) {
                crdviewTreatmentCost.setVisibility(View.GONE);
            } else {
                crdviewTreatmentCost.setVisibility(View.VISIBLE);
            }

            mTotalAvgCostInt = (int) Math.round(mTotalAvgCost);
            txtTotalAvgCost.setText(String.valueOf("$" + mTotalAvgCostInt + ".00"));
        } catch (Exception e) {
            e.getLocalizedMessage();
        }

        // tried Code
        /*try {
            mTotalAvgCost = getTreatmentCost.getTotalAvgCost();
            mTotalAvgCostInt = (int) Math.round(mTotalAvgCost);

            if (mTotalAvgCost.equals(0)) {
                txtTotalAvgCost.setText("$0.00");
            } else {
                txtTotalAvgCost.setText(String.valueOf("$" + mTotalAvgCostInt));
            }
        } catch (Exception e) {
            Logger.e(StringConstants.EXCEPTION, e);
        }*/

        if (getTreatmentCost.getTCCDatas() != null && !getTreatmentCost.getTCCDatas().isEmpty()) {
            llDataFound.setVisibility(View.VISIBLE);
            txtFoundData.setText(getActivity().getString(R.string.txt_found) + " " + getTreatmentCost.getTotalCount() + " " + getActivity().getString(R.string.matches));
            /*txtFoundData.setPaintFlags(txtFoundData.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
            txtFoundData.setOnClickListener(view -> {
                TCCSearchDetailList fragment2 = new TCCSearchDetailList();
                FragmentManager manager = getFragmentManager();
                manager.beginTransaction().replace(R.id.frame_container, fragment2).addToBackStack(null).commit();
            });*/
        } else {
            llDataFound.setVisibility(View.GONE);
        }

        txtInNetwork.setOnClickListener(view -> {
            if (isInNetWorkSelected) {
                //InNet
                txtInNetwork.setBackground(ContextCompat.getDrawable(getActivity(), R.drawable.button_pressed));
                txtInNetwork.setTextColor(Color.WHITE);
                lLInNetwork.setVisibility(View.VISIBLE);
                txtInNetwork.setPadding(15, 15, 15, 15);
                // OOP
                txtOutOfNetwork.setBackground(ContextCompat.getDrawable(getActivity(), R.drawable.button_selector));
                txtOutOfNetwork.setTextColor(ResourcesCompat.getColor(getResources(), R.color.colorPrimary, null));
                lLOutOfNetwork.setVisibility(View.GONE);
                txtOutOfNetwork.setVisibility(View.VISIBLE);
                txtOutOfNetwork.setPadding(15, 15, 15, 15);
                isInNetWorkSelected = false;
                isOutNetWorkSelected = true;
            }
        });

        txtOutOfNetwork.setOnClickListener(view -> {
            if (isOutNetWorkSelected) {
                // OOP
                txtOutOfNetwork.setBackground(ContextCompat.getDrawable(getActivity(), R.drawable.button_pressed));
                txtOutOfNetwork.setTextColor(Color.WHITE);
                lLOutOfNetwork.setVisibility(View.VISIBLE);
                txtOutOfNetwork.setVisibility(View.VISIBLE);
                txtOutOfNetwork.setPadding(15, 15, 15, 15);
                //InNet
                txtInNetwork.setBackground(ContextCompat.getDrawable(getActivity(), R.drawable.button_selector));
                txtInNetwork.setTextColor(ResourcesCompat.getColor(getResources(), R.color.colorPrimary, null));
                lLInNetwork.setVisibility(View.GONE);
                txtInNetwork.setPadding(15, 15, 15, 15);
                isOutNetWorkSelected = false;
                isInNetWorkSelected = true;
            }
        });

        String mDedInNetwork = ProfileDataCache.getInstance().getDedInNetwork();
        String mDedOutNetwork = ProfileDataCache.getInstance().getDedOutNetwork();
        if (ProfileDataCache.getInstance().getDedInNetwork() != null && mDedInNetwork.contains(".0")) {
            mDedInNetwork = mDedInNetwork.replace(".0", ".00");
            txtDeductibleInNetwork.setText("$" + mDedInNetwork);
        }
        if (ProfileDataCache.getInstance().getDedOutNetwork() != null && mDedOutNetwork.contains(".0")) {
            mDedOutNetwork = mDedOutNetwork.replace(".0", ".00");
            txtDeductibleOutNetwork.setText("$" + mDedOutNetwork);
        }

        String mOopInNetwork = ProfileDataCache.getInstance().getOopInNetwork();
        String mOopOutNetwork = ProfileDataCache.getInstance().getOopOutNetwork();
        if (ProfileDataCache.getInstance().getOopInNetwork() != null && mOopInNetwork.contains(".0")) {
            mOopInNetwork = mOopInNetwork.replace(".0", ".00");
            txtOOPInNetwork.setText("$" + mOopInNetwork);
        }
        if (ProfileDataCache.getInstance().getOopOutNetwork() != null && mOopOutNetwork.contains(".0")) {
            mOopOutNetwork = mOopOutNetwork.replace(".0", ".00");
            txtOOPOutOfNetwork.setText("$" + mOopOutNetwork);
        }

        if (!mOopInNetwork.equalsIgnoreCase("")) {
            if (Double.parseDouble(mOopInNetwork) > mTotalAvgCostInt) {
                txtInNetworkTotalAvgCostAdjust.setText(String.valueOf("$" + mTotalAvgCostInt + ".00"));
            } else {
                txtInNetworkTotalAvgCostAdjust.setText(String.valueOf("$" + Double.parseDouble(mOopInNetwork)));
            }
        }

        if (!mOopOutNetwork.equalsIgnoreCase("")) {
            if (Double.parseDouble(mOopOutNetwork) > mTotalAvgCostInt) {
                txtOutOfNetworkTotalAvgCostAdjust.setText(String.valueOf("$" + mTotalAvgCostInt + ".00"));
            } else {
                txtOutOfNetworkTotalAvgCostAdjust.setText(String.valueOf("$" + Double.parseDouble(mOopOutNetwork)));
            }
        }

        rvTccSearchResults.setHasFixedSize(true);
        final LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        rvTccSearchResults.setLayoutManager(layoutManager);
        if (getTreatmentCost != null && getTreatmentCost.getTCCDatas() != null) {
            TccProvSearchResultAdapter adapter = new TccProvSearchResultAdapter(getActivity(), getTreatmentCost.getTCCDatas());
            rvTccSearchResults.setItemAnimator(new DefaultItemAnimator());
            rvTccSearchResults.setAdapter(adapter);
            adapter.notifyDataSetChanged();
        }

        return rootView;
    }

    private void showDialogError(String title, String string) {
        try {
            AlertDialog.Builder alret = new AlertDialog.Builder(getActivity())
                    .setTitle(title)
                    .setCancelable(false)
                    .setMessage(string)
                    .setPositiveButton(getActivity().getString(R.string.close), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialog.dismiss();
                        }
                    });
            dialog = alret.create();
            dialog.show();
        } catch (Exception e) {
            e.getLocalizedMessage();
        }
    }

    /*private int getConvertValue(String mResValue) {
        try {
            if (mResValue.contains(".0")) {
                mResValue = mResValue.replace(".0", "");
                return Integer.parseInt(mResValue);
            }
        } catch (Exception e) {
		e.getLocalizedMessage();
        }
        return 0;
    }*/

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUnbinder.unbind();
    }
}
