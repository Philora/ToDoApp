package com.wps.memberapp.presentation.treatmentcostcalculator.fragment;

import com.wps.memberapp.presentation.base.MvpPresenter;

interface TCCSearchPresenter extends MvpPresenter {

    void getProcedureCode();

    void getTCCMemberDeductible();

    void getTCCOOPRequest();

    void getTreatmentCost();

    void getApplicantsGeoLocation();
}
