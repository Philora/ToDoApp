package com.wps.memberapp.presentation.treatmentcostcalculator.fragment;

import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.AccountBalance;
import com.wps.memberapp.data.model.AccountBalanceOOP;
import com.wps.memberapp.data.model.ApplicantGeoLocation;
import com.wps.memberapp.data.model.GetMemberOOPReponse;
import com.wps.memberapp.data.model.GetProcedureCode;
import com.wps.memberapp.data.model.GetTreatmentCost;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.base.MvpView;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class TCCSearchPresenterImp implements TCCSearchPresenter {
    private MvpView mView;

    @Override
    public void onAttach(MvpView mView) {
        this.mView = mView;
    }

    @Override
    public void getProcedureCode() {
        mView.showProgress();
        VolleyService.getProcedureCodes(mView.getAppContext(), AppConstants.GET_PROCEDURE_CODES, new VolleyResponseListener() {
            public void onResponse(String response) {
                List<GetProcedureCode> procedureCodes = new ArrayList<>();
                mView.hideProgress();
                //Processing the response
                if (response != null) {
                    try {
                        Gson gson = new Gson();
                        JSONArray jsonArray = new JSONArray(response);
                        for (int i = 0; i < jsonArray.length(); i++) {
                            GetProcedureCode details = gson.fromJson(jsonArray.getString(i), GetProcedureCode.class);
                            procedureCodes.add(details);
                        }
                        ProfileDataCache.getInstance().setProcedureCodes(procedureCodes);
                        ((TCCSearchView) mView).onTCCSearchResponse(procedureCodes);
                    } catch (Exception e) {
                        Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
                    }
                }
            }

            @Override
            public void onError(String error) {
                mView.hideProgress();
            }
        });
    }

    @Override
    public void getTCCMemberDeductible() {
        mView.showProgress();
        //Sending API request to get the account balance of the user
        VolleyService.getMemberDeductible(mView.getAppContext(), AppConstants.GET_MEMBER_DEDUCTIBLE, new VolleyResponseListener() { // GET_ACCOUNT_BALANCE
            @Override
            public void onError(String error) {
                Log.d("deductible response",error);

            }

            @Override
            public void onResponse(String response) {
                mView.hideProgress();
                //Processing the response
                if (response != null && response.length() > 0) {
                    try {
                        Log.d("deductible response","deductibke");
                        Gson gson = new GsonBuilder().create();
                        String jsonObject = new JSONObject(response).get(StringConstants.BENEFITS_KEY).toString();
                        AccountBalance mAccountModel = gson.fromJson(jsonObject, AccountBalance.class);
                        ProfileDataCache.getInstance().setAccountBalance(mAccountModel);
                        ((TCCSearchView) mView).onTCCMemDeductibleResponse(mAccountModel);
                    } catch (Exception e) {
                        e.getLocalizedMessage();
                    }
                }
            }
        });
    }

    @Override
    public void getTCCOOPRequest() {
        mView.showProgress();
        //Sending API request to get the account balance of the user
        VolleyService.getTCCOOP(mView.getAppContext(), AppConstants.GET_MEMBER_OOP, new VolleyResponseListener() { // GET_ACCOUNT_BALANCE_OOP
            @Override
            public void onError(String error) {
                Log.d("deductible response",error.toString());

            }

            @Override
            public void onResponse(String response) {
                mView.hideProgress();
                //Processing the response
                if (response != null && response.length() > 0) {
                    try {
                        Gson gson = new GsonBuilder().create();
                        String jsonObject = new JSONObject(response).toString();
                        GetMemberOOPReponse memberOOPReponse = gson.fromJson(jsonObject, GetMemberOOPReponse.class);
                        ProfileDataCache.getInstance().setMemberOOPReponse(memberOOPReponse);
                        ((TCCSearchView) mView).onTCCOOPResponse(memberOOPReponse);
                    } catch (Exception e) {
                       e.getLocalizedMessage();
                    }
                }
            }
        });

    }

    @Override
    public void getApplicantsGeoLocation() {
        VolleyService.getApplicantsLocation(mView.getAppContext(), AppConstants.APPLICANTS_GEO_LOCATION, new VolleyResponseListener() {
            @Override
            public void onResponse(String response) {
                mView.hideProgress();
                try {
                    //Processing the response
                    Log.i("Claim response", StringConstants.RESPONSE);
                    if (response != null && response.length() > 0) {
                        ApplicantGeoLocation model = new Gson().fromJson(response, ApplicantGeoLocation.class);
                        ProfileDataCache.getInstance().setGeoLat(model.getLatitude());
                        ProfileDataCache.getInstance().setGeoLong(model.getLongitude());
                    }
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
            }

            @Override
            public void onError(String error) {
                mView.hideProgress();
                Log.d("OOP response",error);
            }
        });
    }

    @Override
    public void getTreatmentCost() {
        mView.showProgress();
        VolleyService.getTreatmentCostRequest(mView.getAppContext(), AppConstants.GET_TREATMENT_COST, new VolleyResponseListener() {
            public void onResponse(String response) {
                mView.hideProgress();
                //Processing the response
                if (response != null && response.length() > 0) {
                    try {
                        Gson gson = new GsonBuilder().create();
                        String jsonObject = new JSONObject(response).toString();
                        GetTreatmentCost mTreatmentCost = gson.fromJson(jsonObject, GetTreatmentCost.class);
                        ProfileDataCache.getInstance().setTCCResponse(mTreatmentCost);
                        ((TCCSearchView) mView).onTreatmentCostResponse(mTreatmentCost);
                    } catch (Exception e) {
                        e.getLocalizedMessage();
                    }
                }
            }

            @Override
            public void onError(String error) {
                mView.hideProgress();
            }
        });
    }

    @Override
    public void onDetach() {
        mView = null;
    }

}
