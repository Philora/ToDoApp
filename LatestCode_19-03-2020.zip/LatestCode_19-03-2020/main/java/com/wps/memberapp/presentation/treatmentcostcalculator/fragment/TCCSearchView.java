package com.wps.memberapp.presentation.treatmentcostcalculator.fragment;

import com.wps.memberapp.data.model.AccountBalance;
import com.wps.memberapp.data.model.AccountBalanceOOP;
import com.wps.memberapp.data.model.GetMemberOOPReponse;
import com.wps.memberapp.data.model.GetProcedureCode;
import com.wps.memberapp.data.model.GetTreatmentCost;

import java.util.List;

interface TCCSearchView {

    void onTCCSearchResponse(List<GetProcedureCode> procedureCodes);

    void onTCCMemDeductibleResponse(AccountBalance mAccountModel);

    void onTCCOOPResponse(GetMemberOOPReponse memberOOPReponse);

    void onTreatmentCostResponse(GetTreatmentCost mTreatmentCost);
}
