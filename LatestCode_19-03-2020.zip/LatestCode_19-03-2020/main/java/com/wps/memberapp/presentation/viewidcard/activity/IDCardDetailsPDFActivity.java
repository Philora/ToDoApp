package com.wps.memberapp.presentation.viewidcard.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.android.volley.VolleyError;
import com.github.barteksc.pdfviewer.PDFView;
import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.domain.dataservice.VolleyByteResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.LocaleHelper;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import org.json.JSONObject;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import butterknife.BindView;
import butterknife.ButterKnife;

import static com.wps.memberapp.utility.GeneralUtils.hideProgress;

/**
 * This activity is used to display ID Card as PDF to the respective user.
 */
public class IDCardDetailsPDFActivity extends AppCompatActivity {

    //Member variables declaration
    @BindView(R.id.pdfView)
    PDFView pdfView;
    @BindView(R.id.web_view_id_pdf)
    WebView wvIdPdf;

    private static final String FILE_NAME = "details.pdf";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getApplicationContext());
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view_pdf);
        ButterKnife.bind(this);

        GeneralUtils.showProgress(this);
        callVIewIDAPI();
    }

    private void callVIewIDAPI() {
        VolleyService.saveJsonResultRequest(getApplicationContext(),
                AppConstants.SAVE_JSON_RESULT, new VolleyResponseListener() {
                    @Override
                    public void onError(String error) {
                        hideProgress();
                    }

                    @Override
                    public void onResponse(String response) {
                        try {
                            //Sending request for ID Card PDF
                            Log.d("ID_CARD_PDF_ACTIVITY", "onResponse: "+response);
                            if (response != null) {
                                response = response.replace('"', '@');
                                response = response.replace("@", "");
                                Log.d("PDF Response",response);
                                VolleyService.getIDCardAsPDF(getApplicationContext(), AppConstants.DOWNLOAD_PDF_ID_CARD + response, new VolleyByteResponseListener() {
                                    @Override
                                    public void onResponse(byte[] response) {
                                        Log.i("PDF Response", String.valueOf(response));
                                        if (isWriteStoragePermissionGranted() && isReadStoragePermissionGranted()) {
                                            convertBytesToPDF(response);
                                            hideProgress();
                                            File pdfFile = new File(Environment.getExternalStorageDirectory() + "/IDCard/" + FILE_NAME);
                                            try {
                                                pdfView.fromFile(pdfFile).enableDoubletap(true).load();
                                            } catch (Exception e) {
                                                Logger.e("Exc1", e);
                                            }
                                        }
                                    }

                                    @Override
                                    public void onError(VolleyError error) {
                                        hideProgress();
                                        try {
                                            JSONObject obj = new JSONObject(String.valueOf(error));
                                            Toast.makeText(getApplicationContext(), "Download failed", Toast.LENGTH_LONG).show();
                                            GeneralUtils.showAlertDialog(IDCardDetailsPDFActivity.this, getString(R.string.download_failed));
                                        } catch (Exception e) {
                                            Toast.makeText(getApplicationContext(), "Exception - Download failed", Toast.LENGTH_LONG).show();
                                            Logger.e(StringConstants.EXCEPTION, e);
                                        }
                                    }
                                });
                            }
                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    }
                });
    }

    private void convertBytesToPDF(byte[] response) {
        try {
            File folder = new File(Environment.getExternalStorageDirectory() + "/IDCard/");
            folder.mkdir();
            File pdfFile = new File(folder, FILE_NAME);
            FileOutputStream fos = new FileOutputStream(pdfFile);
            fos.write(response);
            if (!pdfFile.exists()) {
                pdfFile.createNewFile();
            }
            fos.close();
//            Toast.makeText(getApplicationContext(), "Converted from byte to PDF", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            System.out.println("Exception: " + e);
        }
    }

    @SuppressLint("LongLogTag")
    public boolean isReadStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                Log.v("IDCardDetailsPDFActivity", "Permission is granted1");
                return true;
            } else {
                Log.v("IDCardDetailsPDFActivity", "Permission is revoked1");
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 3);
                return false;
            }
        } else {
            Log.v("IDCardDetailsPDFActivity", "Permission is granted1");
            return true;
        }
    }

    @SuppressLint("LongLogTag")
    public boolean isWriteStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                Log.v("IDCardDetailsPDFActivity", "Permission is granted2");
                return true;
            } else {
                Log.v("IDCardDetailsPDFActivity", "Permission is revoked2");
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 2);
                return false;
            }
        } else {
            Log.v("IDCardDetailsPDFActivity", "Permission is granted2");
            return true;
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (isWriteStoragePermissionGranted() && isReadStoragePermissionGranted()) {
            Log.d("LoginActivityFitbit", "Success ");
        }
    }

    @Override
    protected void attachBaseContext(Context base) {
        String lang = SharedPreferenceHelper.getInstance().getPreference(base, "Language");
        if ("es".equalsIgnoreCase(lang)) {
            base = LocaleHelper.setLocale(base, "es");
            super.attachBaseContext(base);
        } else {
            base = LocaleHelper.setLocale(base, "en");
            super.attachBaseContext(base);
        }

    }
}
