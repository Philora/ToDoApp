package com.wps.memberapp.presentation.viewidcard.adapter;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.Address;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.domain.dataservice.VolleyResponseListener;
import com.wps.memberapp.domain.dataservice.VolleyService;
import com.wps.memberapp.presentation.viewidcard.activity.IDCardDetailsPDFActivity;
import com.wps.memberapp.presentation.viewidcard.fragment.IDCardDetailFragment;
import com.wps.memberapp.utility.AppConstants;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

/**
 * This adapter used to display list of users along with view ID
 * card option as list view.
 */
public class IdCardAdapter extends RecyclerView.Adapter<IdCardAdapter.IdCardViewHolder> {

    //This context  will be used to inflate the layout
    private final Activity mCtx;
    private AlertDialog mDialog;
    private final AppCompatActivity mActivity;
    //We are storing all the product in a list
    private final List<MemberDetails> mMemberDetailList;

    public IdCardAdapter(Activity mCtx, AppCompatActivity mActivity, List<MemberDetails> mMemberDetailList) {
        this.mCtx = mCtx;
        this.mMemberDetailList = mMemberDetailList;
        this.mActivity = mActivity;
    }

    /*
  Creating ViewHolder based on the layout to bind the data to adapter.
   */
    @NonNull
    @Override
    public IdCardViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.row_view_id_card, parent, false);
        return new IdCardViewHolder(view);
    }

    /*
    Binding data to ViewHolder class object based on the position.
    */
    @Override
    public void onBindViewHolder(@NonNull final IdCardViewHolder holder, final int position) {
        if (mMemberDetailList != null && !mMemberDetailList.isEmpty()) {

            //Binding member details data to views.
            final MemberDetails memberDetails = mMemberDetailList.get(position);
            if (memberDetails != null) {
                if (memberDetails.getFirstName() != null && !memberDetails.getFirstName().equals("null")
                        && memberDetails.getLastName() != null && !memberDetails.getLastName().equals("null")) {
                    String name = memberDetails.getFirstName() + StringConstants.SPACE_SINGLE + memberDetails.getLastName();
                    holder.idCardMemberDetailTextView.setText(name);
                    holder.imageView1.setBackgroundResource(R.drawable.ic_avatar);
                }
                SimpleDateFormat format = new SimpleDateFormat("yyyy-mm-dd", Locale.ENGLISH);
                Date newDate = null;
                try {
                    if (memberDetails.getDateOfBirth() != null && !memberDetails.getDateOfBirth().equals("null")) {
                        newDate = format.parse(memberDetails.getDateOfBirth());
                    }
                } catch (ParseException e) {
                    Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
                }
                format = new SimpleDateFormat("mm/dd/yyyy", Locale.ENGLISH);
                String date = format.format(newDate);
                holder.dobDetailsTextView.setText(date);

                //Click listener to launch ID Card PDF in an activity.
                // Old_Code
               /* holder.imageView.setOnClickListener(view -> {
                    if (GeneralUtils.isOnline(mCtx)) {
                        Intent intent = new Intent(mCtx, IDCardDetailFragment.class);
                        mCtx.startActivity(intent);
                    } else {
                        GeneralUtils.showAlertDialog(mCtx, mCtx.getString(R.string.login_no_internet));
                    }
                });*/
                holder.imageView.setOnClickListener(view -> {
                    IDCardDetailFragment idCardDetailView = new IDCardDetailFragment();
                    Bundle bundle = new Bundle();
                    if (!mMemberDetailList.isEmpty()) {
                        bundle.putParcelableArrayList("member", (ArrayList<? extends Parcelable>) mMemberDetailList);
                    }
                    bundle.putInt("position", holder.getAdapterPosition());
                    idCardDetailView.setArguments(bundle);
                    mActivity.getSupportFragmentManager().beginTransaction().replace(R.id.frame_container, idCardDetailView).addToBackStack(null).commit();
                });

                //Click listener to send new ID Card request.
                holder.requestIDCardTv.setOnClickListener(view -> {
                    if (GeneralUtils.isOnline(mCtx)) {
                        ProfileDataCache.getInstance().setIdCardPosition(holder.getAdapterPosition());
                        requestIDCard();
                    } else {
                        GeneralUtils.showAlertDialog(mCtx, mCtx.getString(R.string.login_no_internet));
                    }
                });
            }
        }
    }

    /*
    This method is used to send validate Id card request to validate user new Id card request.
     */
    private void requestIDCard() {
        GeneralUtils.showProgress(mCtx);
        VolleyService.validateIDCardRequest(mCtx, AppConstants.VALIDATE_IDCARD_REQUEST, new VolleyResponseListener() {
            @Override
            public void onResponse(String message) {
                GeneralUtils.hideProgress();
                try {
                    JSONObject obj = new JSONObject(message);
                    String type = obj.getString("ReturnType");
                    String date = obj.getString("OrderDate");
                    date = date.split("T")[0];

                    //Based on the response we are showing popup to user.
                    if (type != null && type.equalsIgnoreCase("1")) {
                        showIDCardConfirmDialog();
                    } else if (type != null && type.equalsIgnoreCase("3")) {
                        showDialogWithYesNo("An ID card request was raised on " + date + ". Do you want to order ID Card again?");
                    } else {
                        showDialog(mCtx.getString(R.string.idcard_not_processed));
                    }
                } catch (Exception e) {
                    Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
                }
            }

            @Override
            public void onError(String error) {
                GeneralUtils.hideProgress();
            }
        });
    }

    @Override
    public int getItemCount() {
        if (mMemberDetailList != null) {
            return mMemberDetailList.size();
        } else {
            return 0;
        }
    }

    /**
     * View Holder class to bind the member details data to views.
     */
    class IdCardViewHolder extends RecyclerView.ViewHolder {

        final TextView idCardMemberDetailTextView;
        final TextView dobDetailsTextView;
        final TextView requestIDCardTv;
        final ImageView imageView;
        final ImageView imageView1;

        private IdCardViewHolder(@NonNull View itemView) {
            super(itemView);
            idCardMemberDetailTextView = itemView.findViewById(R.id.nameValue);
            dobDetailsTextView = itemView.findViewById(R.id.submissionDateValue);
            requestIDCardTv = itemView.findViewById(R.id.requestIDCard);
            requestIDCardTv.setPaintFlags(requestIDCardTv.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
            imageView = itemView.findViewById(R.id.imageView);
            imageView1 = itemView.findViewById(R.id.imageView1);
        }
    }

    /*
    This method is used to show dialog to user to confirm new ID card request.
     */
    private void showIDCardConfirmDialog() {
        View view = View.inflate(mCtx, R.layout.dialog_idcard_request_confirm, null);
        TextView name = view.findViewById(R.id.name);
        TextView address1 = view.findViewById(R.id.address1);
        TextView address2 = view.findViewById(R.id.address2);
        TextView phone = view.findViewById(R.id.phone);
        int idCardPosition = ProfileDataCache.getInstance().getIdCardPosition();
        MemberDetails details = ProfileDataCache.getInstance().getmMemberDetails().get(idCardPosition);
        String nameData = details.getFirstName() + StringConstants.SPACE_SINGLE + details.getLastName();
        name.setText(nameData);
        if (details.getAddressList() != null && !details.getAddressList().isEmpty()) {
            Address address = details.getAddressList().get(idCardPosition);
            if (address != null) {
                address1.setText(address.getAddress1() + " " + address.getAddress2());
                String addressData = address.getCity() + ", " + address.getState() + StringConstants.SPACE_SINGLE + address.getZipCode();
                address2.setText(addressData);
            }
        }
        String phoneNumber = details.getPhoneNumber();
        phoneNumber = phoneNumber.replaceFirst("(\\d{3})(\\d{3})(\\d+)", "$1-$2-$3");   // 3-3-4 like US based number format (with hyphen enabled) -
        String mobile = mCtx.getString(R.string.phone) + StringConstants.SPACE_SINGLE + phoneNumber;
        phone.setText(mobile);

        AlertDialog.Builder dilog = new AlertDialog.Builder(mCtx);
        dilog.setView(view)
                .setNegativeButton(mCtx.getString(R.string.cancel), null)
                .setCancelable(false)
                .setPositiveButton(mCtx.getString(R.string.submit), (dialogInterface, i) -> {
                    mDialog.dismiss();
                    GeneralUtils.showProgress(mCtx);
                    VolleyService.newIDCardByEmail(mCtx, AppConstants.REQUEST_IDCARD_BY_EMAIL, new VolleyResponseListener() {
                        @Override
                        public void onResponse(String message) {
                            GeneralUtils.hideProgress();
                            if (message != null && message.equalsIgnoreCase("true")) {
                                showDialog(mCtx.getString(R.string.idcard_processed));
                            } else {
                                showDialog(mCtx.getString(R.string.idcard_not_processed));
                            }
                        }

                        @Override
                        public void onError(String error) {
                            GeneralUtils.hideProgress();
                        }
                    });
                });
        mDialog = dilog.create();
        mDialog.show();
        if (mDialog.getWindow() != null) {
            mDialog.getWindow().setBackgroundDrawableResource(R.drawable.idcard_dialog_bg);
        }
    }

    /*
    This method is used to show message to user with OK button.
     */
    private void showDialog(String msg) {
        AlertDialog.Builder dilog = new AlertDialog.Builder(mCtx);
        dilog.setMessage(msg)
                .setPositiveButton(mCtx.getString(R.string.ok), null);
        mDialog = dilog.create();
        mDialog.show();
        TextView textView = mDialog.findViewById(android.R.id.message);
        if (textView != null) {
            textView.setTextSize(15);
        }
    }

    /*
   This method is used to show message to user with Yes or No buttons.
    */
    private void showDialogWithYesNo(String msg) {
        AlertDialog.Builder dilog = new AlertDialog.Builder(mCtx);
        dilog.setMessage(msg)
                .setPositiveButton(mCtx.getString(R.string.yes), (dialogInterface, i) -> showIDCardConfirmDialog())
                .setNegativeButton(mCtx.getString(R.string.no), null);
        mDialog = dilog.create();
        mDialog.show();
        TextView textView = mDialog.findViewById(android.R.id.message);
        if (textView != null) {
            textView.setTextSize(15);
        }
    }
}
