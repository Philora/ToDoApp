package com.wps.memberapp.presentation.viewidcard.fragment;


import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Fragment;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.presentation.base.BaseFragment;
import com.wps.memberapp.presentation.viewidcard.activity.IDCardDetailsPDFActivity;
import com.wps.memberapp.utility.GeneralUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import androidx.core.app.ActivityCompat;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;


/**
 * Created by 133580 on 11/29/2017.
 */

public class IDCardDetailFragment extends BaseFragment {
    @BindView(R.id.nameValue)
    TextView name;
    @BindView(R.id.groupValue)
    TextView groupId;
    @BindView(R.id.memberIdValue)
    TextView memberId;
    @BindView(R.id.planTypeValue)
    TextView planType;
    @BindView(R.id.planIDValue)
    TextView planId;
    @BindView(R.id.effectiveDateValue)
    TextView effectiveDate;
    @BindView(R.id.pcpNameValue)
    TextView pcpName;
    @BindView(R.id.pcpNumberValue)
    TextView pcpPhone;
    @BindView(R.id.urgentCareValue)
    TextView urgentCareValue;
    @BindView(R.id.ERVisitValue)
    TextView erVisitValue;
    @BindView(R.id.specialVisitValue)
    TextView specialVisitValue;
    @BindView(R.id.officeVisitValue)
    TextView officeVisitValue;
    @BindView(R.id.clientDetailTextView)
    TextView clientDetailTextView;
    @BindView(R.id.healthPlanTxtView)
    TextView healthPlanTxtView;
    private Unbinder unbinder;

    /**
     * This override method is used to inflate the layout for fragment
     * @return rootView
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        View rootView = inflater.inflate(R.layout.frag_view_id_card, container, false);
        unbinder = ButterKnife.bind(this, rootView);
        Bundle bundle = this.getArguments();
        int pos = bundle.getInt("position");
        if (bundle.size() > 0) {
            ArrayList<MemberDetails> member = bundle.getParcelableArrayList("member");
            name.setText(member.get(pos).getFirstName() + " " + member.get(pos).getLastName());
            groupId.setText(member.get(pos).getGroupId());
            memberId.setText(member.get(pos).getSubscriberID() + "-" + member.get(pos).getPersonNumber());
            planType.setText(member.get(pos).getPlanType());
            planId.setText(member.get(pos).getPlanCode());

            TextView txtDownloadPDF = getActivity().findViewById(R.id.txt_Call);
            txtDownloadPDF.setVisibility(View.VISIBLE);
            txtDownloadPDF.setOnClickListener(view -> {
                Toast.makeText(getActivity(), "Loading...", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getActivity(), IDCardDetailsPDFActivity.class);
                ProfileDataCache.getInstance().setPersonIDNumber(member.get(pos).getPersonNumber());
                ProfileDataCache.getInstance().setSubscriberID(member.get(pos).getSubscriberID());
                ProfileDataCache.getInstance().setGroupId(member.get(pos).getGroupId());
                startActivity(intent);
            });

            if (member.get(pos).getCoverageDate() != null) {
                String date = member.get(0).getCoverageDate();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                Date testDate = null;
                try {
                    testDate = sdf.parse(date);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault());
                String effDate = formatter.format(testDate);
                effectiveDate.setText(effDate);
            }
            if (member.get(pos).getPCPName() != null) {
                pcpName.setText(member.get(pos).getPCPName());
            }

            if (member.get(pos).getPlanName() != null && !member.get(pos).getPlanName().equals("null")) {
                healthPlanTxtView.setText(member.get(pos).getPlanName());
                clientDetailTextView.setText(member.get(pos).getPlanName());
                clientDetailTextView.setSelected(true);
            }
        }
        return rootView;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }

    @Override
    public void onStart() {
        super.onStart();
        if (isWriteStoragePermissionGranted() && isReadStoragePermissionGranted()) {
            Log.d("LoginActivityFitbit", "Success ");
        }
    }

    @SuppressLint("LongLogTag")
    public boolean isReadStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (getActivity().checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                Log.v("IDCardDetailsPDFActivity", "Permission is granted1");
                return true;
            } else {
                Log.v("IDCardDetailsPDFActivity", "Permission is revoked1");
                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 3);
                return false;
            }
        } else {
            Log.v("IDCardDetailsPDFActivity", "Permission is granted1");
            return true;
        }
    }

    @SuppressLint("LongLogTag")
    public boolean isWriteStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (getActivity().checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                Log.v("IDCardDetailsPDFActivity", "Permission is granted2");
                return true;
            } else {
                Log.v("IDCardDetailsPDFActivity", "Permission is revoked2");
                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 2);
                return false;
            }
        } else {
            Log.v("IDCardDetailsPDFActivity", "Permission is granted2");
            return true;
        }
    }
}
