package com.wps.memberapp.presentation.viewidcard.fragment;

import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.presentation.base.BaseFragment;
import com.wps.memberapp.presentation.viewidcard.adapter.IdCardAdapter;
import com.wps.memberapp.utility.GeneralUtils;
import com.wps.memberapp.utility.Logger;
import com.wps.memberapp.utility.StringConstants;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/**
 * Used to display the list of ID cards to view by user
 */

public class ViewIDCardFrament extends BaseFragment {

    //Declaring member variables

    /**
     * This override method is used to inflate the layout for fragment
     *
     * @return rootView
     */
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,  ViewGroup container,
                             Bundle savedInstanceState) {
        GeneralUtils.setLanguage(getActivity());
        if (container != null) {
            container.removeAllViews();
            container.clearDisappearingChildren();
        }
        View rootView = inflater.inflate(R.layout.fragment_view_id_card, container, false);
        if(getActivity()!=null) {
            TextView fragmentTitle = getActivity().findViewById(R.id.textViewTitle);
            fragmentTitle.setText(R.string.view_id_card_title);
            TextView txtDownloadPDF = getActivity().findViewById(R.id.txt_Call);
            txtDownloadPDF.setVisibility(View.GONE);
            ImageView imageViewSearch = getActivity().findViewById(R.id.imageViewSearch);
            imageViewSearch.setVisibility(View.GONE);
        }
        RecyclerView rv = rootView.findViewById(R.id.recyclerIdCardView);
        ProgressBar mSpinner = rootView.findViewById(R.id.loaderIDCard);
        mSpinner.getIndeterminateDrawable().setColorFilter(GeneralUtils.getColor(getActivity(), R.color.blue), PorterDuff.Mode.MULTIPLY);

        //Setting layout manager to recycleview
        rv.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        rv.setLayoutManager(layoutManager);

        //Getting member details from cache and setting to adapter
        if (ProfileDataCache.getInstance().getmMemberDetails() != null && !ProfileDataCache.getInstance().getmMemberDetails().isEmpty()) {
            ArrayList<MemberDetails> memberDetails = (ArrayList<MemberDetails>) ProfileDataCache.getInstance().getmMemberDetails();
            IdCardAdapter adapter = new IdCardAdapter(getActivity(),(AppCompatActivity) getActivity(), memberDetails);
            rv.setItemAnimator(new DefaultItemAnimator());
            rv.setAdapter(adapter);
            adapter.notifyDataSetChanged();
        }
        return rootView;
    }
}
