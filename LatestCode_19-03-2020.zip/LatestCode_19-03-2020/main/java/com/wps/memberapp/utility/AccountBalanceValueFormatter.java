package com.wps.memberapp.utility;

import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.formatter.IValueFormatter;
import com.github.mikephil.charting.utils.ViewPortHandler;

import androidx.annotation.NonNull;

/**
 * To format the value with $ sign in the bar chart
 */
class AccountBalanceValueFormatter implements IValueFormatter {
    @NonNull
    @Override
    public String getFormattedValue(float v, Entry entry, int i, ViewPortHandler viewPortHandler) {
        if (v > 0f) {
            String mFormatted = String.valueOf(v);
            if (mFormatted.contains(".0")) {
                mFormatted = mFormatted.replace(".0", ".00");
            }
            return "$" + mFormatted;
        } else {
            return "";
        }
    }
}
