package com.wps.memberapp.utility;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;

import com.wps.memberapp.R;


public class AlertDialogFragment extends DialogFragment {
    /**
     * Create a new instance of AlertDialogFragment.
     */

    @NonNull
    public static AlertDialogFragment newInstance(int title, String message) {
        AlertDialogFragment f = new AlertDialogFragment();
        Bundle args = new Bundle();
        args.putInt("title", title);
        args.putString("message", message);
        f.setArguments(args);
        return f;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        String title = "";
        String msg = "";
        if (getActivity() != null && getArguments() != null) {
            title = getActivity().getString(getArguments().getInt("title"));
            msg = getArguments().getString("message");
        }
        return new AlertDialog.Builder(getActivity())
                .setTitle(title)
                .setMessage(msg)
                .setPositiveButton(getActivity().getString(R.string.dialog_ok_action), null)
                .create();
    }
}
