package com.wps.memberapp.utility;

import android.content.Context;

/**
 * This class is used to declare constants used inside application
 */
public class AppConstants {



    private AppConstants() {
    }

    /**
     * Key to pass API message
     */

//    private static final String BASE_URL = "https://external.digitalhealth.nttdataservices.com/HealthGen/";
//    private static final String BASE_URL = "https://external-akamai.healthcare.nttdataservices.com/HealthGen/"; //external-akamai
    private static final String BASE_URL = "https://sit1-external.digitalhealth.nttdataservices.com/HealthGen/"; // SIT1
    public static final String LOGIN_STC_TOKEN = BASE_URL + "STS/STS.svc/IssueUserToken";
    public static final String LOGIN_FED_AUTH_TOKEN = BASE_URL + "Services/SSOLogin.aspx";
    //    public static final String FED_AUTH_REFERRER = BASE_URL + "https://external-akamai.healthcare.nttdataservices.com/HealthGen/Modules/Global/templates/SSOLogin.html";
    public static final String FED_AUTH_REFERRER = BASE_URL + "https://sit1-external.digitalhealth.nttdataservices.com/HealthGen/Modules/Global/templates/SSOLogin.html"; // SIT1
    public static final String GET_PROFILE_DETAILS = BASE_URL + "Services/api/MyProfile/GetProfile";
    public static final String GET_USER_PROFILE_DETAILS = BASE_URL + "Services/api/MyProfile/GetUserProfile";
    public static final String GET_FULL_DASHBOARD = BASE_URL + "Services/api/Dashboard/GetFullDashboard";
    public static final String GET_CLAIMS = BASE_URL + "Services/api/Claims/GetClaims";
    public static final String GET_CLAIMS_SUMMARY = BASE_URL + "Services/api/Claims/GetClaimsSummary";
    public static final String GET_MEMBER_DETAILS = BASE_URL + "Services/api/Member/GetMemberDetails";
    public static final String GET_NOTIFICATIONS = BASE_URL + "Services/api/Dashboard/GetNotifications";
    public static final String GET_ACCOUNT_BALANCE = BASE_URL + "Services/api/Member/GetMemberDeductibleResponse";
    //    public static final String GET_NEWS_CONTENT = "https://external-akamai.healthcare.nttdataservices.com/umbraco/Surface/NewsSurface/NewsContent?language=en&country=us&logicalGroup=Member&region=us&applicationName=HIX";
    public static final String GET_NEWS_CONTENT = "https://sit1-external.digitalhealth.nttdataservices.com/umbraco/Surface/NewsSurface/NewsContent?language=en&country=us&logicalGroup=Member&region=us&applicationName=HIX"; // SIT1
    //    public static final String GET_NOTIFICATIONS_CONTENT = "https://external-akamai.healthcare.nttdataservices.com/umbraco/Surface/Content/MicroContent?language=en&region=us&segment=public&country=us&logicalGroup=Member_DashboardNotifications&applicationName=HIX&isString=1";
    public static final String GET_NOTIFICATIONS_CONTENT = "https://sit1-external.digitalhealth.nttdataservices.com/umbraco/Surface/Content/MicroContent?language=en&region=us&segment=public&country=us&logicalGroup=Member_DashboardNotifications&applicationName=HIX&isString=1";     //SIT1
    public static final String GET_AUTH_SEARCH = BASE_URL + "Services/api/Authorization/GetAuthSearch";
    public static final String GET_AUTH_DETAILS = BASE_URL + "Services/api/Authorization/GetAuthDetails";
    public static final String GET_AUTHORIZATION_REFERAL_DETAILS = BASE_URL + "Services/api/Authorization/GetProvDashboardAuth";
    public static final String GET_CLAIM_DETAILS = BASE_URL + "Services/api/Claims/GetCliamDetails";

    // Secure Messages
    public static final String GET_SECURE_MESSAGES = BASE_URL + "Services/api/SecureMessages/GetSecureMessages";
    public static final String GET_SECURE_MESSAGE_DETAILS = BASE_URL + "Services/api/SecureMessages/GetSecureMessageDetails";
    public static final String COMPOSE_MESSAGE = BASE_URL + "Services/api/SecureMessages/SendNewMessage";
    public static final String SEND_REPLY = BASE_URL + "Services/api/SecureMessages/SendReply";
    public static final String SECURE_MESSAGE_PROVIDER = BASE_URL + "Services/api/SecureMessages/GetSecureMessageProvider";
    public static final String SECURE_MESSAGE_PROV_PCP = BASE_URL + "Services/api/SecureMessages/GetSecureMessageProviderPCP";


    public static final String GET_MEMBER_ELIGINFO = BASE_URL + "Services/api/Member/GetMemberEligInfo";
    public static final String GET_SECURE_MESSAGE_SUBJECTS = BASE_URL + "Services/api/SecureMessages/GetSecureMessagesSubjects";

    //    public static final String FIND_DOCTOR = "https://connect.wpsic.com/Gateway/commercialGateway/unauth/fadHome.do";
    public static final String FIND_DOCTOR = "";
    public static final String GET_ID_CARD_DETAILS_PDF = BASE_URL + "Services/api/Document/GetIDCard?";
    public static final String GET_CLAIM_DOCUMENT = BASE_URL + "Services/api/Document/GetDocumentByClaimNumber";
    public static final String GET_BENEFIT_USER_DETAILS = BASE_URL + "/Services/api/Member/GetBenifitMembers";
    public static final String GET_BENEFIT_PRODUCT_DETAILS = BASE_URL + "/Services/api/Member/GetProductBSDLResponse";
    public static final String REGISTER_NEW_USER = "https://sit1-external.digitalhealth.nttdataservices.com/en/Member/Anonymous#/Registration?WebsiteID=hnc7rhl";   //changed before status call - b5bgurh// Old value //hnc7rhl //SIT1

    public static final String VALIDATE_IDCARD_REQUEST = BASE_URL + "Services/api/Member/ValidateIdCardRequest";
    public static final String REQUEST_IDCARD_BY_EMAIL = BASE_URL + "Services/api/Member/RequestNewCardByEmail";
    public static final String GET_MEMBER_GROUP_LIST = BASE_URL + "Services/api/Member/GetMemberGroupList";
    public static final String UPDATE_MEMBER_GROUP_LIST = BASE_URL + "Services/api/Member/UpdateMemberGroupIsPrefered";
    public static final String CHANGE_PARAM = BASE_URL + "Services/api/Account/PostChangePassword";
    public static final String GET_ACCOUNT_BALANCE_OOP = BASE_URL + "Services/api/Member/GetMemberOOPResponse";
    public static final String CUSTOMER_RESOURCE_DENTAL = "https://www.deltadental.com/us/en/member.html";
    public static final String CUSTOMER_RESOURCE_VISION = "https://www.davisvision.com/Member/";
    public static final String GET_DEMOGRAPHY_UPDATE_HISTORY = BASE_URL + "Services/api/Member/GetDemographyUpdateHistory";
    public static final String VERIFY_PARAM = BASE_URL + "Services/api/Account/GetUserValidated";
    public static final String GET_SECURITY_QUESTIONS = BASE_URL + "Services/api/Account/GetSecurityQuestion";
    public static final String GET_USER_SECURITY_QUESTIONS = BASE_URL + "Services/api/MyProfile/GetAccountSecurityQuestions";
    public static final String UPDATE_SECURITY_QUESTIONS = BASE_URL + "Services/api/MyProfile/UpdatedSecurityQuesAns/";
    public static final String GET_COUNTRY_DATA = BASE_URL + "Services/api/Account/CountyStateValid";
    public static final String UPDATE_DEMOGRAPHY = BASE_URL + "Services/api/Member/UpdateMemberDemography";

    /**
     * IBM Cloud Push Notifications App UUID and Client Secret ID
     */
    public static final String APP_UUID = "7135ee6f-cf39-466a-9e2c-04e9b496c52c";
    public static final String CLIENT_SECRET_ID = "112a14f8-6006-4627-85ea-6f23a6055333";

    /**
     * Health Vault widget URL
     */
    public static final String HEALTH_VAULT_URL = "https://www.healthvault.com/en-us/healthvault-for-consumers/";

    /**
     * SFDC Community URL
     */
    public static final String SFDC_COMMUNITY_URL = "https://health-gen.force.com/memberportal/s/";


    /**
     * SFDC Community URL
     */
    public static final String VIEW_DOC_PDF_URL = "https://sit1-external.digitalhealth.nttdataservices.com/Customers/HealthGen/HealthGen_EOB_Sample.pdf";

    /**
     * Livezilla Chat widget URL
     */
//    public static final String LIVEZILLA_CHAT_URL = "https://external-akamai.healthcare.nttdataservices.com/livezilla/chat.php?s=e4eb674678784cc2f34cdf0dd76a9d57&ptn=John&pto=true";
    public static final String LIVEZILLA_CHAT_URL = "https://sit1-external.digitalhealth.nttdataservices.com/livezilla/chat.php?s=e4eb674678784cc2f34cdf0dd76a9d57&ptn=John&pto=true"; //SIT1

    /**
     * Shared Preferences key value in store
     */
    public static final String PREFS_FILE_NAME = "MemberAppSharedPrefs";
    public static final String AUTHORIZATION_TOKEN = "Authorization_Token";

    /**
     * Forgot Password URL
     */
//    public static final String RESET_CREDENTIALS = "https://external.digitalhealth.nttdataservices.com/en/Member/Anonymous#/ForgotPassword?WebsiteID=b5bgurh";
//    public static final String RESET_CREDENTIALS = "https://external-akamai.healthcare.nttdataservices.com/en/Member/Anonymous#/ForgotPassword?WebsiteID=b5bgurh";
    public static final String RESET_CREDENTIALS = "https://sit1-external.digitalhealth.nttdataservices.com/en/Member/Anonymous#/ForgotPassword?WebsiteID=hnc7rhl"; //SIT1

    /**
     * Medication Notification registration URL
     */
    public static final String REGISTER_DEVICE_URL = BASE_URL + "Services/api/RegisterMember/GetRegisterMemberInquiry";
    public static final String GET_REMINDER = BASE_URL + "Services/api/RegisterMember/GetMemberMedicineRegByMemberId";
    public static final String GET_RESCHEDULE_REMINDER = BASE_URL + "Services/api/RegisterMember/";

    public static final String IMMUNIZATION_REGISTRATION_URL = "https://external.digitalhealth.nttdataservices.com/HealthGen/Services/api/ImmunizationReg/InsertImmunizationReg";

    public static final String GET_MEDICATIONS_BY_MEMBER_ID_URL = BASE_URL + "Services/api/Medication/GetMedicationsByMemberID";


    public static final String GET_IMMUNIZATIONS_BY_MEMBER_ID_URL = "https://external.digitalhealth.nttdataservices.com/HealthGen/Services/api/Immunization/GetImmunizationByMemberID";

    public static final String GET_IMMUNIZATION_BY_SUBSCRIBER_ID_URL = BASE_URL + "Services/api/Immunization/GetImmunizationBySubscriberId";

    public static final String ADD_MEDICATION_DETAILS = BASE_URL + "Services/api/Medication/InsertMedication";
    /**
     * Immunization appointment URL
     */
    public static final String ADD_APPOINTMENT_URL = BASE_URL + "Services/api/Immunization/InsertImmunizationHistory";

    public static final String ADD_VACCINE_URL = BASE_URL + "Services/api/Immunization/InsertImmunizationHistory";

    //    public static final String GET_IMMUNIZATION_HISTORY_URL = BASE_URL + "Services/api/Immunization/GetImmunizationHistoryDetailsViewByPDF?Member_id=788449148601";
    public static final String GET_IMMUNIZATION_HISTORY_URL = "";

    public static final String GET_VACCINE_LIST_URL = BASE_URL + "Services/api/Immunization/GetImmunizationVaccineGroup";

    //    public static final String SURVEY_URL = "https://consumerism.healthcare.nttdataservices.com/limesurvey/"; // Old URL
    public static final String SURVEY_URL = "https://external.digitalhealth.nttdataservices.com/limesurveyExternal/"; // Checked with Eti

    //    public static final String MEDICAL_COVERAGE_PDF = "https://external-akamai.healthcare.nttdataservices.com/Customers/HealthGen/NTT_HIX_Portal_PlanDetailExample.pdf";
    public static final String MEDICAL_COVERAGE_PDF = "https://sit1-external.digitalhealth.nttdataservices.com/Customers/HealthGen/NTT_HIX_Portal_PlanDetailExample.pdf"; //SIT1

    public static final String PDF_WEB_VIEW = BASE_URL + "Services/api/MayoClinic/GetMayoClinicDataViewByPDF?DocID=";

    // View ID Card
    //    public static final String DOWNLOAD_ID_CARD_PDF = "https://external.digitalhealth.nttdataservices.com/HealthGen/Services/api/Member/TempCardPdf?FMSSubscriberID=";
    public static final String SAVE_JSON_RESULT = BASE_URL +"Services/api/Utility/SaveJsonRequest";
    public static final String DOWNLOAD_PDF_ID_CARD = BASE_URL + "Services/api/Member/TempCardPdf?req=";

    public static final String PERMISSION = "PERMISSION";

    // TeleMedicine + InTouch
    public static final String TELE_MEDICINE_URL = "https://external.digitalhealth.nttdataservices.com/limesurveyExternal/index.php?r=survey/index&sid=855178&newtest=Y&lang=en"; // Shraddha shared the URL
    public static final String TELE_MEDICINE_INTOUCH = "https://demo.visitnow.org/c5058507-4c8d-4556-a49b-c94bacd4098b";

    // GetProviderSearch
    public static final String GET_LANGUAGE_SPOKEN = BASE_URL + "Services/api/ProviderSearch/GetLanguage_Spoken";
    public static final String APPLICANTS_GEO_LOCATION = BASE_URL + "Services/api/PCP/ApplicantsGeoLocation";
    public static final String GET_CITY_COUNTRY = BASE_URL + "Services/api/ProviderSearch/GetCityCounty";
    public static final String GET_PRACTICE_GROUP = BASE_URL + "Services/api/ProviderSearch/GetPracticeGroup";
    public static final String GET_SPECIALITY = BASE_URL + "Services/api/ProviderSearch/GetSpeciality";
    public static final String GET_HOSPITAL_AFFILIATION = BASE_URL + "Services/api/ProviderSearch/GetHospitalAffiliatedList";
    public static final String GET_CLINIC_NAME = BASE_URL + "Services/api/ProviderSearch/GetClinicName";
    public static final String GET_AREA_OF_EXPERTISE = BASE_URL + "Services/api/ProviderSearch/GetAreaOfExpertise";

    //    public static final String GET_PCP_SEARCH = "https://external-akamai.healthcare.nttdataservices.com/umbraco/api/ProviderSearch/PCPSearch";
    public static final String GET_PCP_SEARCH = "https://sit1-external.digitalhealth.nttdataservices.com/umbraco/api/ProviderSearch/PCPSearch";    //SIT1
    //    public static final String GET_EXPERT_PROVIDER_PDF = "https://external-akamai.healthcare.nttdataservices.com/umbraco/api/ProviderSearch/ExportProviderSearchResults";
    public static final String GET_EXPERT_PROVIDER_PDF = "https://sit1-external.digitalhealth.nttdataservices.com/umbraco/api/ProviderSearch/ExportProviderSearchResults";    //SIT1

    //    public static final String EXPORT_AS_PDF = "https://external-akamai.healthcare.nttdataservices.com/umbraco/api/ProviderSearch/DownLoadAttachment?fileName=";
    public static final String EXPORT_AS_PDF = "https://sit1-external.digitalhealth.nttdataservices.com/umbraco/api/ProviderSearch/DownLoadAttachment?fileName=";    //SIT1

    //TCC
    public static final String GET_PROCEDURE_CODES = BASE_URL + "Services/api/TreatmentCostCalc/GetProcedureCodes";
    public static final String GET_MEMBER_DEDUCTIBLE = BASE_URL + "Services/api/Member/GetMemberDeductibleResponse";
    public static final String GET_MEMBER_OOP = BASE_URL + "Services/api/Member/GetMemberOOPResponse";
    public static final String GET_TREATMENT_COST = BASE_URL + "Services/api/TreatmentCostCalc/GetTreatmentCost";

    // Fitbit
    public static final String GET_FITBIT_OAUTH = "https://api.fitbit.com/oauth2/token";

    // My Health Coach
    public static final String MY_HEALTH_COACH = "https://coach.fitbit.com/welcome/register?redirect_url=%2F";


    // Wellness Score
    public static final String WELLNESS_SCORE = BASE_URL + "Services/api/Dashboard/GetHRAPDF";

    //CareAssessmentReview - New Widget for Demo
    public static final String CARE_WELLNESS_REVIEW = "https://external-akamai.healthcare.nttdataservices.com/Customers/HealthGen/MemberHealthReport.pdf"; // Shared by Shraddha(04-032020)

    // CareManagement // New Enhancement Mar-10-2020
    public static final String SYMPTOM_CHECKER = "https://www.mayoclinic.org/symptom-checker/select-symptom/itt-20009075"; // Shared by Shraddha via teams

    // Attachment Secure Message
    public static final String DOWNLOAD_SECURE_MESSAGE_ATTACHMENT = "https://sit1-external.digitalhealth.nttdataservices.com/HealthGen/Services/api/SecureMessages/DownLoadAttachment?fileName=";


    // Knowledge Base
    public static final String GET_KNOWLEDGE_BASE = "https://sit1-external.digitalhealth.nttdataservices.com/HealthGen/Services/api/MayoClinic/GetArticlesForSearch";


}
