package com.wps.memberapp.utility;

import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.formatter.IValueFormatter;
import com.github.mikephil.charting.utils.ViewPortHandler;

import java.util.Map;

import androidx.annotation.NonNull;

public class AuthReferralValueFormatter implements IValueFormatter {

    @NonNull
    @Override
    public String getFormattedValue(float value, Entry entry, int dataSetIndex, ViewPortHandler viewPortHandler) {
        if (value > 0f) {
            String mFormatted = String.valueOf(value);
            if (mFormatted.contains(".0")) {
                mFormatted = mFormatted.replace(".0", "");
            }
            if (mFormatted.equalsIgnoreCase("1")) {
                return mFormatted + " Auth";
            } else {
                return mFormatted + " Auths";
            }
        } else {
            return "0 Auth";
        }
    }
}
