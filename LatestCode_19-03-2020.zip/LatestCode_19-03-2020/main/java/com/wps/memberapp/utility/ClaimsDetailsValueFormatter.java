package com.wps.memberapp.utility;

import android.annotation.SuppressLint;

import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.formatter.IValueFormatter;
import com.github.mikephil.charting.utils.ViewPortHandler;

import androidx.annotation.NonNull;

public class ClaimsDetailsValueFormatter implements IValueFormatter {

    @SuppressLint("DefaultLocale")
    @NonNull
    @Override
    public String getFormattedValue(float v, Entry entry, int i, ViewPortHandler viewPortHandler) {
        if (v > 0f) {
            String mFormatted = String.valueOf(v);
            if (mFormatted.equalsIgnoreCase("0.0")) {
                mFormatted = mFormatted.replace("0.0", "0.00");
            }
            double value = Double.parseDouble(mFormatted);
            mFormatted = String.format("%.2f", value);
            return "$" + mFormatted;
        } else {
            return "$0.00";
        }
    }
}

