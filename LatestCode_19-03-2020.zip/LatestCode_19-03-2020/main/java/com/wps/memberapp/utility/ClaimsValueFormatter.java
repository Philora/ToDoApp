package com.wps.memberapp.utility;

import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.formatter.IValueFormatter;
import com.github.mikephil.charting.utils.ViewPortHandler;

import androidx.annotation.NonNull;

public class ClaimsValueFormatter implements IValueFormatter {
    @NonNull
    @Override
    public String getFormattedValue(float v, Entry entry, int i, ViewPortHandler viewPortHandler) {
        if (v > 0f) {
            String mFormatted = String.valueOf(v);
            if (mFormatted.contains(".0")) {
                mFormatted = mFormatted.replace(".0", "");
            }
            if (mFormatted.equalsIgnoreCase("1")) {
                return mFormatted + " Claim";
            } else {
                return mFormatted + " Claims";
            }
        } else {
            return "0 Claim";
        }
    }
}
