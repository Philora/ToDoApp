package com.wps.memberapp.utility;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class CustomRecyclerView extends RecyclerView {


    public CustomRecyclerView(@NonNull Context context,  AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public boolean performClick() {
        Log.i("click","performClick");
        return super.performClick();
    }
}
