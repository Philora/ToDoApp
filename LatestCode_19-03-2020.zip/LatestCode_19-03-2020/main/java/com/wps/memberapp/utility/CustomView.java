package com.wps.memberapp.utility;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.wps.memberapp.R;


/**
 * Used to create custom view based on frame layout
 */

public class CustomView extends FrameLayout {

    private final TextView textView;

    public CustomView(Context context) {
        super(context);
        LayoutInflater.from(context).inflate(R.layout.frag_custom_view, this);
        textView =  getRootView().findViewById(R.id.txtSun);
    }

    public void display(String text, boolean isSelected) {
        textView.setText(text);
        textView.setBackgroundColor(getResources().getColor(R.color.grey_color));
        display(isSelected);
    }

    /* Changing textview color and background color*/
    public void display(boolean isSelected) {
        if (isSelected) {
            textView.setTextColor(Color.parseColor("#FFFFFF"));
            textView.setBackgroundColor(getResources().getColor(R.color.blue));
        } else {
            textView.setTextColor(getResources().getColor(R.color.txt_label_color));
            textView.setBackgroundColor(getResources().getColor(R.color.grey_color));
        }
    }
}
