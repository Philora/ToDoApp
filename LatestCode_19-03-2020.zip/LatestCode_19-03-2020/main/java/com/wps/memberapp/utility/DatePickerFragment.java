package com.wps.memberapp.utility;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.util.Log;
import android.widget.DatePicker;

import java.util.Calendar;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;

/**
 * Used to display the datepicker dialog with custom values
 */

public class DatePickerFragment extends DialogFragment {

    private DatePickerDialog.OnDateSetListener ondateSet;
    private int year;
    private int month;
    private int day;
    private String mDatePick;

    public void setCallBack(DatePickerDialog.OnDateSetListener ondate) {
        ondateSet = ondate;
    }

    @SuppressLint("NewApi")
    @Override
    public void setArguments(Bundle args) {
        super.setArguments(args);

        //Setting values for year, month and date
        year = args.getInt("year");
        month = args.getInt("month");
        day = args.getInt("day");
        mDatePick = args.getString("CustomDatePicker");
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        if (getActivity() != null) {
            Calendar c = Calendar.getInstance();
//            return new DatePickerDialog(getActivity(), ondateSet, year, month, day);
            DatePickerDialog picker = new DatePickerDialog(getActivity(),
                    ondateSet, year, month, day);
            if (!mDatePick.isEmpty() && mDatePick.equalsIgnoreCase("AddMedDatePicker")) {
                picker.getDatePicker().setMinDate(System.currentTimeMillis());
            }
            Log.d("picker timestamp", c.getTime().getTime() + "");
            return picker;
        }
        throw new IllegalArgumentException("Dialog at position is not an instance of  AlertDialog");
    }
}