package com.wps.memberapp.utility;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class EncryptManager {
    private static final int AES_KEY_SIZE = 128;
    private static final int IV_SIZE = 12;
    private static final int TAG_BIT_LENGTH = 128;
    private SecretKey aesKey = null;
    private GCMParameterSpec gcmParamSpec;
    private static EncryptManager encryptManager;

    public static EncryptManager getEncryptManager() {
        if (encryptManager == null) {
            encryptManager = new EncryptManager();
        }
        return encryptManager;
    }

    private EncryptManager() {
        // Generating Key
        SecureRandom secRandom = new SecureRandom();
        try {
            KeyGenerator keygen = KeyGenerator.getInstance("AES"); // Specifying algorithm key will be used for
            keygen.init(AES_KEY_SIZE, secRandom); // Specifying Key size to be used, Note: This would need JCE Unlimited Strength to be installed explicitly
            aesKey = keygen.generateKey();
        } catch (NoSuchAlgorithmException noSuchAlgoExc) {
            System.out.println("Key being request is for AES algorithm, but this cryptographic algorithm is not available in the environment " + noSuchAlgoExc);
            //System.exit(1);
        }
        // Generating IV
        byte[] iv = new byte[IV_SIZE];
        secRandom.nextBytes(iv); // SecureRandom initialized using self-seeding
        // Initialize GCM Parameters
        gcmParamSpec = new GCMParameterSpec(TAG_BIT_LENGTH, iv);
    }

    /*private static SecretKeySpec secretKey;

    private static void setKey(String myKey) {
        MessageDigest sha;
        try {
            byte[] key = myKey.getBytes(StandardCharsets.UTF_8);
            sha = MessageDigest.getInstance("SHA-1");
            key = sha.digest(key);
            key = Arrays.copyOf(key, 16);
            secretKey = new SecretKeySpec(key, "AES");
        } catch (Exception e) {
            Logger.e(StringConstants.EXCEPTION, e);
        }
    }
*/
    public String encrypt(String strToEncrypt) {
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, aesKey, gcmParamSpec);
            cipher.updateAAD("MyAAD".getBytes()); // add AAD tag data before encrypting
            byte[] cipherTextInByteArr = cipher.doFinal(strToEncrypt.getBytes());
            return new String(cipherTextInByteArr);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    public String decrypt(String strToDecrypt) {
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, aesKey, gcmParamSpec);
            cipher.updateAAD("MyAAD".getBytes()); // add AAD tag data before encrypting
            byte[] cipherTextInByteArr = cipher.doFinal(strToDecrypt.getBytes());
            return new String(cipherTextInByteArr);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

   /* public static String encrypt(String strToEncrypt, String secret) {
        try {
            setKey(secret);
            Cipher cipher = Cipher.getInstance("AES/GCM/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            return new String(android.util.Base64.encode((cipher.doFinal(strToEncrypt.getBytes(StandardCharsets.UTF_8))), 0));
        } catch (Exception e) {
            Logger.e(StringConstants.EXCEPTION, e);
        }
        return null;
    }

    static String decrypt(String strToDecrypt, String secret) {
        try {
            setKey(secret);
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            return new String(cipher.doFinal(android.util.Base64.decode(strToDecrypt, 0)));
        } catch (Exception e) {
            Logger.e(StringConstants.EXCEPTION, e);
        }
        return null;
    }*/
}
