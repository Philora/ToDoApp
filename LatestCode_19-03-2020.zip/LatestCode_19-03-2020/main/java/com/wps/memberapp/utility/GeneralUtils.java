package com.wps.memberapp.utility;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInstaller;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.webkit.PermissionRequest;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.HorizontalBarChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.wps.memberapp.R;
import com.wps.memberapp.data.cache.ProfileDataCache;
import com.wps.memberapp.data.model.AccountBalance;
import com.wps.memberapp.data.model.AccountBalanceOOP;
import com.wps.memberapp.data.model.ClaimSummaryModel;
import com.wps.memberapp.data.model.MemberDetails;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;
import com.wps.memberapp.domain.fitbitauth.authentication.AuthenticationManager;
import com.wps.memberapp.presentation.login.activity.LoginActivity;
//import com.wps.memberapp.presentation.splash.activity.SampleActivity;
import com.wps.memberapp.presentation.splash.activity.LanguageActivity;

import java.net.URLEncoder;
import java.security.Permissions;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.regex.Pattern;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import static android.app.Activity.RESULT_CANCELED;
import static android.app.Activity.RESULT_OK;
import static org.webrtc.ContextUtils.getApplicationContext;


public class GeneralUtils {

    private static final int REQUEST_CODE_UNINSTALL_FREE_APP = 100;
    private static Dialog mProgressDialog;
    static ArrayList<BarEntry> entries;
    static Locale locale;
    private static android.app.AlertDialog dialog;


    private GeneralUtils() {
    }

    /**
     * Shows progress bar to the user and disables interaction
     **/
    public static void showProgress(@NonNull Context context) {
        try {
            if (mProgressDialog != null) {
                mProgressDialog.dismiss();
                mProgressDialog = null;
            }
            mProgressDialog = new Dialog(context);
            mProgressDialog.setCancelable(false);
            mProgressDialog.setContentView(R.layout.progressbar_layout);
            if (mProgressDialog.getWindow() != null) {
                mProgressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }
            mProgressDialog.show();
        } catch (Exception e) {
            Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
        }
    }

    /**
     * hides progress bar to the user and enables interaction.
     **/
    public static void hideProgress() {
        try {
            if (mProgressDialog != null) {
                mProgressDialog.dismiss();
            }
        } catch (Exception e) {
            Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
        }
    }


    public static void showTryAgainDialog(@NonNull Activity activity, String msg) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setCancelable(false)
                .setMessage(msg);
        builder.setPositiveButton(R.string.ok, (dialogInterface, i) -> {
            builder.create().dismiss();
        });
        builder.show();

    }

    public static int getColor(Context ctx, int color) {
        Resources res = ctx.getResources();
        int appliedColor;
        if (Build.VERSION.SDK_INT < 23) {
            appliedColor = res.getColor(color);
        } else {
            appliedColor = ContextCompat.getColor(ctx, color);
        }
        return appliedColor;
    }

    /**
     * Public method to determine if Device is connected to the internet.
     *
     * @param context context of the caller.
     */
    public static boolean isOnline(@NonNull Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm != null) {
            NetworkInfo netInfo = cm.getActiveNetworkInfo();
            return netInfo != null && netInfo.isConnected();
        }
        return false;
    }

    public static void setLanguage(Context context) {
        String lang = SharedPreferenceHelper.getInstance().getPreference(context, "Language");
//        Context mContext;
        if ("es".equalsIgnoreCase(lang)) {
            locale = new Locale("es");
            context = LocaleHelper.setLocale(context, "es");
        } else {
            locale = new Locale("en");
            context = LocaleHelper.setLocale(context, "en");
        }
/*        if ("es".equalsIgnoreCase(lang)) {
            locale = new Locale("es");
        } else {
            locale = new Locale("en");
        }*/
        /*Resources res = context.getResources();
        Configuration config = new Configuration(res.getConfiguration());
        if (Build.VERSION.SDK_INT >= 21) {
            config.setLocale(locale);
            context = context.createConfigurationContext(config);
        } else {
            config.locale = locale;
            res.updateConfiguration(config, res.getDisplayMetrics());
        }*/
    }

    public static String getCurrentMemberID() {
        List<MemberDetails> detailsList = ProfileDataCache.getInstance().getmMemberDetails();
        MemberDetails details = detailsList.get(0);
        return details.getfMSSeqMemberId();
    }

    /**
     * Returns device UUID.
     *
     * @param context context of the callback.
     */
    @NonNull
    public static String getDeviceId(@NonNull Context context) {
        String deviceId = null;
        try {
            deviceId = ((TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE)).getDeviceId();
        } catch (SecurityException e) {
            Logger.e("Ex3", e);
        }
        if (deviceId != null) {
            return deviceId;
        } else {
            return android.os.Build.SERIAL;
        }
    }

    public static void showTitle(AppCompatActivity activity, Toolbar toolbar, String title) {
        TextView textView = activity.findViewById(R.id.textView2);
        TextView fragmentTitle = toolbar.findViewById(R.id.textViewTitle);
        ImageView imageViewSearch = activity.findViewById(R.id.imageViewSearch);
        imageViewSearch.setVisibility(View.GONE);
        TextView txtDownloadPDF = activity.findViewById(R.id.txt_Call);
        txtDownloadPDF.setVisibility(View.GONE);
        textView.setVisibility(View.VISIBLE);
        if (!TextUtils.isEmpty(title)) {
            fragmentTitle.setText(title);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                fragmentTitle.setTextColor(activity.getColor(R.color.blue));
            }
        }
    }

    /**
     * Logs out from the app and launches login screen.
     *
     * @param context context of the caller.
     */
    public static void logoutApp(@NonNull Context context) {
        ProfileDataCache.getInstance().clearCache();
        SharedPreferenceHelper.getInstance().clearPreference(context, AppConstants.AUTHORIZATION_TOKEN);
        SharedPreferenceHelper.getInstance().clearPreference(context, "FedAuth");
        SharedPreferenceHelper.getInstance().clearPreference(context, "FedAuth1");
        // SharedPreferenceHelper.getInstance().clearPreference(context, StringConstants.PARAM2);
        // SharedPreferenceHelper.getInstance().clearPreference(context, StringConstants.PARAM1);
        //SharedPreferenceHelper.getInstance().clearPreference(context, "Language");
        SharedPreferenceHelper.getInstance().clearPreference(context, "sessionid");
        SharedPreferenceHelper.getInstance().clearPreference(context, "rememberMeStatus");
        SharedPreferenceHelper.getInstance().clearPreference(context, "step_goal");
        Intent intent = new Intent(context, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(intent);
        System.exit(0);
    }


    /**
     * Used to convert HashMap data to String
     */

    @NonNull
    public static String convertToBody(@NonNull Map<String, String> params) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry key : params.entrySet()) {
            if (params.get(key.getKey().toString()) != null) {
                sb.append(key.getKey().toString()).append("=");
                sb.append(params.get(key.getKey().toString())).append("&");
            }
        }
        String data = sb.toString();
        data = data.substring(0, data.length() - 1);
        return data;
    }

    public static String getBase64String(String data) {
        try {
            byte[] bytesEncoded = android.util.Base64.encode(data.getBytes(), 0);
            return new String(bytesEncoded, StringConstants.DEFAULT_TEXT_ENCODING);
        } catch (Exception e) {
            Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
        }
        return "";
    }

    public static String getEncodedString(@NonNull String original) {
        // Encode data on your side using BASE64
        try {
            byte[] bytesEncoded = android.util.Base64.encode(original.getBytes(), 0);
            String coded = new String(bytesEncoded, StringConstants.DEFAULT_TEXT_ENCODING);
            return URLEncoder.encode(coded, StringConstants.DEFAULT_TEXT_ENCODING);
        } catch (Exception e) {
            Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
        }
        return null;
    }

    public static String getBase64ChangePasswordString(@NonNull String original) {
        // Encode data on your side using BASE64
        try {
            byte[] bytesEncoded = android.util.Base64.encode(original.getBytes(), 0);
            return new String(bytesEncoded, StringConstants.DEFAULT_TEXT_ENCODING);
        } catch (Exception e) {
            Logger.e(StringConstants.EXCEPTION, StringConstants.EXCEPTION);
        }
        return null;
    }

    public static String getRealmString(String env, @NonNull Context context) {
        String param1 = SharedPreferenceHelper.getInstance().getPreference(context, StringConstants.PARAM2);
        String param2 = SharedPreferenceHelper.getInstance().getPreference(context, StringConstants.PARAM1);
        String url = "realm=https%3A%2F%2F" + env + ".nttdataservices.com%2FHealthGen%2FServices%2F" +
                "&UserName=" + getEncodedString(param1) +
                "&Password=" + getEncodedString(param2);
        Log.i("realm", url);
        return "realm=https%3A%2F%2F" + env + ".nttdataservices.com%2FHealthGen%2FServices%2F" +
                "&UserName=" + getEncodedString(param1) +
                "&Password=" + getEncodedString(param2);
    }

    /**
     *  * To get request sub type based on the current login user
     *  * @return auth request sub type
     *  
     */

    public static String getAuthRequestSubType() {
        String reqSubType = NetworkConfigValues.AUTHSEARCH;
        if (ProfileDataCache.getInstance().getmMemberDetails() != null) {
            String personNumber = ProfileDataCache.getInstance().getmMemberDetails().get(0).getPersonNumber();
            if (personNumber != null && personNumber.equals("01")) {
                reqSubType = NetworkConfigValues.AUTHSEARCH_SUBSCRIBER;
            }
        }
        return reqSubType;
    }

    /**
     *  * To get request sub type based on the current login user
     *  * @return claim request sub type
     *  
     */

    public static String getClaimRequestSubType() {
        String reqSubType = NetworkConfigValues.CLAIMLIST;
        if (ProfileDataCache.getInstance().getmMemberDetails() != null) {
            String personNumber = ProfileDataCache.getInstance().getmMemberDetails().get(0).getPersonNumber();
            if (personNumber != null && personNumber.equals("01")) {
                reqSubType = NetworkConfigValues.CLAIMLISTSUBSCRIBER;
            }
        }
        return reqSubType;
    }

    /**
     * Used to plot Account Balance data and plot it using Vertical bar Chart through MP Android chart library
     *
     * @param accountBalance account balance object
     */

    @NonNull
    public static BarChart getVerticalChartResults(@NonNull Context context, @NonNull AccountBalance accountBalance, boolean isFamily) {

        BarChart mBChart = new BarChart(context);
        mBChart.invalidate();
        ArrayList<BarEntry> yVals1 = new ArrayList<>();
        int[] myCOLORSCHART = {Color.rgb(44, 49, 120), Color.rgb(41, 171, 226)};
        List<String> xValues = Arrays.asList(context.getResources().getStringArray(R.array.Account_Balance_Range));
        mBChart.getDescription().setEnabled(false);
        // scaling can now only be done on x- and y-axis separately
        mBChart.setPinchZoom(false);
        mBChart.setDrawGridBackground(false);
        mBChart.setDrawBarShadow(false);

        mBChart.setDrawValueAboveBar(true);
        mBChart.setHighlightFullBarEnabled(false);

        // change the position of the y-labels
        YAxis leftAxis = mBChart.getAxisRight();
        leftAxis.setDrawGridLines(false);
        leftAxis.setEnabled(false);
        leftAxis.setAxisMinimum(0f); // this replaces setStartAtZero(true)
        mBChart.getAxisRight().setEnabled(false);

        if (isFamily) {

            float inNetworkFamilyDeductible = Float.parseFloat(accountBalance.getInNetworkFamilyDeductible());
            float inNetworkFamilyDeductibleSpent = Float.parseFloat(accountBalance.getInNetworkFamilyDeductibleSpent());
            float deductibleFamilyInNetwork = inNetworkFamilyDeductible - inNetworkFamilyDeductibleSpent;

            float outNetworkFamilyDeductible = Float.parseFloat(accountBalance.getOutNetworkFamilyDeductible());
            float outNetworkFamilyDeductibleSpent = Float.parseFloat(accountBalance.getOutNetworkFamilyDeductibleSpent());
            float deductibleFamilyOutNetwork = outNetworkFamilyDeductible - outNetworkFamilyDeductibleSpent;

            yVals1.add(new BarEntry(0, new float[]{inNetworkFamilyDeductibleSpent, deductibleFamilyInNetwork}));
            yVals1.add(new BarEntry(1, new float[]{outNetworkFamilyDeductibleSpent, deductibleFamilyOutNetwork}));
        } else {

            float inNetworkIndDeductible = Float.parseFloat(accountBalance.getInNetworkIndDeductible());
            float inNetworkIndDeductibleSpent = Float.parseFloat(accountBalance.getInNetworkIndDeductibleSpent());
            float deductibleInNetwork = inNetworkIndDeductible - inNetworkIndDeductibleSpent;

            float outNetworkIndDeductible = Float.parseFloat(accountBalance.getOutNetworkIndDeductible());
            float outNetworkIndDeductibleSpent = Float.parseFloat(accountBalance.getOutNetworkIndDeductibleSpent());
            float deductibleIndOutNetwork = outNetworkIndDeductible - outNetworkIndDeductibleSpent;

            yVals1.add(new BarEntry(0, new float[]{inNetworkIndDeductibleSpent, deductibleInNetwork}));
            yVals1.add(new BarEntry(1, new float[]{outNetworkIndDeductibleSpent, deductibleIndOutNetwork}));
        }

        BarDataSet set1;
        if (mBChart.getData() != null &&
                mBChart.getData().getDataSetCount() > 0) {
            set1 = (BarDataSet) mBChart.getData().getDataSetByIndex(0);
            if (!yVals1.isEmpty()) {
                set1.setValues(yVals1);
                mBChart.getData().notifyDataChanged();
                mBChart.notifyDataSetChanged();
            }
        } else {
            set1 = new BarDataSet(yVals1, "");
            set1.setColors(myCOLORSCHART);
            set1.setDrawValues(true);
            set1.setVisible(true);
            ArrayList<IBarDataSet> dataSets = new ArrayList<>();
            dataSets.add(set1);
            BarData data = new BarData(dataSets);
            data.setValueFormatter(new AccountBalanceValueFormatter());
            data.setValueTextColor(Color.BLACK);
            data.setValueTextSize(8f);
            mBChart.setExtraRightOffset(30f);
            set1.setStackLabels(new String[]{"Met", "Remaining"});
            data.setBarWidth(0.4f);
            mBChart.setData(data);
        }

        Legend l = mBChart.getLegend();
        l.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
        l.setHorizontalAlignment(Legend.LegendHorizontalAlignment.RIGHT);
        l.setOrientation(Legend.LegendOrientation.HORIZONTAL);

        XAxis xAxis = mBChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM_INSIDE);
        xAxis.setValueFormatter(new IndexAxisValueFormatter(xValues));
        xAxis.setDrawLabels(true);
        xAxis.setDrawGridLines(false);
        xAxis.setDrawAxisLine(false);
        xAxis.setLabelCount(7);
        xAxis.setGranularity(1f);
        xAxis.setGranularityEnabled(true);
        mBChart.setVisibleXRangeMaximum(4);
        mBChart.setTouchEnabled(false);
        mBChart.invalidate();
        return mBChart;
    }

    /**
     * Used to plot Account Balance OOP data and plot it using Vertical bar Chart through MP Android chart library
     *
     * @param accountBalance account balance object
     */

    @NonNull
    public static BarChart getVerticalChartResultsOOP(@NonNull Context context, @NonNull AccountBalanceOOP accountBalance, boolean isFamily) {

        BarChart mBChart = new BarChart(context);
        mBChart.invalidate();
        ArrayList<BarEntry> yVals1 = new ArrayList<>();
        int[] myCOLORSCHART = {Color.rgb(44, 49, 120), Color.rgb(41, 171, 226)};
        List<String> xValues = Arrays.asList(context.getResources().getStringArray(R.array.Account_Balance_OOP_Range));
        mBChart.getDescription().setEnabled(false);
        // scaling can now only be done on x- and y-axis separately
        mBChart.setPinchZoom(false);
        mBChart.setDrawGridBackground(false);
        mBChart.setDrawBarShadow(false);

        mBChart.setDrawValueAboveBar(true);
        mBChart.setHighlightFullBarEnabled(false);

        // change the position of the y-labels
        YAxis leftAxis = mBChart.getAxisRight();
        leftAxis.setDrawGridLines(false);
        leftAxis.setEnabled(false);
        leftAxis.setAxisMinimum(0f); // this replaces setStartAtZero(true)
        mBChart.getAxisRight().setEnabled(false);

        if (isFamily) {
            float inNetworkFamilyOOP = Float.parseFloat(accountBalance.getInNetworkFamilyOOP());
            float inNetworkFamilyOOPSpent = Float.parseFloat(accountBalance.getInNetworkFamilyOOPSpent());
            float oopFamilyInNetwork = inNetworkFamilyOOP - inNetworkFamilyOOPSpent;

            float outNetworkFamilyOOP = Float.parseFloat(accountBalance.getOutNetworkFamilyOOP());
            float outNetworkFamilyOOPSpent = Float.parseFloat(accountBalance.getOutNetworkFamilyOOPSpent());
            float oopFamilyOutNetwork = outNetworkFamilyOOP - outNetworkFamilyOOPSpent;

            yVals1.add(new BarEntry(0, new float[]{inNetworkFamilyOOPSpent, oopFamilyInNetwork}));
            yVals1.add(new BarEntry(1, new float[]{outNetworkFamilyOOPSpent, oopFamilyOutNetwork}));
        } else {

            float inNetworkIndOOP = Float.parseFloat(accountBalance.getInNetworkIndOOP());
            float inNetworkIndOOPSpent = Float.parseFloat(accountBalance.getInNetworkIndOOPSpent());
            float oopInNetwork = inNetworkIndOOP - inNetworkIndOOPSpent;

            float outNetworkIndOOP = Float.parseFloat(accountBalance.getOutNetworkIndOOP());
            float outNetworkIndOOPSpent = Float.parseFloat(accountBalance.getOutNetworkIndOOPSpent());
            float oopIndOutNetwork = outNetworkIndOOP - outNetworkIndOOPSpent;

            yVals1.add(new BarEntry(0, new float[]{inNetworkIndOOPSpent, oopInNetwork}));
            yVals1.add(new BarEntry(1, new float[]{outNetworkIndOOPSpent, oopIndOutNetwork}));
        }

        BarDataSet set1;
        if (mBChart.getData() != null &&
                mBChart.getData().getDataSetCount() > 0) {
            set1 = (BarDataSet) mBChart.getData().getDataSetByIndex(0);
            if (!yVals1.isEmpty()) {
                set1.setValues(yVals1);
                mBChart.getData().notifyDataChanged();
                mBChart.notifyDataSetChanged();
            }
        } else {
            set1 = new BarDataSet(yVals1, "");
            set1.setColors(myCOLORSCHART);
            set1.setDrawValues(true);
            set1.setVisible(true);
            ArrayList<IBarDataSet> dataSets = new ArrayList<>();
            dataSets.add(set1);
            BarData data = new BarData(dataSets);
            data.setValueFormatter(new AccountBalanceValueFormatter());
            data.setValueTextColor(Color.BLACK);
            data.setValueTextSize(8f);
            mBChart.setExtraRightOffset(30f);
            set1.setStackLabels(new String[]{"Met", "Remaining"});
            data.setBarWidth(0.4f);
            mBChart.setData(data);
        }

        Legend l = mBChart.getLegend();
        l.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
        l.setHorizontalAlignment(Legend.LegendHorizontalAlignment.RIGHT);
        l.setOrientation(Legend.LegendOrientation.HORIZONTAL);

        XAxis xAxis = mBChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.TOP);
        xAxis.setValueFormatter(new IndexAxisValueFormatter(xValues));
        xAxis.setDrawLabels(true);
        xAxis.setDrawGridLines(false);
        xAxis.setDrawAxisLine(false);
        xAxis.setLabelCount(7);
        xAxis.setGranularity(1f);
        xAxis.setGranularityEnabled(true);
        mBChart.setVisibleXRangeMaximum(4);
        mBChart.setTouchEnabled(false);
        mBChart.invalidate();
        return mBChart;
    }

    /**
     * Used to plot Claim Summary data and plot it using Horizontal bar Chart through MP Android chart library
     *
     * @param model claim summary object
     */

    @NonNull
    public static HorizontalBarChart getHorizontalChartResults(@NonNull Context context, ClaimSummaryModel model) {
        int[] myCOLORS = {Color.rgb(140, 198, 64), Color.rgb(41, 171, 226), Color.rgb(44, 49, 120),
                Color.rgb(4, 85, 165), Color.rgb(7, 182, 131)};
        HorizontalBarChart mHChart = new HorizontalBarChart(context);
        entries = new ArrayList<>();
        List<Integer> daysCount = new ArrayList<>();
        if (model.getDays15() == null)
            daysCount.add(0);
        else {
            daysCount.add(Integer.parseInt(model.getDays15()));
        }
        if (model.getDays30() == null)
            daysCount.add(0);
        else {
            daysCount.add(Integer.parseInt(model.getDays30()));
        }
        if (model.getDays60() == null)
            daysCount.add(0);
        else {
            daysCount.add(Integer.parseInt(model.getDays60()));
        }
        if (model.getDays90() == null || model.getDays90Plus() == null) {
            daysCount.add(0);
        } else {
            daysCount.add(Integer.parseInt(model.getDays90()) + Integer.parseInt(model.getDays90Plus()));
        }
        List<String> labels = Arrays.asList(context.getResources().getStringArray(R.array.Claims_Range));
        XAxis xl = mHChart.getXAxis();
        xl.setPosition(XAxis.XAxisPosition.BOTTOM);
        xl.setDrawAxisLine(false);
        xl.setDrawGridLines(false);
        LabelValueFormatter xaxisFormatter = new LabelValueFormatter(labels);
        xl.setValueFormatter(xaxisFormatter);
        xl.setGranularity(1);

        YAxis yl = mHChart.getAxisLeft();
        yl.setPosition(YAxis.YAxisLabelPosition.INSIDE_CHART);
        yl.setDrawGridLines(false);
        yl.setEnabled(false);
        yl.setAxisMinimum((int) 0);

        YAxis yr = mHChart.getAxisRight();
        yr.setPosition(YAxis.YAxisLabelPosition.INSIDE_CHART);
        yr.setDrawGridLines(false);
        yr.setDrawLabels(false);
        yr.setAxisMinimum((int) 0);

        for (int i = 0; i < daysCount.size(); i++) {
//            entries.add(new BarEntry(i, Float.parseFloat(daysCount.get(i)+context.getString(R.string.claims))));
            entries.add(new BarEntry(i, (int) Math.round(daysCount.get(i))));
        }
        BarDataSet d = new BarDataSet(entries, "New DataSet");
        ArrayList<Integer> colors = new ArrayList<>();
        for (int c : myCOLORS) colors.add(c);
        d.setColors(colors);
        ArrayList<IBarDataSet> sets = new ArrayList<>();
        sets.add(d);

        BarData cd = new BarData(sets);
        cd.setValueFormatter(new ClaimsValueFormatter());
        cd.setBarWidth(0.5f);
        cd.setValueTextSize(13f);
        mHChart.setData(cd);
        mHChart.setDrawBarShadow(false);
        mHChart.getDescription().setEnabled(false);
        mHChart.setDrawValueAboveBar(true);
        mHChart.setPinchZoom(false);
        mHChart.setDrawGridBackground(false);
        mHChart.getLegend().setEnabled(false);
        mHChart.setTouchEnabled(false);
        mHChart.animateXY(2000, 2000);
        mHChart.invalidate();
        return mHChart;
    }

    public static boolean isPasswordValid(String param1) {
        boolean isValid = true;
        Pattern pattern = Pattern.compile(StringConstants.MPARAM_REGEX);
        if (param1.length() < 9 || param1.length() > 20) {
            isValid = false;
        }
        if (!pattern.matcher(param1).matches()) {
            isValid = false;
        }
        return isValid;
    }

    public static String getTodayDate() {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH) + 1;
        int day = cal.get(Calendar.DAY_OF_MONTH);
        return month + "/" + day + "/" + year;
    }

    public static String getDateFormat(String termDate) {
        /*MemberDetails mMemberDetails = ProfileDataCache.getInstance().getmMemberDetails().get(0);
        String date = mMemberDetails.getTermDate();*/

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        Date testDate = null;
        try {
            testDate = sdf.parse(termDate); // date
        } catch (ParseException e) {
            e.printStackTrace();
        }
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault());
        String newFormat = formatter.format(testDate);
        return newFormat;
    }

    public static String generateRandomString() {
        String uuid = UUID.randomUUID().toString();
        uuid = uuid.replace("-", "");
        return uuid;
    }

    public static void showAlertDialog(@NonNull Activity activity, String msg) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setCancelable(false)
                .setMessage(msg)
                .setPositiveButton(activity.getString(R.string.ok), null).create().show();
    }

    public static String getPersonNumber(String name) {
        List<MemberDetails> detailsList = ProfileDataCache.getInstance().getmMemberDetails();
        for (MemberDetails details : detailsList) {
            String item = details.getFirstName() + " " + details.getLastName();
            Log.i(name, item);
            if (name.equalsIgnoreCase(item)) {
                return details.getPersonNumber();
            }
        }
        return "01";
    }



    public static void uninstallApp(@NonNull Activity activity) {
        String appPackage = "com.wps.memberapp";

        Uri uri = Uri.parse("package:com.wps.memberapp");
        Intent intent = new Intent("android.intent.action.DELETE", uri);
        activity.startActivityForResult(intent, REQUEST_CODE_UNINSTALL_FREE_APP);

        /*Intent intent = new Intent(activity, activity.getClass());
        PendingIntent sender = PendingIntent.getActivity(activity, 0, intent, 0);
        PackageInstaller mPackageInstaller = activity.getPackageManager().getPackageInstaller();
        mPackageInstaller.uninstall(appPackage, sender.getIntentSender());*/

       /* BroadcastReceiver br = new SampleActivity();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_PACKAGE_REMOVED);
        intentFilter.addDataScheme("package");
        context.registerReceiver(br, intentFilter);*/

        /*BroadcastReceiver uninstallApplication = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {

                if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    String packageName = Objects.requireNonNull(intent.getData()).getEncodedSchemeSpecificPart();
                    Toast.makeText(context, "USER UNINSTALL : " + packageName, Toast.LENGTH_SHORT).show();
                }
            }
        };
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_PACKAGE_REMOVED);
        intentFilter.addDataScheme("package");
        context.registerReceiver(uninstallApplication, intentFilter);*/
    }

    /*@Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == CODE_AUTHENTICATION_VERIFICATION) {
            Toast.makeText(this, "Success: Verified user's identity", Toast.LENGTH_SHORT).show();
            PackageInstaller.Session.setLock(false);
            startActivity(new Intent(context, WelcomeACtivity.class));
        } else if (resultCode == RESULT_CANCELED && requestCode == CODE_AUTHENTICATION_VERIFICATION) {
            finish();
        } else {
            Toast.makeText(this, "Failure: Unable to verify user's identity", Toast.LENGTH_SHORT).show();
        }
    }*/

    /*public boolean uninstallPackage(Context context, String packageName) {

        ComponentName name = new ComponentName(LanguageActivity.this, MyDeviceAdminReceiver.class.getCanonicalName());
        PackageManager packageManger = context.getPackageManager();
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            PackageInstaller packageInstaller = packageManger.getPackageInstaller();
            PackageInstaller.SessionParams params = new PackageInstaller.SessionParams(
                    PackageInstaller.SessionParams.MODE_FULL_INSTALL);
            params.setAppPackageName(packageName);
            int sessionId = 0;
            try {
                sessionId = packageInstaller.createSession(params);
            } catch (IOException e) {
                e.printStackTrace();
                return false;
            }
            packageInstaller.uninstall(packageName, PendingIntent.getBroadcast(context, sessionId,
                    new Intent("android.intent.action.MAIN"), 0).getIntentSender());
            return true;
        }
        System.err.println("old sdk");
        return false;
    }*/

   /* private static void uninstallCheck(Activity activity, final PermissionRequest request) {

        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setCancelable(false)
                .setMessage("UnInstalling the App")
                .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            request.grant(new String[]{Manifest.permission.REQUEST_DELETE_PACKAGES});
                        }
                    }
                }).create().show();
    }*/
}
