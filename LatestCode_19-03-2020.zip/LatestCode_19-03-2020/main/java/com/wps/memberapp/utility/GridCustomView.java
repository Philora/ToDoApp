package com.wps.memberapp.utility;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.wps.memberapp.R;


/**
 *  Used to create custom view based on frame layout
 */

public class GridCustomView extends FrameLayout {

    TextView gridItem;
    ImageView imageViewGrid;

    public GridCustomView(Context context) {
        super(context);
        LayoutInflater.from(context).inflate(R.layout.frag_grid_custom_view, this);
        gridItem = (TextView) getRootView().findViewById(R.id.textViewGridItem);
        imageViewGrid = (ImageView) getRootView().findViewById(R.id.imageViewCircle);
    }

    public void display(String text, boolean isSelected) {
        gridItem.setText(text);
        imageViewGrid.setImageResource(R.drawable.circle);
        display(isSelected);
    }

    /* Used to update the imageview and grid item based on the user selection*/
    public void display(boolean isSelected) {
        if(isSelected){
            imageViewGrid.setImageResource(R.drawable.selected_circle);
            gridItem.setTextColor(Color.parseColor("#FFFFFF"));
        }
        else{
            imageViewGrid.setImageResource(R.drawable.circle);
            gridItem.setTextColor(getResources().getColor(R.color.txt_label_color));
        }
    }
}
