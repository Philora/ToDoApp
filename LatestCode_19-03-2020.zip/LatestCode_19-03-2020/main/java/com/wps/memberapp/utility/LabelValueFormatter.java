package com.wps.memberapp.utility;

import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;

import java.util.List;

class LabelValueFormatter implements IAxisValueFormatter {

    private final List<String> mValues;

    LabelValueFormatter(List<String> values) {
        this.mValues = values;
    }

    @Override
    public String getFormattedValue(float value, AxisBase axis) {

        int val = (int) value;
        String label = "";
        if (val >= 0 && val < mValues.size()) {
            label = mValues.get(val);
        }
        return label;
    }
}



