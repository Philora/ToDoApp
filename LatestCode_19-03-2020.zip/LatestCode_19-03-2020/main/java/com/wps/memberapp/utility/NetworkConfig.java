package com.wps.memberapp.utility;

public class NetworkConfig {

    public static final String MedicationRequest = "MedicationRequest";
    public static final String ID = "id";
    public static final String TIME = "time";
    public static final String QUANTITY = "quantity";


    private NetworkConfig() {
    }

    public static final String COOKIE = "Cookie";
    public static final String CONTENT_TYPE = "Content_Type";
    public static final String CONTENT_TYPE_FORM_URLENCODED = "application/x-www-form-urlencoded";
    public static final String CONTENT_TYPE_FORM_URLENCODED_UTF = "application/x-www-form-urlencoded; charset=utf-8";
    public static final String REQUEST_TYPE = "RequestType";
    public static final String REQUEST_SUB_TYPE = "RequestSubType";
    public static final String UPDATE_PARAMETERS_0_PARAM_NAME = "UpdateParameters[0][ParamName]";
    public static final String UPDATE_PARAMETERS_0_PARAM_VALUE = "UpdateParameters[0][Value]";
    public static final String UPDATE_PARAMETERS_1_PARAM_NAME = "UpdateParameters[1][ParamName]";
    public static final String UPDATE_PARAMETERS_1_PARAM_VALUE = "UpdateParameters[1][Value]";
    public static final String UPDATE_PARAMETERS_2_PARAM_NAME = "UpdateParameters[2][ParamName]";
    public static final String UPDATE_PARAMETERS_2_PARAM_VALUE = "UpdateParameters[2][Value]";
    public static final String UPDATE_PARAMETERS_3_PARAM_NAME = "UpdateParameters[3][ParamName]";
    public static final String UPDATE_PARAMETERS_3_PARAM_VALUE = "UpdateParameters[3][Value]";
    public static final String UPDATE_PARAMETERS_4_PARAM_NAME = "UpdateParameters[4][ParamName]";
    public static final String UPDATE_PARAMETERS_4_PARAM_VALUE = "UpdateParameters[4][Value]";
    public static final String UPDATE_PARAMETERS_5_PARAM_NAME = "UpdateParameters[5][ParamName]";
    public static final String UPDATE_PARAMETERS_5_PARAM_VALUE = "UpdateParameters[5][Value]";
    public static final String SUBSCRIBER_ID = "SubscriberID";
    public static final String PERSON_NUMBER = "PersonNumber";
    public static final String GROUP_ID = "GroupID";
    public static final String GROUP_Id = "GroupId";
    public static final String PAGE_ID = "PageID";
    public static final String PAGE_SIZE = "PageSize";
    public static final String REQUEST_PARAMETERS_0_PARAM_NAME = "RequestParameters[0][ParamName]";
    public static final String REQUEST_PARAMETERS_0_PARAM_VALUES = "RequestParameters[0][Values][]";
    public static final String REQUEST_PARAMETERS_0_OPERATOR = "RequestParameters[0][Operator]";
    public static final String REQUEST_PARAMETERS_1_PARAM_NAME = "RequestParameters[1][ParamName]";
    public static final String REQUEST_PARAMETERS_1_PARAM_VALUES = "RequestParameters[1][Values][]";
    public static final String REQUEST_PARAMETERS_1_OPERATOR = "RequestParameters[1][Operator]";
    public static final String REQUEST_PARAMETERS_2_PARAM_NAME = "RequestParameters[2][ParamName]";
    public static final String REQUEST_PARAMETERS_2_PARAM_VALUES = "RequestParameters[2][Values][]";
    public static final String REQUEST_PARAMETERS_2_OPERATOR = "RequestParameters[2][Operator]";
    public static final String REQUEST_PARAMETERS_3_PARAM_NAME = "RequestParameters[3][ParamName]";
    public static final String REQUEST_PARAMETERS_3_PARAM_VALUES = "RequestParameters[3][Values][]";
    public static final String REQUEST_PARAMETERS_3_OPERATOR = "RequestParameters[3][Operator]";
    public static final String REQUEST_PARAMETERS_4_PARAM_NAME = "RequestParameters[4][ParamName]";
    public static final String REQUEST_PARAMETERS_4_PARAM_VALUES = "RequestParameters[4][Values][]";
    public static final String REQUEST_PARAMETERS_4_OPERATOR = "RequestParameters[4][Operator]";
    public static final String REQUEST_PARAMETERS_5_PARAM_NAME = "RequestParameters[5][ParamName]";
    public static final String REQUEST_PARAMETERS_5_PARAM_VALUES = "RequestParameters[5][Values][]";
    public static final String REQUEST_PARAMETERS_5_OPERATOR = "RequestParameters[5][Operator]";
    public static final String REQUEST_PARAMETERS_6_PARAM_NAME = "RequestParameters[6][ParamName]";
    public static final String REQUEST_PARAMETERS_6_PARAM_VALUES = "RequestParameters[6][Values][]";
    public static final String REQUEST_PARAMETERS_6_OPERATOR = "RequestParameters[6][Operator]";
    public static final String EXNTERNAL_ID = "ExternalID";
    public static final String USER_ID = "UserID";
    public static final String MPARAM = "Password";
    public static final String USER_TYPE = "UserType";
    public static final String PRODUCT_DETAILS_ID = "ProductDetailID";
    public static final String DATE = "Date";
    public static final String TERM_DATE = "TermDate";
    public static final String RECIPIENT_TYPE = "RecipientType";
    public static final String CLAIM_NUMBER = "ClaimNumber";
    public static final String PROFILE_ID = "ProfileID";
    public static final String ROLE_ID = "RoleID";
    public static final String LEVEL_CLASSIFICATION = "Level1_Classification";
    public static final String SUBSCRIBER_IDS = "SubscriberIDs[]";
    public static final String EXTERNAL_KEY2 = "External_key2";
    public static final String REQUEST = "request";
    public static final String REQUEST_LOB = "request[LOB]";
    public static final String REQUEST_BUSINESS_UNIT = "request[BusinessUnit]";
    public static final String REFERER = "Referer";
    public static final String REFERRER = "referrer";
    public static final String USER_AGENT = "User-Agent";
    public static final String WRESULT = "wresult";
    public static final String SID = "SID";
    public static final String WA = "wa";
    public static final String NEW_PARAM = "NewPassword";
    public static final String CURRENT_PARAM = "CurrentPassword";
    public static final String UPDATED_MEMBER_INFO_FIRSTNAME = "updatedMemberInfo[FirstName]";
    public static final String UPDATED_MEMBER_INFO_MIDDLENAME = "updatedMemberInfo[MiddleInitial]";
    public static final String UPDATED_MEMBER_INFO_LASTNAME = "updatedMemberInfo[LastName]";
    public static final String UPDATED_MEMBER_INFO_DOB = "updatedMemberInfo[DateOfBirth]";
    public static final String UPDATED_MEMBER_INFO_GENDER = "updatedMemberInfo[Gender]";
    public static final String UPDATED_MEMBER_INFO_PHONE = "updatedMemberInfo[PhoneNumber]";
    public static final String UPDATED_MEMBER_INFO_SUBID = "updatedMemberInfo[SubscriberID]";
    public static final String UPDATED_MEMBER_INFO_GROUPID = "updatedMemberInfo[GroupId]";
    public static final String UPDATED_MEMBER_INFO_PERSONNO = "updatedMemberInfo[PersonNumber]";
    public static final String UPDATED_MEMBER_INFO_EXTERNAL_KEY3 = "updatedMemberInfo[External_Key3]";
    public static final String UPDATED_MEMBER_INFO_PRODUCT_CODE = "updatedMemberInfo[ProductCode]";
    public static final String UPDATED_MEMBER_INFO_RELATIONSHIP_CODE = "updatedMemberInfo[RelationshipCode]";
    public static final String UPDATED_MEMBER_INFO_PLANNAME = "updatedMemberInfo[PlanName]";
    public static final String UPDATED_MEMBER_INFO_PLANTYPE = "updatedMemberInfo[PlanType]";
    public static final String UPDATED_MEMBER_INFO_COVERAGE_STARTDATE = "updatedMemberInfo[CoverageStartDate]";
    public static final String UPDATED_MEMBER_INFO_COVERAGE_ENDDATE = "updatedMemberInfo[CoverageEndDate]";
    public static final String UPDATED_MEMBER_INFO_ADDRESSES_0_ADDRESS1 = "updatedMemberInfo[Addresses][0][Address1]";
    public static final String UPDATED_MEMBER_INFO_ADDRESSES_0_ADDRESS2 = "updatedMemberInfo[Addresses][0][Address2]";
    public static final String UPDATED_MEMBER_INFO_ADDRESSES_0_CITY = "updatedMemberInfo[Addresses][0][City]";
    public static final String UPDATED_MEMBER_INFO_ADDRESSES_0_STATE = "updatedMemberInfo[Addresses][0][State]";
    public static final String UPDATED_MEMBER_INFO_ADDRESSES_0_COUNTY = "updatedMemberInfo[Addresses][0][County]";
    public static final String UPDATED_MEMBER_INFO_ADDRESSES_0_ZIPCODE = "updatedMemberInfo[Addresses][0][ZipCode]";
    public static final String UPDATED_MEMBER_INFO_ADDRESSES_0_HOMEPHONE = "updatedMemberInfo[Addresses][0][HomePhone]";
    public static final String UPDATED_MEMBER_INFO_ADDRESSES_0_ADRESSTYPE = "updatedMemberInfo[Addresses][0][AddressType]";
    public static final String UPDATED_MEMBER_INFO_ADDRESSES_1_ADDRESS1 = "updatedMemberInfo[Addresses][1][Address1]";
    public static final String UPDATED_MEMBER_INFO_ADDRESSES_1_ADDRESS2 = "updatedMemberInfo[Addresses][1][Address2]";
    public static final String UPDATED_MEMBER_INFO_ADDRESSES_1_CITY = "updatedMemberInfo[Addresses][1][City]";
    public static final String UPDATED_MEMBER_INFO_ADDRESSES_1_STATE = "updatedMemberInfo[Addresses][1][State]";
    public static final String UPDATED_MEMBER_INFO_ADDRESSES_1_COUNTY = "updatedMemberInfo[Addresses][1][County]";
    public static final String UPDATED_MEMBER_INFO_ADDRESSES_1_ZIPCODE = "updatedMemberInfo[Addresses][1][ZipCode]";
    public static final String UPDATED_MEMBER_INFO_ADDRESSES_1_HOMEPHONE = "updatedMemberInfo[Addresses][1][HomePhone]";
    public static final String UPDATED_MEMBER_INFO_ADDRESSES_1_ADRESSTYPE = "updatedMemberInfo[Addresses][1][AddressType]";


    public static final String REQUEST_TYPE_ACTION = "request[TypeAction]";
    public static final String REQUEST_SUBSCRIBER_ID = "request[SubscriberId]";
    public static final String REQUEST_PERSON_NUMBER = "request[personnumber]";


    // For GeoLocation Request
    public static final String ADDRESS_1 = "Address1";
    public static final String ADDRESS_2 = "Address2";
    public static final String CITY = "City";
    public static final String STATE = "State";
    public static final String ZIPCODE = "ZipCode";
    public static final String COUNTY_NAME = "CountyName";


    public static final String sessionid = "sessionid";
    public static final String MEMBER_ID = "MemberId";
    public static final String MEMBER_NAME = "MedicationName";
    public static final String SUBSCRIBER_FNAME = "SubscriberFName";
    public static final String SUBSCRIBER_LNAME = "SubscriberLName";
    public static final String MEMBER_FNAME = "MemberFName";
    public static final String MEMBER_LNAME = "MemberLName";
    public static final String DEVICE_ID = "DEVICE_ID";
    public static final String MEMBER_FIRST_NAME = "MEMBER_FIRST_NAME";
    public static final String MEMBER_LAST_NAME = "MEMBER_LAST_NAME";
    public static final String DEPENDEND_MEMBER_ID = "DEPENDEND_MEMBER_ID";
    public static final String NOTIFICATION_FLAG = "NOTIFICATION_FLAG";
    public static final String REMINDER_FLAG = "REMINDER_FLAG";
    public static final String APPOINTMENT_FLAG = "APPOINTMENT_FLAG";
    public static final String MEMBER_DOB = "MemberDOB";
    public static final String VACCINE_ID = "VaccineId";
    public static final String DOS = "DOS";
    public static final String DOA = "DOA";
    public static final String PROVIDER_NAME = "ProviderName";
    public static final String IMMUNIZATION_REQUEST = "ImmunizationRequest";
    public static final String INTAKEPLAN = "IntakePlan";
    public static final String DOSE = "Dose";
    public static final String UNIT = "Unit";
    public static final String STARTDATE = "StartDate";
    public static final String ENDDATE = "EndDate";
    public static final String SELECTEDTIMES = "SelectedTimes";
    public static final String IMAGE = "Image";
    public static final String SETREMINDER = "setReminder";
    public static final String REMINDERBEFORE = "reminderBefore";
    public static final String SELECTEDDAYS = "SelectedDays";


    public static final String UPDATE_PARAMETERS_6_PARAM_NAME = "UpdateParameters[6][ParamName]";
    public static final String UPDATE_PARAMETERS_6_PARAM_VALUE = "UpdateParameters[6][Value]";
    public static final String UPDATE_PARAMETERS_7_PARAM_NAME = "UpdateParameters[7][ParamName]";
    public static final String UPDATE_PARAMETERS_7_PARAM_VALUE = "UpdateParameters[7][Value]";
    public static final String UPDATE_PARAMETERS_8_PARAM_NAME = "UpdateParameters[8][ParamName]";
    public static final String UPDATE_PARAMETERS_8_PARAM_VALUE = "UpdateParameters[8][Value]";
    public static final String PLANTYPE = "PlanType";

    public static final String UPDATE_PARAMETERS_9_PARAM_NAME = "UpdateParameters[9][ParamName]";
    public static final String UPDATE_PARAMETERS_9_PARAM_VALUE = "UpdateParameters[9][Value]";

    // TCC
    public static final String PROCEDURE_CODE = "ProcedureCode";
    public static final String SELECTED_PLAN = "SelectedPlan"; // New Enhancement Mar-10-2020

    // Change Security Question
    public static final String EMAIL_ID = "Email_ID";
    public static final String QUESTION_LIST = "QuestionList";
    public static final String ANSWER_LIST = "AnswerList";

    // PCP
    public static final String GET_PCP_REQUEST_ZIPCODE = "getPCPRequest[ZipCode]";
    public static final String GET_PCP_REQUEST_PROVIDER_TYPE = "getPCPRequest[ProviderType]";
    public static final String GET_PCP_REQUEST_PLAN = "getPCPRequest[Plan]";
    public static final String GET_PCP_REQUEST_IS_PRIMARY_CARE = "getPCPRequest[IsPrimaryCareProvider]";
    public static final String GET_PCP_REQUEST_FIRST_NAME = "getPCPRequest[FirstName]";
    public static final String GET_PCP_REQUEST_LAST_NAME = "getPCPRequest[LastName]";
    public static final String GET_PCP_REQUEST_CLINIC_NAME = "getPCPRequest[ClinicName]";
    public static final String GET_PCP_REQUEST_ORGANIZATION_NAME = "getPCPRequest[OrganizationName]";
    public static final String GET_PCP_REQUEST_GENDER = "getPCPRequest[Gender]";
    public static final String GET_PCP_REQUEST_SPECIALITY = "getPCPRequest[Speciality]";
    public static final String GET_PCP_REQUEST_AREA_OF_EXPERTISE = "getPCPRequest[AreaofExpertise]";
    public static final String GET_PCP_REQUEST_HOSPITAL_AFFILIATION = "getPCPRequest[HospitalAffilation]";
    public static final String GET_PCP_REQUEST_LANGUAGE_SPOKEN = "getPCPRequest[LanguageSupported]";
    public static final String GET_PCP_REQUEST_DISTANCE = "getPCPRequest[Distance]";
    public static final String GET_PCP_REQUEST_ACCEPTING_NEW_PATIENTS = "getPCPRequest[IsAcceptingNewPatients]";
    public static final String GET_PCP_REQUEST_IS_BOARDING_CERTIFICATE = "getPCPRequest[IsBoardCertificationAccreditation]";
    public static final String GET_PCP_REQUEST_IS_ADA_ACCESSIBILITY = "getPCPRequest[IsADAAccessibility]";
    public static final String GET_PCP_REQUEST_IS_TELEMEDICINE = "getPCPRequest[IsTelemedicine]";
    public static final String GET_PCP_REQUEST_IS_URGENT_CARE_FACILITY = "getPCPRequest[IsUrgentCareFacility]";
    public static final String GET_PCP_REQUEST_IS_EXTENDED_HOURS = "getPCPRequest[IsExtendedHours]";
    public static final String GET_PCP_REQUEST_IS_ACCREDITATION = "getPCPRequest[IsAccreditation]";
    public static final String GET_PCP_REQUEST_FACILITY_NAME = "getPCPRequest[FacilityName]";
    public static final String GET_PCP_REQUEST_CLINICAL_STAFF_LANGUAGE = "getPCPRequest[ClinicalStaffLanguage]";
    public static final String GET_PCP_REQUEST_IS_INTERPRETATION_SERVICES = "getPCPRequest[IsInterpretation_Services]";
    public static final String GET_PCP_REQUEST_UPDATED_DATE = "getPCPRequest[Updated_Date]";
    public static final String GET_PCP_REQUEST_LANGUAGE_KEY = "getPCPRequest[LanguageKey]";
    public static final String GET_PCP_REQUEST_BLANK_SEARCH = "getPCPRequest[BlankSearch]";
    public static final String GET_PCP_REQUEST_PAGE_ID = "getPCPRequest[PageID]";
    public static final String GET_PCP_REQUEST_PAGE_SIZE = "getPCPRequest[PageSize]";
    public static final String GET_PCP_REQUEST_LATITUDE = "getPCPRequest[Latitude]";
    public static final String GET_PCP_REQUEST_LONGITUDE = "getPCPRequest[Longitude]";


}
