package com.wps.memberapp.utility;

public class NetworkConfigValues {
    public static final String SET_REMINDER_VALUE = "true";
    public static final String IN = "IN";

    private NetworkConfigValues() {
    }

    public static final String MESSAGES = "MESSAGES";
    public static final String REPLY = "REPLY";
    public static final String LIST = "LIST";
    public static final String DETAILS = "DETAILS";
    public static final String MESSAGE_ID = "MessageId";
    public static final String CREATE = "CREATE";
    public static final String TYPE = "Type";
    public static final String ONE = "1";
    public static final String HEADER = "Header";
    public static final String CDATA = "<![CDATA[ <HEADERS><HEADER/></HEADER>  ]]>";
    public static final String MSG_TEXT = "MsgText";
    public static final String PRIOR = "Prior";
    public static final String ZERO = "0";
    public static final String MSG_SUB = "MsgSubject";
    public static final String MSG_WF_STATUS = "MsgWfStatus";
    public static final String CLAIMS = "CLAIMS";
    public static final String CLAIMDETAILS ="DENTCLAIMDETAILS"; // "CLAIMDETAILS";(For external - environment)
    static final String CLAIMLIST = "CLAIMLIST";
    static final String CLAIMLISTSUBSCRIBER = "CLAIMLISTSUBSCRIBER";
    public static final String TEN = "10";
    public static final String TWENTY = "20";
    public static final String TWENTY_FIVE = "25";
    public static final String THIRTY = "30";
    public static final String STATUS = "Status";
    public static final String EQ = "EQ";
    public static final String FROM_DATE = "FromDate";
    public static final String GE = "GE";
    public static final String TO_DATE = "Todate";
    public static final String LE = "LE";
    public static final String MEMBER_FNAME = "MemberFName";
    public static final String MEMBER_LNAME = "MemberLName";
    public static final String PERSON_NO = "PERSON_NO";
    public static final String AUTHS = "AUTHS";
    public static final String AUTHDETAILS = "AUTHDETAILS";
    public static final String AUTH_NUMBER = "AuthNumber";
    static final String AUTHSEARCH = "AUTHSEARCH";
    static final String AUTHSEARCH_SUBSCRIBER = "AUTHSEARCH_SUBSCRIBER";
    public static final String FIRST_NAME = "FirstName";
    public static final String LAST_NAME = "LastName";
    public static final String BT = "BT";
    public static final String AS_OF = "AsOF";
    public static final String BENIFITS = "BENIFITS";
    public static final String BENIFITS_MEMBER_LIST = "BENIFITS_MEMBER_LIST";
    public static final String EFFECTIVE_DATE = "EffectiveDate";
    public static final String CLAIM_NUMBER = "ClaimNumber";
    public static final String MEMBER = "Member";
    public static final String CY = "CY";
    public static final String MEMBCLAIMSUMMARY = "MEMBCLAIMSUMMARY";
    public static final String MEMBCLAIMSUMMARY_FOR_SUBSCRIBER = "MEMBCLAIMSUMMARYFORSUBSCRIBER";
    public static final String REQ = "Req";
    public static final String REF_NUMBER = "ReferenceNumber";
    public static final String SUBJECT = "Subject";
    public static final String MESSID = "MessID";
    public static final String REPLY_TEXT = "ReplyText";
    public static final String SID = "SId";
    public static final String HASH_CODE = "HashCode";
    //    public static final String REFERER_VALUE = "https://external.digitalhealth.nttdataservices.com/en/member/page";
//    public static final String REFERER_VALUE = "https://external-akamai.healthcare.nttdataservices.com/en/member/page";
    public static final String REFERER_VALUE = "https://sit1-external.digitalhealth.nttdataservices.com/en/member/page";    //SIT1
    public static final String OLD_USER_AGENT_VALUE = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36";
    // Checking while Steve's Call
    public static final String USER_AGENT_VALUE = "Dalvik";
//    public static final String USER_AGENT_VALUE="Android";

    public static final String UPLOADED_FILE_NAME = "UploadedFileName";
    public static final String GENERATED_FILE_NAME = "GeneratedFileName";
    public static final String CURRENT_REL_ENTY_ID = "Current_Rel_Enty_Id";
    public static final String REPORTS = "REPORTS";
    public static final String CITYCOUNTY = "CITYCOUNTY";
    public static final String PRACTICEGROUP = "PRACTICEGROUP";
    public static final String SPECIALITY = "SPECIALITY";
    public static final String SPECIALTY = "SPECIALTY";
    public static final String AFFILIATEDLIST = "AFFILIATEDLIST";
    public static final String CLINICNAME = "CLINICNAME";
    public static final String AREAOFEXPERTISE = "AREAOFEXPERTISE";
    public static final String HOSPITAL_AFFILIATED = "HOSPITAL_AFFILIATED";
    public static final String CLAIM_TYPE = "Claim_Type";
    public static final String CDATA_OPT = "<![CDATA[opt]]>";
    public static final String TYPE_ID = "TypeID";
    public static final String PROVIDER_ID = "ProviderID";
    public static final String CN = "CN";


}
