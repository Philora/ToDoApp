package com.wps.memberapp.utility;
import java.util.List;

public interface PermissionResultCallback
{
    void permissionGranted(int requestCode);
    void partialPermissionGranted(int requestCode, List<String> grantedPermissions);
    void permissionDenied(int requestCode);
    void neverAskAgain(int requestCode);
}
