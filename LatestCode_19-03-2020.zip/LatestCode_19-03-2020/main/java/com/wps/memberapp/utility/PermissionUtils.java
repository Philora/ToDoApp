package com.wps.memberapp.utility;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;


public class PermissionUtils {

    private final Activity currentActivity;
    private static final int MY_PERMISSIONS_REQUEST_WRITE_CALENDAR = 123;

    private final PermissionResultCallback permissionResultCallback;

    private List<String> permissionList = new ArrayList<>();
    private List<String> listPermissionsNeeded = new ArrayList<>();
    private String dialogContent = "";
    private int reqCode;

    public PermissionUtils(Context context) {
        this.currentActivity = (Activity) context;
        permissionResultCallback = (PermissionResultCallback) context;
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == 1 && grantResults.length > 0) {
            Map<String, Integer> perms = new HashMap<>();

            for (int i = 0; i < permissions.length; i++) {
                perms.put(permissions[i], grantResults[i]);
            }

            final ArrayList<String> pendingPermissions = new ArrayList<>();

            for (int i = 0; i < listPermissionsNeeded.size(); i++) {
                if (perms.get(listPermissionsNeeded.get(i)) != PackageManager.PERMISSION_GRANTED) {
                    if (ActivityCompat.shouldShowRequestPermissionRationale(currentActivity, listPermissionsNeeded.get(i))) {
                        pendingPermissions.add(listPermissionsNeeded.get(i));
                    } else {
                        Log.i("Go to settings", "and enable permissions");
                        permissionResultCallback.neverAskAgain(reqCode);
                        Toast.makeText(currentActivity, "Go to settings and enable permissions", Toast.LENGTH_LONG).show();
                        return;
                    }
                }

            }

            if (!pendingPermissions.isEmpty()) {
                showMessageOKCancel(new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        switch (which) {
                            case DialogInterface.BUTTON_POSITIVE:
                                checkPermission(permissionList, dialogContent, reqCode);
                                break;
                            case DialogInterface.BUTTON_NEGATIVE:
                                Log.i("permisson", "not fully given");
                                if (permissionList.size() == pendingPermissions.size())
                                    permissionResultCallback.permissionDenied(reqCode);
                                else
                                    permissionResultCallback.partialPermissionGranted(reqCode, pendingPermissions);
                                break;
                            default:
                                break;
                        }


                    }
                });

            } else {
                Log.i("all", "permissions granted");
                Log.i("proceed1", "to next step");
                permissionResultCallback.permissionGranted(reqCode);

            }
        }
    }

    /**
     * Check the API Level & Permission
     */

    public void checkPermission(List<String> permissions, String dialogContent, int requestCode) {
        this.permissionList = permissions;
        this.dialogContent = dialogContent;
        this.reqCode = requestCode;

        if (Build.VERSION.SDK_INT >= 23) {
            if (checkAndRequestPermissions(permissions, requestCode)) {
                permissionResultCallback.permissionGranted(requestCode);
                Log.i("all permissions", "granted");
                Log.i("proceed", "to callback");
            }
        } else {
            permissionResultCallback.permissionGranted(requestCode);

            Log.i("all permissions", "granted");
            Log.i("proceed2", "to callback");
        }

    }


    /**
     * Check and request the Permissions
     */

    private boolean checkAndRequestPermissions(List<String> permissions, int requestCode) {

        if (!permissions.isEmpty()) {
            listPermissionsNeeded = new ArrayList<>();

            for (int i = 0; i < permissions.size(); i++) {
                int hasPermission = ContextCompat.checkSelfPermission(currentActivity, permissions.get(i));

                if (hasPermission != PackageManager.PERMISSION_GRANTED) {
                    listPermissionsNeeded.add(permissions.get(i));
                }

            }

            if (!listPermissionsNeeded.isEmpty()) {
                ActivityCompat.requestPermissions(currentActivity, listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), requestCode);
                return false;
            }
        }

        return true;
    }

    /**
     * Explain app needs for permissions
     */
    private void showMessageOKCancel(DialogInterface.OnClickListener okListener) {
        new AlertDialog.Builder(currentActivity)
                .setMessage("Camera and Location Services Permission required for this app")
                .setPositiveButton("Ok", okListener)
                .setNegativeButton("Cancel", okListener)
                .create()
                .show();
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    public static boolean checkPermission(final Context context1) {
        int currentAPIVersion = Build.VERSION.SDK_INT;
        if (currentAPIVersion >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(context1, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                if (ActivityCompat.shouldShowRequestPermissionRationale((Activity) context1, Manifest.permission.CAMERA)) {
                    AlertDialog.Builder alertBuilder = new AlertDialog.Builder(context1);
                    alertBuilder.setCancelable(false);
                    alertBuilder.setTitle("Permission necessary");
                    alertBuilder.setMessage("Camera permission is necessary to take photo!!!");
                    alertBuilder.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                        @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions((Activity) context1, new String[]{Manifest.permission.CAMERA}, MY_PERMISSIONS_REQUEST_WRITE_CALENDAR);
                        }
                    });
                    AlertDialog alert = alertBuilder.create();
                    alert.show();
                } else {
                    ActivityCompat.requestPermissions((Activity) context1, new String[]{Manifest.permission.CAMERA}, MY_PERMISSIONS_REQUEST_WRITE_CALENDAR);
                }
                return false;
            } else {
                return true;
            }
        } else {
            return true;
        }
    }

}
