package com.wps.memberapp.utility;

import android.app.DialogFragment;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.TimePicker;


import com.wps.memberapp.R;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;


public class ReminderAlertDialog extends DialogFragment {

    private TextView selectedTime;
    private TextView pickTime;

    public static ReminderAlertDialog newInstance() {
        return new ReminderAlertDialog();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.frag_reminder_alert, container,
                false);
        getDialog().requestWindowFeature(STYLE_NO_TITLE);
        getDialog().setCancelable(false);
        TextView onTime = rootView.findViewById(R.id.onTime);
        pickTime = rootView.findViewById(R.id.pickTime);
        TextView cancel = rootView.findViewById(R.id.cancel);
        TextView ok = rootView.findViewById(R.id.ok);

        Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT+1:00"));
        Date currentLocalTime = cal.getTime();
        DateFormat date = new SimpleDateFormat("HH:mm a", Locale.US);

        date.setTimeZone(TimeZone.getTimeZone("GMT+5:30"));

        String localTime = date.format(currentLocalTime);
        String time="Now" + " "+ localTime;
        onTime.setText(time);

        cancel.setOnClickListener(view -> dismiss());

        ok.setOnClickListener(view -> dismiss());

        pickTime.setOnClickListener(view -> {
            Calendar mcurrentTime = Calendar.getInstance();
            int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
            int minute = mcurrentTime.get(Calendar.MINUTE);
            TimePickerDialog mTimePicker;
            mTimePicker = new TimePickerDialog(getActivity(), new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                    String time1 =selectedHour + ":" + selectedMinute;
                    pickTime.setText(time1);
                }
            }, hour, minute, true);//Yes 24 hour time
            mTimePicker.setTitle("Select Time");
            mTimePicker.show();
        });
        return rootView;
    }
}
