package com.wps.memberapp.utility;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;

import com.wps.memberapp.R;
import com.wps.memberapp.data.preferences.SharedPreferenceHelper;


public class SessionManagementDialog extends DialogFragment {
    /**
     * Create a new instance of AlertDialogFragment.
     */
    @NonNull
    public static SessionManagementDialog newInstance(int title, String message) {
        SessionManagementDialog f = new SessionManagementDialog();
        Bundle args = new Bundle();
        args.putInt("title", title);
        args.putString("message", message);
        f.setArguments(args);
        return f;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NORMAL, R.style.DialogFragmentTheme);

    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        String title = "";
        String msg = "";
        if (getActivity() != null && getArguments() != null) {
            title = getActivity().getString(getArguments().getInt("title"));
            msg = getArguments().getString("message");
        }
        return new AlertDialog.Builder(getActivity())
                .setCancelable(false)
                .setTitle(title)
                .setMessage(msg)
                .setPositiveButton(R.string.dialog_ok_action, (dialog, which) ->
                        logout())
                .create();

    }

    @Override
    public void onCancel(DialogInterface dialog) {
        super.onCancel(dialog);
        logout();
    }

    private void logout() {
        if (getActivity() != null) {
            SharedPreferenceHelper.getInstance().clearPreference(getActivity(), AppConstants.AUTHORIZATION_TOKEN);
            SharedPreferenceHelper.getInstance().clearPreference(getActivity(), "FedAuth");
            SharedPreferenceHelper.getInstance().clearPreference(getActivity(), "FedAuth1");
            GeneralUtils.logoutApp(getActivity());
        }
    }
}
