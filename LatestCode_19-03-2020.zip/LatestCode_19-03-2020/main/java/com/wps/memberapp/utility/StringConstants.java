package com.wps.memberapp.utility;

public class StringConstants {
    public static final String sessionid = "sessionid";
    public static final String intakePlanValue = "intakePlanValue";
    public static final String doseValueSelectedItem = "doseValueSelectedItem";
    public static final String doseUnitValueSelectedItem ="doseUnitValueSelectedItem";
    public static final String medicine_name="medicine_name";
    public static final String startDate = "startDate";
    public static final String endDate ="endDate";
    public static final String MEMBER_ID = "MEMBER_ID";
    public static final String VACCINE_GROUP_ID = "VACCINE_GROUP_ID";
    public static final String reminder_time = "reminder_time";
    public static final String DATE_OF_SERVICE = "DATE_OF_SERVICE";
    public static final String PROVIDER_NAME = "PROVIDER_NAME";
    public static final String MEMBER_FNAME = "MEMBER_FNAME";
    public static final String MEMBER_LNAME = "MEMBER_LNAME";
    public static final String MEMBER_DOB = "MEMBER_DOB";
    public static final String DAY_OF_WEEK = "DAY_OF_WEEK" ;
    public static final String FIRST_NAME = "FIRSTNAME";
    public static final String LAST_NAME = "LASTNAME";


    private StringConstants() {
    }

    public static final String DEFAULT_TEXT_ENCODING = "UTF-8";
    public static final String MIME_TYPE_HTML = "text/html";
    public static final String EXCEPTION = "exception";
    public static final String CONTENT_TYPE = "Content-Type";
//    public static final String DOMAIN_NAME = "external.digitalhealth";
    public static final String DOMAIN_NAME = "sit1-external.digitalhealth"; //SIT1
//    public static final String DOMAIN_NAME = "external-akamai.healthcare";
    public static final String USERNAME_REGEX = "[^a-z0-9_.]";
    public static final String MPARAM_REGEX = "^(?=.*[a-z])(?=.*[A-Z])(?=.*[-_&%$#])(?=.*\\d).+$";
    public static final String LOB_WPS = "WPS";
    public static final String LOB_AAH = "AAH";
    public static final String ENTITY_ID_MEDMARSOL = "MEDMARSOL";
    public static final String ENTITY_ID_EMPLYRSOL = "EMPLYRSOL";
    public static final String ENTITY_ID_COMMSOLGR = "COMMSOLGR";
    public static final String ENTITY_ID_COMMSOLIN = "COMMSOLIN";
    public static final String SPACE_SINGLE = " ";
    public static final String BENEFITS_KEY = "BenfAccumulators";
    public static final String APP_DYNAMICS_KEY = "AD-AAB-AAM-DKJ";
    public static final String PARAM2 = "username";
    public static final String PARAM1 = "password";
    public static final String STARTDATE = "<<startdate>>";
    public static final String ENDDATE = "<<enddate>>";
    public static final String RESPONSE = "Success_Response";
    public static final String ERROR = "Error";
    public static final String SELECTED_DAY = "SELECTED_DAY";



    public static final String DENTAL = "Dental";
    public static final String DENTCLAIMDETAILS = "DENTCLAIMDETAILS";
    public static final String PHARMACY = "Pharmacy";
    public static final String PHARMCLAIMDETAILS = "PHARMCLAIMDETAILS";
    public static final String PROFESSIONAL = "Professional";
    public static final String PROF_CLAIMDETAILS = "PROF_CLAIMDETAILS";
    public static final String INSTITUTIONAL = "Institutional";
    public static final String INSTCLAIMDETAILS = "INSTCLAIMDETAILS";
    public static final String TCC_DATAS = "tCCDatas";



    public static final String Ref_MemberID_Colon = "Ref : MemberID : ";
    public static final String Ref_Member_ID_Colon = "Ref : Member ID : ";
    public static final String Claim_Number_Colon = " Claim Number : ";
    public static final String Dot_Space = ". ";
    public static final String Authorization_Number_Colon = " Authorization Number : ";



}
